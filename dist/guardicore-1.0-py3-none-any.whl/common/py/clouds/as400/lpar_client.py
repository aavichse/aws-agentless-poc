from ftplib import FTP, FTP_TLS
from common.logger import get_logger
from datetime import datetime
import ssl
from collections import namedtuple

LOG = get_logger(module_name=__name__)
FTPS_DEFAULT_PORT = 990
CON_TIMEOUT = 60


class ImplicitFTP_TLS(FTP_TLS):
    """FTP_TLS subclass to support implicit FTPS."""
    """Constructor takes a boolean parameter ignore_PASV_host whether o ignore the hostname"""
    """in the PASV response, and use the hostname from the session instead"""

    def __init__(self, *args, **kwargs):
        self.ignore_PASV_host = kwargs.get('ignore_PASV_host')
        kwargs = {k: v for k, v in kwargs.items() if not k == 'ignore_PASV_host'}
        super().__init__(*args, **kwargs)
        self._sock = None

    @property
    def sock(self):
        """Return the socket."""
        return self._sock

    @sock.setter
    def sock(self, value):
        """When modifying the socket, ensure that it is ssl wrapped."""
        if value is not None and not isinstance(value, ssl.SSLSocket):
            value = self.context.wrap_socket(value)
        self._sock = value

    def ntransfercmd(self, cmd, rest=None):
        """Override the ntransfercmd method"""
        conn, size = FTP.ntransfercmd(self, cmd, rest)
        conn = self.sock.context.wrap_socket(conn, server_hostname=self.host)
        return conn, size

    def makepasv(self):
        host, port = super().makepasv()
        return (self.host if self.ignore_PASV_host else host), port


class LPARClient(object):
    def __init__(self, port=None, **kwargs):
        self.lpar_name = kwargs['name']
        self.ip = kwargs['ip']
        self.user = kwargs['user']
        self.password = kwargs['password']
        self.port = port
        self.connection = None
        self.open_time = None
        self.con_reuse = kwargs['con_reuse_time']
        self.data_ips = kwargs['data_ips']
        self.use_ftps = kwargs['use_ftps']
        # If FTPs passive server is behind a NAT we need to ignore the passive HOST returned by server and use the
        # original host ip
        self.ignore_pasv_host = kwargs['ignore_pasv_host']

    def initialize(self):
        self._connect()

    def connect_ftps(self):
        try:
            self.connection = ImplicitFTP_TLS(ignore_PASV_host=self.ignore_pasv_host)
            if self.port:
                self.connection.connect(host=self.ip, port=self.port, timeout=CON_TIMEOUT)
            else:
                self.connection.connect(host=self.ip, port=FTPS_DEFAULT_PORT, timeout=CON_TIMEOUT)
        except Exception as exc:
            LOG.exception("Failed to connect to LPAR: {}".format(self.lpar_name))
            self.connection = None

    def connect_ftp(self):
        try:
            if self.port:
                self.connection = FTP()
                self.connection.connect(self.ip, self.port, timeout=CON_TIMEOUT)
            else:
                self.connection = FTP(self.ip, timeout=CON_TIMEOUT)
        except Exception as exc:
            LOG.exception("Failed to connect to LPAR: {}".format(self.lpar_name))
            self.connection = None

    def _connect(self):
        if self.connection:
            self.connection = None
        if self.use_ftps:
            self.connect_ftps()
        else:
            self.connect_ftp()
        if self.connection:
            try:
                self.connection.login(self.user, self.password)
                if self.use_ftps:
                    self.connection.prot_p()
                self.connection.sendcmd('RCMD CHGJOB LOG(4 00 *SECLVL) LOGCLPGM(*YES)')
                self.connection.sendcmd(
                    "RCMD SNDMSG MSG('GC: A Guardicore new connection is starting.')"
                    " TOMSGQ(*SYSOPR) MSGTYPE(*INFO)")
            except Exception as exc:
                LOG.exception("Failed to connect to LPAR: {}".format(self.lpar_name))
                self.connection = None
            self.open_time = datetime.now()
            LOG.debug("Connected to LPAR {} successfully at {}".format(self.lpar_name, self.open_time))

    @property
    def name(self):
        return self.lpar_name

    def get_connection(self, force=False):
        if not force and self.connection and (
                self.open_time and (datetime.now() - self.open_time).total_seconds() < self.con_reuse):
            return self.connection
        else:
            LOG.debug("Opening a new FTP connection for LPAR: {}, on IP: {}, port: {}".format(self.lpar_name, self.ip,
                                                                                              self.port))
            self._connect()
        return self.connection

    def on_error(self):
        self.connection.sendcmd('RCMD DSPJOBLOG OUTPUT(*PRINT)')
        self.connection.sendcmd(
            "RCMD SNDMSG MSG('GC:A Guardicore connection has ended with suspected errors. "
            "Check job log.') TOMSGQ(*SYSOPR) MSGTYPE(*INFO)")
