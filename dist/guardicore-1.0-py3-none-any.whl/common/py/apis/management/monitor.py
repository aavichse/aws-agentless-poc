import base64
import traceback
from datetime import datetime

from common.py.apis import DEFAULT_RABBITMQ_PASSWORD, DEFAULT_RABBITMQ_USERNAME, UpgradeStatus, \
    RPCExchange, RPCQueue, RPCMessage
from common.logger import get_logger
from common.py.apis.management.rabbit import RabbitMQManagementAPI

__author__ = 'Amit'

LOG = get_logger(module_name=__name__)


class MonitoredServicesManagerManagementAPI(object):
    def __init__(self, management_hosts,
                 monitor_id,
                 user=DEFAULT_RABBITMQ_USERNAME, password=DEFAULT_RABBITMQ_PASSWORD,
                 transport_type='gevent', rabbitmq_use_ssl=True, **kwargs):
        self.monitor_id = monitor_id
        self.rabbitapi = None

        for index, management_host in enumerate(management_hosts):
            try:
                self.rabbitapi = RabbitMQManagementAPI(management_host=management_host,
                                                       exchange=RPCExchange.MONITOR_EXCHANGE_NAME,
                                                       transport_type=transport_type,
                                                       component_id=self.monitor_id,
                                                       queue_name=self.monitor_id,
                                                       user=user, password=password,
                                                       exchange_type='fanout',
                                                       routing_keys=None,
                                                       rabbitmq_use_ssl=rabbitmq_use_ssl,
                                                       rpc_call_default_exchange='',
                                                       rpc_call_default_routing_key=RPCQueue.MONITOR_RPC_QUEUE_NAME,
                                                       **kwargs)
                break
            except Exception as exc:
                if index < len(management_hosts) - 1:
                    LOG.warn("Error connecting to rabbit of management host '%s' from monicore %s: %s",
                             management_host, self.monitor_id, exc)
                else:
                    raise

        LOG.debug("Opened new RabbitMQ API connection to management host '%s' for monicore %s",
                  self.rabbitapi.management_host, self.monitor_id)

        self.progress_order = 0

        try:
            self.send_i_am_alive()
        except:
            self.rabbitapi.close()
            raise

    def __del__(self):
        self.close()

    def send_i_am_alive(self):
        self.rabbitapi.call_management_rpc(RPCMessage.Monitor.MONITOR_MANAGER_IS_UP_FUNC_NAME,
                                           monitor_id=self.monitor_id,
                                           blocking=True)

    def close(self):
        if self.rabbitapi:
            LOG.debug("Closing RabbitMQ API connection to management host '%s' for monicore %s",
                      self.rabbitapi.management_host, self.monitor_id)
            self.rabbitapi.close()
            self.rabbitapi = None

    def add_error_callback(self, callback_func):
        """
        See rabbitapi.add_error_callback
        """
        self.rabbitapi.add_error_callback(callback_func)

    def add_read_loop_error_callback(self, callback_func):
        """
        See rabbitapi.add_read_loop_error_callback
        """
        self.rabbitapi.add_read_loop_error_callback(callback_func)

    def add_msg_callback_error_callback(self, callback_func):
        """
        See rabbitapi.add_msg_callback_error_callback
        """
        self.rabbitapi.add_msg_callback_error_callback(callback_func)

    def add_get_debug_logs_callback(self, callback_func):
        """
        :param callback_func: This function will be called whenever the management needs to get debug log files.
        The return value should be a file object which contains a .tar.gz with all relevant logs.
        """

        def get_debug_logs(message_content):
            services_list = message_content.get('services_list', None)
            rotated_logs = message_content.get('rotated_logs', False)

            log_file = None
            try:
                log_file = callback_func(services_list, rotated_logs)
            except:
                LOG.exception("Error in get_debug_logs callback")

            if not log_file:
                LOG.error("Didn't get debug log from component(s): {}".format(services_list))

                self.rabbitapi.call_management_rpc(RPCMessage.Monitor.MONITOR_PUT_DEBUG_LOG_RPC_FUNC_NAME,
                                                   monitor_id=self.monitor_id,
                                                   file_data=None)
            else:
                # decode added to prevent json dump create list of ints repr. chars
                self.rabbitapi.call_management_rpc(RPCMessage.Monitor.MONITOR_PUT_DEBUG_LOG_RPC_FUNC_NAME,
                                                   monitor_id=self.monitor_id,
                                                   file_data=base64.b64encode(log_file.read()).decode('utf-8'))
                log_file.close()

        self.rabbitapi.add_callback(RPCMessage.Monitor.MONITOR_GET_DEBUG_LOGS_MESSAGE_TYPE, get_debug_logs)

    def report_monitored_services_status(self, monitored_services_status):
        self.rabbitapi.call_management_rpc(RPCMessage.Monitor.MONITOR_REPORT_SERVICES_STATUS_RPC_FUNC_NAME,
                                           monitor_id=self.monitor_id,
                                           monitored_services_status=monitored_services_status)

    def report_monitored_services_information(self, monitored_services_information):
        self.rabbitapi.call_management_rpc(RPCMessage.Monitor.MONITOR_REPORT_SERVICES_INFORMATION_RPC_FUNC_NAME,
                                           monitor_id=self.monitor_id,
                                           monitored_services_information=monitored_services_information)

    def _change_services_status_callback(self, message_content, callback_func, rpc_func_name):
        services_list = message_content.get('services_list', None)

        error = None
        try:
            callback_func(services_list, filter_safe_to_stop=False)
        except:
            LOG.exception("Error while calling change services status callback %s", callback_func)
            error = traceback.format_exc()

        self.rabbitapi.call_management_rpc(rpc_func_name,
                                           monitor_id=self.monitor_id,
                                           error=error)

    def add_start_services_callback(self, callback_func):
        self.rabbitapi.add_callback(
            RPCMessage.Monitor.MONITOR_START_SERVICE_MESSAGE_TYPE,
            lambda message_content: self._change_services_status_callback(message_content,
                                                                          callback_func,
                                                                          RPCMessage.Monitor.MONITOR_START_SERVICES_RPC_FUNC_NAME))

    def add_stop_services_callback(self, callback_func):
        self.rabbitapi.add_callback(
            RPCMessage.Monitor.MONITOR_STOP_SERVICE_MESSAGE_TYPE,
            lambda message_content: self._change_services_status_callback(message_content,
                                                                          callback_func,
                                                                          RPCMessage.Monitor.MONITOR_STOP_SERVICES_RPC_FUNC_NAME))

    def add_restart_services_callback(self, callback_func):
        self.rabbitapi.add_callback(
            RPCMessage.Monitor.MONITOR_RESTART_SERVICE_MESSAGE_TYPE,
            lambda message_content: self._change_services_status_callback(message_content,
                                                                          callback_func,
                                                                          RPCMessage.Monitor.MONITOR_RESTART_SERVICES_RPC_FUNC_NAME))

    def add_initiate_ansible_upgrade_callback(self, callback_func):
        """
        :param callback_func: A function which will be called whenever a full upgrade is initiated
        :return:
        """

        def initiate_full_upgrade(message_content):
            try:
                callback_func()
            except Exception as exc:
                LOG.error("Caught exception while upgrading  %s", exc)
                self.rabbitapi.send_message(message_type=RPCMessage.Monitor.UPGRADE_STATUS_MESSAGE_TYPE,
                                            routing_key=RPCQueue.MANAGEMENT_UPGRADER_QUEUE_NAME,
                                            monitor_id=self.monitor_id,
                                            status=UpgradeStatus.Failed.value,
                                            error="Error while initiating upgrade: %s" % (traceback.format_exc(),),
                                            was_rollbacked=True)

        self.rabbitapi.add_callback(RPCMessage.Monitor.INITIATE_UPGRADE_MESSAGE_TYPE, initiate_full_upgrade)

    def add_initiate_rootfs_upgrade_callback(self, callback_func):
        """
        :param callback_func: A function which will be called whenever a rootfs upgrade is started or continued
        """

        def initiate_rootfs_upgrade(message_content):
            status = UpgradeStatus.Successful.value
            error = ""

            try:
                LOG.info("Triggering rootfs upgrade callback, received args: {}".format(message_content))
                callback_func(action=message_content["action"], priority=message_content["priority"])
            except Exception as exc:
                LOG.error("Caught exception while setting rootfs upgrade control maps %s", exc)
                status = UpgradeStatus.Failed.value
                error = "Error setting rootfs control maps: %s" % (traceback.format_exc(),)
            finally:
                routing_key = message_content.get("status_queue", None)
                if not routing_key:
                    LOG.error("Cannot send status reply message. Missing status queue name information.")
                    return
                self.rabbitapi.send_message(message_type=RPCMessage.Monitor.ROOTFS_UPGRADE_STATUS_MESSAGE_TYPE,
                                            routing_key=routing_key,
                                            monitor_id=self.monitor_id,
                                            status=status,
                                            error=error)

        self.rabbitapi.add_callback(RPCMessage.Monitor.INITIATE_ROOTFS_UPGRADE_MESSAGE_TYPE, initiate_rootfs_upgrade)

    def add_initiate_differential_patch_callback(self, callback_func):
        """
        :param callback_func: A function which will be called whenever a differential patch procedure is initiated
        :return:
        """

        def initiate_differential_patch(message_content):
            try:
                if message_content['message_type'] != RPCMessage.Monitor.INITIATE_DIFFERENTIAL_PATCH_MESSAGE_TYPE:
                    raise TypeError("Expecting message type: %s, received: %s",
                                    RPCMessage.Monitor.INITIATE_DIFFERENTIAL_PATCH_MESSAGE_TYPE,
                                    message_content['message_type'])

                callback_func(message_content)
            except Exception as exc:
                LOG.error("Caught exception while performing differential patch %s", exc)
                self.rabbitapi.send_message(message_type=RPCMessage.Monitor.DIFFERENTIAL_PATCH_STATUS_MESSAGE_TYPE,
                                            routing_key=RPCQueue.MANAGEMENT_DIFFPATCH_QUEUE_NAME,
                                            monitor_id=self.monitor_id,
                                            status=UpgradeStatus.Failed.value,
                                            error="Error while initiating differential patch: %s" % (
                                            traceback.format_exc(),),
                                            was_rollbacked=True)

        self.rabbitapi.add_callback(RPCMessage.Monitor.INITIATE_DIFFERENTIAL_PATCH_MESSAGE_TYPE,
                                    initiate_differential_patch)

    def notify_upgrade_started(self, upgrade_cfgs):
        LOG.info("Initiating %s on %s", upgrade_cfgs.name, self.monitor_id)
        self.initialize_progress()
        self.rabbitapi.send_message(message_type=upgrade_cfgs.rpc_message_type, routing_key=upgrade_cfgs.rpc_queue_name,
                                    monitor_id=self.monitor_id, status=UpgradeStatus.Started.value, was_rollbacked=True)

    def notify_upgrade_in_progress(self, upgrade_cfgs, progress=None, is_error=False):
        self.progress_forward()
        progress_text = '{timestamp} | {progress}'.format(timestamp=datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
                                                          progress=progress)
        progress_dict = {'progress': progress_text, 'is_error': is_error} if progress else None
        self.rabbitapi.send_message(message_type=upgrade_cfgs.rpc_message_type, routing_key=upgrade_cfgs.rpc_queue_name,
                                    monitor_id=self.monitor_id, status=UpgradeStatus.InProgress.value,
                                    progress=progress_dict, progress_order=self.progress_order)

    def notify_upgrade_success(self, upgrade_cfgs):
        LOG.info("%s for %s completed successfully", upgrade_cfgs.name, self.monitor_id)
        self.rabbitapi.send_message(message_type=upgrade_cfgs.rpc_message_type, routing_key=upgrade_cfgs.rpc_queue_name,
                                    monitor_id=self.monitor_id, status=UpgradeStatus.Successful.value)

    def notify_upgrade_failed(self, upgrade_cfgs, error):
        """
        :param error: error reason
        :return:
        """
        LOG.info("%s for %s failed", upgrade_cfgs.name, self.monitor_id)
        self.rabbitapi.send_message(message_type=upgrade_cfgs.rpc_message_type, routing_key=upgrade_cfgs.rpc_queue_name,
                                    monitor_id=self.monitor_id, status=UpgradeStatus.Failed.value, error=error)

    def initialize_progress(self):
        self.progress_order = 0

    def progress_forward(self):
        self.progress_order += 1
