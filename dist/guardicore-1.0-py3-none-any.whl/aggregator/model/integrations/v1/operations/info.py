from __future__ import annotations

from typing import Any, Dict, List, Optional, Union
from uuid import UUID

from pydantic import BaseModel, Field, RootModel

from ..common.common import Connector


class GeneralInfo(BaseModel):
    general: Optional[Dict[str, Any]] = None


class Hierarchy(BaseModel):
    id: str
    name: str
    children: Optional[List[Hierarchy]] = None


class EnvUnit(BaseModel):
    id: UUID
    name: str
    parent: str = Field(
        ...,
        description='the location in the organization Hierarchy specified by the Hierarchy id. can be empty string if integration does not have a Hierarchy structure.',
    )


class OrganizationTreeInfo(BaseModel):
    org_tree: Hierarchy = Field(
        ...,
        alias='org-tree',
        description='describing integration organization hierarchy structure if such structure exist. e.g. azure management groups',
    )


class EnvUnits(RootModel[List[EnvUnit]]):
    root: List[EnvUnit]

    def __getattr__(self, attr: str):
        return getattr(self.root, attr)

    def __iter__(self):
        for item in self.root:
            yield item


class IntegrationEnvInfo(BaseModel):
    connector_type: Connector = Field(..., alias='connector-type')
    connector_id: UUID = Field(..., alias='connector-id')
    info: Union[OrganizationTreeInfo, GeneralInfo]


Hierarchy.model_rebuild()
