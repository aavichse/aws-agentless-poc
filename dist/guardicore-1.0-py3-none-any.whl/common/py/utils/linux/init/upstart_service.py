from dbus import DBusException

from upstart.job import UpstartJob

from common.logger import get_logger
from common.py.utils.linux.init.init_service import InitService
from common.py.utils.linux.init.model import InitServiceStatus, UpstartJobState

LOG = get_logger(module_name=__name__)

UPSTART_STATUS_MAPPING = {
    UpstartJobState.WAITING: InitServiceStatus.STARTING,
    UpstartJobState.SECURITY: InitServiceStatus.STARTING,
    UpstartJobState.PRE_START: InitServiceStatus.STARTING,
    UpstartJobState.SPAWNED: InitServiceStatus.STARTING,
    UpstartJobState.POST_START: InitServiceStatus.STARTING,
    UpstartJobState.RUNNING: InitServiceStatus.RUNNING,
    UpstartJobState.PRE_STOP: InitServiceStatus.STOPPED,
    UpstartJobState.STOPPING: InitServiceStatus.STOPPED,
    UpstartJobState.KILLED: InitServiceStatus.STOPPED,
    UpstartJobState.POST_STOP: InitServiceStatus.STOPPED
}


class UpstartService(InitService):
    """
    Ubuntu upstart service http://upstart.ubuntu.com
    """

    def __init__(self, service_name):
        super(UpstartService, self).__init__(service_name=service_name)
        try:
            self._upstart_job = UpstartJob(job_name=service_name)
        except Exception:
            LOG.exception("Failed to create upstart service '%s'", service_name)

    def start(self):
        try:
            if self._upstart_job:
                self._upstart_job.start()
                return InitServiceStatus.STARTING
            return InitServiceStatus.NOT_FOUND
        except Exception:
            LOG.exception("Failed to start service '%s'", self.service_name)
            return InitServiceStatus.FAIL_START

    def stop(self):
        try:
            if self._upstart_job:
                self._upstart_job.stop()
                return InitServiceStatus.STOPPED
            return InitServiceStatus.NOT_FOUND
        except Exception:
            LOG.exception("Failed to stop service '%s'", self.service_name)
            return InitServiceStatus.FAIL_STOP

    def get_status(self):
        try:
            job_status = self._upstart_job.get_status()
            if not job_status:
                LOG.warning("Failed to get status for service '%s'", self.service_name)
                return InitServiceStatus.UNKNOWN

            job_state = job_status.get('state')
            if not job_state:
                LOG.warning("Failed to get state for service '%s' from upstart status: %s", self.service_name, job_status)
                return InitServiceStatus.UNKNOWN

            job_state_enum = UpstartJobState.from_str(str(job_state))
            if not job_state_enum:
                LOG.warning("Failed to translate state for service '%s' to upstart status: %s", self.service_name,
                         job_state)
                return InitServiceStatus.UNKNOWN

            return UPSTART_STATUS_MAPPING.get(job_state_enum, InitServiceStatus.UNKNOWN)
        except DBusException:
            # org.freedesktop.DBus.Error.UnknownMethod is thrown when the service stops
            # as well as in numerous other cases
            return InitServiceStatus.STOPPED
        except Exception:
            LOG.exception("Fail to get status for service '%s'", self.service_name)
            return InitServiceStatus.UNKNOWN

    def get_log_location(self):
        return '/var/log/upstart/%s.log' % self.service_name

    def cleanup(self):
        pass
