import os
import inspect
import importlib
from common.logger import get_logger


LOG = get_logger(module_name=__name__)

LEVELS_FROM_GC_ROOT = 3  # Number of parent dirs till GC_ROOT

def load_user_classes(base_path, base_class, ignore_errors=False):
    classes = set()
    modules = find_modules(base_path)
    LOG.debug("Loading modules: %r", list(modules))
    for module_name in modules:
        try:
            module = importlib.import_module(module_name)
            for cls in get_module_classes(module, base_class):
                if cls not in classes:
                    classes.add(cls)
        except Exception:
            if ignore_errors:
                continue
            raise
    return list(classes)


def load_specific_user_class(class_path):
    module_name, class_name = class_path.rsplit('.', 1)
    module = importlib.import_module(module_name)
    members = inspect.getmembers(module, lambda cls: (inspect.isclass(cls) and
                                                      cls.__name__ == class_name))
    return members[0][1]


def find_modules(base_path):
    """
    Returns a set of importable module names under SERVICES directory.
    """
    modules = set()
    for dirpath, _, filenames in os.walk(base_path):
        temp_filenames = filenames[:]
        for filename in filenames:
            if filename.endswith(".pyo") and\
               filename.replace(".pyo", ".py") in filenames:
                temp_filenames.remove(filename)
        for filename in filter(lambda fname: fname.endswith((".py", ".pyo")), temp_filenames):
            relpath = os.path.relpath(dirpath, os.path.abspath(os.path.join(os.path.dirname(__file__),
                                                                            "../" * LEVELS_FROM_GC_ROOT)))
            module_name = '.'.join([relpath.replace("/", "."), filename]) if relpath != '.' else filename
            module_name = os.path.splitext(module_name)[0]
            modules.add(module_name)
    return modules


def get_module_classes(module, base_cls):
    members = inspect.getmembers(module, lambda cls: (inspect.isclass(cls) and
                                                      cls is not base_cls and
                                                      issubclass(cls, base_cls)))
    return [member[1] for member in members]
