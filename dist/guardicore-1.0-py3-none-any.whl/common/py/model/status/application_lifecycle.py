from enum import IntEnum


class ApplicationLifecyclePhase(IntEnum):
    INITIALIZING = 0
    VERIFYING = 1
    STARTING = 2
    STARTED = 3
    CLEANING_UP = 4
    FAILED = 5
