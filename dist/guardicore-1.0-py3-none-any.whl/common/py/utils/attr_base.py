import attr

from enum import Enum


@attr.s
class AttrBase(object):
    @staticmethod
    def convert_enums(attr_obj):
        """
        Convert all enums into their values
        :param attr_obj: attr.s class object
        :return:
        """
        if not hasattr(attr_obj, u'items'):
            return

        for key, value in list(attr_obj.items()):
            if isinstance(key, Enum):
                attr_obj.pop(key)
                key = key.value
                attr_obj[key] = value
            if isinstance(value, dict):
                AttrBase.convert_enums(value)
            elif isinstance(value, list):
                for i, item in enumerate(value):
                    if isinstance(item, Enum):
                        value[i] = item.value
                    elif isinstance(item, dict):
                        AttrBase.convert_enums(item)
            elif isinstance(value, Enum):
                attr_obj[key] = value.value

    def to_dict(self):
        attr_dict = attr.asdict(self)
        AttrBase.convert_enums(attr_dict)
        return attr_dict
