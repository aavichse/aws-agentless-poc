from collections import Counter

from common.logger import get_logger
from common.py.model.status import SERVICE_STATUS_KEY, SERVICE_MESSAGE_KEY, SERVICES_STATUS_KEY, APPLICATION_STATUS_KEY
from common.py.model.status.application_lifecycle import ApplicationLifecyclePhase
from common.py.model.status.service_status import ServiceStatus

APP_LIFECYCLE_TO_STATUS = {
    ApplicationLifecyclePhase.INITIALIZING: ServiceStatus.INITIATING,
    ApplicationLifecyclePhase.VERIFYING: ServiceStatus.PENDING,
    ApplicationLifecyclePhase.STARTING: ServiceStatus.PENDING,
    ApplicationLifecyclePhase.STARTED: ServiceStatus.RUNNING,
    ApplicationLifecyclePhase.CLEANING_UP: ServiceStatus.TERMINATED,
    ApplicationLifecyclePhase.FAILED: ServiceStatus.FAILED
}

LOG = get_logger(module_name=__name__)


class ApplicationStatus(object):
    def __init__(self, lifecycle_phase=ApplicationLifecyclePhase.INITIALIZING, services_status=None):
        self._lifecycle_phase = lifecycle_phase
        self._services_status = services_status if services_status else {}

    def list_app_status_services(self):
        return self._services_status.keys()

    def add_service_status(self, service_name, service_status, msg=None):
        if service_status is None:
            return

        self._services_status[service_name] = {SERVICE_STATUS_KEY: service_status}
        if msg:
            self._services_status[service_name][SERVICE_MESSAGE_KEY] = msg

    def remove_app_status_service(self, service_name):
        self._services_status.pop(service_name, None)

    def get_service_status(self, service_name):
        return self._services_status.get(service_name)

    def set_lifecycle_phase(self, lifecycle_phase):
        if lifecycle_phase != self._lifecycle_phase and \
                lifecycle_phase in (ApplicationLifecyclePhase.FAILED, ApplicationLifecyclePhase.CLEANING_UP):
            # Clear up previous status only on non-recoverable states as there might be PENDING
            # services for whom state should be persisted even when application lifecycle moved to STARTED.
            # Classic example for this is network-db-sync - the application is in STARTED mode since
            # both redis&kafka connections has been established but since the DB has not been announced as READY
            # yet there is still a PENDING service whose state should be persisted
            self._services_status.clear()
        self._lifecycle_phase = lifecycle_phase

    @property
    def overall_status(self):
        lifecycle_status = APP_LIFECYCLE_TO_STATUS.get(self._lifecycle_phase, ServiceStatus.UNKNOWN)
        if lifecycle_status in (ServiceStatus.TERMINATED, ServiceStatus.FAILED):
            return lifecycle_status

        all_service_statuses = [service_status_info.get(SERVICE_STATUS_KEY, ServiceStatus.UNKNOWN) for
                                service_name, service_status_info in
                                self._services_status.items()]
        status_counter = Counter(all_service_statuses)

        for status in (
                ServiceStatus.TERMINATED, ServiceStatus.FAILED, ServiceStatus.INITIATING,
                ServiceStatus.PENDING):
            if status_counter[status] > 0:
                return status

        if lifecycle_status == ServiceStatus.RUNNING and \
                status_counter[ServiceStatus.RUNNING] == len(all_service_statuses):
            return ServiceStatus.RUNNING

        return lifecycle_status

    def to_dict(self):
        res = {APPLICATION_STATUS_KEY: self.overall_status}
        if self._services_status:
            res[SERVICES_STATUS_KEY] = self._services_status

        return res

    def to_json(self):
        res = {APPLICATION_STATUS_KEY: self.overall_status.name}
        if self._services_status:
            res[SERVICES_STATUS_KEY] = self._services_status.copy()
            for service_status_info in res[SERVICES_STATUS_KEY].values():
                service_status_info[SERVICE_STATUS_KEY] = getattr(service_status_info[SERVICE_STATUS_KEY], 'name',
                                                                  service_status_info[SERVICE_STATUS_KEY])

        return res

    @property
    def current_lifecycle_phase(self):
        return self._lifecycle_phase

    def clear(self):
        self._lifecycle_phase = ApplicationLifecyclePhase.INITIALIZING
        self._services_status.clear()
