"""
Created on Jul 6, 2014

@author: itamar
"""

import inspect
import os.path
import traceback
from common import logger
from common.py.model.exceptions import DriverLoadError
from common.py.utils.config import cfg
from common.py.utils.importutils import import_class

LOG = logger.get_logger(module_name=__name__)

default_opts = [cfg.BoolOpt('drivers_debug', default=False,
                            help="Do some more debug printing while loading the drivers"), ]

cfg.CONF.register_opts(default_opts, "default")


class DriversUtil(object):
    """
    In charge of loading and handling drivers dynamic loading
    """

    @staticmethod
    def get_driver(driver_path, driver_type_name, expected_class=None):
        """get_driver(driver_path, driver_type_name) -> driver class object
        
        Get a generic driver by a given path. The driver_type_name is only for
        logging purposes. The class type object is returned by the class isn't
        instantiated.
        """

        try:
            if cfg.CONF.default.drivers_debug:
                filename, lineno, funcname = inspect.stack()[3][1:4]
                path, filename = os.path.split(filename)
                filename = os.path.join(os.path.split(path)[-1], filename)
                LOG.debug("Loading %s as %s driver by %s->%s (line %d)" % (
                    driver_path, driver_type_name, filename, funcname, lineno))

            class_obj = import_class(driver_path)

            # check for valid class type
            if expected_class and not issubclass(class_obj, expected_class):
                raise DriverLoadError(driver_path, driver_type_name, "Driver class isn't of class %s()", expected_class)

            return class_obj
        except ImportError:
            raise DriverLoadError(driver_path, driver_type_name, "Error while importing driver: %s", traceback.format_exc())

    @staticmethod
    def load_driver(driver_path, driver_type_name, expected_class=None, should_init=True, **kwargs):
        """load_driver(driver_path, driver_type_name, **kwargs) -> driver class instance
        
        Load a generic driver by a given path. The driver_type_name is only for
        logging purposes. kwargs will be forwarded to the class instance c'tor.
        """
        
        if not driver_path:
            raise DriverLoadError('<missing>', driver_type_name,
                                  "Missing driver name, probably miss-configuration")

        driver_class = DriversUtil.get_driver(driver_path, driver_type_name, expected_class)

        if should_init:
            try:
                return driver_class(**kwargs)
            except Exception:
                raise DriverLoadError(driver_path, driver_type_name,
                                      "Exception while loading driver %s", traceback.format_exc())
        else:
            return driver_class
