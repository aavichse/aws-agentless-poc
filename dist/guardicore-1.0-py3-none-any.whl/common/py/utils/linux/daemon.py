import atexit
from six.moves import cPickle, xrange
import os

import eventlet
from eventlet.greenio import GreenPipe

try:
    import fcntl
except ImportError:
    fcntl = None
    if os.name != 'nt':  # on Linux, re-raise the error
        raise

import sys
import time
import traceback
from signal import SIGTERM
try:
    MAXFD = os.sysconf("SC_OPEN_MAX")
except Exception:
    MAXFD = 256
if not sys.platform.startswith('win'):
    import fcntl


from common.logger import get_logger

LOG = get_logger(module_name=__name__)

SIGKILL = 9

__author__ = 'Eddie'


class DaemonFuncs(object):
    @classmethod
    def pipe_cloexec(cls):
        """Create a pipe with FDs set CLOEXEC."""
        # Pipes' FDs are set CLOEXEC by default because we don't want them
        # to be inherited by other subprocesses: the CLOEXEC flag is removed
        # from the child's FDs by _dup2(), between fork() and exec().
        # This is not atomic: we would need the pipe2() syscall for that.
        r, w = os.pipe()
        cls._set_cloexec_flag(r)
        cls._set_cloexec_flag(w)
        return r, w

    @staticmethod
    def _set_cloexec_flag(fd, cloexec=True):
        try:
            cloexec_flag = fcntl.FD_CLOEXEC
        except AttributeError:
            cloexec_flag = 1

        old = fcntl.fcntl(fd, fcntl.F_GETFD)
        if cloexec:
            fcntl.fcntl(fd, fcntl.F_SETFD, old | cloexec_flag)
        else:
            fcntl.fcntl(fd, fcntl.F_SETFD, old & ~cloexec_flag)

    @staticmethod
    def close_fds(but):
        if hasattr(os, 'closerange'):
            os.closerange(3, but)
            os.closerange(but + 1, MAXFD)
        else:
            for i in xrange(3, MAXFD):
                if but == i:
                    continue
                try:
                    os.close(i)
                except:
                    pass


class Daemon(object):
    """
    A generic daemon class.

    Usage: subclass the Daemon class and override the run() method
    """

    def __init__(self, pidfile, stop_timeout, stdin='/dev/null', stdout='/dev/null', stderr='/dev/null',
                 sleep_func=time.sleep):
        self.stdin = stdin
        self.stop_timeout = stop_timeout
        self.stdout = stdout
        self.stderr = stderr
        self.pidfile = pidfile
        self.sleep = sleep_func

    def _daemonize(self, errpipe_write):
        """
        do the UNIX double-fork magic, see Stevens' "Advanced
        Programming in the UNIX Environment" for details (ISBN 0201563177)
        http://www.erlenstar.demon.co.uk/unix/faq_2.html#SEC16
        """
        try:
            pid = os.fork()
            if pid > 0:
                os.waitpid(pid, 0)
                # Return to the main app code
                return
        except OSError as e:
            LOG.error("fork #1 failed: %d (%s)" % (e.errno, e.strerror))
            raise

        # The main process should not get here!

        # decouple from parent environment
        os.chdir("/")
        os.setsid()
        os.umask(0)

        # do second fork
        try:
            pid = os.fork()
            if pid > 0:
                # exit from second parent
                os._exit(0)
        except OSError as e:
            LOG.error("fork #2 failed: %d (%s)" % (e.errno, e.strerror))
            os._exit(1)

        try:
            DaemonFuncs.close_fds(but=errpipe_write)
            # This is used to avoid stdout/stderr monkey patching by logger
            sys.stdout = sys.__stdout__
            sys.stderr = sys.__stderr__
            # redirect standard file descriptors
            sys.stdout.flush()
            sys.stderr.flush()
            si = open(self.stdin, 'r')
            so = open(self.stdout, 'w')
            se = open(self.stderr, 'wb', 0)
            os.dup2(si.fileno(), sys.stdin.fileno())
            os.dup2(so.fileno(), sys.stdout.fileno())
            os.dup2(se.fileno(), sys.stderr.fileno())

            # write pidfile
            atexit.register(self.delpid)
            pid = str(os.getpid())
            with open(self.pidfile, 'w') as pidfile:
                pidfile.write("%s\n" % pid)
                pidfile.flush()
                os.fsync(pidfile.fileno())

            self.run()
        except:
            exc_type, exc_value, tb = sys.exc_info()
            # Save the traceback and attach it to the exception object
            exc_lines = traceback.format_exception(exc_type,
                                                   exc_value,
                                                   tb)
            exc_value.child_traceback = ''.join(exc_lines)
            os.write(errpipe_write, cPickle.dumps(exc_value))
        finally:
            # Make sure that the process exits no matter what.
            # The return code does not matter much as it won't be reported to the application
            os._exit(1)

    def delpid(self):
        try:
            os.remove(self.pidfile)
        except OSError:
            pass

    def is_alive(self):
        # Check for a pidfile to see if the daemon already runs
        pid = self.get_pid()
        if not pid:
            return False

        try:
            os.kill(pid, 0)
            return True
        except OSError:
            self.delpid()
            return False

    def get_pid(self):
        if not self.pidfile or not os.path.exists(self.pidfile):
            return None

        try:
            with open(self.pidfile, 'r') as pf:
                pid = int(pf.read().strip())
                return pid
        except (IOError, OSError, ValueError):
            self.delpid()
            return None

    def wait_for_desired_state(self, alive=True, timeout=1):
        start_time = time.time()
        while time.time() < start_time + timeout:
            if alive == self.is_alive():
                return True
            self.sleep(0.1)
        return False

    def start(self):
        """
        Start the daemon
        """

        if self.is_alive():
            LOG.warn("Daemon with %s pidfile is already running" % self.pidfile)
            return

        # For transferring possible exec failure from child to parent
        # The first char specifies the exception type: 0 means
        # OSError, 1 means some other error.
        errpipe_read, errpipe_write = DaemonFuncs.pipe_cloexec()
        try:
            try:
                # Start the daemon
                self._daemonize(errpipe_write)
            finally:
                # be sure the FD is closed no matter what
                os.close(errpipe_write)
            # Wait for exec to fail or succeed; possibly raising exception
            errpipe_read = GreenPipe(errpipe_read, 'rb', 0)
            data = errpipe_read.read()
        finally:
            if hasattr(errpipe_read, 'close'):
                errpipe_read.close()
            else:
                os.close(errpipe_read)

        if data != b"":
            child_exception = cPickle.loads(data)
            LOG.error(child_exception.child_traceback)

    def stop(self):
        """
        Stop the daemon
        """
        if not self.is_alive():
            LOG.warn("Daemon with %s pidfile is not running" % self.pidfile)
            return  # not an error in a restart

        pid = self.get_pid()

        # Try killing the daemon process
        try:
            os.killpg(os.getpgid(pid), SIGTERM)
            if self.wait_for_desired_state(alive=False, timeout=self.stop_timeout):
                return
            os.killpg(os.getpgid(pid), SIGKILL)
            self.delpid()
        except OSError as err:
            err = str(err)
            if err.find("No such process") > 0:
                if os.path.exists(self.pidfile):
                    os.remove(self.pidfile)
            else:
                raise

    def restart(self):
        """
        Restart the daemon
        """
        self.stop()
        self.start()

    def run(self):
        """
        You should override this method when you subclass Daemon. It will be called after the process has been
        daemonized by start() or restart().
        """
        raise NotImplementedError()


class SimpleDaemon(Daemon):
    def __init__(self, pid_file, stop_timeout, stdout, stderr, cmd_line):
        super(SimpleDaemon, self).__init__(pidfile=pid_file,
                                           stop_timeout=stop_timeout,
                                           sleep_func=eventlet.sleep,
                                           stdout=stdout,
                                           stderr=stderr)
        self.cmd_line = cmd_line

    def run(self):
        try:
            env = os.environ.copy()
            os.execvpe(self.cmd_line[0], args=self.cmd_line, env=env)
        except Exception as e:
            raise SimpleDaemonCommandException("Failed to exec: (%s)" % ' '.join(self.cmd_line), e)


class SimpleDaemonCommandException(Exception):
    pass
