from binascii import a2b_base64
from common.py.apis import DEFAULT_RABBITMQ_USERNAME, DEFAULT_RABBITMQ_PASSWORD, \
    REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT, ComponentType, \
    AgentComponentType, AggregatorType, RPCExchange, RPCMessage
from common.py.apis.management import UNKNOWN_API_VERSION
from common.py.apis.management.aggregating_system_component import AggregatorBaseComponentManagementAPI
from common.py.events.agent import ComponentState
from common.logger import get_logger
from common.py.configuration.agent_configuration_schema import CONFIGURABLE_AGENT_TYPES
from common.py.events.mitigation.machine_details import AgentType

LOG = get_logger(module_name=__name__)

__author__ = 'Amit'


class MitigationAgentManagementAPI(AggregatorBaseComponentManagementAPI):
    COMPONENT_TYPE = ComponentType.MITIGATION_AGENT
    AGENTS_COMPONENT_TYPE = AgentComponentType.REVEAL_AGENT
    COMPONENT_BASE_URI = 'aggregators'

    def __init__(self, management_hosts, agent_id, version=UNKNOWN_API_VERSION, user=DEFAULT_RABBITMQ_USERNAME,
                 password=DEFAULT_RABBITMQ_PASSWORD, configuration_schema=None, aggregator_configuration_schema=None,
                 associated_mgmt_configuration=None, agent_details=None, guest_installation_details=None,
                 aggregator_type=AggregatorType.COLLECTOR, aggregator_features=None, collector_type=None, **kwargs):
        component_id = self.COMPONENT_TYPE.prefix + agent_id
        component_details = agent_details if agent_details is not None else {}
        component_details.update(dict(version=version,
                                      associated_mgmt_configuration=associated_mgmt_configuration,
                                      guest_installation_details=guest_installation_details))

        super(MitigationAgentManagementAPI, self).\
            __init__(management_hosts=management_hosts,
                     user=user,
                     password=password,
                     version=version,
                     exchange=RPCExchange.MITIGATION_AGENT_EXCHANGE_NAME,
                     component_id=component_id,
                     agent_id=agent_id,
                     aggregator_type=aggregator_type,
                     aggregator_features=aggregator_features,
                     collector_type=collector_type,
                     component_details=component_details,
                     heartbeat=REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT,
                     configuration_schema=configuration_schema,
                     aggregator_configuration_schema=aggregator_configuration_schema,
                     **kwargs)

        self.agents_details = {}

        self._max_connections_per_agent_limit = -1
        self._protected_subnets_cache = None

        self.max_limit_update_cbk = None
        self.protected_subnets_update_cbk = None

        self.rabbitapi.add_callback(RPCMessage.MitigationAgent.MITIGATION_AGENT_MAX_CONNECTIONS_PER_AGENT_MESSAGE_TYPE,
                                    lambda message: self._set_max_connections_per_agent_limit(message['limit']))
        self.rabbitapi.add_callback(RPCMessage.Aggregator.AGGREGATOR_PROTECTED_SUBNETS_MESSAGE_TYPE,
                                    lambda message: self._set_protected_subnets_cache(message['subnets']))

    def get_state(self):
        state = self.rabbitapi.call_management_rpc(RPCMessage.MitigationAgent.MITIGATION_AGENT_GET_STATE_RPC_FUNC_NAME,
                                                   component_id=self.component_id,
                                                   component_type=self.COMPONENT_TYPE,
                                                   component_details=self.component_details,
                                                   component_status=self.component_status,
                                                   blocking=True)
        return ComponentState[state]

    def add_state_update_callback(self, callback_func, initial_call=True):
        self.rabbitapi.add_callback(RPCMessage.MitigationAgent.MITIGATION_AGENT_STATE_CHANGE_MESSAGE_TYPE,
                                    lambda message: callback_func(ComponentState[message['state']]),
                                    initial_call=initial_call,
                                    initial_call_func=lambda: callback_func(self.get_state()))

    def find_matching_datapath_id(self):
        return ComponentType.DATAPATH.prefix + self.component_details['agent_id']

    # Worker related APIs
    def agent_alive_to_mgmt(self, message_body, compressed):
        message_body = self.uncompress_message_body(message_body) if compressed else message_body
        self.rabbitapi.call_management_rpc(
            rpc_func_name=RPCMessage.Aggregator.AGGREGATOR_REPORT_AGENTS_ALIVE_RPC_FUNC_NAME,
            exchange=RPCExchange.AGENT_EVENT_EXCHANGE_NAME,
            message_body=message_body,
            compressed=compressed)

    def report_network_visibility_event(self, message_body, compressed, sequence, stale):
        message_body = self.uncompress_message_body(message_body) if compressed else message_body
        self.rabbitapi.call_management_rpc(
            rpc_func_name=RPCMessage.Visibility.REPORT_VISIBILITY_MONGOENGINE_EVENT_RPC_FUNC_NAME,
            exchange=RPCExchange.VISIBILITY_EXCHANGE_NAME,
            message_body=message_body,
            compressed=compressed,
            sequence=sequence,
            stale=stale)

    def machine_details_to_mgmt(self, message_body, compressed):
        message_body = self.uncompress_message_body(message_body) if compressed else message_body
        self.rabbitapi.call_management_rpc(
            rpc_func_name=RPCMessage.MitigationAgent.MITIGATION_AGENT_REPORT_MACHINE_DETAILS_UPDATE_RPC_FUNC_NAME,
            exchange=RPCExchange.MACHINE_UPDATE_EXCHANGE_NAME,
            message_body=message_body,
            compressed=compressed)

    def dns_info_to_mgmt(self, message_body, compressed):
        message_body = self.uncompress_message_body(message_body) if compressed else message_body
        self.rabbitapi.call_management_rpc(
            rpc_func_name=RPCMessage.Datapath.DATAPATH_REPORT_DNS_INFO_RPC_FUNC_NAME,
            exchange=RPCExchange.DNS_EXCHANGE_NAME,
            routing_key='',
            message_body=message_body,
            compressed=compressed)

    def agent_config_update_result_to_mgmt(self, message_body, compressed):
        message_body = self.uncompress_message_body(message_body) if compressed else message_body
        return self.rabbitapi.call_management_rpc(
            rpc_func_name=RPCMessage.Agent.AGENTS_CONFIGURATIONS_REPORT_RESULT,
            exchange=RPCExchange.AGENT_CONFIGURATION_EXCHANGE_NAME,
            blocking=False,
            message_body=message_body,
            compressed=compressed)

    def get_max_connections_per_agent_limit(self):
        if self._max_connections_per_agent_limit == -1:
            self._set_max_connections_per_agent_limit(self._get_max_connections_per_agent_limit_from_mgmt())
        return self._max_connections_per_agent_limit

    def get_protected_subnets(self):
        if self._protected_subnets_cache is None:
            self._protected_subnets_cache = \
                self.rabbitapi.call_management_rpc(RPCMessage.Aggregator.AGGREGATOR_GET_PROTECTED_SUBNETS,
                                                   blocking=True)
        return self._protected_subnets_cache

    def add_agent_config_update_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.Agent.AGENT_CONFIG_UPDATE_MESSAGE_TYPE,
                                    lambda message: callback_func(message.get('agents_configurations')))
    def add_max_limit_update_callback(self, callback_func):
        # Callback on Agent limit update
        self.max_limit_update_cbk = callback_func

    def add_protected_subnets_update_callback(self, callback_func):
        # Set callback on protected subnets update
        self.protected_subnets_update_cbk = callback_func

    def get_agents_configuration(self, agent_types):
        assert all([isinstance(a, AgentType) for a in agent_types])
        if not agent_types:
            agent_types = tuple(CONFIGURABLE_AGENT_TYPES)
        return self.rabbitapi.call_management_rpc(rpc_func_name=RPCMessage.Agent.AGENT_GET_CONFIGURATION,
                                                  exchange=RPCExchange.AGENT_CONFIGURATION_EXCHANGE_NAME,
                                                  agent_types=agent_types,
                                                  blocking=True)

    def get_agents_installation_password(self):
        return self.rabbitapi.call_management_rpc(
            RPCMessage.Aggregator.AGGREGATOR_GET_AGENTS_INSTALLATION_PASSWORD_RPC_FUNC_NAME,
            blocking=True)

    def _set_protected_subnets_cache(self, subnets):
        self._protected_subnets_cache = subnets
        if self.protected_subnets_update_cbk is not None:
            self.protected_subnets_update_cbk(subnets)

    def _get_max_connections_per_agent_limit_from_mgmt(self):
        return self.rabbitapi.call_management_rpc(
            RPCMessage.MitigationAgent.MITIGAIION_AGENT_GET_MAX_CONNECTIONS_PER_AGENT_RPC_FUNC_NAME,
            blocking=True)

    def _set_max_connections_per_agent_limit(self, limit):
        if limit != 0:
            log_func = LOG.info
        else:
            log_func = LOG.warn
        if limit != self._max_connections_per_agent_limit:
            log_func("Setting max connections per agent. Changed from %d to %d",
                     self._max_connections_per_agent_limit, limit)
        self._max_connections_per_agent_limit = limit
        if self.max_limit_update_cbk is not None:
            self.max_limit_update_cbk(limit)

    @staticmethod
    def uncompress_message_body(message_body):
        return a2b_base64(message_body)
