from __future__ import annotations

import re
from importlib import import_module
from pathlib import PosixPath
from types import ModuleType
from typing import List, Union, Dict

from common.logger import get_logger

LOG = get_logger(module_name=__name__)
SCRIPT_DIR = PosixPath(__file__).parent.resolve()
DEFAULT_VERSION = "latest"


class IntegrationModelsException(Exception):
    pass


class GroupDictEasyAccess(dict):
    __getattr__ = dict.__getitem__


class IntegrationModels:
    def __init__(self, effective_version: str = DEFAULT_VERSION):
        self.api_version = effective_version.lower()
        if self.api_version != DEFAULT_VERSION:
            self.api_version = self.api_version if self.api_version.startswith("v") else f"v{self.api_version}"

        self.confirm_version_support()
        self.modules = self.load_modules()

    def __repr__(self) -> str:
        return f"<CloudAppModels api-version={self.api_version} available-modules={list(self.modules.keys())}>"

    def load_modules(self) -> dict:
        # Load version groups
        available_groups = [group for group in SCRIPT_DIR.glob(f"{self.api_version}/*")
                            if group.is_dir() and group.stem != "__pycache__"]
        LOG.info(f"Available groups for version {self.api_version}: {[group.stem for group in available_groups]}")
        modules = GroupDictEasyAccess({group.stem: self.load_group(group) for group in available_groups})

        # Load version-less models
        for m in SCRIPT_DIR.glob("*"):
            if not m.is_dir() and m.stem != "__init__" and (m.name.endswith(".py") or m.name.endswith(".pyc")):
                LOG.info(f"Loading version independent module: {m.stem}")
                modules[m.stem] = import_module(f"aggregator.model.integrations.{m.stem}")

        return modules

    def load_group(self, group_path: PosixPath) -> dict:
        return GroupDictEasyAccess({
            m.stem: import_module(f"aggregator.model.integrations.{self.api_version}.{group_path.stem}.{m.stem}")
            for m in group_path.glob("*.py*")
        })

    def confirm_version_support(self) -> None:
        available_versions = self.available_versions()
        LOG.info(f"Available versions: {available_versions}")
        if not available_versions:
            raise IntegrationModelsException("No supported versions found!")
        if self.api_version == DEFAULT_VERSION:
            self.api_version = available_versions[-1]
        elif self.api_version not in available_versions:
            raise IntegrationModelsException(f"Version '{self.api_version}' is not available: {available_versions}")
        LOG.info(f"Using version: {self.api_version}")

    def __getattr__(self, attr: str) -> ModuleType:
        try:
            chain = attr.split('.')
            result = self.modules
            for obj in chain:
                result = getattr(result, obj)
            return result
        except (AttributeError, KeyError):
            raise IntegrationModelsException(f"Module '{attr}' not found! Loaded modules: {', '.join(self.modules.keys())}")

    @classmethod
    def available_versions(cls) -> List[str]:
        return [path.stem for path in cls.sort_versions(SCRIPT_DIR.glob("v[1-9]*")) if path.is_dir()]

    @staticmethod
    def sort_versions(versions: List[PosixPath]) -> List[str]:
        def version_int(version_str: PosixPath) -> int:
            return int(re.findall(r'\d+', version_str.stem)[0])
        return sorted(versions, key=version_int)

    @classmethod
    def latest_version(cls) -> Union[str, None]:
        available_versions = cls.available_versions()
        return available_versions[-1] if available_versions else None

    @classmethod
    def get_all_versions(cls) -> Dict[str, IntegrationModels]:
        """Load all available versions and return them as a dict {"v1": v1-models, ..}
        Also map key 'latest' to the highest version models
        """

        available_versions = cls.available_versions()
        all_versions = {v: cls(effective_version=v) for v in available_versions}
        all_versions[DEFAULT_VERSION] = all_versions[available_versions[-1]]
        return all_versions


ALL_MODELS = IntegrationModels.get_all_versions()
