import calendar
import importlib
import inspect
import sys
from attr import asdict
from datetime import datetime
from enum import Enum
import six
if six.PY3:
    from collections.abc import Iterable
else:
    from collections import Iterable

try:
    from bson import ObjectId
except ImportError:
    ObjectId = None

from common.py.model.fastenum import Enum as FastEnum
if six.PY3:
    from common.py.apis.management import ManagementAPIError
else:
    class ManagementAPIError(Exception):    # to be never used
        pass


def find_outer_cls_by_inner_obj(obj):
    scope = inspect.getmodule(obj)
    # Get all classes in module
    classes = (member[1] for member in inspect.getmembers(scope, inspect.isclass))
    for cls in classes:
        # Get all nested classes in cls
        for member in inspect.getmembers(cls, inspect.isclass):
            if member[1] == obj.__class__:
                return cls


def encode_obj_class(obj):
    obj_class = [obj.__class__.__module__, obj.__class__.__name__]
    # Sanity check
    try:
        decode_obj_class(obj_class)
        return obj_class
    except AttributeError:
        # Assume this is the cause of a nested class definition (support up to one level of nesting)
        out_cls = find_outer_cls_by_inner_obj(obj)
        return [obj.__class__.__module__, "{}.{}".format(out_cls.__name__, obj.__class__.__name__)]


def decode_obj_class(obj_class):
    module_name, cls_path = obj_class
    try:
        cur_module = sys.modules[module_name]
    except KeyError:
        try:
            cur_module = importlib.import_module(module_name, cls_path)
        except ModuleNotFoundError:
            if module_name.startswith("common.") and not module_name.startswith("common.py."):
                module_name = module_name.replace("common.","common.py.")
            cur_module = importlib.import_module(module_name, cls_path)
    for cls_name in cls_path.split('.'):
        cur_module = getattr(cur_module, cls_name)
    return cur_module


def encode_objects(obj):
    if hasattr(obj, 'to_json') and hasattr(obj, 'from_json'):
        return {'__obj_class__': encode_obj_class(obj),
                '__obj_value__': obj.to_json(),
                '__from_json__': True}

    if isinstance(obj, dict):
        return {encode_key(k): encode_objects(v) for k, v in obj.items()}

    if isinstance(obj, tuple):
        return {'__tuple__': [encode_objects(v) for v in obj]}
    # fix to support dict_values in python 3
    if isinstance(obj, Iterable) and not isinstance(obj, six.string_types):
        return [encode_objects(v) for v in obj]

    if isinstance(obj, datetime):
        return {'__date__': int(calendar.timegm(obj.timetuple()) * 1000 + obj.microsecond / 1000)}

    if isinstance(obj, (Enum, FastEnum)):
        return {'__obj_class__': encode_obj_class(obj),
                '__obj_value__': obj.value}
    
    instance_types = (ObjectId, ManagementAPIError) if ObjectId else ManagementAPIError
    if isinstance(obj, instance_types):
        return {'__obj_class__': encode_obj_class(obj),
                '__obj_value__': str(obj)}

    # Check if object is an attr. check stolen from attr._asdict_anything
    if getattr(obj.__class__, "__attrs_attrs__", None) is not None:
        return {
            '__obj_class__': encode_obj_class(obj),
            '__obj_value__': encode_objects(asdict(obj, recurse=False)),
            '__from_attr__': True
        }

    return obj


def decode_objects(obj):
    if isinstance(obj, dict):
        if '__obj_class__' in obj and '__obj_value__' in obj:
            cls = decode_obj_class(obj['__obj_class__'])
            val = obj['__obj_value__']
            if obj.get('__from_json__', False):
                return cls.from_json(val)

            if obj.get('__from_attr__', False):
                kwargs = {k: decode_objects(v) for k, v in val.items()}
                return cls(**kwargs)

            return cls(val)

        if '__tuple__' in obj:
            return tuple(decode_objects(v) for v in obj['__tuple__'])

        if '__date__' in obj:
            timestamp = obj['__date__']
            return datetime.utcfromtimestamp(timestamp / 1000.0)

        return {k: decode_objects(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [decode_objects(v) for v in obj]
    return obj


# Prevent 'TypeError: Dict key must be str' errors
def encode_key(k):
    if isinstance(k, (Enum, FastEnum)):
        return str(k.value)
    if not type(k) is str:
        return str(k)
    return k


def object_to_dict(obj):
    if isinstance(obj, (int, str, float)):
        return obj
    if isinstance(obj, list):
        return [object_to_dict(item) for item in obj]
    if isinstance(obj, dict):
        return {key: object_to_dict(value) for key, value in obj.items()}
    if hasattr(obj, '__dict__'):
        return {key: object_to_dict(value) for key, value in obj.__dict__.items()}
    return str(obj)  # Fallback to a string representation for other types
