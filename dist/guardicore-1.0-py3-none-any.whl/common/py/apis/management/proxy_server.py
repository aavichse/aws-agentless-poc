from binascii import a2b_base64

from common.py.apis import ComponentType, DEFAULT_RABBITMQ_USERNAME, DEFAULT_RABBITMQ_PASSWORD, AggregatorType, \
    RPCExchange, REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT, RPCMessage
from common.py.apis.management import UNKNOWN_API_VERSION
from common.py.apis.management.aggregating_system_component import AggregatorBaseComponentManagementAPI
from common.py.apis.management.collector import CollectorAPI


class CloudProxyManagementAPI(AggregatorBaseComponentManagementAPI):
    COMPONENT_TYPE = ComponentType.PROXY_SERVER
    RABBIT_API_CLASS = CollectorAPI
    COMPONENT_BASE_URI = 'aggregators'

    def __init__(
            self,
            management_hosts,
            component_id,
            version=UNKNOWN_API_VERSION,
            user=DEFAULT_RABBITMQ_USERNAME,
            password=DEFAULT_RABBITMQ_PASSWORD,
            configuration_schema=None,
            aggregator_configuration_schema=None,
            component_details=None,
            aggregator_type=AggregatorType.COLLECTOR,
            aggregator_features=None,
            collector_type=None,
            **kwargs
    ):
        component_details = component_details if component_details is not None else {}
        component_details.update({
            "version": version,
            "management_host": management_hosts[-1],
            'agent_id': component_id
        })

        super().__init__(
            management_hosts=management_hosts,
            agent_id=component_id,
            user=user,
            password=password,
            version=version,
            exchange=RPCExchange.AGGREGATOR_EXCHANGE_NAME,
            component_id=self.COMPONENT_TYPE.prefix + component_id,
            aggregator_type=aggregator_type,
            aggregator_features=aggregator_features,
            collector_type=collector_type,
            component_details=component_details,
            heartbeat=REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT,
            configuration_schema=configuration_schema,
            aggregator_configuration_schema=aggregator_configuration_schema,
            **kwargs
        )

    def report_reveal_events(self, message_body, compressed, sequence, stale):
        message_body = a2b_base64(message_body) if compressed else message_body
        self.rabbitapi.call_management_rpc(
            rpc_func_name=RPCMessage.Visibility.REPORT_VISIBILITY_MONGOENGINE_EVENT_RPC_FUNC_NAME,
            exchange=RPCExchange.VISIBILITY_EXCHANGE_NAME,
            message_body=message_body,
            compressed=compressed,
            sequence=sequence,
            stale=stale
        )
