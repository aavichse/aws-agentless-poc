from __future__ import print_function

import errno
import json
import os
import re
import select
import shlex
import signal
import subprocess
import time

from common.logger import get_logger

__author__ = 'Eddie'

LOG = get_logger(module_name=__name__)

EXEC_DEBUG = False


class CheckProcessError(RuntimeError):
    def __init__(self, returncode, cmd, stdout=None, stderr=None):
        self.returncode = returncode
        self.cmd = cmd
        self.stdout = stdout
        self.stderr = stderr

    def __str__(self):
        return "Error executing command %r (ret=%d): stdout: %r, stderr: %r" % (self.cmd, self.returncode,
                                                                                self.stdout, self.stderr)


def strerror(exit_code):
    try:
        return os.strerror(exit_code)
    except ValueError:
        return "Unknown exit code %d" % (exit_code, )
    except TypeError:
        return "Unknown type for exit code: %r" % (exit_code, )


def _build_cmd(cmd, root_helper=None, addl_env=None):
    if root_helper:
        cmd = shlex.split(root_helper) + cmd
    cmd = map(str, cmd)

    env = os.environ.copy()
    if addl_env:
        env.update(addl_env)

    return cmd, env


def check_output_independent(cmd, root_helper=None, addl_env=None, process_input=None,
                             merge_stderr=False, subprocess_to_use=subprocess, shell=False,
                             close_fds=False, cwd=None):
    cmd, env = _build_cmd(cmd, root_helper, addl_env)

    if EXEC_DEBUG:
        print("Output execution:", cmd)

    # execute the subprocess
    process = subprocess_to_use.Popen(cmd,
                                      shell=shell,
                                      stdout=subprocess.PIPE,
                                      stderr=subprocess.STDOUT if merge_stderr else subprocess.PIPE,
                                      stdin=subprocess.PIPE if process_input else None,
                                      env=env,
                                      close_fds=close_fds,
                                      universal_newlines=True,
                                      cwd=cwd)

    # send process input is given and read all stdout/stderr data
    output, stderr = process.communicate(process_input)

    # close stdin pipe if needed
    if process_input:
        process.stdin.close()

    try:
        # get the process return code
        retcode = process.wait()

        if 0 != retcode:
            if EXEC_DEBUG:
                print("Output execution failed:", cmd, retcode)
            raise CheckProcessError(returncode=retcode, cmd=cmd, stdout=output.strip(), stderr=stderr.strip())

        if EXEC_DEBUG:
            print("Output execution returned:", cmd)
    finally:
        if process.stdout:
            process.stdout.close()
        if process.stderr:
            process.stderr.close()

    return output


def subprocess_call_independent(args, process_input=None, merge_stderr=True, subprocess_to_use=subprocess,
                                check=False, log_error=True, progress_callback=None, **kwargs):
    start_time = time.time()

    # execute the subprocess
    process = subprocess_to_use.Popen(args,
                                      stdout=subprocess.PIPE,
                                      stderr=subprocess.STDOUT if merge_stderr else subprocess.PIPE,
                                      stdin=subprocess.PIPE if process_input else None,
                                      **kwargs)
    try:
        if progress_callback is not None:
            assert callable(progress_callback), "progress_callback must be callable"

            if process_input:
                process.stdin.write(process_input)
                process.stdin.flush()

            read_set = [process.stdout]
            if not merge_stderr:
                read_set.append(process.stderr)

            def _progress_data(buffer, newdata):
                for line in newdata.splitlines():
                    progress_callback(process, line)
                return buffer + newdata

            stderr = ""
            output = ""
            while read_set:
                try:
                    rlist, _, _ = select.select(read_set, [], [])
                except select.error as e:
                    if e.args[0] == errno.EINTR:
                        continue
                    raise

                if process.stdout in rlist:
                    data = os.read(process.stdout.fileno(), 1024)
                    if not data:
                        process.stdout.close()
                        read_set.remove(process.stdout)
                    output = _progress_data(output, data)

                if process.stderr in rlist:
                    data = os.read(process.stderr.fileno(), 1024)
                    if not data:
                        process.stderr.close()
                        read_set.remove(process.stderr)
                    stderr = _progress_data(stderr, data)
        else:
            # send process input is given and read all stdout/stderr data
            output, stderr = process.communicate(process_input)

        # close stdin pipe if needed
        if process_input:
            process.stdin.close()

        # get the process return code
        exit_code = process.poll()

        if check and exit_code:
            if not merge_stderr:
                output = "stdout:\n%s\nstderr:\n%s" % (output, stderr)

            if log_error:
                LOG.warn("Execution of command %s failed (%s), output is:\n%s",
                         args, strerror(exit_code), output)

            raise subprocess_to_use.CalledProcessError(exit_code, cmd=args, output=output)
    except:
        if process.poll() is None:
            LOG.warn("subprocess %d still running during error, killing it", process.pid)
            try:
                os.kill(process.pid, signal.SIGTERM)
            except OSError: pass
        raise

    return {'args': args,
            'exit_code': exit_code,
            'exit_code_str': strerror(exit_code),
            'stdout': output,
            'stderr': stderr,
            'stdin': process_input,
            'run_time': time.time() - start_time}


STAT_KEYS = ('ppid', 'pgrp', 'session', 'tty_nr', 'tpgid', 'flags', 'minflt', 'cminflt', 'majflt',
             'cmajflt', 'utime', 'stime', 'cutime', 'cstime', 'priority', 'nice', 'num_threads',
             'itrealvalue', 'starttime', 'vsize', 'rss', 'rsslim', 'startcode', 'endcode', 'startstack',
             'kstkesp', 'kstkeip', 'signal', 'blocked', 'sigignore', 'sigcatch', 'wchan', 'nswap',
             'cnswap', 'exit_signal', 'processor', 'rt_priority', 'policy', 'delayacct_blkio_ticks',
             'guest_time', 'cguest_time', 'start_data', 'end_data', 'start_brk', 'arg_start',
             'arg_end', 'env_start', 'env_end', 'exit_code')


def get_process_details(pid):
    try:
        proc_stat = open("/proc/%d/stat" % (pid, ), "rb").read().strip()
    except (OSError, IOError):
        return None

    proc_stat_match = re.match(r"^(\d+)\s[(]([^)]+)[)]\s(\w)\s(.+)$", proc_stat)
    if not proc_stat_match:
        return None

    pid, name, state, proc_stat = proc_stat_match.groups()

    try:
        proc_stat = map(int, proc_stat.split())
        details = dict(zip(STAT_KEYS, proc_stat))
        details.update({'pid': int(pid), 'name': name, 'state': state})
        return details
    except Exception:
        return None


def is_process_alive(pid):
    return os.path.isdir("/proc/%d" % (pid, ))


def get_process_parent_pid(pid):
    try:
        process_status = open("/proc/%d/status" % (pid, ), "r").readlines()
    except (OSError, IOError):
        return None
    return int([stat_line for stat_line in process_status if stat_line.startswith("PPid:")][0].split()[-1])


def get_process_name(pid):
    try:
        return open("/proc/%d/comm" % (pid, ), "r").read().strip()
    except (OSError, IOError):
        return None


def get_listening_process_by_port(port, subprocess_to_use=subprocess):
    try:
        listening_process_pid = int(subprocess_to_use.check_output(["lsof", "-Pni", "TCP:%d" % port, "-sTCP:LISTEN", "-t"]).strip())
        listening_process_cmdline = open("/proc/%d/cmdline" % (listening_process_pid, ), "rb").read().replace("\0", " ").strip()
    except:
        return -1, "N/A"

    return listening_process_pid, listening_process_cmdline


def get_listening_process_by_address(address, subprocess_to_use=subprocess):
    try:
        devnull = open(os.devnull, "w")
        lsof_output = subprocess_to_use.check_output(["lsof", "-F", "p", "-n", address, "-t"], stderr=devnull)
        listening_process_pid = int(lsof_output.strip()[1:])
        listening_process_cmdline = open("/proc/%d/cmdline" %
                                         (listening_process_pid, ), "rb").read().replace("\0", " ").strip()
    except:
        return -1, "N/A"

    return listening_process_pid, listening_process_cmdline


def kill_process_soft_then_hard(pid, timeout, sleep_to_use):
    # try breaking the other process
    try:
        os.kill(pid, signal.SIGINT)
    except Exception as exc:
        pass

    start_time = time.time()
    while time.time() - start_time <= timeout:
        if not os.path.isdir("/proc/%d" % pid):
            break
        sleep_to_use(1)
    else:
        LOG.error("Process %d didn't stop after %d seconds - killing it brutally", pid, timeout)
        # kill that process brutally
        try:
            os.kill(pid, signal.SIGKILL)
        except Exception as exc:
            pass


def get_uptime():
    """get_uptime() -> {'uptime': <system uptime in seconds>,
                        'idle_time': <system idle time in seconds>}
    """
    uptime = open("/proc/uptime", "r").read().strip().split()

    return {'uptime': float(uptime[0]),
            'idle_time': float(uptime[1])}


def get_load_average():
    """get_load_average() -> {'last_minute': float,
                              'last_5_minutes': float,
                              'last_15_minutes': float,
                              'active_scheduling_entities': int,
                              'total_scheduling_entities': int,
                              'last_created_pid': int}
    """
    
    load_avg = open("/proc/loadavg", "r").read().strip().split()
    active_sched, total_sched = load_avg[3].split("/")

    return {'last_minute': float(load_avg[0]),
            'last_5_minutes': float(load_avg[1]),
            'last_15_minutes': float(load_avg[2]),
            'active_scheduling_entities': int(active_sched),
            'total_scheduling_entities': int(total_sched),
            'last_created_pid': int(load_avg[4]),
            }


def list_modules():
    return [module.split()[0] for module in open("/proc/modules", "r").readlines()]


def get_process_parent_chain(pid):
    if not is_process_alive(pid):
        return []
    parent_chain = [{'pid': pid, 'name': get_process_name(pid)}]
    next_pid = pid
    while next_pid:
        next_pid = get_process_parent_pid(next_pid)
        parent_chain.append({'pid': next_pid, 'name': get_process_name(next_pid)})
    return parent_chain


def ignore_arguments(func, *args, **kwargs):
    """
    Returns a function which calls func with *args, **kwargs when called,
    ignoring the parameters passed to it during the actual call.
    Can be used for callbacks.
    """
    return lambda *unused, **unused2: func(*args, **kwargs)


def read_json_file_content(file_path):
    with open(file_path) as fd:
        return json.load(fd)


def csv_file_to_list(file_path, strip_elements=False):
    with open(file_path) as fd:
        elements_as_list = fd.read().strip().split(',')

    if strip_elements:
        elements_as_list = [element.strip() for element in elements_as_list if element]

    return elements_as_list
