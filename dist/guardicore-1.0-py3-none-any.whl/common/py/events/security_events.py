__author__ = 'Barak'

from enum import IntEnum  # USE enum34 PACKAGE FOR THIS


def service_to_security_event_type(service):
    """
    Gets service name (i.e 'ssh') and returns the Enum class of the matching security event type.
    """
    options = {
        'ssh': SshEventType,
        'windows': WindowsEventType,
        'smb': SmbEventType
    }
    return options[service.lower()]


class SshEventType(IntEnum):
    """ When adding event types, don't forget to put a matching string in common/locales/events.en.yml
    """
    FailedAuthentication = 1
    SuccessfulAuthentication = 2
    ShellOpened = 3
    CommandByShell = 4
    MaliciousCommandByShell = 5
    ShellTerminated = 6
    SecureFileAccess = 7
    ExecutionOfUploadedFile = 8
    ChangeCreatedFilePermissionsToExecutable = 9
    SshServiceProviderTerminated = 10


class WindowsEventType(IntEnum):
    """ When adding event types, don't forget to put a matching string in common/locales/events.en.yml
    """
    CreateProcess = 1
    SocketOperation = 2
    CallFromStack = 3
    SocketBind = 5
    SocketConnect = 6


class SmbEventType(IntEnum):
    """ When adding event types, don't forget to put a matching string in common/locales/events.en.yml
    """
    FailedAuthentication = 1
    SuccessfulAuthentication = 2
    CallFromStack = 3
    CallFromHeap = 4
    SocketBind = 5
    SocketConnect = 6
    SocketGotConnection = 7
    FileAccess = 8
    CreateProcess = 9

