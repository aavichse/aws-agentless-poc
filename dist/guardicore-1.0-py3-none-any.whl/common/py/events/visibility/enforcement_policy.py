import re
from enum import IntEnum, Enum

import attr
import six

from common.py.events.attrs import int_attr, string_attr, enum_attr, Dictable, list_attr, optional_dictable_converter, \
    dictable_list_converter


# TODO: remove code duplication between this and the management code.
from common.py.utils.enum_utils import TransformableEnum


class VisibilityPolicyAction(IntEnum):
    ALLOW = 0
    ALERT = 1
    BLOCK = 2


class VisibilityPolicySectionPosition(TransformableEnum):
    OVERRIDE_ALLOW = 160
    OVERRIDE_ALERT = 180
    OVERRIDE_BLOCK = 200
    ALLOW = 300
    ALERT = 400
    BLOCK = 500


# Note: see agents/enforcement/qapi-schema.json for agent side definition of
# the rules derivation


class EnforcementRuleTable(IntEnum):
    Output = 1
    Input = 2


class AddressClassification(TransformableEnum):
    Private = 1
    Internet = 2


class EnforcementIcmpVersion(Enum):
    v4 = '4'


ADDRESS_CLASSIFICATION_OPTION_MAP = {
    AddressClassification.Private: "Non Internet Address",
    AddressClassification.Internet: "Internet Address"
}

MAX_ICMP_INT_VALUE = 255
MIN_ICMP_INT_VALUE = 0


class EnforcementPolicyDerivationType(IntEnum):
    Layer7 = 7
    Layer4 = 4

    @classmethod
    def format(cls, layer):
        format_mapping = {
            cls.Layer7.value: 'Full layer enforcement',
            cls.Layer4.value: 'L4 only enforcement'
        }
        return format_mapping.get(layer, layer)


@attr.s()
class EnforcementAndLabels(Dictable):
    and_labels = list_attr()


@attr.s()
class EnforcementOrLabels(Dictable):
    or_labels = list_attr(converter=dictable_list_converter(EnforcementAndLabels), default=attr.Factory(list))


@attr.s()
class EnforcementCompoundLabel(Dictable):
    include_labels = attr.ib(converter=optional_dictable_converter(EnforcementOrLabels),
                             default=attr.Factory(EnforcementOrLabels))
    exclude_labels = attr.ib(converter=optional_dictable_converter(EnforcementOrLabels),
                             default=attr.Factory(EnforcementOrLabels))


@attr.s
class EnforcementActiveDirectoryGroup(Dictable):
    group_id = attr.ib(type=str)
    group_name = attr.ib(type=str)


@attr.s
class EnforcementUserGroup(Dictable):
    domain_name = attr.ib(type=str)
    active_directory_groups = list_attr(converter=dictable_list_converter(EnforcementActiveDirectoryGroup),
                                        default=attr.Factory(list))


@attr.s()
class EnforcementIcmpMatch(Dictable):
    icmp_type = attr.ib(validator=lambda i, a, v: isinstance(v, int) and MIN_ICMP_INT_VALUE <= v <= MAX_ICMP_INT_VALUE)
    icmp_codes = attr.ib(factory=list, validator=lambda i, a, v: isinstance(v, list) and (
        MIN_ICMP_INT_VALUE <= code <= MAX_ICMP_INT_VALUE for code in v))
    version = attr.ib(
        validator=lambda i, a, v: isinstance(v, six.string_types) and v in EnforcementIcmpVersion.__members__.values(),
        default=EnforcementIcmpVersion.v4.value
    )

@attr.s
class EnforcementWindowsService(Dictable):
    name = attr.ib(type=str)
    image_names = list_attr(default=None)


@attr.s()
class EnforcementPolicyRuleFilter(Dictable):
    asset_ids = list_attr(default=None)
    labels = list_attr(converter=dictable_list_converter(EnforcementCompoundLabel), default=None)
    subnets = list_attr(default=None)
    processes = list_attr(default=None)
    windows_services = list_attr(converter=dictable_list_converter(EnforcementWindowsService), default=None)
    only_windows_services = attr.ib(type=bool, default=False)
    domains = list_attr(default=None)
    address_classification = enum_attr(AddressClassification, default=None)
    user_groups = list_attr(converter=dictable_list_converter(EnforcementUserGroup), default=None)
    azure_ad_groups = list_attr(default=None)

    @asset_ids.validator
    def is_not_empty_list(self, attribute, value):
        if isinstance(value, list) and len(value) == 0:
            raise ValueError("Assets cannot be an empty list")


DEFAULT_CORPORATE_FLAG_IF_NOT_EXIST = True


class NetworkProfile(TransformableEnum):
    CORPORATE = 0
    OFF_CORPORATE = 1
    BOTH_NETWORKS = 2


class ConnectionNetworkProfile(TransformableEnum):
    """
    Whether connection network profile is on or off corporate
    """
    CORPORATE = 1
    OFF_CORPORATE = 0

    @classmethod
    def from_value(cls, value):
        bool_to_enum = {True: cls.CORPORATE, False: cls.OFF_CORPORATE}
        return bool_to_enum[value]


@attr.s()
class EnforcementPolicyRule(Dictable):
    RULE_NAME_PARSE_RE = re.compile(r"(?P<rule_id>.*) \((?P<section_position>.*) / (?P<ruleset_name>.*)\)")

    rule_id = string_attr()
    ruleset_name = string_attr()
    action = enum_attr(VisibilityPolicyAction)
    section_position = enum_attr(VisibilityPolicySectionPosition)

    # if port_list is empty and port_ranges is empty, any port is matched
    ports = list_attr(default=None)  # list of ints
    port_ranges = list_attr(default=None)   # list of (start, end) pairs

    ip_protocols = list_attr(default=None)  # of ProtocolType

    icmp_matches = list_attr(converter=dictable_list_converter(EnforcementIcmpMatch), default=attr.Factory(list))

    source = attr.ib(default=None, converter=optional_dictable_converter(EnforcementPolicyRuleFilter))
    destination = attr.ib(default=None, converter=optional_dictable_converter(EnforcementPolicyRuleFilter))

    network_profile = enum_attr(NetworkProfile, default=NetworkProfile.CORPORATE)
    attributes = attr.ib(default=attr.Factory(dict))

    @property
    def rule_name(self):
        return "{self.rule_id} ({self.section_position.name} / {self.ruleset_name})".format(self=self)

    @classmethod
    def parse_rule_name(cls, rule_name):
        """
        Parse rule_name (as formatted by cls.rule_name) into (rule_id, section_position, ruleset_name)
        :param rule_name: rule name string
        :return: (rule_id, section_position, ruleset_name)
        """
        m = cls.RULE_NAME_PARSE_RE.match(rule_name)
        if m:
            return m.group('rule_id'), m.group('section_position'), m.group('ruleset_name')
        return rule_name, '', ''


@attr.s()
class EnforcementPolicy(Dictable):
    revision_number = int_attr()

    rules = list_attr(converter=dictable_list_converter(EnforcementPolicyRule))
