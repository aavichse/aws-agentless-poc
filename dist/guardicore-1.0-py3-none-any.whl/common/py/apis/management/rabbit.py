import datetime
import os
import ssl
import time
import uuid
from distutils.version import LooseVersion
from functools import wraps

import haigha2
from haigha2.exceptions import ConnectionError

from common.py.apis.management import ManagementAPIError, RPCTimeoutError
from common.py.apis.management.transport import GEventTransport, EventletTransport, GEventPoolTransport
from common.py.apis.rabbitutils import decode_message, JSON_ENCODING, encode_compressed_by_size, build_message_body
from common.py.apis.management.rabbit_client_stats import RabbitMQClientStats
from common.logger import get_logger
from common.py.saas.configuration import get_rabbitmq_url

from haigha2.message import Message
from haigha2.connection import Connection

from common.py.apis import GUARDICORE_VHOST_NAME, RPC_MSG_TYPE_KEY, DEFAULT_RABBIT_HEARTBEAT, \
    BASE_TLS_PATH, RPC_MESSAGE_TIMEOUT_ADDITIONAL, DEFAULT_RPC_TIMEOUT_SECS, RPCExchange, RPCRoutingKey, \
    MessagePriority, DEFAULT_RABBITMQ_USERNAME, DEFAULT_RABBITMQ_PASSWORD, DEFAULT_RABBITMQ_CALLBACK_POOL_SIZE
from haigha2.ssl_connection import SSLConnection


__author__ = 'Amit'

MS_IN_SEC = 1000

RABBITMQ_DEFAULT_QOS_PREFETCH_FLAG = None # If set to 'None' prefetch will be set to the default (i.e unlimited).
RABBITAPI_DEFAULT_LOCK_TIMEOUT_SEC = 60
LONG_LOCK_TIME_THRESHOLD = 2
CONNECTION_CLOSE_TIMEOUT = 15


# see RabbitMQ documentation (1=non-persistent, 2=persistent)
# Note: messages are durable only if they are sent with this delivery mode
# over *named, durable* queues (otherwise, the delivery mode is ignored).

NON_PERSISTENT_MESSAGE_DELIVERY_MODE = 1
PERSISTENT_MESSAGE_DELIVERY_MODE = 2

RABBITMQ_HOST = get_rabbitmq_url(default_url='rabbitmq.service.gc.guardicore')

RABBITMQ_SSL_PORT = 5671

RABBITMQ_CLIENT_TLS_PATH = os.path.join(BASE_TLS_PATH, 'rabbitmq')
RABBITMQ_CLIENT_TLS_KEY_FILE = os.path.join(RABBITMQ_CLIENT_TLS_PATH, 'key.pem')
RABBITMQ_CLIENT_TLS_CERT_FILE = os.path.join(RABBITMQ_CLIENT_TLS_PATH, 'cert.pem')

RABBITMQ_TLS_CA_PATH = os.path.join(BASE_TLS_PATH, 'gcca')
RABBITMQ_TLS_CA_FILE = os.path.join(RABBITMQ_TLS_CA_PATH, 'cacert.pem')

class EmptyRabbitConnection(Exception):
    pass


def rabbitapi_locked(lock_acquire_timeout=RABBITAPI_DEFAULT_LOCK_TIMEOUT_SEC):
    """
    decorator for methods which access the rabbitapi.
    Makes sure that access to the rabbitapi is done while holding an exclusive lock, so that
    no two methods can access the lock simultaneously.
    :param lock_acquire_timeout: lock acquire timeout (0 for non-blocking).
    :return: decorator
    """
    def decorator(f):
        @wraps(f)
        def execute_locked(self, *args, **kwargs):
            """
            Safely publishes a message through the RabbitMQ channel.
            A eventlet/gevent lock is used to prevent multiple greenlets from concurrently publishing a message;
            this is needed as haigha2 (as of 0.8.0) does not properly prevent this situation.
            See https://guardicore.atlassian.net/browse/GC-2712
            """
            if not self._rabbitapi_lock.acquire(timeout=lock_acquire_timeout):
                self.logger.error("Couldn't acquire rabbitapi lock for %d seconds! (during call to %r)",
                                  lock_acquire_timeout, f)
                raise ManagementAPIError("Couldn't acquire rabbitapi lock for %d seconds! (during call to %r)" %
                                         (lock_acquire_timeout, f))
            try:
                acquired_time = time.time()
                res = f(self, *args, **kwargs)
                lock_time = time.time() - acquired_time
                if lock_time > LONG_LOCK_TIME_THRESHOLD:
                    self.logger.warn("Lock was locked for %s, in callback: %s", lock_time, f)
                return res
            finally:
                self._rabbitapi_lock.release()

        return execute_locked

    return decorator


class RabbitMQManagementAPI(object):
    RABBITMQ_CLIENT_TLS_PATH = os.path.join(BASE_TLS_PATH, 'rabbitmq')
    RABBITMQ_TLS_CA_PATH = os.path.join(BASE_TLS_PATH, 'gcca')
    RABBIT_SERVER_COMMON_NAME = 'GuardicoreRabbitMQServer'
    RABBITMQ_SSL_SNI = "guardicore-rmq-server"
    RABBITMQ_SNI_SSL_PORT = 443
    RABBITMQ_HTTP_PORT = 5672
    DELAY_BETWEEN_RETRIES_SEC = 10

    def __init__(self, management_host, user, password, exchange, transport_type,
                 component_id,
                 port=RABBITMQ_SNI_SSL_PORT,
                 ssl_server_name_indication=RABBITMQ_SSL_SNI,
                 connect_timeout=3,
                 blocking=False,
                 queue_name=None, rabbitmq_use_ssl=True, rabbitmq_tls_path=RABBITMQ_CLIENT_TLS_PATH,
                 rabbitmq_tls_ca_path=RABBITMQ_TLS_CA_PATH,
                 heartbeat=DEFAULT_RABBIT_HEARTBEAT, exchange_type='direct', routing_keys=None,
                 declare_queue_args=None, declare_rpc_queue=True, callbacks=None, error_callback=None,
                 rpc_call_timeout_sec=DEFAULT_RPC_TIMEOUT_SECS,
                 rpc_call_default_exchange=RPCExchange.CONTROL_EXCHANGE_NAME, rpc_call_default_routing_key='',
                 peer_hostname=RABBIT_SERVER_COMMON_NAME, attempt_reconnect_on_error=True,
                 prefetch_count=RABBITMQ_DEFAULT_QOS_PREFETCH_FLAG,
                 callback_pool_size=DEFAULT_RABBITMQ_CALLBACK_POOL_SIZE,
                 read_loop_error_callback=None):
        """
        Initializes RabbitMQ management API
        """
        if LooseVersion(haigha2.__version__) < LooseVersion('1.0.0'):
            raise ImportError("Haigha2 version 1.0.0 or higher is required; pip install haigha2==1.0.0")

        self.logger = get_logger()
        self.logger.debug("Initializing component api for component %s", component_id)

        self.management_host = management_host
        self.rabbitmq_port = port
        self._connect_timeout = connect_timeout
        self.ssl_sni = ssl_server_name_indication
        self.user = user
        self.password = password

        self.peer_hostname = peer_hostname
        self.exchange = exchange
        self.exchange_type = exchange_type
        self.declare_queue_args = declare_queue_args if declare_queue_args is not None else {}
        self.declare_rpc_queue = declare_rpc_queue
        self.prefetch_count = prefetch_count
        self.callback_pool_size = callback_pool_size
        self.client_stats = RabbitMQClientStats()
        self.rpc_call_default_routing_key = rpc_call_default_routing_key
        self.rpc_call_default_exchange = rpc_call_default_exchange
        # if prefetching is enabled the consumer-producer acks must be enabled as well
        self.send_acks = bool(prefetch_count)

        if declare_queue_args is None:
            # backwards compatibility with the queue_name argument
            if queue_name is None:
                self.declare_queue_args['exclusive'] = True
            else:
                self.declare_queue_args.setdefault('queue', queue_name)
                self.declare_queue_args.setdefault('durable', False)

        self.routing_keys = routing_keys if routing_keys is not None else [RPCRoutingKey.BROADCAST_ROUTING_KEY]
        self.rabbitmq_use_ssl = rabbitmq_use_ssl
        self.rabbitmq_tls_path = rabbitmq_tls_path
        self.rabbitmq_tls_ca_path = rabbitmq_tls_ca_path
        self.rpc_call_timeout_sec = rpc_call_timeout_sec
        self.transport_type = transport_type
        self.blocking = blocking
        self.component_id = component_id
        self.heartbeat = heartbeat
        self.close_required = False
        self.shutting_down = False
        self.error_callback_func = None
        self.read_loop_error_callback_func = None
        self.msg_callback_error_callback_func = None
        self.attempt_reconnect_on_error = attempt_reconnect_on_error

        self._management_time_diff = None  # always set to time difference from management utc time

        self._initialize_transport()

        self._initialize_callbacks(callbacks)
        if error_callback is not None:
            self.add_error_callback(error_callback)
        if read_loop_error_callback is not None:
            self.add_read_loop_error_callback(read_loop_error_callback)

        self._initialize_rabbitmq()

    def _initialize_transport(self):
        """
        Initialize underlying transport class to one of gevent or eventlet based transport.
        """
        transport_types = {'gevent': GEventTransport,
                           'eventlet': EventletTransport,
                           'gevent_pool': GEventPoolTransport}
        if self.transport_type not in transport_types:
            raise ManagementAPIError("Unsupported transport type '{transport_type}'".format(
                transport_type=self.transport_type))
        self.transport = transport_types[self.transport_type]

        if self.transport is None:
            raise ManagementAPIError("Transport type is '{transport_type}' but {transport_type} not installed".format(
                transport_type=self.transport_type))

        if self._is_gevent_pool_transport_instance():
            try:
                self.transport.setup(size=self.callback_pool_size)
            except ManagementAPIError:
                self.logger.debug('Transport pool for rabbitmq client was already created')

    def _is_gevent_pool_transport_instance(self):
        return GEventPoolTransport is not None and self.transport is GEventPoolTransport

    def close(self):
        """
        Safely disconnect and close the rabbitapi, while closing all connections and channels in an orderly fashion.
        """
        self.logger.debug("Closing component API for component %s", self.component_id)
        self.close_required = True
        self._disconnect_rabbitmq()

    def force_close(self):
        """
        Brutally close rabbit, by just disconnecting. This is faster than regular "close", but may leave
         some open resources on the server side, and therefore should be used only for special purpose.
        """
        self.logger.debug("Forcefully Closing component API for component %s", self.component_id)
        self.close_required = True
        self._disconnect_rabbitmq(close_channel=False, close_connection=False)

    @rabbitapi_locked()
    def _disconnect_rabbitmq(self, kill_read_loop_greenlet=True, close_channel=True, close_connection=True):
        """
        Disconnect from rabbitmq.
        :param kill_read_loop_greenlet: should the read loop greenlet be killed?
        :param close_channel: should the rabbit channel be closed?
        """
        self.shutting_down = True
        try:
            if kill_read_loop_greenlet:
                try:
                    self._read_loop_greenlet.kill()
                except Exception:
                    self.logger.exception("Error while killing read loop greenlet")
                except:
                    self.logger.warning("Error while killing read loop greenlet, "
                                        "not printing traceback as it was probably caused intentionally by "
                                        "GreenletExit")

            if self._is_gevent_pool_transport_instance():
                try:
                    self.transport.clean()
                except Exception:
                    self.logger.exception("Error while cleaning rabbitmq client transport pool")

            if self._channel is not None:
                self.logger.info("Disconnecting from rabbitmq")
                if close_channel:
                    self.logger.debug("Closing channel...")
                    try:
                        with self.transport.Timeout(CONNECTION_CLOSE_TIMEOUT):
                            self._channel.close()
                    except ConnectionError:
                        self.logger.exception("Error while attempting to close channel - moving on.")
                    except self.transport.Timeout:
                        self.logger.warn("Timeout closing the connection, ignoring it")

                # Sometimes a disconnection won't mark the channel as closed, and the next RPC call will block forever
                self._channel._closed = True
                self._channel = None

            if self._rabbitconn is not None:
                if close_connection:
                    self.logger.debug("Closing connection...")
                    try:
                        self._rabbitconn.close()
                    except ConnectionError:
                        self.logger.exception("Error while attempting to close connection - moving on.")

                self.logger.debug("Disconnecting...")
                try:
                    self._rabbitconn.disconnect()
                except ConnectionError:
                    self.logger.exception("Error while attempting to disconnect from rabbitmq - moving on.")
                self._rabbitconn = None
        finally:
            self.shutting_down = False

    def _initialize_callbacks(self, callbacks=None):
        """
        Initialize message callbacks dict.
        :param callbacks: list of predefined callbacks to register
        """
        self.message_callbacks = {}
        if callbacks is not None:
            for message_type, callback_func in callbacks.items():
                self.add_callback(message_type, callback_func)

    def _initialize_rabbitmq(self):
        """
        Initialize rabbitmq connection, channel and other related objects.
        :return: None
        """
        self._rabbitmq_frames_arrived = self.transport.Event()
        self._rabbitapi_lock = self.transport.Lock()
        self._connect_to_rabbitmq()
        self._read_loop_greenlet = self.transport.spawn(self._read_loop)
        self._read_loop_greenlet.link(self._read_loop_error_callback)

    def _rabbit_connection_close_cb(self):
        """
        Close callback called by haigha when the connection was closed.
        We mark the internal connection object as closed and possibly prepare for reconnection attempt.
        """
        self.logger.info("Haigha close callback called. Cleaning up...")
        if not self._rabbitconn:
            self.logger.info("No RabbitMQ Connection found")
            return

        if self.shutting_down:
            # GC-17135: When a connection error happens during an attempt to close the channel object,
            # haigha will call the connection close callback and we'll get here.
            # If we do nothing in this scenario, haigha is gonna get completely stuck waiting for read_frames
            # (waiting for an ACK on the channel close). To avoid it, we're raising a ConnectionError here
            # which will make haigha give up on the close request and we'll get back to the original
            # _disconnect_rabbitmq call.
            # On that note, haigha is shit. Don't say I didn't warn ya.
            self.logger.error("Rabbit connection close CB called during shutdown")
            raise ConnectionError("Rabbit connection close CB called during shutdown "
                                  "- raising exception to forcefully terminate connection")

        self._disconnect_rabbitmq(kill_read_loop_greenlet=False, close_channel=False, close_connection=False)

    @rabbitapi_locked()
    def _connect_to_rabbitmq(self):
        """
        Connect to the rabbitmq server.
        """
        if self.rabbitmq_use_ssl:
            if not self.ssl_sni:
                # this is needed for non-SNI users on management, since we don't have SNI support on our
                # Python version (2.7.6)
                self._rabbitconn = get_ssl_connection(rabbitmq_host=self.management_host,
                                                      user=self.user,
                                                      password=self.password,
                                                      vhost=GUARDICORE_VHOST_NAME,
                                                      port=self.rabbitmq_port,
                                                      logger=self.logger,
                                                      heartbeat=self.heartbeat,
                                                      close_cb=self._rabbit_connection_close_cb)
            else:
                self._rabbitconn = SSLConnection(host=self.management_host, user=self.user, password=self.password,
                                                 vhost=GUARDICORE_VHOST_NAME,
                                                 port=self.rabbitmq_port,
                                                 connect_timeout=self._connect_timeout,
                                                 server_hostname=self.ssl_sni,
                                                 logger=self.logger,
                                                 heartbeat=self.heartbeat,
                                                 close_cb=self._rabbit_connection_close_cb)
                self._rabbitconn.initialize_ssl(
                    transport_type='gevent' if self.transport_type in ('gevent', 'gevent_pool') else self.transport_type,
                    keyfile=os.path.join(self.rabbitmq_tls_path, 'key.pem'),
                    certfile=os.path.join(self.rabbitmq_tls_path, 'cert.pem'),
                    cert_reqs=ssl.CERT_REQUIRED,
                    ca_certs=os.path.join(self.rabbitmq_tls_ca_path, 'cacert.pem'),
                    server_hostname=self.ssl_sni)
                if self.peer_hostname:
                    self._rabbitconn.verify_hostname(self.peer_hostname)
        else:
            self._rabbitconn = Connection(host=self.management_host, user=self.user, password=self.password,
                                          vhost=GUARDICORE_VHOST_NAME,
                                          port=RabbitMQManagementAPI.RABBITMQ_HTTP_PORT,
                                          connect_timeout=self._connect_timeout,
                                          logger=self.logger,
                                          transport='gevent' if self.transport_type in ('gevent', 'gevent_pool') else self.transport_type,
                                          heartbeat=self.heartbeat,
                                          close_cb=self._rabbit_connection_close_cb)

        self.logger.info("%s - Connection to RabbitMQ server successful", self.component_id)

        # Initialize rabbitmq channel, queues, exchanges etc.
        self._channel = self._rabbitconn.channel(synchronous=True)

        if self.prefetch_count:
            self._channel.basic.qos(prefetch_count=self.prefetch_count)

        self._queue = self._channel.queue.declare(**self.declare_queue_args)[0]

        if self.exchange:
            self._channel.exchange.declare(exchange=self.exchange, type=self.exchange_type)
            for routing_key in self.routing_keys:
                self._channel.queue.bind(queue=self._queue, exchange=self.exchange, routing_key=routing_key)

        self._channel.basic.consume(queue=self._queue,
                                    consumer=self._process_message,
                                    no_ack=not self.send_acks)

        # RPC Initialization
        self._responses = {}

    def _delivery_ack_callback(self, delivery_tag, gt=None):
        self._channel.basic.ack(delivery_tag=delivery_tag)

    def _read_loop_error_callback(self, gt):
        """
        Error callback called on exceptions in the read loop greenlet.
        :param gt: the failed greenlet
        :return: None
        """
        self._error_callback(gt, callback_func=self.read_loop_error_callback_func)

    def _msg_callback_error_callback(self, gt):
        """
        Error callback called on exceptions on message callbacks.
        :param gt: the failed greenlet
        :return: None
        """
        self._error_callback(gt, callback_func=self.msg_callback_error_callback_func)

    def _error_callback(self, gt, callback_func):
        """
        Internal error callback, called when one of the rabbitapi greenlets goes down.
        Fetches the exception and calls the registered error callback func.
        :param gt: the failed greenlet
        """
        error = self.transport.get_greenlet_exception(gt)
        if error is None:
            return

        if callback_func is None:
            callback_func = self.error_callback_func

        if callback_func is None:
            self.logger.error("An error happened on greenlet %s but no error callback was set: %s", gt, error)
        else:
            try:
                callback_func(error)
            except:
                self.logger.exception("Error while calling error callback %s on error %s", callback_func, error)
                raise

    def add_error_callback(self, callback_func):
        """
        Backwards compatibility: add a unified error callback called both on read loop errors and on
        errors on message callbacks.
        The function would be called with a single parameter - the raised exception.
        :param callback_func: callback function
        """
        self.error_callback_func = callback_func

    def add_read_loop_error_callback(self, callback_func):
        """
        Adds an error callback function which will be called when there is an unexpected Exception in the
        component RabbitMQ read loop - for example, when a disconnection is detected.
        The function would be called with a single parameter - the raised exception.
        :param callback_func: callback function
        """
        self.read_loop_error_callback_func = callback_func

    def add_msg_callback_error_callback(self, callback_func):
        """
        Adds an error callback function which will be called when there is an unexpected Exception
        in a message callback.
        The function would be called with a single parameter - the raised exception.
        :param callback_func: callback function
        """
        self.msg_callback_error_callback_func = callback_func

    @rabbitapi_locked()
    def _publish_message(self, msg, exchange, routing_key):
        """
        Safely publishes a message through the RabbitMQ channel.
        A lock is used to prevent multiple greenlets from concurrently publishing a message;
        this is needed as haigha (as of 0.8.0) does not properly prevent this situation.
        See https://guardicore.atlassian.net/browse/GC-2712
        """
        if self._channel is None:
            raise EmptyRabbitConnection('Error in RabbitMQ API read loop. Channel was not reinitialized correctly.')
        self._channel.basic.publish(msg=msg, exchange=exchange, routing_key=routing_key)

    def add_callback(self, message_type, callback_func, initial_call=False, initial_call_func=None):
        """
        Registers a message handling callback function.
        callback_func will be called with a message dictionary,
        containing {message_type: message_type, **additional_params}
        :param message_type:
        :param callback_func:
        """
        def _callback(msg, message_contents):
            try:
                reply_message = callback_func(message_contents)
            except Exception:
                self.logger.exception(("Exception on callback %r processing message "
                                      "type %r (content: %r)"), callback_func, message_type, message_contents)
                raise
            
            if 'reply_to' not in msg.properties:
                return

            reply_to = msg.properties["reply_to"]
            correlation_id = msg.properties["correlation_id"]
            result = (self.component_id, True, reply_message)
            msg_encoding = JSON_ENCODING
            body, compressed = encode_compressed_by_size(result, msg_encoding)
            response = Message(body, correlation_id=correlation_id, delivery_mode=PERSISTENT_MESSAGE_DELIVERY_MODE,
                               encoding=msg_encoding, compressed=compressed)
            if not self._channel:
                self.logger.warn("RabbitMQ channel closed during callback %r, dropping response message with "
                                 "correlation ID %s to routing key %s", callback_func, correlation_id, reply_to)
                return
            self._publish_message(msg=response, exchange='', routing_key=reply_to)

        self.message_callbacks[message_type] = _callback
        self.logger.debug('Callback registered, callbacks are now : {}, API is : {}'.format(
            self.message_callbacks, self))

        if initial_call and initial_call_func is not None:
            initial_call_func()

    def _process_message(self, msg):
        """
        Message processing handler, called when a message is read for consumption. Process the message,
        potentially call the appropriate callback for it.
        :param msg: message
        """
        application_headers = msg.properties.get('application_headers', {})
        message_contents, encoding_used = decode_message(msg.body, application_headers.get('encoding', None),
                                                         application_headers.get('compressed', False))

        rpc_message_type = message_contents[RPC_MSG_TYPE_KEY]
        self.client_stats.on_message_received(rpc_message_type)

        callback = self.message_callbacks.get(rpc_message_type, None)
        if callback is None:
            self.logger.info("Component id: %s received message type %s with no callback registered",
                             self.component_id, rpc_message_type)
            self.logger.debug("Message: '%s'", message_contents)
            self.logger.debug("Available processing callbacks are: {}, API is: {}".format(self.message_callbacks, self))
            self.client_stats.on_callback_not_registered(rpc_message_type)

            if self.send_acks:
                self._delivery_ack_callback(delivery_tag=msg.delivery_info['delivery_tag'])
            return

        callback_greenlet = self.transport.spawn(callback, msg, message_contents)

        if callback_greenlet is None:
            # Failed to spawn greenlet, could be if spawning in limited gevent pool
            self.logger.info('failed to spawn gevent, probably pool is full')
            if self._is_gevent_pool_transport_instance():
                self.logger.debug("gevent pool size: {}\t"
                                  "running: {}\t"
                                  "free: {}".format(self.transport._POOL.size,
                                                    len(self.transport._POOL),
                                                    self.transport._POOL.free_count()))
            self.client_stats.on_callback_spawn_failed(rpc_message_type)

            if self.send_acks:
                self._delivery_ack_callback(delivery_tag=msg.delivery_info['delivery_tag'])
            return

        if self.send_acks:
            callback_greenlet.link(lambda gt:
                                   self._delivery_ack_callback(delivery_tag=msg.delivery_info['delivery_tag'],
                                                               gt=gt))

        callback_greenlet.link(self._msg_callback_error_callback)

    def _is_rabbitmq_connection_closed(self):
        """
        Check if the underlying rabbitmq connection is closed.
        :return: True if it's closed, False if it's still active.
        """
        # `haigha` connection is not marked as closed when it's
        # transport is disconnected and become None. If the transport is None read_frames
        # return immediately (and do nothing).
        # So in order to avoid busy loop we check directly that the transport is not None (which is the third condition)
        # :see: https://github.com/agoragames/haigha/issues/77
        # :see: https://guardicore.atlassian.net/browse/GC-5385
        return (self._channel is None or self._channel.closed
                or self._rabbitconn is None or self._rabbitconn.closed or self._rabbitconn._transport is None)

    def _read_loop(self):
        """
        RabbitMQ frames reading loop.
        """
        while True:  # If temporarily disconnected, we retry.
            try:
                while not self._is_rabbitmq_connection_closed():
                    # note: this is not done with self._rabbitapi_lock held since it would block anything else.
                    # however, if at the beginning of read_frames the connection is open, read_frames
                    # will succeed, so we're supposed to be ok.
                    self._rabbitconn.read_frames()
                    self._rabbitmq_frames_arrived.set()
                    self._rabbitmq_frames_arrived.reset()
            except Exception:
                if not self.close_required:
                    self.logger.exception('Error while reading RabbitMQ frames')
            finally:
                if self.close_required:
                    self.logger.debug("Closing component %s read loop", self.component_id)
                    return
                if not self.attempt_reconnect_on_error:
                    raise ManagementAPIError("Error in rabbit API read loop. "
                                             "Not reconnecting since reconnection is disabled. ")
                self._attempt_reconnect()  # will raise an error if reconnection failed

    def _attempt_reconnect(self):
        """
        Attempt to reconnect to rabbitmq after error.
        """
        error_str = 'Error in read_loop\n'
        if self._channel and self._channel.close_info:
            error_str += 'RabbitMQ Channel closed: %s : %s\n' % (
                self._channel.close_info['reply_code'],
                self._channel.close_info['reply_text'])
        if self._rabbitconn and self._rabbitconn.close_info:
            error_str += 'RabbitMQ Connection closed: %s : %s\n' % (
                self._rabbitconn.close_info['reply_code'],
                self._rabbitconn.close_info['reply_text'])

        self.logger.error('%sReconnecting in %d seconds...' % (
            error_str,
            self.DELAY_BETWEEN_RETRIES_SEC))

        try:
            self.logger.debug("Forcibly disconnecting previous RabbitMQ connection...")
            self._disconnect_rabbitmq(kill_read_loop_greenlet=False, close_channel=False, close_connection=False)
        except Exception:
            self.logger.exception("Error while closing previous RabbitMQ connections")

        self.transport.sleep(self.DELAY_BETWEEN_RETRIES_SEC)

        # Try and close the existing connection, in order not to leak it

        self.logger.info("API Reconnecting to RabbitMQ server")
        self._connect_to_rabbitmq()

    def _update_management_timestamp(self, management_timestamp):
        """
        Update known time diff from management according to the reported management timestamp.
        :param management_timestamp: last reported management timestamp
        """
        self._management_time_diff = management_timestamp - datetime.datetime.utcnow()

    def get_management_time_diff(self):
        """get_management_time_diff()
        Get the current value of the management time diff.
        """

        return self._management_time_diff

    def set_management_time_diff(self, new_time_diff):
        """set_management_time_diff(new_time_diff)
        :param new_time_diff: the new time diff to set
        """

        self._management_time_diff = new_time_diff

    def get_management_utcnow(self):
        """
        Get current timestamp in utcnow, in (approximate) management time
        :return: current timestamp.
        """
        if self._management_time_diff is None:
            self.logger.debug("Management time diff is unknown - assuming times match")
            return datetime.datetime.utcnow()

        return datetime.datetime.utcnow() + self._management_time_diff

    def _on_rpc_response(self, msg):
        """
        Called on RPC message response. Pushes it to the queue of processed responses.
        :param msg: response message
        """
        timestamp = msg.properties.get("timestamp")
        if timestamp:
            self._update_management_timestamp(timestamp)

        corr_id = msg.properties["correlation_id"]
        if corr_id in self._responses:
            self._responses[corr_id] = msg

    def send_message(self, message_type, exchange='', routing_key=None, expiration_sec=None,
                     durable=True, **kwargs):
        """
        Sends a RabbitMQ message to a specific exchange/routing key.
        :param message_type: a string which indicates the message type
        :param exchange:
        :param routing_key:
        :param expiration_sec: after how many seconds message is irrelevant
        :param durable: is message supposed to survive broker restarts
        :param kwargs: additional parameters which go into message
        """
        kwargs['component_id'] = self.component_id
        message = {RPC_MSG_TYPE_KEY: message_type}
        message.update(kwargs)
        delivery_mode = PERSISTENT_MESSAGE_DELIVERY_MODE if durable else NON_PERSISTENT_MESSAGE_DELIVERY_MODE
        msg_encoding = JSON_ENCODING
        body, compressed = encode_compressed_by_size(message, msg_encoding)
        if expiration_sec is None:
            rabbit_msg = Message(body, delivery_mode=delivery_mode,
                                 application_headers={'encoding': msg_encoding, 'compressed': compressed})
        else:
            rabbit_msg = Message(body, delivery_mode=delivery_mode,
                                 expiration=str(expiration_sec*MS_IN_SEC),
                                 application_headers={'encoding': msg_encoding, 'compressed': compressed})

        self._publish_message(msg=rabbit_msg, exchange=exchange, routing_key=routing_key)

    def call_management_rpc(self, rpc_func_name, blocking=None, priority=None,
                            timeout_sec=None, expiration_sec=None, exchange=None,
                            routing_key=None, msg_encoding=JSON_ENCODING, message_body=None, compressed=False,
                            **kwargs):
        """
        Send an RPC to the management server, and maybe get response.
        :param rpc_func_name: RPC function name
        :param blocking: if True - wait for response. if False, send and return immediately. Otherwise, decide according
            to self.blocking.
        :param priority: message priority (should not be touched except for very specific cases).
        :param expiration_sec: optional message expiration
        :param timeout_sec: optional send timeout
        :param routing_key: an optional routing key to which queue should this message be delivered
        :param exchange: an exchange name to be delivered to
        :param msg_encoding: the encoding for the message
        :param message_body: optional message body
        :param compressed: is message body compressed
        :param kwargs: other message arguments
        :return: return value from management if send is blocking, None otherwise.
        """
        if blocking is None:
            blocking = self.blocking

        if exchange is None:
            exchange = self.rpc_call_default_exchange
        if routing_key is None:
            routing_key = self.rpc_call_default_routing_key

        assert isinstance(rpc_func_name, str)
        corr_id = str(uuid.uuid4())

        self.logger.debug("Sending message %s with correlation id %s to exchange: %s with routing key: %s",
                          rpc_func_name, corr_id, exchange, routing_key)

        if not message_body:
            message_body, compressed = build_message_body(rpc_func_name, **kwargs)

        application_headers = {'encoding': msg_encoding, 'compressed': compressed}

        # Specific to Reveal component. Done to preserve message structure
        self.append_reveal_specific_application_headers(application_headers, **kwargs)

        default_priority = MessagePriority.BLOCKING_MESSAGE_PRIORITY if blocking else \
            MessagePriority.LOW_MESSAGE_PRIORITY
        # python 3 can't cmp None in max
        if not priority:
            priority = 0	
        priority = max(priority, default_priority)

        if blocking:
            if timeout_sec is None:
                timeout_sec = self.rpc_call_timeout_sec[priority]

            # no point in processing the message after more then ~timeout sec (since the caller already gave up)
            max_expiration = timeout_sec + RPC_MESSAGE_TIMEOUT_ADDITIONAL
            expiration_sec = max_expiration if expiration_sec is None else min(expiration_sec, max_expiration)

            callback_queue = self._channel.queue.declare(exclusive=True)[0]
            self.logger.debug("Created one-time RPC callback queue %s", callback_queue)

        else:
            callback_queue = None

        try:
            if expiration_sec is None:
                msg = Message(message_body, reply_to=callback_queue, correlation_id=corr_id,
                              content_type=rpc_func_name, delivery_mode=PERSISTENT_MESSAGE_DELIVERY_MODE,
                              priority=priority, application_headers=application_headers)
            else:
                msg = Message(message_body, reply_to=callback_queue, correlation_id=corr_id,
                              content_type=rpc_func_name, expiration=str(expiration_sec*MS_IN_SEC),
                              delivery_mode=PERSISTENT_MESSAGE_DELIVERY_MODE,
                              priority=priority, application_headers=application_headers)

            msg._properties['timestamp'] = self.get_management_utcnow()

            if blocking:
                self._responses[corr_id] = None

            self._publish_message(msg=msg, exchange=exchange, routing_key=routing_key)
            if not blocking:
                return

            self._channel.basic.consume(callback_queue, self._on_rpc_response, no_ack=self.send_acks)

            with self.transport.Timeout(timeout_sec, exception=RPCTimeoutError(rpc_func_name)):
                while self._responses[corr_id] is None:
                    self._rabbitmq_frames_arrived.wait()
        finally:
            if callback_queue is not None:
                try:
                    self.logger.debug("Deleting RPC callback queue %s", callback_queue)
                    self._channel.queue.delete(callback_queue)
                except Exception:
                    self.logger.exception("Failed to delete RPC queue %s. Moving on.", callback_queue)

        return_msg = self._responses.pop(corr_id)
        application_headers = return_msg.properties.get('application_headers', {})
        return_value, encoding_used = decode_message(return_msg.body, application_headers.get('encoding', None),
                                                     application_headers.get('compressed', False))
        self.logger.debug("Got reply for RPC func %s with corr_id %s", rpc_func_name, corr_id)
        if isinstance(return_value, BaseException):
            raise ManagementAPIError("%s: %s" % (return_value.__class__.__name__, return_value, ))
        return return_value

    def add_routing_key(self, routing_key):
        """
        Add a routing key which routs messages to self._queue.
        :param routing_key: routing key
        """
        if routing_key in self.routing_keys:
            return

        self.routing_keys.append(routing_key)
        self.logger.info("Adding routing key %s", routing_key)
        self._channel.queue.bind(queue=self._queue, exchange=self.exchange, routing_key=routing_key)
        self.logger.info("Added routing key %s", routing_key)

    def remove_routing_key(self, routing_key):
        """
        Remove a routing key.
        :param routing_key: routing key
        """
        if routing_key not in self.routing_keys:
            return

        self.routing_keys.remove(routing_key)
        self.logger.info("Removing routing key %s", routing_key)
        self._channel.queue.unbind(queue=self._queue, exchange=self.exchange, routing_key=routing_key)
        self.logger.info("Removed routing key %s", routing_key)

    @staticmethod
    def append_reveal_specific_application_headers(application_headers, **kwargs):
        """ Reveal component in Aggregator might store reveal-event report messages in compressed format.
        In order to keep message structure as is and avoid decompressing-compressing message in order
        to modify message (add stale/sequence flags) it was decided to add them in application_headers."""
        sequence = kwargs.get('sequence')
        stale = kwargs.get('stale')
        if sequence is not None:
            application_headers['sequence'] = sequence
        if stale is not None:
            application_headers['stale'] = stale

    def dump_stats(self):
        return self.client_stats.dump_stats()

def get_ssl_connection(rabbitmq_host=RABBITMQ_HOST,
                       user=DEFAULT_RABBITMQ_USERNAME,
                       password=DEFAULT_RABBITMQ_PASSWORD,
                       vhost=GUARDICORE_VHOST_NAME,
                       heartbeat=DEFAULT_RABBIT_HEARTBEAT,
                       port=RABBITMQ_SSL_PORT,
                       transport='gevent',
                       close_cb=None,
                       logger=None):
    logger = logger if logger else get_logger()
    logger.info('Initializing RabbitMQ SSL connection to {}:{}'.format(rabbitmq_host, port))
    conn = SSLConnection(host=rabbitmq_host, user=user, password=password,
                         vhost=vhost,
                         port=port,
                         logger=logger,
                         heartbeat=heartbeat,
                         close_cb=close_cb)


    logger.info('Using following SSL files')
    logger.info('cert file: "{}"'.format(RABBITMQ_CLIENT_TLS_CERT_FILE))
    logger.info('key file: "{}"'.format(RABBITMQ_CLIENT_TLS_KEY_FILE))
    logger.info('ca file: "{}"'.format(RABBITMQ_TLS_CA_FILE))
    conn.initialize_ssl(transport_type='gevent' if transport in ('gevent', 'gevent_pool') else transport,
                        keyfile=RABBITMQ_CLIENT_TLS_KEY_FILE,
                        certfile=RABBITMQ_CLIENT_TLS_CERT_FILE,
                        cert_reqs=ssl.CERT_REQUIRED,
                        ca_certs=RABBITMQ_TLS_CA_FILE)

    return conn

