from enum import IntEnum

from common.py.apis import DEFAULT_RABBITMQ_USERNAME, DEFAULT_RABBITMQ_PASSWORD, RPCExchange, RPCMessage, \
    MessagePriority, RPCRoutingKey
from common.py.apis.management.rabbit import RabbitMQManagementAPI
from common.logger import get_logger

LOG = get_logger(module_name=__name__)


class ExportersRoutingKey(object):
    EVENTS_EXPORTER_KEY = 'events_exporter_key'
    COMMANDS_EXPORTER_KEY = 'commands_exporter_key'
    NETWORK_LOG_EXPORTER_KEY = 'network_log_exporter_key'


class ExportersQueue(IntEnum):
    events = 0
    network_logs = 1
    control = 2
    commands = 3


EXPORTERS_QUEUE_ROUTING = {
    ExportersQueue.events:
        [ExportersRoutingKey.EVENTS_EXPORTER_KEY],
    ExportersQueue.network_logs:
        [ExportersRoutingKey.NETWORK_LOG_EXPORTER_KEY],
    ExportersQueue.control:
        [RPCRoutingKey.BROADCAST_ROUTING_KEY],
    ExportersQueue.commands:
        [ExportersRoutingKey.COMMANDS_EXPORTER_KEY]
}


class DataExportManagementApi(object):

    def __init__(self, management_hosts, component_id, exporter_queues, transport_type="gevent",
                 user=DEFAULT_RABBITMQ_USERNAME,
                 password=DEFAULT_RABBITMQ_PASSWORD, ssl_sni=RabbitMQManagementAPI.RABBITMQ_SSL_SNI,
                 port=RabbitMQManagementAPI.RABBITMQ_SNI_SSL_PORT,
                 exchange=RPCExchange.DATA_EXPORTER_EXCHANGE_NAME,
                 prefetch_count=None,
                 **kwargs):
        """
        Triggers an agent upgrades and checks for upgrade status' for each agent
        :param management_hosts:
        :param component_id:
        :param exporter_queues: {ExportersQueue: queue_name} if queue name is None it will create a new queue
        :param transport_type: default gevent
        :param user: DEFAULT_RABBITMQ_USERNAME
        :param password: DEFAULT_RABBITMQ_PASSWORD
        :param ssl_sni: RabbitMQManagementAPI.RABBITMQ_SSL_SNI
        :param port: RabbitMQManagementAPI.RABBITMQ_SSL_SNI
        :param exchange: RPCExchange.DATA_EXPORTER_EXCHANGE_NAME
        :param prefetch_count: None
        :param **kwargs:
        """

        self.rabbit_apis = {}
        management_host = None
        kwargs.update(dict(user=user,
                           password=password,
                           port=port,
                           ssl_server_name_indication=ssl_sni,
                           transport_type=transport_type,
                           component_id=component_id,
                           exchange=exchange,
                           prefetch_count=prefetch_count,
                           exchange_type='direct'))

        for index, management_host in enumerate(management_hosts):
            kwargs['management_host'] = management_host
            for exporter_queue, queue_name in exporter_queues.items():
                try:
                    routing_keys = EXPORTERS_QUEUE_ROUTING.get(exporter_queue, None)  # default will be broadcast
                    self.rabbit_apis[exporter_queue] = RabbitMQManagementAPI(
                        routing_keys=routing_keys,
                        queue_name=queue_name,
                        **kwargs)

                except Exception as exc:
                    if index < len(management_hosts) - 1:
                        LOG.warn("Error connecting rabbit from data exporter in component '%s' to over"
                                 " management host '%s': %s", component_id, management_host, exc)
                    else:
                        raise
            break
        self.management_host = management_host

    @property
    def rabbitapi(self):
        return self.rabbit_apis.get(ExportersQueue.events)

    @property
    def network_log_rabbitapi(self):
        return self.rabbit_apis.get(ExportersQueue.network_logs)

    @property
    def control_rabbitapi(self):
        return self.rabbit_apis.get(ExportersQueue.control)

    @property
    def commands_rabbitapi(self):
        return self.rabbit_apis.get(ExportersQueue.commands)

    def dump_stats(self):
        if self.network_log_rabbitapi:
            LOG.info("Network Log API client: %r", self.network_log_rabbitapi.dump_stats())

        if self.rabbitapi:
            LOG.info("Rabbit API client: %r", self.rabbitapi.dump_stats())

        if self.control_rabbitapi:
            LOG.info("Control API client: %r", self.control_rabbitapi.dump_stats())

        if self.commands_rabbitapi:
            LOG.info("Commands API client: %r", self.commands_rabbitapi.dump_stats())

    def __del__(self):
        self.close()

    def close(self):
        for api in self.rabbit_apis.values():
            if api:
                api.close()
        self.rabbit_apis = {}

    def get_rabbit_api(self):
        return self.rabbitapi

    def add_export_incident_callback(self, callback):
        if self.rabbitapi is None:
            raise Exception('Events log rabbit API was not initialized by the caller')
        self.rabbitapi.add_callback(RPCMessage.Exporters.EXPORT_INCIDENT_MESSAGE_TYPE,
                                    lambda msg: callback(msg['incident']))

    def add_export_generic_incident_callback(self, callback):
        if self.rabbitapi is None:
            raise Exception('Events log rabbit API was not initialized by the caller')
        self.rabbitapi.add_callback(RPCMessage.Exporters.EXPORT_GENERIC_INCIDENT_MESSAGE_TYPE,
                                    lambda msg: callback(msg['message']))

    def add_export_incident_iocs_callback(self, callback):
        if self.rabbitapi is None:
            raise Exception('Events log rabbit API was not initialized by the caller')
        self.rabbitapi.add_callback(RPCMessage.Exporters.EXPORT_INCIDENT_IOCS_MESSAGE_TYPE,
                                    lambda msg: callback(msg['incident'],
                                                         msg['iocs']))

    def add_export_audit_log_entry_callback(self, callback):
        if self.rabbitapi is None:
            raise Exception('Events log rabbit API was not initialized by the caller')
        self.rabbitapi.add_callback(RPCMessage.Exporters.EXPORT_AUDIT_LOG_ENTRY_MESSAGE_TYPE,
                                    lambda msg: callback(msg['audit_log_entry']))

    def add_export_system_alert_callback(self, callback):
        if self.rabbitapi is None:
            raise Exception('Events log rabbit API was not initialized by the caller')
        self.rabbitapi.add_callback(RPCMessage.Exporters.EXPORT_SYSTEM_ALERT_MESSAGE_TYPE,
                                    lambda msg: callback(msg['system_alert']))

    def add_export_agent_log_callback(self, callback):
        if self.rabbitapi is None:
            raise Exception('Events log rabbit API was not initialized by the caller')
        self.rabbitapi.add_callback(RPCMessage.Exporters.EXPORT_AGENT_LOG_MESSAGE_TYPE,
                                    lambda msg: callback(msg['agent_log']))

    def add_export_agent_alerts_status_report_callback(self, callback):
        self.rabbitapi.add_callback(RPCMessage.Exporters.EXPORT_AGENT_ALERTS_STATUS_REPORT_MESSAGE_TYPE,
                                    lambda msg: callback(msg['agent_alerts_report']))

    def add_export_label_change_log_callback(self, callback):
        if self.rabbitapi is None:
            raise Exception('Events log rabbit API was not initialized by the caller')
        self.rabbitapi.add_callback(RPCMessage.Exporters.EXPORT_LABEL_CHANGES_LOG_MESSAGE_TYPE,
                                    lambda msg: callback(msg['label_change_log']))

    def add_export_saved_map_status_callback(self, callback):
        if self.rabbitapi is None:
            raise Exception('Events log rabbit API was not initialized by the caller')
        self.rabbitapi.add_callback(RPCMessage.Exporters.EXPORT_SAVED_MAP_STATUS_MESSAGE_TYPE,
                                    lambda msg: callback(msg['saved_map']))

    def add_exporters_configuration_changed_callback(self, callback):
        if self.control_rabbitapi is None:
            raise Exception('Control rabbit API was not initialized by the caller')
        self.control_rabbitapi.add_callback(RPCMessage.Configuration.SYSTEM_CONFIGURATION_CHANGE_MESSAGE_TYPE,
                                            lambda msg: callback())

    def add_export_network_log_callback(self, callback):
        if self.network_log_rabbitapi is None:
            raise Exception('Network log rabbit API was not initialized by the caller')
        self.network_log_rabbitapi.add_callback(RPCMessage.Exporters.EXPORT_NETWORK_LOG_MESSAGE_TYPE,
                                                lambda msg: callback(msg['network_log_records']))

    def add_export_insight_alert_callback(self, callback):
        if self.rabbitapi is None:
            raise Exception('Events log rabbit API was not initialized by the caller')
        self.rabbitapi.add_callback(RPCMessage.Exporters.EXPORT_INSIGHT_ALERT_LIST_MESSAGE_TYPE,
                                    lambda msg: callback(msg['insight_alert_list']))

    def get_exporters_configuration(self):
        if self.commands_rabbitapi is None:
            raise Exception('commands rabbit API was not initialized by the caller')
        return self.commands_rabbitapi.call_management_rpc(RPCMessage.Exporters.GET_SYSLOG_CONFIGURATION_RPC_FUNC_NAME,
                                                           blocking=True)

    def get_exporters_additional_configuration(self):
        if self.commands_rabbitapi is None:
            raise Exception('commands rabbit API was not initialized by the caller')

        return self.commands_rabbitapi.call_management_rpc(RPCMessage.Exporters.GET_EXPORTER_ADDITIONAL_CONFIGURATION_RPC_FUNC_NAME,
                                                           blocking=True)

    def get_exporter_instances(self):
        if self.commands_rabbitapi is None:
            raise Exception('commands rabbit API was not initialized by the caller')

        return self.commands_rabbitapi.call_management_rpc(RPCMessage.Exporters.GET_EXPORTER_INSTANCES_FUNC_NAME,
                                                           blocking=True)

    def add_syslog_connectivity_test_callback(self, callback_func):
        """
        the callback method should have arguments:
        correlation_id - result should contain that id to return (used by us)
        syslog_config - to override default syslog exporter configuration
        audit_log_entry - log to send to syslog server
        """
        if self.commands_rabbitapi is None:
            raise Exception('commands rabbit API was not initialized by the caller')
        self.commands_rabbitapi.add_callback(RPCMessage.Exporters.SYSLOG_CONNECTIVITY_TEST,
                                             lambda message: callback_func(correlation_id=message['correlation_id'],
                                                                           syslog_config=message['syslog_config'],
                                                                           audit_log_entry=message['audit_log_entry']))

    def report_syslog_connectivity_test_result(self, correlation_id, result,
                                               error=None, error_message=None, error_code=None):
        """result should be of type ConnectionTestResult"""
        if self.commands_rabbitapi is None:
            raise Exception('commands rabbit API was not initialized by the caller')
        return self.commands_rabbitapi.call_management_rpc(
            RPCMessage.Exporters.REPORT_SYSLOG_CONNECTIVITY_TEST_RESULT,
            priority=MessagePriority.BLOCKING_MESSAGE_PRIORITY, blocking=True,
            correlation_id=correlation_id, result=result,
            error=error, error_message=error_message, error_code=error_code)

