'''
Created on Sep 23, 2014

@author: itamar
'''

import traceback
from common.logger import get_logger


def log_invocations_with_args(method):
    """log_invocations_with_args(method)
    
    Decorator which log the invocations of the method and it's arguments
    """
    
    def _wrapper(self, *args, **kwargs):
        module = getattr(method, "__module__", None)
        if not module:
            module = "unknown_module" if not getattr(module, "im_class", None) else method.im_class.__module__     
        
        logger = get_logger(module_name=module)
        
        logger.debug("Method %s.%s is called with arguments: %r, %r", module, method.__name__, args, kwargs)
        
        successful = False
        try:
            ret = method(self, *args, **kwargs)
            successful = True
        finally:
            if successful:
                logger.debug("Method %s.%s returned", module, method.__name__)
            else:
                logger.debug("Method %s.%s broke unsuccessful", module, method.__name__)
        
        return ret
    
    return _wrapper

def log_invocations_catch_exception(method):
    """log_invocations_catch_exception(method)
    
    Decorator which log the invocations of the method and catch all exceptions
    inside the method and report them
    """
    
    def _wrapper(self, *args, **kwargs):
        module = getattr(method, "__module__", None)
        if not module:
            module = "unknown_module" if not getattr(module, "im_class", None) else method.im_class.__module__     
        
        logger = get_logger(module_name=module)
        
        logger.debug("Method %s.%s is called with arguments: %r, %r", module, method.__name__, args, kwargs)
        
        ret = None
        try:
            ret = method(self, *args, **kwargs)
            logger.debug("Method %s.%s returned", module, method.__name__)
        except:
            logger.debug("Method %s.%s broke unsuccessful: %s", module, method.__name__, traceback.format_exc())
        
        return ret
    
    return _wrapper

def log_invocations(method):
    """log_invocations(method)
    
    Decorator which log the invocations of the method.
    """
    
    def _wrapper(self, *args, **kwargs):
        module = getattr(method, "__module__", None)
        if not module:
            module = "unknown_module" if not getattr(module, "im_class", None) else method.im_class.__module__     
        
        logger = get_logger(module_name=module)
        
        logger.debug("Method %s.%s is called", module, method.__name__)
        
        successful = False
        try:
            ret = method(self, *args, **kwargs)
            successful = True
        finally:
            if successful:
                logger.debug("Method %s.%s returned", module, method.__name__)
            else:
                logger.debug("Method %s.%s broke unsuccessful", module, method.__name__)
        
        return ret
    
    return _wrapper
