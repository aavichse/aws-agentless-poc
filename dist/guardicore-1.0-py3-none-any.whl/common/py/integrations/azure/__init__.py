from common.py.integrations.azure.control_client import AzureControlClient
from common.py.integrations.azure.proxy_client import AzureProxyClient
from common.py.integrations.azure.inventory_processor import AzureInventoryProcessor
