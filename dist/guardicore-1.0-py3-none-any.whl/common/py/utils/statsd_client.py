import statsd
from statsd.client import StatsClientBase

from common.logger import get_logger

LOG = get_logger(module_name=__name__)


# statsd client to load in case of loading error
class DummayStatsdClient(StatsClientBase):
    def __init__(self):
        super(DummayStatsdClient, self).__init__()

        self._prefix = None

    # noinspection PyMethodOverriding
    def _send(self, data):
        pass

    def pipeline(self):
        raise NotImplementedError()


class _StatsdClientFactory(object):
    """
    statsd client shall be used when no datadog dependency is available for the component
    e.g. aggregator, collector, monicore otherwise use `common.util.gc_statsd.GCStatsd`
    """

    # noinspection PyBroadException
    def get_statsd_client(self, *args, **kwargs):
        try:
            return statsd.StatsClient(*args, **kwargs)
        except:
            LOG.exception("Error loading statsd client (args=%s, kwargs=%s), no metrics will be reported", args, kwargs)
            return DummayStatsdClient()


StatsdClientFactory = _StatsdClientFactory()
