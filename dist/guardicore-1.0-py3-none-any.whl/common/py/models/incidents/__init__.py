from enum import Enum


class IncidentType(Enum):
    INCIDENT_OPTIONS_DEFAULT_INCIDENT_TYPE = 'Incident'
    FILE_DETECTED_INCIDENT_TYPE = 'File Detected'
    HONEYPOT_INCIDENT_TYPE = 'Deception'
    LATERAL_MOVEMENT_INCIDENT_TYPE = 'Lateral Movement'
    NETWORK_SCAN_INCIDENT_TYPE = 'Network Scan'
    NETWORK_VISIBILITY_INCIDENT_TYPE = 'Reveal'
    ANY_INCIDENT_TYPE = 'Any'
    EXPERIMENTAL_INCIDENT_TYPE = 'Experimental'
    INTEGRITY_INCIDENT_TYPE = 'Integrity'


class GenericRevealIncidentType(Enum):
    POLICY_VIOLATION = 'Policy Violation'
    BAD_REPUTATION = 'Bad Reputation'
