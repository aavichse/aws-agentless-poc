
from common.py.apis import DEFAULT_RABBITMQ_USERNAME, DEFAULT_RABBITMQ_PASSWORD, \
    REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT, ComponentType, AgentComponentType, AggregatorType, \
    RPCExchange, RPCMessage
from common.py.apis.management import UNKNOWN_API_VERSION
from common.py.apis.management.aggregating_system_component import AggregatorBaseComponentManagementAPI
from common.py.apis.management.collector import CollectorAPI
from common.py.events.agent import ComponentState
from common.logger import get_logger


LOG = get_logger(module_name=__name__)


class DetectionServerManagementAPI(AggregatorBaseComponentManagementAPI):
    COMPONENT_TYPE = ComponentType.DETECTION_AGENTS_SERVER
    AGENTS_COMPONENT_TYPE = AgentComponentType.DETECTION_AGENT
    RABBIT_API_CLASS = CollectorAPI
    COMPONENT_BASE_URI = 'aggregators'

    def __init__(self, management_hosts, agent_id, version=UNKNOWN_API_VERSION, user=DEFAULT_RABBITMQ_USERNAME,
                 password=DEFAULT_RABBITMQ_PASSWORD, configuration_schema=None, aggregator_configuration_schema=None,
                 associated_mgmt_configuration=None, agent_details=None, guest_installation_details=None,
                 aggregator_type=AggregatorType.COLLECTOR, aggregator_features=None, collector_type=None, **kwargs):
        component_id = self.COMPONENT_TYPE.prefix + agent_id
        component_details = agent_details if agent_details is not None else {}
        component_details.update(dict(version=version,
                                      associated_mgmt_configuration=associated_mgmt_configuration,
                                      management_host=management_hosts[-1],
                                      guest_installation_details=guest_installation_details))
        component_details['agent_id'] = agent_id

        super(DetectionServerManagementAPI, self).__init__(management_hosts=management_hosts,
                                                           agent_id=agent_id,
                                                           user=user,
                                                           password=password,
                                                           version=version,
                                                           exchange=RPCExchange.DETECTION_AGENTS_SERVER_EXCHANGE_NAME,
                                                           component_id=component_id,
                                                           aggregator_type=aggregator_type,
                                                           aggregator_features=aggregator_features,
                                                           collector_type=collector_type,
                                                           component_details=component_details,
                                                           heartbeat=REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT,
                                                           configuration_schema=configuration_schema,
                                                           aggregator_configuration_schema=aggregator_configuration_schema,
                                                           **kwargs)

        self.agents_details = {}

    def get_state(self):
        state = self.rabbitapi.call_management_rpc(RPCMessage.DetectionServer.DETECTION_AGENTS_SERVER_GET_STATE_RPC_FUNC_NAME,
                                                   component_id=self.component_id,
                                                   component_type=self.COMPONENT_TYPE,
                                                   component_details=self.component_details,
                                                   component_status=self.component_status,
                                                   blocking=True)
        return ComponentState[state]

    def add_state_update_callback(self, callback_func, initial_call=True):
        self.rabbitapi.add_callback(RPCMessage.DetectionServer.DETECTION_AGENTS_SERVER_STATE_CHANGE_MESSAGE_TYPE,
                                    lambda message: callback_func(ComponentState[message['state']]),
                                    initial_call=initial_call,
                                    initial_call_func=lambda: callback_func(self.get_state()))

    def report_fim_scan_result(self, fim_scan_results):
        """
        Reports a FIM scan result for a list of agents
        :param list fim_scan_results: a list of FimScanReport objects
        """
        self.rabbitapi.call_management_rpc(RPCMessage.DetectionServer.DETECTION_AGENTS_SERVER_FIM_SCAN_REPORT_RPC_FUNC_NAME,
                                           exchange=RPCExchange.DETECTION_AGENTS_SERVER_EXCHANGE_NAME,
                                           reports=fim_scan_results,
                                           blocking=True)

    def get_fim_policy(self):
        """
        Get the current FIM policy.
        :return: current FIM policy, as an FIMPolicy instance.
        """
        policy = self.rabbitapi.call_management_rpc(
            RPCMessage.DetectionServer.DETECTION_AGENTS_SERVER_GET_FIM_POLICY_RPC_FUNC_NAME,
            blocking=True)
        return policy

    def add_fim_policy_update_callback(self, callback_func, initial_call=True):
        """
        Register a callback to be called whenever the FIM policy is updated.
        :param callback_func: callback function. Expected to receive a single argument for the policy,
            as an FIMPolicy instance.
        :param initial_call: should the callback be called after registration with the current policy?
        """
        self.rabbitapi.add_callback(RPCMessage.DetectionServer.FIM_POLICY_UPDATE_MESSAGE_TYPE,
                                    lambda message: callback_func(),
                                    initial_call=initial_call,
                                    initial_call_func=lambda: callback_func())

    def add_osquery_command_callback(self, callback_func):
        """
        Register a callback to be called whenever an OSQuery Command arrives
        """
        self.rabbitapi.add_callback(RPCMessage.DetectionServer.DETECTION_AGENTS_SERVER_OSQUERY_COMMAND_FUNC_NAME,
                                    lambda message: callback_func(message['query_id'],
                                                                  message['time'],
                                                                  message['action'],
                                                                  message.get('configuration'),
                                                                  message.get('agent_uuids'),
                                                                  message.get('query')))

    def send_osquery_results(self, results):
        self.rabbitapi.call_management_rpc(RPCMessage.Aggregator.AGGREGATOR_OSQUERY_RESULTS_RPC_FUNC_NAME,
                                           routing_key=RPCMessage.Aggregator.AGGREGATOR_OSQUERY_RESULTS_RPC_FUNC_NAME,
                                           exchange=RPCExchange.AGENT_EVENT_EXCHANGE_NAME,
                                           query_report=results)
