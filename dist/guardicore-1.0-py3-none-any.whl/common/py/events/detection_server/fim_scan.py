import datetime
from collections import defaultdict

import attr

from common.py.events import LongHashType
from common.py.events.attrs import Dictable, enum_attr
from common.py.events.detection_server.fim_verdict import FIMPathScanVerdict


@attr.s
class FIMScanReport(Dictable):
    agent_id = attr.ib()            # type: str
    hostname = attr.ib()            # type: str
    source = attr.ib()              # type: str
    template_scans = attr.ib()      # type: [FIMTemplateScanReport]
    revision_id = attr.ib()         # type: int

    @classmethod
    def from_buffer(cls, buffered_scan_result):
        """
        Builds a FIMScanReport from buffered Redis messages
        :param str buffered_scan_result: a buffered FIM scan result
        :return: an instance of FIMScanReport
        """
        temp_object = cls.from_json(buffered_scan_result)
        return cls(agent_id=temp_object.agent_id,
                   hostname=temp_object.hostname,
                   source=temp_object.source,
                   revision_id=int(temp_object.revision_id),
                   template_scans=cls._fim_report_from_buffer(temp_object.template_scans))

    def get_template_id_to_scanned_paths_by_verdict(self, verdict):
        """
        Returns all pathes by verdict with their corresponding template ID
        :param FIMPathScanVerdict verdict: a verdict to group by
        :return: a dict of lists in the form of {<template_id>: [FIMPathScanReport, ], ...} objects
        """
        result = defaultdict(list)
        for report in self.template_scans:
            scanned_paths = report.get_scanned_paths_by_verdict(verdict)
            if scanned_paths:
                result[report.template_id] += report.get_scanned_paths_by_verdict(verdict)
        return result

    @classmethod
    def _fim_report_from_buffer(cls, fim_agents_reports):
        return [FIMTemplateScanReport.from_buffer(template_id=agent_scan_report['template_id'],
                                                  hash_type=agent_scan_report['hash_type'],
                                                  agent_scan_report=agent_scan_report['scan_results'])
                for agent_scan_report in fim_agents_reports]


@attr.s
class FIMTemplateScanReport(Dictable):
    template_id = attr.ib()                                 # type: str
    scan_results = attr.ib()                                # type: [FIMPathScanReport]
    hash_type = enum_attr(enum_type=LongHashType)           # type: LongHashType

    @classmethod
    def from_buffer(cls, template_id, agent_scan_report, hash_type):
        """
        Builds a FIMTemplateScanReport from buffered Redis messages
        :param str template_id: the template ID
        :param LongHashType hash_type: the hash type used for scan
        :param list agent_scan_report: the buffered scan report
        :return: an instance of FIMTemplateScanReport
        """
        return cls(template_id=template_id,
                   hash_type=hash_type,
                   scan_results=[FIMPathScanReport.from_buffer(path_scan_report)
                                 for path_scan_report in agent_scan_report])

    def get_scanned_paths_by_verdict(self, verdict):
        """
        Get all scanned paths whose scan verdict matches 'verdict'
        :param verdict: a FIMPathScanVerdict enum
        :return: a list of FIMPathScanReport matching that verdict
        """
        return [path_scan for path_scan in self.scan_results if path_scan.verdict == verdict]


@attr.s
class FIMPathScanReport(Dictable):
    path = attr.ib()                                     # type: str
    check_time = attr.ib()                               # type: datetime
    verdict = enum_attr(enum_type=FIMPathScanVerdict)    # type: FIMPathScanVerdict
    modified_time = attr.ib(default=None)                # type: datetime
    file_owner_name = attr.ib(default=None)              # type: str
    hash = attr.ib(default='')                           # type: str
    label_info = attr.ib(default=None)                   # type: FIMScanLabelInfo
    valid_template_id = attr.ib(default=None)            # type: str
    valid_label_name = attr.ib(default='')               # type: str
    error_description = attr.ib(default='')              # type: str

    @classmethod
    def from_buffer(cls, fim_report):
        """
        Builds a FIMPathScanReport from buffered Redis messages
        :param dict fim_report: a buffered path scan result
        :return: an instance of FIMPathScanReport
        """
        return cls(path=fim_report['path'],
                   hash=fim_report['hash'],
                   verdict=fim_report['verdict'],
                   check_time=fim_report['check_time'],
                   modified_time=fim_report['modified_time'],
                   file_owner_name=fim_report.get('file_owner_name'),
                   label_info=FIMScanLabelInfo.from_buffer(fim_report['label_info']) if fim_report['label_info'] else None,
                   error_description=fim_report['error_description'])


@attr.s
class FIMScanLabelInfo(Dictable):
    label_id = attr.ib()    # type: str
    key = attr.ib()         # type: str
    value = attr.ib()       # type: str

    @classmethod
    def from_buffer(cls, label_info):
        return cls(label_id=label_info['label_id'],
                   key=label_info['key'],
                   value=label_info['value'])
