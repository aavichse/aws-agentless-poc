from enum import Enum

__author__ = 'uri'


class NavigateBack(Exception):
    pass


class Skip(Exception):
    pass


class PasswordWeak(Exception):
    pass


class PasswordInvalid(Exception):
    pass


class TaskFailed(Exception):
    pass


class NetworkAddressMode(Enum):
    DHCP = "Automatic assignment by DHCP server"
    Static = "Set your IP Address manually"
    Skip = "Don't change the network configuration"


class DeploymentMode(Enum):
    OnPremise = "On premise deployment"
    SaaS = "Software as a Service deployment"


class HostConfigTask(Enum):
    SYSTEM_PASSWORD = 'root password'
    NETWORK_INTERFACES = 'network interfaces'

    def __str__(self):
        return self.value
