import attr
import json
import uuid
import datetime
import traceback
import sys
from enum import IntEnum, auto
from common.py.events.attrs import Dictable, string_attr, list_attr, enum_attr, dict_attr, set_attr, datetime_attr, \
    float_attr, LegacyDictable


def ensure_cls(cl):
    def converter(val):
        if isinstance(val, cl):
            return val
        else:
            return cl(**val)
    return converter


class AgentSDKTaskStatus(IntEnum):
    CREATED = 0
    QUEUED = 1
    IN_PROGRESS = 2
    ERROR = 3
    SUCCESS = 4


class AgentSDKCommandType(IntEnum):
    AGENT_COMMAND = 0
    OSQUERY = 1
    EVENT_LOG = 2
    ETW = 3


# Change should be reflected in management/scripts/sdk/agent_sdk.py
class AgentCommands(IntEnum):
    MODULES_STATUS = auto()
    GET_FILE_HASH = auto()
    GET_FILE_ATTRIBUTES = auto()
    LIST_DIRECTORY = auto()
    QUERY_EXTENDED_PROCESS_LIST = auto()
    GET_OS_DETAILS = auto()
    GET_FILE_SIZE = auto()
    TERMINATE_PROCESS = auto()
    PING = auto()
    GET_HOSTNAME = auto()
    GET_UPTIME = auto()
    START_AGENT_MODULES = auto()
    STOP_AGENT_MODULES = auto()
    ENABLE_MODULES = auto()
    DISABLE_MODULES = auto()
    GET_AGENT_INFO = auto()
    GET_AGENT_STATUS = auto()
    SET_CONFIGURATION = auto()
    GET_CONFIGURATION = auto()
    OPEN_FILE = auto()
    READ_FILE = auto()
    SEEK_FILE = auto()
    CLOSE_FILE = auto()
    CLOSE_OPEN_FILES = auto()
    GET_EXECUTABLE_CAPABILITIES = auto()
    GET_SYSTEM_STATUS = auto()
    KILL_PROCESS = auto()
    WRITE_FILE = auto()


class OSQueryCommands(IntEnum):
    BOOTSTRAP = auto()
    IS_SUPPORTED = auto()
    LIST_TABLES = auto()
    GET_SUMMARY = auto()
    RUN_QUERY = auto()


class EventLogCommands(IntEnum):
    START_REMOTE_EVENT_LOG_EXTRACTION = auto()
    STOP_REMOTE_EVENT_LOG_EXTRACTION = auto()
    CHECK_REMOTE_EVENT_LOG_EXTRACTION_STATUS = auto()


class EtwCommands(IntEnum):
    START_REMOTE_ETW_SESSION = auto()
    STOP_REMOTE_ETW_SESSION = auto()
    COMMIT_REMOTE_ETW_SESSION = auto()
    PROLONG_REMOTE_ETW_SESSION = auto()
    GET_ETW_SESSION_INFO = auto()
    GET_ETW_SESSIONS_LIST = auto()
    STOP_ALL_ETW_SESSIONS = auto()


@attr.s
class AgentSdkResult(LegacyDictable):
    body = string_attr(default=None)
    error = string_attr(default=None)
    duration = float_attr(default=None)


@attr.s
class AgentSdkBulkResult(LegacyDictable):
    results = dict_attr(factory=dict)  # AgentSdkResult by agent_id
    total_duration = float_attr(default=None)

    @classmethod
    def from_json(cls, json_str):
        try:
            result_by_agent_id = json.loads(json_str).get('results')
            return cls({agent_id: AgentSdkResult(**response) for agent_id, response in result_by_agent_id.items()})
        except:
            return None


@attr.s
class AgentSdkBulkCommand(Dictable):
    command = string_attr()
    command_type = enum_attr(enum_type=AgentSDKCommandType)
    agents = list_attr()
    query = string_attr(default=None)
    params = dict_attr(factory=dict)
    params_by_agent = dict_attr(factory=dict)


@attr.s
class AgentSdkTask:
    bulk_command = attr.ib(converter=ensure_cls(AgentSdkBulkCommand))
    task_id = attr.ib(factory=uuid.uuid4)
    creation_time = datetime_attr(factory=datetime.datetime.utcnow)
    status = enum_attr(enum_type=AgentSDKTaskStatus, default=AgentSDKTaskStatus.CREATED)
    bulk_result = attr.ib(factory=AgentSdkBulkResult)  # of uuid to AgentSdkResult
    current_agent_set = set_attr(factory=set)

    @classmethod
    def from_dict(cls, data, command_type):
        try:
            data.update({'command_type': command_type})
            task = cls(data)
        except:
            return None, traceback.format_exception(*sys.exc_info())

        task.current_agent_set = set(task.bulk_command.agents)
        return task, None

    def to_dict(self):
        result = self.bulk_result.to_dict()
        result['status'] = self.status.name.lower()
        return result
