from common.py.collection.control.client.agents_server_client import AgentsServerComponentControlClient
from common.py.model.aggregator import AggregatorComponent


class ControllerServerControlClient(AgentsServerComponentControlClient):
    def __init__(self, **kwargs):
        kwargs.pop('component_name', None)
        super(ControllerServerControlClient, self).__init__(component_name=AggregatorComponent.ControllerServer,
                                                            **kwargs)

    def get_machine_details_updates(self):
        return self.call("/agents/details/reports", method="GET")

    def force_machine_details_updates(self):
        return self.call("/agents/details/force-report", method="POST")

    def agent_configurations_cleanup(self, agent_uuid):
        return self.call("/agents-config/agent_configurations_cleanup?&agent_uuid={}".format(agent_uuid), method="GET")

    def notify_dcinventory_update(self, revision):
        self.call_with_reconnect(uri='/controller/dcinventory_update_notification', method='POST')
