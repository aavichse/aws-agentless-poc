from enum import Enum

from common.py.apis.management.agent_details import AgentType


class AssetType(Enum):
    UNDEFINED = 'undefined'
    WORKSTATION = 'workstation'  # aka endpoint
    SERVER = 'server'  # aka workload
    K8S = 'k8s'
    DPOP = 'dpop'

    @staticmethod
    def is_valid(asset_type):
        return asset_type.upper() in AssetType.__members__

    @classmethod
    def agent_type_to_asset_type(cls, agent_type):
        """
        translation between AgentType and AssetType
        """
        if agent_type == AgentType.ENDPOINT.name:
            return cls.WORKSTATION
        elif agent_type == AgentType.WORKLOAD.name:
            return cls.SERVER
