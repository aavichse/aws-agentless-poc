from enum import IntEnum
from typing import List


class AgentKOUpgradeState(IntEnum):
    PENDING = 1
    STARTING = 2
    STARTED = 3
    SKIPPED = 4
    FINISHED = 5
    FAILED = 6
    NOT_APPLICABLE = 7

    @staticmethod
    def get_completed_states():
        # type: () -> List
        return [
            AgentKOUpgradeState.FINISHED,
            AgentKOUpgradeState.FAILED,
            AgentKOUpgradeState.SKIPPED
        ]

    @staticmethod
    def get_running_states():
        # type: () -> List
        return [
            AgentKOUpgradeState.STARTING,
            AgentKOUpgradeState.STARTED
        ]


class AgentKOUpradeReport:
    KO_UPGRADE_JOB_ID = 'ko_upgrade_job_id'
    CHANGES = 'changes'
    AGENT_ID = 'agent_id'
    EVENT_TIME = 'event_time'
    KO_UPGRADE_STATE = 'ko_upgrade_state'
    MSG = 'msg'
