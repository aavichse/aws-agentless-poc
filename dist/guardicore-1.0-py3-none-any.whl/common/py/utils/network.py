"""
Created on Jul 9, 2014

@author: itamar
"""

import sys
import six
import struct
import ipaddress
import socket

from common.py.model.exceptions import InvalidPacketError, InvalidIPError
from common.py.utils.config import cfg

try:
    from pytricia import PyTricia
except ImportError:
    if not sys.platform.startswith("win"):
        raise
    PyTricia = None

# from dpkt.ip
IP_PROTO_TCP = 6  # TCP

# from dpkt.ethernet
ETH_TYPE_8021Q = 0x8100  # IEEE 802.1Q VLAN tagging
ETH_TYPE_IP = 0x0800  # IP protocol
ETH_TYPE_IP6 = 0x86DD  # IPv6 protocol
ETH_TYPE_ARP = 0x0806  # address resolution protocol


def ip2int(addr):
    return struct.unpack("!I", socket.inet_aton(addr))[0]


def int2ip(addr):
    return socket.inet_ntoa(struct.pack("!I", addr))


def get_tcp_ports(pkt):
    """get_tcp_ports(pkt) -> (src_port, dst_port)

    Return the source and destination ports for a given TCP packet (assuming
    this is an IP packet, received by iptables nfqueue's..
    """

    protocol_type = struct.unpack_from("B", pkt, 9)[0]
    if IP_PROTO_TCP != protocol_type:
        raise InvalidPacketError("Excepting TCP packet, protocol type %d found", protocol_type)

    return struct.unpack_from(">HH", pkt, 20)


def get_ip_addresses(pkt):
    """get_ip_addresses(pkt) -> (src_ip, dst_ip)

    Return the source and destination ips for a given IP packet (assuming
    this is an IP packet, received by iptables nfqueue's..
    """

    return struct.unpack_from(">II", pkt, 12)


def get_vlan_tag(pkt):
    """get_vlan_tag(vlan_id, pkt)
    """

    eth_type = struct.unpack_from(">H", pkt, 12)[0]
    if ETH_TYPE_8021Q != eth_type:
        raise InvalidPacketError("Can't get VLAN tag packet for an untagged packet (Ethernet type: 0x%04X)",
                                 eth_type)

    return struct.unpack_from("!H", pkt, 14)[0]


def modify_vlan_tag(vlan_id, pkt, force=False):
    """modify_vlan_tag(vlan_id, pkt, force)

    Modify the VLAN tagging on a given tagged packet. If the packet isn't
    tagged, InvalidPacketError exception is raised.
    [ SRC MAC  | DST MAC | 802.1Q TYPE ]
    [ VLAN TAG |           <--- changed tagging
    <---             Payload        --->
    ]

    :param vlan_id: The identifier of the vlan to change.
    :type vlan_id: int.
    :param pkt: The pkt to change.
    :type pkt: buffer object.
    :param force: If force is True, the packet is wrapped in vlan if one not present.
    :type force: bool.
    """

    eth_type = struct.unpack_from(">H", pkt, 12)[0]

    if ETH_TYPE_8021Q == eth_type:
        return pkt[:14] + struct.pack(">H", vlan_id) + pkt[16:]

    elif force:
        return push_vlan_layer(vlan_id, pkt)

    else:
        raise InvalidPacketError("Can't modify VLAN tag packet for an untagged packet (Ethernet type: 0x%04X)",
                                 eth_type)


def strip_vlan_tag(pkt, quiet=False):
    """strip_vlan_tag(pkt)
    
    Strip the VLAN tagging on a given tagged packet. If the packet isn't
    tagged, InvalidPacketError exception is raised.
    [ SRC MAC  | DST MAC | 802.1Q TYPE ]
    [ VLAN TAG |           <--- remove
    <---             Payload        ---> 
    ]

    :param quiet : If the packet don't contain vlan, be quite and don't raise exceptions.
    :type quiet : boolean.
    """

    eth_type = struct.unpack_from(">H", pkt, 12)[0]

    if ETH_TYPE_8021Q == eth_type:
        return pkt[:12] + pkt[16:]
    elif quiet:
        return pkt
    else:
        raise InvalidPacketError("Can't strip VLAN tag packet for an untagged packet (Ethernet type: 0x%04X)", eth_type)


def push_vlan_layer(vlan_id, pkt):
    """push_vlan_layer(vlan_id, data) -> packet data
    push a VLAN tagging to a given ethernet packet
        [ SRC MAC  | DST MAC | 802.1Q TYPE ]
        [ VLAN TAG | <Real Type>          <--- Push here, copy original XXX Type
        <---             Payload        --->
        ]

    """

    ethernet_addresses = pkt[:12]
    ethernet_ether_type = pkt[12:14]
    ethernet_payload = pkt[14:]

    pkt = ethernet_addresses
    pkt += struct.pack(">H", ETH_TYPE_8021Q)
    pkt += struct.pack(">H", vlan_id) + ethernet_ether_type
    pkt += ethernet_payload

    return pkt


def add_ethernet_layer(src_mac, dst_mac, vlan_id, data):
    """add_ethernet_layer(src_mac, dst_mac, vlan_id, data) -> packet data
    add an ethernet header with VLAN tagging:
        [ DST MAC  | SRC MAC | 802.1Q TYPE ]
        [ VLAN TAG | IP TYPE ]
        <---             Payload        --->
    """

    # add packet ethernet header
    pkt = dst_mac
    pkt += src_mac
    pkt += struct.pack(">H", ETH_TYPE_8021Q)
    pkt += struct.pack(">HH", vlan_id, ETH_TYPE_IP)

    # add rest of packet payload
    pkt += data

    return pkt


def fix_frame_checksum(pkt, ip_offset=14, psuedo_checksum=False):
    """
    :param pkt: packet to fix
    :param ip_offset: offset of ip packet start
    :return: packet with correct checksum
    """
    def carry_add(a, b):
        c = a + b
        return (c & 0xffff) + (c >> 16)

    def partial_checksum(checksum, buf, offset, count):
        for i in range(offset, offset + count, 2):
            w = struct.unpack_from(">H", buf, i)[0]
            checksum = carry_add(checksum, w)

        return checksum

    def calc_pseudo_header_checksum():
        pseudo_header = (pkt[ip_offset+12:ip_offset+20] +                     # Source Address, Destination Address
                         "\x00" +                                             # Reserved
                         pkt[ip_offset + 9] +                                 # IP Protocol
                         struct.pack(">H", len(pkt) - (ip_offset + ip_len)))  # Data Length

        return partial_checksum(0, pseudo_header, 0, 12)

    ip_len = (struct.unpack_from("B", pkt, ip_offset)[0] >> 4) * 5

    if psuedo_checksum:
        checksum = struct.unpack_from(">H", pkt, ip_offset + ip_len + 16)[0]
    else:
        checksum = calc_pseudo_header_checksum()

    prefix = pkt[:ip_offset + ip_len + 16]
    checksum = partial_checksum(checksum, prefix, ip_offset + ip_len, 16)

    suffix = pkt[ip_offset + ip_len + 18:]
    checksum = partial_checksum(checksum, suffix + "\x00", 0, len(suffix))

    checksum = ~checksum & 0xffff
    return prefix + struct.pack(">H", checksum) + suffix


IPV4_MAPPED_IPV6 = 'ipv4_mapped_ipv6'
LINK_LOCAL = 'link_local'
IPV4_EMBEDDED_IPV6_PREFIX_32 = 'ipv4_embedded_ipv6_prefix_32'
IPV4_EMBEDDED_IPV6_PREFIX_40 = 'ipv4_embedded_ipv6_prefix_40'
IPV4_EMBEDDED_IPV6_PREFIX_48 = 'ipv4_embedded_ipv6_prefix_48'
IPV4_EMBEDDED_IPV6_PREFIX_56 = 'ipv4_embedded_ipv6_prefix_56'
IPV4_EMBEDDED_IPV6_PREFIX_64 = 'ipv4_embedded_ipv6_prefix_64'
IPV4_EMBEDDED_IPV6_PREFIX_96 = 'ipv4_embedded_ipv6_prefix_96'

IPV4_MAPPED_IPV6_PREFIX = '::ffff'
IPV4_EMBEDDED_IPV6_PREFIX = '2001:db8:'
LINK_LOCAL_PREFIX = 'fe80::'
ADDRESS_FAMILY = {4: socket.AF_INET,
                  6: socket.AF_INET6,
                  IPV4_MAPPED_IPV6: socket.AF_INET6,
                  LINK_LOCAL: socket.AF_INET6,
                  IPV4_EMBEDDED_IPV6_PREFIX_32: socket.AF_INET6,
                  IPV4_EMBEDDED_IPV6_PREFIX_40: socket.AF_INET6,
                  IPV4_EMBEDDED_IPV6_PREFIX_48: socket.AF_INET6,
                  IPV4_EMBEDDED_IPV6_PREFIX_56: socket.AF_INET6,
                  IPV4_EMBEDDED_IPV6_PREFIX_64: socket.AF_INET6,
                  IPV4_EMBEDDED_IPV6_PREFIX_96: socket.AF_INET6}

CLASS_TRIM_BYTES = {4: 1,
                    6: 4,
                    IPV4_MAPPED_IPV6: 1,
                    LINK_LOCAL: 4,
                    IPV4_EMBEDDED_IPV6_PREFIX_32: 9,  # if prefix is 32 bits, the IPv4 last digit is at byte 9 (from the right)
                    IPV4_EMBEDDED_IPV6_PREFIX_40: 7,
                    IPV4_EMBEDDED_IPV6_PREFIX_48: 6,
                    IPV4_EMBEDDED_IPV6_PREFIX_56: 5,
                    IPV4_EMBEDDED_IPV6_PREFIX_64: 4,
                    IPV4_EMBEDDED_IPV6_PREFIX_96: 1
                    }


def _get_ipv4_embedded_address_type(ip, ipv4_embedded_prefix_length):
    ipv4_embedded_prefix_length = int(ipv4_embedded_prefix_length)

    # understanding the prefix-length from ip is difficult, for example if the ipv4 starts with "hex - 1" e.g. "16" (0x10)
    # then we can't determine whether the prefix is "2001:db8:1" (length-40) or "2001:db8:" (length-36)

    return {
            32: IPV4_EMBEDDED_IPV6_PREFIX_32,
            40: IPV4_EMBEDDED_IPV6_PREFIX_40,
            48: IPV4_EMBEDDED_IPV6_PREFIX_48,
            56: IPV4_EMBEDDED_IPV6_PREFIX_56,
            64: IPV4_EMBEDDED_IPV6_PREFIX_64,
            96: IPV4_EMBEDDED_IPV6_PREFIX_96
            }[ipv4_embedded_prefix_length]


def get_ip_subnet(ip, address_type=None, ipv4_embedded_prefix_length=96):
    """
    gets an ip and return a guardicore-defined "subnet" of that IP.
    the IP can be either an IPv4 or IPv6
    an IPv6 can also be a special type - "IPv4-mapped IPv6" (https://tools.ietf.org/html/rfc3493.html#section-3.6)
                                      or "IPv4-embedded IPv6" (https://tools.ietf.org/html/rfc6052#section-2.2)
    :param ip:
    :param address_type:
    :param ipv4_embedded_prefix_length: default value for ipv4-embedded-ipv6 prefix length is 96
        can't read this from oslo since aggregators don't have access to it.
    :return:
    """
    ip = ip.lower()
    if address_type is None:
        # quick-hack heuristics (to skip attempting to convert this to ipaddress.ip_address which may be expensive)
        if ':' in ip:
            if ip.startswith(LINK_LOCAL_PREFIX):
                address_type = LINK_LOCAL
            elif ip.startswith(IPV4_MAPPED_IPV6_PREFIX):
                address_type = IPV4_MAPPED_IPV6
            elif ip.startswith(IPV4_EMBEDDED_IPV6_PREFIX):
                address_type = _get_ipv4_embedded_address_type(ip, ipv4_embedded_prefix_length)
            else:
                address_type = 6
        else:
            address_type = 4
    else:
        address_type = address_type.value

    address_family = ADDRESS_FAMILY[address_type]
    class_trim_bytes = CLASS_TRIM_BYTES[address_type]

    try:
        subnet = socket.inet_ntop(address_family,
                                  socket.inet_pton(address_family, ip)[:-class_trim_bytes] + b"\0"*class_trim_bytes)
    except Exception as exc:
        raise InvalidIPError("Failed to convert ip: %s to subnet - %s", ip, exc)

    return subnet


KNOWN_LOCAL_NETWORKS = {4: ipaddress._IPv4Constants._private_networks,
                        6: ipaddress._IPv6Constants._private_networks}


def get_private_addresses():
    private_ips = []

    for local_network in KNOWN_LOCAL_NETWORKS[4]:
        private_ips.append(str(local_network))

    private_ips += cfg.CONF.management.internal_subnets
    return private_ips


def backported_subnet_of(a, b):
    """
    Backported from python 3.7. When we switch to that version, this can be removed.
    """
    try:
        # Always false if one is v4 and the other is v6.
        if a._version != b._version:
            raise TypeError("{} and {} are not of the same version".format(a, b))
        return (b.network_address <= a.network_address and
                b.broadcast_address >= a.broadcast_address)
    except AttributeError:
        raise TypeError("Unable to test subnet containment between {} and {}".format(a, b))


def intersect_subnets_lists(*subnets_lists):
    """
    Intersects lists of subnets, returning only subnets which exist (or are contained in other subnets) in all lists.
    :param subnets_lists: list of subnet lists, each subnet given as a string
    :return: one joined list of intersecting subnets.
    >>> intersect_subnets_lists()
    []
    >>> intersect_subnets_lists(["1.1.1.0/30"])
    ['1.1.1.0/30']
    >>> intersect_subnets_lists(["1.1.1.1/32"], \
                                ["1.1.1.0/30"])
    ['1.1.1.1/32']
    >>> intersect_subnets_lists(["1.1.1.0/31", "2.2.2.0/31"], \
                                ["1.1.1.1/30"])
    ['1.1.1.0/31']
    >>> sorted(intersect_subnets_lists(["1.1.1.0/31", "2.2.2.0/31"], \
                                       ["1.1.1.1/30", "2.2.2.1/32"]))
    ['1.1.1.0/31', '2.2.2.1/32']
    >>> sorted(intersect_subnets_lists(["1.1.1.0/31", "2.2.2.0/31", "3.3.3.0/31"], \
                                       ["1.1.1.1/30", "2.2.2.1/32", "3.3.3.1/32"], \
                                       ["1.1.1.1/30", "2.2.2.1/32", "3.3.3.0/31"]))
    ['1.1.1.0/31', '2.2.2.1/32', '3.3.3.1/32']
    >>> sorted(intersect_subnets_lists(["10.0.0.0/8"], \
                                       ["10.0.0.0/16", "192.168.14.1/26", "192.168.5.64/32", "10.0.0.0/8", "10.0.0.0/2"]))
    ['10.0.0.0/16', '10.0.0.0/8']
    """

    if not subnets_lists:
        return []

    if PyTricia is not None:
        # If there are M subnet lists and N subnets at the most in each list, so this runs in O(M^2 * N * Log(N))
        return_subnets = set()

        subnets_index_to_tree = {}
        for i, subnets_list in enumerate(subnets_lists):
            subnets_index_to_tree[i] = PyTricia(128)
            for subnet in subnets_list:
                subnets_index_to_tree[i][subnet] = subnet

        for i, subnets_list in enumerate(subnets_lists):
            for subnet in subnets_list:
                for j, tree in subnets_index_to_tree.items():
                    if i != j and subnet not in tree:
                        break
                else:
                    return_subnets.add(subnet)
        return list(return_subnets)

    # old version without PyTricia

    def subnet_str_lists_to_ip_network(subnets_list):
        return [ipaddress.ip_network(six.text_type(subnet), strict=False)
                for subnet in subnets_list]

    def ip_network_to_subnets_list(ip_networks_list):
        return list(map(str, ip_networks_list))

    subnets_lists = list(map(subnet_str_lists_to_ip_network, subnets_lists))

    intersection = subnets_lists[0]  # at every iteration, reduce the intersection to include another list.
    for subnets_list in subnets_lists[1:]:
        intersection_temp = []
        for s1 in intersection:
            for s2 in subnets_list:
                # subnet intersection is easy - two subnets intersect if one is contained in the other or vice-versa.
                if backported_subnet_of(s1, s2):
                    intersection_temp.append(s1)
                elif backported_subnet_of(s2, s1):
                    intersection_temp.append(s2)

        intersection = intersection_temp

    return ip_network_to_subnets_list(intersection)


def intersect_subnets_lists_non_str(*subnets_lists):
    """
    >>> intersect_subnets_lists_non_str([ipaddress.ip_network("1.1.1.1/32")], \
                                        [ipaddress.ip_network("1.1.1.0/30")])
    ['1.1.1.1/32']
    """
    def ip_network_to_subnets_list(ip_networks_list):
        return list(map(str, ip_networks_list))

    subnets_lists = map(ip_network_to_subnets_list, subnets_lists)
    return intersect_subnets_lists(*subnets_lists)


def is_ip_address(blob):
    """

    :param blob: IP address as long or string
    :return: bool

    >>> is_ip_address(u"127.0.0.1")
    True
    >>> is_ip_address(u"127.0.0.a")
    False
    >>> is_ip_address("127.0.0.1")
    True
    >>> is_ip_address("not-an-ip")
    False
    >>> is_ip_address("127::1")
    True

    """

    if six.PY2 and type(blob) == str:
        blob = unicode(blob)

    try:
        ipaddress.ip_address(blob)
        return True
    except (ValueError, ipaddress.AddressValueError):
        return False


def get_ip_from_domain(ip_or_domain):
    if is_ip_address(ip_or_domain):
        return ip_or_domain

    try:
        ip_address = socket.gethostbyname(ip_or_domain)
        return ip_address
    except (TypeError, ValueError, socket.gaierror):
        return ''
