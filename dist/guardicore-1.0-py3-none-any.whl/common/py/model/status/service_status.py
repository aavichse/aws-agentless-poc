from enum import IntEnum


class ServiceStatus(IntEnum):
    UNKNOWN = 0
    INITIATING = 1  # services are executing initialize/verify method
    PENDING = 2     # services are starting or started but waiting for connection to external providers e.g. redis
    RUNNING = 3     # services are up & running
    TERMINATED = 4  # services cleaning up
    FAILED = 5      # services encountered unrecoverable internal issue e.g. access denied, bind failed
    DOWN = 6        # service is not running/pid file was not found
    FORCED_DOWN = 7 # service was stopped from monicore
    REPEATED_ERROR = 8  # only monicore can detect services in crash loop. application should not send this status

    @property
    def is_error(self):
        return self in (ServiceStatus.FAILED, ServiceStatus.REPEATED_ERROR)

    @property
    def is_success(self):
        return self in (ServiceStatus.RUNNING, )

    @property
    def is_progress(self):
        return self in (ServiceStatus.INITIATING, ServiceStatus.PENDING)

    @property
    def is_warning(self):
        return self in (ServiceStatus.UNKNOWN, ServiceStatus.TERMINATED, ServiceStatus.DOWN, ServiceStatus.FORCED_DOWN)

