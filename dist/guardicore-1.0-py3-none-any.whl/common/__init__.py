
import os


gc_root = None
# v30
AGGR_HPVM_STORAGE_PATH = "/usr/share/guardicore/storage"


def get_guardicore_root():
    """get_guardicore_root -> str
    Return OS specific absolute path to the Guardicore source root
    we're in right now.
    """

    global gc_root

    if gc_root is None:
        gc_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    return gc_root


def get_guardicore_storage_root():
    """get_guardicore_root -> str
    Return OS specific absolute path to the Guardicore source root
    we're in right now.
    """

    # aggr/hpvm have different storage path
    if os.path.exists("/usr/share/guardicore/storage"):
        return os.path.dirname(AGGR_HPVM_STORAGE_PATH)
    else:
        return get_guardicore_root()
