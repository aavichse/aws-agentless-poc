import logging
from datetime import datetime

import six

from common.py.data_export.exporter import NetworkLogsExporterMixin
from common.py.data_export.exporters.syslog_utils import BaseSyslogExporter, SyslogFormat, DEFAULT_DELIMITER, \
    SyslogFormatDisplayName
from common.py.events.mitigation.network import ConnectionsJointMatchingVerdictFilter, JointMatchingVerdict
from common.py.utils.config import cfg
from common.py.utils.config.types import List, String, Structure
from common.py.utils.datetime_utils import timestamp_to_date
from common.py.data_export.exporters.syslog_datetime import TimeField

NETWORK_LOG_SYSLOG_VERDICTS_STRUCT = Structure([
    cfg.StrOpt('verdict',
               default=ConnectionsJointMatchingVerdictFilter.ALLOWED.value,
               choices=[verdict.value for verdict in ConnectionsJointMatchingVerdictFilter],
               required=True),
])


NETWORK_LOG_SYSLOG_CONF_GROUP = 'network_log_syslog_exporter'
NETWORK_LOG_CEF_FORMATS = (SyslogFormat.CEF.value, SyslogFormat.ARCSIGHT_CEF.value, SyslogFormatDisplayName.CEF.value)

network_log_syslog_opts = [
    cfg.Opt('exported_verdicts',
            type=List(item_type=NETWORK_LOG_SYSLOG_VERDICTS_STRUCT, bounds=True), default=[],
            help="Export network logs with the selected verdicts"),
    cfg.ExtendedOpt('filter_by_labels',
                    default=[],
                    required=False,
                    type=List(item_type=String(unicode=six.PY3, quotes=six.PY2), bounds=True)),
    cfg.ExtendedOpt('exported_label_keys',
                    default=[],
                    required=False,
                    type=List(item_type=String(unicode=six.PY3, quotes=six.PY2), bounds=True)),
    cfg.ExtendedOpt('exported_label_group_keys',
                    default=[],
                    required=False,
                    type=List(item_type=String(unicode=six.PY3, quotes=six.PY2), bounds=True))
]


class NetworkLogSyslogExporter(BaseSyslogExporter, NetworkLogsExporterMixin):
    def __init__(self, conf, syslog_id, is_test_connection=False, **kwargs):
        super(NetworkLogSyslogExporter, self).__init__(conf, is_test_connection=is_test_connection, syslog_id=syslog_id)
        self.syslog_logger = logging.getLogger('guardicore_exports.network_log_syslog:{}'.format(syslog_id))
        self.syslog_logger.propagate = False
        self.add_fqdn_in_syslog_network_log = kwargs.get('add_fqdn_in_syslog_network_log', True)
        self.add_process_hash_in_syslog_network_log = kwargs.get('add_process_hash_in_syslog_network_log', True)
        self.replace_incidents_with_security_event = kwargs.get('replace_incidents_with_security_event', False)

    @property
    def network_log_export_enabled(self):
        return True

    def export_network_log(self, record):
        if not self._should_export_network_log(record):
            return

        try:
            if cfg.CONF.exporters.debug_data_export:
                self.logger.debug("Exporting network log %s to Network logs exporter, server %s:%d",
                                  record.get('id'),
                                  self.conf.base_syslog_exporter.syslog_host,
                                  self.conf.base_syslog_exporter.syslog_port)
        except:
            pass

        message = self._prepare_network_log_message(record)
        self._export_message(message)

    def _should_export_network_log(self, record):
        if not self._is_syslog_defined():
            self.logger.warning('Exporter %s: not exporting record %s - Syslog is not defined',
                                self.conf.base_syslog_exporter.name, record['id'])
            return False
        elif not self._is_in_exported_verdicts(record):
            self.logger.debug('Exporter %s: not exporting record %s - filtered by verdict',
                              self.conf.base_syslog_exporter.name, record['id'])
            return False
        elif not self._filter_by_labels(record):
            self.logger.debug('Exporter %s: not exporting record %s - Filtered by labels',
                              self.conf.base_syslog_exporter.name, record['id'])
            return False
        else:
            return True

    def _prepare_network_log_message(self, record):
        self._prepare_exported_labels_and_label_groups(record)
        if self.conf.base_syslog_exporter.syslog_format in NETWORK_LOG_CEF_FORMATS:
            return self._prepare_network_log_cef_message(record)
        elif self.conf.base_syslog_exporter.syslog_format == SyslogFormat.RFC_5424.value:
            return self._prepare_rfc_5424_message(message_type='Network-Log',
                                                  message_function=self._prepare_network_log_text_message,
                                                  message_function_args=[record])
        else:
            return self._prepare_network_log_text_message(record)

    def _extract_network_log_cef_extensions(self, record):
        start_time = self.get_formatted_time_from_date(timestamp_to_date(record.get('start_time')), TimeField.CEF_START)

        extensions = dict(
            id=record['id'],
            act=record.get('action'),
            cnt=record.get('count'),
            start=start_time,
            src=record.get('source_ip'),
            shost=record.get('source_asset_name'),
            suser=record.get('source_username'),
            dst=record.get('destination_ip'),
            dpt=record.get('destination_port'),
            dhost=record.get('destination_asset_name', 'Unknown'),
            duser=record.get('destination_username'),
            proto=record.get('ip_protocol', '').upper(),
            cs1Label='connection_type',
            cs1=record.get('connection_type'),
            cs2Label='source_asset_labels',
            cs2=record.get('source_asset_labels')
        )
        source_process_full_path = record.get('source_process_full_path')
        # `if source_process_full_path` could be only in one place, but we need to keep `cs<number>` ordered
        if source_process_full_path:
            extensions.update(dict(
                cs3Label='source_process',
                cs3=record.get('source_process_name')
            ))
        extensions.update(dict(
            cs4Label='destination_asset_labels',
            cs4=record.get('destination_asset_labels'),
            cs5Label='security_event' if self.replace_incidents_with_security_event else 'incidents',
            cs5=record.get('incidents'),
            cs6Label='connection_verdict',
            cs6=record.get('connection_verdict'),
            cs7Label='policy_rule',
            cs7=record.get('policy_rule'),
            cs8Label='policy_ruleset',
            cs8=record.get('policy_ruleset'),
            cs9Label='source_asset_label_groups',
            cs9=record.get('source_asset_label_groups'),
            cs10Label='destination_asset_label_groups',
            cs10=record.get('destination_asset_label_groups'),
            cs11Label='source_user_identity',
            cs11=record.get('source_identity'),
            cs12Label='destination_user_identity',
            cs12=record.get('destination_identity')
        ))
        if source_process_full_path:
            extensions.update(dict(
                cs13Label='source_process_path',
                cs13=record.get('source_process_full_path'),
                cs14Label='source_app_name',
                cs14=record.get('source_process')
            ))
        if record.get('destination_process_full_path'):
            extensions.update(dict(
                dproc=record.get('destination_process_name'),
                cs15Label='destination_process_path',
                cs15=record.get('destination_process_full_path'),
                cs16Label='destination_app_name',
                cs16=record.get('destination_process')
            ))
        if record.get('destination_domain') and self._should_display_fqdn():
            extensions.update(dict(
                cs17Label='fqdn',
                cs17=record.get('destination_domain'),
            ))

        if self._should_add_process_hash():
            self._include_process_hash(extensions, record)
        self._remove_empty_extensions(extensions)

        return extensions

    def _should_add_process_hash(self):
        return self.add_process_hash_in_syslog_network_log

    @staticmethod
    def _include_process_hash(extensions, record):
        if record.get('source_process_hash'):
            extensions.update(dict(
                cs18Label='source_process_hash',
                cs18=record.get('source_process_hash'),
            ))
        if record.get('destination_process_hash'):
            extensions.update(dict(
                cs19Label='destination_process_hash',
                cs19=record.get('destination_process_hash'),
            ))

    @classmethod
    def _remove_empty_extensions(cls, extensions):
        keys_to_remove = set()

        for key in extensions:
            if extensions[key] in [None, '', []]:
                keys_to_remove.add(key)
                if key.startswith('cs'):
                    keys_to_remove.add('{}Label'.format(key))

        for key in keys_to_remove:
            extensions.pop(key)

    def _prepare_network_log_cef_message(self, record):
        extensions = self._extract_network_log_cef_extensions(record)
        cef_exporter = self._get_cef_exporter(device_event_class_id='Network Log',
                                              name='Network Log', severity=record.get('status'),
                                              extensions=extensions)

        now_timestamp = self.get_formatted_time_from_date(datetime.utcnow(), TimeField.CEF_HEADER)

        message = cef_exporter.create_cef_message(
            display_hostname=self.conf.base_syslog_exporter.display_hostname,
            now_timestamp=now_timestamp)

        return self._limit_mgs_length(message, self.get_max_syslog_message_len())

    def _prepare_network_log_text_message(self, record, delimiter=DEFAULT_DELIMITER):
        record['delimiter'] = delimiter

        record['time'] = self.get_formatted_time_from_date(timestamp_to_date(record['start_time']))
        source_asset_name = record.get('source_asset_name')
        source_asset_labels = record.get('source_asset_labels')
        source_username = record.get('source_username')
        source_identity = record.get('source_identity')
        source_process_full_path = record.get('source_process_full_path')
        source_process_name = record.get('source_process_name')
        source_process = record.get('source_process')
        source_asset_label_groups = record.get('source_asset_label_groups')

        destination_asset_name = record.get('destination_asset_name')
        destination_asset_labels = record.get('destination_asset_labels')
        destination_username = record.get('destination_username')
        destination_identity = record.get('destination_identity')
        destination_asset_label_groups = record.get('destination_asset_label_groups')
        destination_process_full_path = record.get('destination_process_full_path')
        destination_process_name = record.get('destination_process_name')
        destination_process = record.get('destination_process')
        destination_fqdn = record.get('destination_domain')
        policy_rule = record.get('policy_rule')
        policy_ruleset = record.get('policy_ruleset')
        incidents = record.get('incidents')

        message = "New network connection reported by the Guardicore Security Suite{delimiter}" \
                  "ID: {id}{delimiter}" \
                  "Connection type: {connection_type}{delimiter}" \
                  "Action: {action}{delimiter}" \
                  "Count: {count}{delimiter}" \
                  "Time: {time}{delimiter}" \
                  "Source IP: {source_ip}{delimiter}"
        message += "Source asset name: {source_asset_name}{delimiter}" if source_asset_name else ""
        message += "Source asset labels: {source_asset_labels}{delimiter}" if source_asset_labels else ""
        message += "Source asset label groups: {source_asset_label_groups}{delimiter}" if source_asset_label_groups \
            else ""
        message += "Source user name: {source_username}{delimiter}" if source_username else ""
        message += "Source user identity: {source_identity}{delimiter}" if source_identity else ""
        message += "Source process name: {source_process_name}{delimiter}" if source_process_name else ""
        message += "Source process path: {source_process_full_path}{delimiter}" if source_process_full_path else ""
        message += "Source application name: {source_process}{delimiter}" if source_process else ""
        message += "Destination IP: {destination_ip}{delimiter}" \
                   "Destination port: {destination_port}{delimiter}"
        message += "Destination asset name: {destination_asset_name}{delimiter}" if destination_asset_name else ""
        message += "Destination asset labels: {destination_asset_labels}{delimiter}" if destination_asset_labels else ""
        message += "Destination asset label groups: {destination_asset_label_groups}{delimiter}" \
            if destination_asset_label_groups else ""
        message += "Destination user name: {destination_username}{delimiter}" if destination_username else ""
        message += "Destination user identity: {destination_identity}{delimiter}" if destination_identity else ""
        message += "Destination process name: {destination_process_name}{delimiter}" if destination_process_name \
            else ""
        message += "Destination process path: {destination_process_full_path}{delimiter}" \
            if destination_process_full_path else ""
        message += "Destination process name: {destination_process}{delimiter}" if destination_process \
            else ""
        message += "FQDN: {destination_domain}{delimiter}" \
            if destination_fqdn and self._should_display_fqdn() else ""
        message += "Protocol: " + record.get('ip_protocol').upper() + "{delimiter}"
        message += "Connection verdict: {connection_verdict}{delimiter}"
        message += "Policy rule: {policy_rule}{delimiter}" if policy_rule else ""
        message += "Policy ruleset: {policy_ruleset}{delimiter}" if policy_ruleset else ""
        if self.replace_incidents_with_security_event:
            message += "Security events: {incidents}{delimiter}" if incidents else ""
        else:
            message += "Incidents: {incidents}{delimiter}" if incidents else ""

        message = message.format(**record)

        return message

    def _should_display_fqdn(self):
        return self.add_fqdn_in_syslog_network_log

    def _is_in_exported_verdicts(self, record):
        verdict = JointMatchingVerdict[record['policy_verdict'].upper()]
        exported_verdicts = [item['verdict'] for item in self.conf.network_log_syslog_exporter.exported_verdicts]


        if verdict.is_will_be_blocked_by_agents:
            return ConnectionsJointMatchingVerdictFilter.WILL_BE_BLOCKED.value in exported_verdicts
        elif verdict.is_blocked_by_agents:
            return ConnectionsJointMatchingVerdictFilter.BLOCKED.value in exported_verdicts
        elif verdict.is_could_not_block:
            return ConnectionsJointMatchingVerdictFilter.BLOCKED_BY_MANAGEMENT.value in exported_verdicts
        elif verdict.is_alerted:
            return ConnectionsJointMatchingVerdictFilter.ALERTED_BY_MANAGEMENT.value in exported_verdicts
        elif verdict.is_allowed_and_encrypted:
            return ConnectionsJointMatchingVerdictFilter.ALLOWED_AND_ENCRYPTED.value in exported_verdicts
        else:
            return ConnectionsJointMatchingVerdictFilter.ALLOWED.value in exported_verdicts

    @classmethod
    def _label_name_to_tuple(cls, label):
        return tuple(label.split(": "))

    def _filter_by_labels(self, record):
        filter_by_labels = self.conf.network_log_syslog_exporter.filter_by_labels
        if not filter_by_labels:
            return True

        source_asset_labels = record.get('source_asset_labels', '').split(',')
        destination_asset_labels = record.get('destination_asset_labels', '').split(',')
        connection_labels = source_asset_labels + destination_asset_labels

        if any(label.strip("'") in connection_labels for label in filter_by_labels):
            return True
        else:
            return False

    def _prepare_exported_labels_and_label_groups(self, record):
        """
        Add only relevant label & label group keys matched to per syslog configuration
        exported_label_group_keys && exported_label_keys
        :param record: network log record
        :return:
        """
        for label_type, exported_keys in [('labels', self.conf.network_log_syslog_exporter.exported_label_keys),
                                          ('label_groups', self.conf.network_log_syslog_exporter.exported_label_group_keys)]:
            for direction in ['source', 'destination']:
                direction_asset_label_type = '{direction}_asset_{label_type}'.format(direction=direction,
                                                                                     label_type=label_type)
                direction_labels = record.get(direction_asset_label_type, '').split(',')
                if exported_keys is not None:
                    record[direction_asset_label_type] = ', '.join(
                        [label for label in direction_labels if label.split(': ')[0] in exported_keys])
                else:
                    record[direction_asset_label_type] = ""

    def is_filter_by_labels(self):
        return self.conf.network_log_syslog_exporter.filter_by_labels
