from common.py.clouds import common_opts, label_opts
from common.py.utils.config import cfg, six
from common.py.utils.config.oslo_config import types
from common.py.utils.config.types import Structure

gcp_opts = [
               cfg.StrOpt('service_account'),
               cfg.ExtendedOpt('private_key',
                               default='',
                               type=types.String(unicode=six.PY3, quotes=six.PY2),
                               secret=True,
                               help="Content of the private key (PEM format)"),
               cfg.Opt('projects_list', default=[],
                       type=types.List(item_type=types.String(quotes=True), bounds=True)),
               cfg.StrOpt('proxy_url', default=None, help="Optional HTTP/HTTPS proxy URL"),
           ] + common_opts + label_opts

GCP_AUTH_STRUCTURE = Structure(gcp_opts)

GCP_AUTH_OPTS = [cfg.IntOpt('update_timeout_seconds',
                            default=10 * 60,
                            help="GCP update timeout in seconds")]


def register_opts():
    cfg.CONF.register_opt(cfg.Opt('gcp_configuration', type=GCP_AUTH_STRUCTURE), group="orchestration")

    cfg.CONF.register_opts(opts=GCP_AUTH_OPTS, group="gcp_auth")
