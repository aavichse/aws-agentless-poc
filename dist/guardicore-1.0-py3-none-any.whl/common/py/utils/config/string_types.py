from posixpath import normpath
import six


class CaseSensitiveString(object):
    def __init__(self, string, case_sensitive):
        self.case_sensitive = case_sensitive
        self.string = string
        self.capitalize = self.string.capitalize
        self.center = self.string.center
        self.count = self.string.count
        self.expandtabs = self.string.expandtabs
        self.find = self.string.find
        self.format = self.string.format
        self.index = self.string.index
        self.isalnum = self.string.isalnum
        self.isalpha = self.string.isalpha
        self.isdigit = self.string.isdigit
        self.islower = self.string.islower
        self.isspace = self.string.isspace
        self.istitle = self.string.istitle
        self.isupper = self.string.isupper
        self.join = self.string.join
        self.ljust = self.string.ljust
        self.lower = self.string.lower
        self.lstrip = self.string.lstrip
        self.partition = self.string.partition
        self.replace = self.string.replace
        self.rfind = self.string.rfind
        self.rindex = self.string.rindex
        self.rjust = self.string.rjust
        self.rpartition = self.string.rpartition
        self.rsplit = self.string.rsplit
        self.rstrip = self.string.rstrip
        self.split = self.string.split
        self.splitlines = self.string.splitlines
        self.strip = self.string.strip
        self.swapcase = self.string.swapcase
        self.title = self.string.title
        self.upper = self.string.upper
        self.translate = self.string.translate
        self.zfill = self.string.zfill

    def __add__(self, y):
        return self.string.__add__(y)

    def __contains__(self, y):
        return self.string.__contains__(y)

    def __getitem__(self, y):
        return self.string.__getitem__(y)

    def __getslice__(self, i, j):
        return self.string.__getslice__(i, j)

    def __ge__(self, y):
        return self.string.__ge__(y)

    def __gt__(self, y):
        return self.string.__gt__(y)

    def __len__(self):
        return self.string.__len__()

    def __le__(self, y):
        return self.string.__le__(y)

    def __lt__(self, y):
        return self.string.__lt__(y)

    def __mod__(self, y):
        return self.string.__mod__(y)

    def __mul__(self, n):
        return self.string.__mul__(n)

    def __rmod__(self, y):
        return self.string.__rmod__(y)

    def __rmul__(self, n):
        return self.string.__rmul__(n)

    def __eq__(self, other):
        if isinstance(other, type(self)):
            if self.case_sensitive or other.case_sensitive:
                return self.string == other.string
            else:
                return self.string.lower() == other.string.lower()
        elif isinstance(other, six.string_types):
            if self.case_sensitive:
                return self.string == other
            else:
                return self.string.lower() == other.lower()

        return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        if self.case_sensitive:
            return hash((self.string, self.case_sensitive))
        else:
            return hash((self.string.lower(), self.case_sensitive))

    def __str__(self):
        return self.string

    def to_string(self):
        return self.string if self.case_sensitive else self.string.lower()

    def startswith(self, string, *args, **kwargs):
        if self.case_sensitive:
            return self.string.startswith(string, *args, **kwargs)
        else:
            return self.string.lower().startswith(string.lower(), *args, **kwargs)

    def endswith(self, string, *args, **kwargs):
        if self.case_sensitive:
            return self.string.endswith(string, *args, **kwargs)
        else:
            return self.string.lower().endswith(string.lower(), *args, **kwargs)


class Path(CaseSensitiveString):
    WINDOWS_INVALID_FILE_CHARS = ('\x00', '\x01', '\x02', '\x03', '\x04', '\x05', '\x06', '\x07', '\x08', '\t', '\n',
                                  '\x0b', '\x0c', '\r', '\x0e', '\x0f', '\x10', '\x11', '\x12', '\x13', '\x14', '\x15',
                                  '\x16', '\x17', '\x18', '\x19', '\x1a', '\x1b', '\x1c', '\x1d', '\x1e', '\x1f', '/',
                                  '*', '?', '"', '<', '>', '|')
    LINUX_INVALID_FILE_CHARS = ('\x00',)

    def __init__(self, string, case_sensitive, sep):
        super(Path, self).__init__(string, case_sensitive)
        self.sep = sep

    def basename(self):
        return self.string.rsplit(self.sep, 1)[-1]

    def dirname(self):
        if self.sep not in self.string or self.string.strip() == self.sep:
            return ''

        return self.string.rsplit(self.sep, 1)[0] or self.sep

    def dirname_path(self):
        dirname = self.dirname()
        if not dirname:
            return None

        return self.__class__(string=dirname, case_sensitive=self.case_sensitive, sep=self.sep)

    @classmethod
    def windows(cls, path):
        path = "".join([char for char in path if char not in cls.WINDOWS_INVALID_FILE_CHARS])
        return cls(string=path, case_sensitive=False, sep='\\')

    @classmethod
    def linux(cls, path):
        path = "".join([char for char in path if char not in cls.LINUX_INVALID_FILE_CHARS])
        return cls(string=path, case_sensitive=True, sep='/')

    @classmethod
    def windows_on_linux(cls, path):
        path = "".join([char for char in path if char not in cls.LINUX_INVALID_FILE_CHARS])
        return cls(string=path, case_sensitive=False, sep='/')

    @staticmethod
    def normalize_windows_path_name(path_name):
        if path_name.startswith("\\\\?\\"):  # Extended-length path
            return path_name[4:].lower()

        if path_name.startswith("\\??\\"):  # Native API: Ignore leading '\??\'
            path_name = path_name[4:]

        if path_name.lower().startswith("\\globalroot"):  # Native API: Ignore leading '\GlobalRoot'
            path_name = path_name[11:]

        if path_name.lower().startswith("\\systemroot"):  # Native API: Replace '\SystemRoot' with system root
            path_name = "c:\\windows" + path_name[11:]

        if path_name.lower().startswith("\\windows"):  # Native API: Replace '\Windows' with system root
            path_name = "c:\\windows" + path_name[8:]

        return path_name.lower()

    @staticmethod
    def normalize_linux_path_name(path_name):
        # Use posix's path normalization function
        normalized_path = normpath(path_name)

        # Remove double initial slash
        if normalized_path.startswith("//"):
            normalized_path = "/" + normalized_path[2:]

        return normalized_path

    def export(self):
        return {'path': self.string, 'sep': self.sep, 'case_sensitive': self.case_sensitive}
