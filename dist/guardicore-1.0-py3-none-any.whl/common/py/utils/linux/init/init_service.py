import os
import posixpath
from abc import abstractmethod, ABCMeta

from common.logger import get_logger
from common.py.model import GC_CONF_PATH
from common.py.utils.linux.init.init_service_waiter import InitServiceWaiter

LOG = get_logger(module_name=__name__)

DEFAULT_ENV_PATH = posixpath.join(GC_CONF_PATH, 'init')


class InitService(object):
    """
    Base class for interaction with linux-managed services e.g. systemd, sysV, upstart
    preferably, subclasses will use D-Bus interface for service control to allow control
    from containerized apps
    """
    __metaclass__ = ABCMeta

    def __init__(self, service_name):
        self.service_name = service_name

    @abstractmethod
    def start(self):
        """
        Start current service
        :return: InitServiceStatus
        """
        raise NotImplementedError()

    @abstractmethod
    def stop(self):
        """
        Stop current service
        :return: InitServiceStatus
        """
        raise NotImplementedError()

    @abstractmethod
    def get_status(self):
        """
        Get current service status

        :return: InitServiceStatus
        """
        raise NotImplementedError()

    @abstractmethod
    def get_log_location(self):
        """
        Return the service log file location
        :return:
        """
        raise NotImplementedError()

    def reload_connection(self):
        """
        Reload the connection to the service manager
        :return:
        """
        pass

    def get_waiter(self, service_event, timeout=None, reload_connection=False):
        return InitServiceWaiter(init_service=self, service_event=service_event, timeout=timeout,
                                 reload_connection=reload_connection)

    def create_env_file(self, env_vars, output_path=DEFAULT_ENV_PATH, remove_existing=True):
        """
        Create environment variable file for the service
        It is the responsibility of the service job to make
        the necessary imports for the config file to take affect
        :param env_vars: dict consisting of VARIABLE_NAME : VARIABLE_VALUE
        :param output_path: environment variable output path
        :param remove_existing: remove exiting environment variable file
        :return:
        """

        if not os.path.exists(output_path):
            os.makedirs(output_path)

        env_file_path = posixpath.join(output_path, self.service_name)
        if os.path.exists(env_file_path):
            with open(env_file_path, 'r') as fo:
                LOG.debug("Environment variable path %s already exists with content %s", env_file_path, fo.readlines())
            if remove_existing:
                self.delete_env_file(output_path=output_path)

        env_file_content = '\n'.join(['%s="%s"' % (key, value) for key, value in env_vars.items()])
        with open(env_file_path, 'w') as fo:
            fo.write(env_file_content)
            fo.flush()
            os.fsync(fo.fileno())
            LOG.debug("Setting environment variable path %s with content %s", env_file_path, env_file_content)

    def delete_env_file(self, output_path=DEFAULT_ENV_PATH):
        """
        Delete environment variable file for the service
        :param output_path:
        :return:
        """

        env_file_path = posixpath.join(output_path, self.service_name)
        if os.path.exists(env_file_path):
            os.remove(env_file_path)
            LOG.debug("Environment variable path removed: %s", env_file_path)
        else:
            LOG.debug("Environment variable path %s doesn't exist", env_file_path)

    @abstractmethod
    def cleanup(self):
        pass
