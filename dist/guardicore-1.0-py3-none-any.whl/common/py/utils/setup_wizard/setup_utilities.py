import os
import shutil
import base64
import string
import random
from netaddr import IPNetwork
from xml.dom.minidom import parseString
from common.logger import get_logger
from common.py.utils.generic import subprocess_call_independent
from common.py.utils.linux.ip_lib import IPWrapper, DeviceType
from common.py.utils.str import nativestr

LOGGER_NAME = "setup_wizard"
OVF_ENV_FILE_NAME = 'ovf-env.xml'
MOUNT_SOURCE_PATH = '/dev/sr0'
MOUNT_DESTINATION_PATH = '/mnt'
MOUNT_MODE = '-r'
MOUNT_TYPE = '-t'
MOUNT_FS = 'iso9660'
OVF_ENV_FILE_PATH = os.path.join('/etc/guardicore/', OVF_ENV_FILE_NAME)
ORIGINAL_OVF_ENV_FILE_PATH = os.path.join(MOUNT_DESTINATION_PATH, OVF_ENV_FILE_NAME)
PRODUCT_SECTION_CONFIG_PATH = '/etc/guardicore/guardicore_product_section_setup.conf'
SETUP_WIZARD_PROPERTY_NAME = "setup_wizard_configuration"

EXTERNAL_HAPROXY_ADDRESS = "31.168.234.3"

MOUNT_CMD = ['mount']
MOUNT_CDROM_COMMAND = ['mount', MOUNT_TYPE, MOUNT_FS, MOUNT_MODE, MOUNT_SOURCE_PATH, MOUNT_DESTINATION_PATH]
UNMOUNT_CDROM_COMMAND = ['umount', MOUNT_DESTINATION_PATH]

LOG = get_logger(module_name=LOGGER_NAME)


class SetupUtilities(object):
    def __init__(self):
        self._ovf_env_adapters = {}
        self._ovf_env_properties = {}

    def get_ovf_env_adapters(self):
        if self._ovf_env_adapters == {}:
            self.wrap_import_ovf_environment()
        return self._ovf_env_adapters

    def get_ovf_env_properties(self):
        if self._ovf_env_properties == {}:
            self.wrap_import_ovf_environment()
        return self._ovf_env_properties

    def get_ovf_env_setup_wizard_config(self):
        setup_wizard_config = self.get_ovf_env_properties().get(SETUP_WIZARD_PROPERTY_NAME, None)
        if setup_wizard_config is not None:
            return nativestr(base64.b64decode(setup_wizard_config))
        else:
            return None

    def _is_cdrom_mounted(self):
        """
        a method that checks if the CDROM, which is used for importing product section, is mounted
        """
        command = MOUNT_CMD
        result = subprocess_call_independent(command, merge_stderr=False)

        if result['exit_code']:
            raise EnvironmentError("Failed checking mounts with command: %s because: %s-%s " %
                                   (command, result['exit_code'], result['stderr']))

        mounts = result['stdout'].splitlines()
        expected_mount_beginning = "%s on %s" % (MOUNT_SOURCE_PATH, MOUNT_DESTINATION_PATH)
        for line in mounts:
            if nativestr(line).startswith(expected_mount_beginning):
                return True
        return False

    def _parse_ovf_env_properties(self, xml_content):
        document = parseString(xml_content)
        ovf_env_properties = {}

        for property in document.getElementsByTagName("Property"):
            key = property.attributes['oe:key'].value
            value = property.attributes['oe:value'].value
            ovf_env_properties[key] = value
        return ovf_env_properties

    def _parse_ovf_env_adapters(self, xml_content):
        document = parseString(xml_content)
        ovf_env_adapters = {}
        for adapter in document.getElementsByTagName("ve:Adapter"):
            adapter_network = adapter.attributes['ve:network'].value
            adapter_mac = adapter.attributes['ve:mac'].value
            # adapter_unit = adapter.attributes['ve:unitNumber'].value
            ovf_env_adapters[adapter_mac] = adapter_network
        return ovf_env_adapters

    def wrap_import_ovf_environment(self):
        try:
            self._import_ovf_environment()
        except Exception as e:
            LOG.error("Failed importing ovf environment: %s", e)

    def _import_ovf_environment(self):
        """
        a method that imports a configuration from vmware product section for guardeployer deployments.
        the configuration is loaded from a base64 encoded json property in a xml file,
        mounted from virtual CDROM (/dev/sr0),
        """
        if not self._is_cdrom_mounted():
            if not os.path.isdir(MOUNT_DESTINATION_PATH):
                os.mkdir(MOUNT_DESTINATION_PATH)

            command = MOUNT_CDROM_COMMAND
            result = subprocess_call_independent(command, merge_stderr=False)

            if result['exit_code']:
                raise EnvironmentError("Failed mounting CDROM with command: %s because: %s-%s " %
                                       (command, result['exit_code'], result['stderr']))

        LOG.info("CDROM mounted successfully")
        shutil.copyfile(ORIGINAL_OVF_ENV_FILE_PATH, OVF_ENV_FILE_PATH)
        LOG.info("Copied vmware ovf environment file to: %s", OVF_ENV_FILE_PATH)

        command = UNMOUNT_CDROM_COMMAND
        result = subprocess_call_independent(command, merge_stderr=False)

        if result['exit_code']:
            LOG.warning("Failed unmounting CDROM with command: %s because: %s-%s " %
                        (command, result['exit_code'], result['stderr']))
        else:
            LOG.info("CDROM unmounted successfully")

        with open(OVF_ENV_FILE_PATH, 'r') as fo:
            xml_content = fo.read()

        self._ovf_env_properties = self._parse_ovf_env_properties(xml_content)
        self._ovf_env_adapters = self._parse_ovf_env_adapters(xml_content)

    def get_local_ovf_env_setup_wizard_config(self):
        if not os.path.exists(OVF_ENV_FILE_PATH):
            return None

        with open(OVF_ENV_FILE_PATH, 'r') as fo:
            xml_content = fo.read()

        ovf_env_properties = self._parse_ovf_env_properties(xml_content)
        setup_wizard_config = ovf_env_properties.get(SETUP_WIZARD_PROPERTY_NAME)
        if setup_wizard_config is not None:
            return nativestr(base64.b64decode(setup_wizard_config))

        return None

    def ip_from_cidr_generator(self,cidr, allow_zero_end_ip=False):
        """
        generate ip's from given cidr
        """
        for ip_address in IPNetwork(cidr):
            if not allow_zero_end_ip and ip_address.format().endswith(".0"):
                continue
            yield ip_address

    def get_interfaces_list(self):
        return [(dev.name, dev.link.address) for dev in IPWrapper().get_devices(exclude_loopback=True)
                if DeviceType.Physical == dev.get_type()]

    def get_interface_name_by_network_name(self, network_name):
        interfaces_list = self.get_interfaces_list()
        env_adapters = self.get_ovf_env_adapters()
        for interface_name, interface_mac in interfaces_list:
            if env_adapters.get(interface_mac) == network_name:
                return interface_name
        LOG.warning("Cannot find interface name for network '%s'", network_name)
        return None

    def create_password(self, length=8, upper_letters=True, lower_letters=True, digits=True, symbols=False):
        pool = ""
        if upper_letters:
            pool += string.ascii_uppercase
        if lower_letters:
            pool += string.ascii_lowercase
        if digits:
            pool += string.digits
        if symbols:
            pool += string.punctuation

        return ''.join(random.choice(pool) for _ in range(length))


setup_utilities = SetupUtilities()
