
import re
import sys
import socket
import struct
import warnings
from common import logger
import six


if sys.platform in ["win32", "darwin"]:
    IPWrapper = None
else:
    from common.py.utils.linux.ip_lib import IPWrapper


LOG = logger.get_logger(module_name=__name__)

IPV4_ADDRESS_MATCH = re.compile(r"^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$")
IP_ADDRESS_MATCH = IPV4_ADDRESS_MATCH


def mac_str2buff(mac_str):
    mac_match = re.match("^([0-9a-f]{2}):([0-9a-f]{2}):([0-9a-f]{2}):([0-9a-f]{2}):([0-9a-f]{2}):([0-9a-f]{2})$",
                         mac_str.lower())
    if not mac_match:
        return None

    return "".join(map(lambda x: x.decode("hex"), mac_match.groups()))


def hex2mac(mac):
    return ':'.join([ch.encode('hex') for ch in mac])


def resolve_address(address):
    """resolve_address(address) -> address

    Try resolving name into an address. If this function gets an IP address, it would
    return it. If it isn't an IP address, it would try and translate it. If it fails,
    it would return the address itself.
    """

    if IP_ADDRESS_MATCH.match(address) is None:
        try:
            return socket.gethostbyname(address)
        except (socket.error, socket.gaierror) as exc:
            LOG.warn("Failed to resolve remote name '%s': %s", address, exc)

    return address


def get_best_connect_ip(remote_ip):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    remote_ip = resolve_address(remote_ip)

    try:
        sock.connect((remote_ip, 1))
        sock_name = sock.getsockname()
        if sock_name:
            return sock.getsockname()[0]
    except (socket.error, socket.gaierror) as exc:
        LOG.warn("Failed to resolve remote IP address '%s' for best-connect-ip: %s", remote_ip, exc)
    finally:
        try:
            sock.close()
        except:
            pass

    return None


class IPNetwork(object):
    SUBNET_BIT_NUM = None
    SUBNET_FULL_MASK = None

    __slots__ = ["network", "netmask", "net"]

    def __init__(self, net_n_bits):
        self.SUBNET_FULL_MASK = (1 << self.SUBNET_BIT_NUM) - 1
        try:
            self.net, bits = net_n_bits.split('/')
        except ValueError:
            bits = self.SUBNET_BIT_NUM
            self.net = net_n_bits
        self.netmask = self.SUBNET_FULL_MASK & (self.SUBNET_FULL_MASK << (self.SUBNET_BIT_NUM - int(bits)))

    def __contains__(self, item):
        if type(item) not in six.integer_types:
            LOG.warn("Item is not of the right type %s", type(item))
            return False
        return item & self.netmask == self.network


class IPv4Network(IPNetwork):
    SUBNET_BIT_NUM = 32

    def __init__(self, net_n_bits):
        super(IPv4Network, self).__init__(net_n_bits)
        self.network = struct.unpack('!L', socket.inet_aton(self.net))[0] & self.netmask


class IPv6Network(IPNetwork):
    SUBNET_BIT_NUM = 128
    SUBNET_FULL_MASK = (1 << SUBNET_BIT_NUM) - 1

    def __init__(self, net_n_bits):
        super(IPv6Network, self).__init__(net_n_bits)
        a, b = struct.unpack('!QQ', socket.inet_pton(socket.AF_INET6, self.net))
        self.network = ((a << 64) | b) & self.netmask


def is_ip_in_network(ip, network):
    if '.' in ip and '.' in network:
        return struct.unpack('!L', socket.inet_aton(ip))[0] in IPv4Network(network)
    elif ':' in ip and ':' in network:
        a, b = struct.unpack('!QQ', socket.inet_pton(socket.AF_INET6, ip))
        unpacked = (a << 64) | b
        return unpacked in IPv6Network(network)
    return False


def get_interfaces_info():
    """
    Get the ip address & netmask info for each of the machine interfaces.
    :return: list of interface info dicts
    """
    if IPWrapper is None:
        return []

    interfaces = []
    local_devices = [device for device in IPWrapper(running_as_root=True).get_devices(exclude_loopback=True)
                     if device.addr.list(scope="global") and device.link.address is not None]
    for device in local_devices:
        for inet_address in device.addr.list():
            if inet_address['ip_version'] != 4:
                continue
            ip_address, ip_prefix = inet_address['cidr'].split('/')
            interfaces.append({'interface': device.name,
                               'ip_address': ip_address,
                               'netmask': ip_prefix})

    return interfaces
