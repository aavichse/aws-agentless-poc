import calendar
import time

import pytz
from enum import Enum


class SyslogTimestampFormat(Enum):
    NATIVE = "Native"
    NATIVE_MILLISECONDS = "Native (including milliseconds)"
    ISO8601_MINUTES = "ISO 8601"
    ISO8601_MILLISECONDS = "ISO 8601 (including milliseconds)"

    @classmethod
    def timestamp_format_name(cls, syslog_format):
        return cls[syslog_format.name].value if syslog_format.name in cls.__members__ else syslog_format.value


class TimeField(Enum):
    CEF_HEADER = 0
    CEF_START = 1
    RFC5424_HEADER = 2


class DatetimeFormatter:
    def __init__(self, time_field=None):
        self.time_field = time_field
        self.formatting_operation = {SyslogTimestampFormat.NATIVE.value:
                                         self._native_datetime,
                                     SyslogTimestampFormat.NATIVE_MILLISECONDS.value:
                                         self._native_datetime_with_milliseconds,
                                     SyslogTimestampFormat.ISO8601_MINUTES.value:
                                         self._iso_datetime_without_seconds,
                                     SyslogTimestampFormat.ISO8601_MILLISECONDS.value:
                                         self._iso_datetime_with_milliseconds}

    def _native_datetime(self, timestamp, timezone):
        if self.time_field == TimeField.CEF_START:
            return date_to_timestamp(timestamp)
        if self.time_field == TimeField.CEF_HEADER:
            return get_cef_timestamp()
        if self.time_field == TimeField.RFC5424_HEADER:
            return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        return timestamp.strftime("%Y-%m-%d %H:%M:%S")

    def _native_datetime_with_milliseconds(self, timestamp, timezone):
        if self.time_field == TimeField.CEF_START:
            return date_to_timestamp(timestamp)
        if self.time_field == TimeField.CEF_HEADER:
            return get_cef_timestamp_with_milliseconds()
        if self.time_field == TimeField.RFC5424_HEADER:
            return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        return timestamp.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

    @staticmethod
    def _iso_datetime_without_seconds(timestamp, timezone):
        return date_to_iso_timestamp_with_tz_adjustment(timestamp, timezone,
                                                        iso_format=Date8601Format.LAST_DIGIT_MINUTE)

    @staticmethod
    def _iso_datetime_with_milliseconds(timestamp, timezone):
        return date_to_iso_timestamp_with_tz_adjustment(timestamp, timezone,
                                                        iso_format=Date8601Format.LAST_DIGIT_MILLISECOND)

    def get_timestamp_from_date(self, operation, timestamp, timezone):
        return self.formatting_operation[operation](timestamp, timezone)


class Date8601Format(Enum):
    LAST_DIGIT_MINUTE = "%Y-%m-%dT%H:%M"
    LAST_DIGIT_SECOND = "%Y-%m-%dT%H:%M:%S"
    LAST_DIGIT_MILLISECOND = "%Y-%m-%dT%H:%M:%S.%f"


def get_cef_timestamp(gm_time=None):
    if gm_time is None:
        gm_time = time.gmtime()
    # In CEF the day of the month is represented as a one-digit number without a leading zero for single-digit days
    timestamp = time.strftime("%b %e %H:%M:%S", gm_time).replace('  ', ' ')
    return timestamp


def get_cef_timestamp_with_milliseconds(gm_time=None):
    if gm_time is None:
        gm_time = time.gmtime()
    # In CEF the day of the month is represented as a one-digit number without a leading zero for single-digit days
    timestamp = time.strftime("%b %e %H:%M:%S.%f", gm_time).replace('  ', ' ')[:-3]
    return timestamp


def date_to_iso_timestamp_with_tz_adjustment(datetime_record, tz=pytz.timezone('UTC'),
                                             iso_format=Date8601Format.LAST_DIGIT_MINUTE):
    """
    Convert timestamp to string output with format yyyy-MM-ddTHH:mmZ for UTC time
    Convert timestamp to string output with format yyyy-MM-ddTHH:mm+0000 for non UTC time
    """

    if tz.zone == 'UTC':
        date_format = iso_format.value
        timestamp = datetime_record.strftime(date_format)
        location_offset = "Z"
    else:
        # Time zone offset is configured, and not default to UTC. Need to localize and add the timezone offset
        datetime_record = datetime_record.astimezone(tz)
        location_offset = datetime_record.strftime('%z')
        timestamp = datetime_record.strftime(iso_format.value)

    if iso_format != Date8601Format.LAST_DIGIT_MILLISECOND:
        return timestamp + location_offset
    else:
        return timestamp[:-3] + location_offset


def date_to_timestamp(obj):
    # calendar.timegm is like time.mktime for utc input
    return int(calendar.timegm(obj.timetuple()) * 1000 + obj.microsecond / 1000)



