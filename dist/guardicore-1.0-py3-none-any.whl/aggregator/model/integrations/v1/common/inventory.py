from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional, Union
from pydantic import AwareDatetime, BaseModel, Field, model_validator, field_validator


class ItemType(Enum):
    ASSET = 'asset'


class Label(BaseModel):
    key: str
    value: str


class Type(Enum):
    VM = 'VM'


class AzureNetworkTopology(BaseModel):
    subscription: Optional[str] = None
    resource_group: Optional[str] = Field(None, alias='resource-group')
    region: Optional[str] = None
    resource_id: Optional[str] = Field(
        None,
        alias='resource-id',
        examples=[
            '/subscriptions/6974b4cf-6bf8-4454-8d22-a8f33084d699/resourceGroups/DEMO_SETUP/providers/Microsoft.Compute/virtualMachines/spoke1-vm'
        ],
    )


class AzureNetworkAccess(BaseModel):
    public_access_enabled: Optional[bool] = Field(None, alias='public-access-enabled')
    private_access_enabled: Optional[bool] = Field(None, alias='private-access-enabled')
    service_endpoint_enabled: Optional[bool] = Field(
        None, alias='service-endpoint-enabled'
    )


class NetworkInterfaceData(BaseModel):
    id: Optional[str] = Field(
        None, description='nic id, managed as resource id in Azure'
    )
    mac_address: str = Field(..., alias='mac-address')
    network: str
    subnet_id: str = Field(..., alias='subnet-id')
    private_ip_addresses: Optional[List[str]] = Field(
        None, alias='private-ip-addresses'
    )
    public_ip_addresses: Optional[List[str]] = Field(None, alias='public-ip-addresses')


class OnlineStatus(Enum):
    ONLINE = 'online'
    OFFLINE = 'offline'


class PowerState(Enum):
    RUNNING = 'running'
    STOPPED = 'stopped'
    RESTARTING = 'restarting'


class RegistrationStatus(Enum):
    REGISTERED = 'registered'
    UNREGISTERED = 'unregistered'


class Type1(Enum):
    MS = 'MS'


class Type2(Enum):
    IOT = 'IOT'


class IOTRegistrationStatus(BaseModel):
    reg_status: Optional[RegistrationStatus] = Field(None, alias='reg-status')
    reg_date: Optional[AwareDatetime] = Field(None, alias='reg-date')
    unreg_date: Optional[AwareDatetime] = Field(None, alias='unreg-date')


class HardwareInfo(BaseModel):
    hw_class: Optional[str] = Field('unknown', alias='hw-class')
    hw_manufacturer: Optional[str] = Field('unknown', alias='hw-manufacturer')
    hw_type: Optional[str] = Field('unknown', alias='hw-type')


class IOT(BaseModel):
    type: Type2
    os_details: Optional[Dict[str, Any]] = Field(None, alias='os-details')
    hw_details: HardwareInfo = Field(..., alias='hw-details')
    nics: Optional[List[NetworkInterfaceData]] = None
    power_state: Optional[PowerState] = Field(None, alias='power-state')
    online_status: Optional[OnlineStatus] = Field(None, alias='online-status')
    registration_status: Optional[IOTRegistrationStatus] = Field(
        None, alias='registration-status'
    )
    device_score: Optional[str] = Field(None, alias='device-score')


class ManagedServiceData(BaseModel):
    type: Type1
    nics: Optional[List[NetworkInterfaceData]] = None
    network_topology: Optional[Union[AzureNetworkTopology, Dict[str, Any]]] = Field(
        None, alias='network-topology'
    )
    network_access: Optional[Union[AzureNetworkAccess, Dict[str, Any]]] = Field(
        None, alias='network-access'
    )


class VMData(BaseModel):
    type: Type
    os_details: Optional[Dict[str, Any]] = Field(None, alias='os-details')
    hw_details: Optional[HardwareInfo] = Field(None, alias='hw-details')
    nics: Optional[List[NetworkInterfaceData]] = None
    network_topology: Optional[Union[AzureNetworkTopology, Dict[str, Any]]] = Field(
        None, alias='network-topology'
    )
    power_state: Optional[PowerState] = Field(None, alias='power-state')


class InventoryItem(BaseModel):
    # Change from base model: Pydantic generates InventoryItem1/2 and root model, we unify them here
    # Change from base model: item_type is str instead of Enum
    item_type: str = Field(
        'asset',
        alias='item-type',
        description='inventory item type - currently asset only',
    )
    # Change from base model: Both item_id and external_ids are configured optional,
    # but we validate one of them exists in the model validator
    item_id: Optional[str] = Field(
        None, alias='item-id', description='inventory item id assigned by Centra'
    )
    external_ids: Optional[List[str]] = Field(
        None,
        alias='external-ids',
        description='list of external IDs that are managed by external asset management systems such as Azure resource management',
    )
    entity_type: Optional[str] = Field(
        None,
        alias='entity-type',
        description='asset type such as Virtual Machine or Azure SQL Server',
    )
    entity_category: Optional[str] = Field(
        None,
        alias='entity-category',
        description='asset category such as Compute or Database',
    )
    entity_name: Optional[str] = Field(
        None, alias='entity-name', description='asset name'
    )
    entity_data: Optional[Union[VMData, ManagedServiceData, IOT, Dict[str, Any]]] = Field(
        None,
        alias='entity-data',
        description='additional entity data depending on its type',
        union_mode='left_to_right'  # Added to base model: union_mode
    )
    labels: Optional[List[Label]] = None
    # Added to base model: metadata_attributes (not in contracts, currently not in use)
    metadata_attributes: Optional[dict] = Field(
        None,
        alias='metadata-attributes')

    # Added to base model: model validator
    @model_validator(mode='wrap')
    @classmethod
    def validate_model(cls, model: Union[InventoryItem, dict], handler, info):
        if isinstance(model, dict):
            assert model.get('item-id') or model.get('external-ids'), "no item-id or external-ids"
            if not model.get('item-id') and model.get('external-ids'):
                model['item-id'] = model.get('external-ids')[0]
                return handler(model)
        return handler(model)

    @field_validator('item_type', mode='before')
    @classmethod
    def validate_item_type(cls, v: Union[str, None]) -> str:
        if v is None:
            return ItemType.ASSET.value
        return v
