import errno
import json
import struct
import datetime
from enum import IntEnum, Enum

import attr
from six import add_metaclass

from common.py.configuration.consts import EN_DEFAULT_MAX_ERR_RULES_TO_REPORT
from common.py.events.attrs import fast_to_dict
from common.logger import get_logger
from common.py.model.exceptions import GuardicoreException
from common.py.model.status.service_status import ServiceStatus
from common.py.utils.config.six import fastjson
from common.py.events.visibility.enforcement_sf import EnforcementFeatures
from common.singleton import Singleton
from common.py.utils.dict_scheme import DictScheme, MandatoryDictField, TypeBool, TypeInt, TypeSequence, \
    OptionalDictField, TypeString
from common.py.utils.str import to_bytes

try:
    from eventlet import sleep
    from eventlet.green import socket
    from eventlet.timeout import Timeout
except ImportError:
    from gevent import socket, sleep
    from gevent.timeout import Timeout

LOG = get_logger(module_name=__name__)


class PolicyDerivationErrors(IntEnum):
    ERROR_OK = 0  # means that there is no error
    ERROR_CROSSED_LIMITATION = 1
    ERROR_GENERIC = 2
    ERROR_BAD_COMMAND_FORMAT = 3
    ERROR_POLICY_DERIVE = 4
    ERROR_POLICY_SWAP = 5
    ERROR_POLICY_FIT = 6
    ERROR_MAX_RULES = 7
    ERROR_MAX_ENTITIES = 8
    ERROR_NO_DNS_SUPPORT = 9
    ERROR_NO_FIP_SUPP = 10
    ERROR_NO_PROCESS_SUPPORT = 11
    ERROR_NO_NOT_RULE_SUPPORT = 12
    ERROR_NO_IDENTITY_RULE_SUPPORT = 13
    ERROR_INVALID_RULE_FORMAT = 14
    ERROR_AGENT_INTERNAL = 15
    ERROR_NO_ICMP_SUPPORT = 16
    ERROR_NO_LBL_GROUP_SUPPORT = 17
    ERROR_INVALID_CONTAINER_ATTR = 18
    ERROR_MAX_POLICY_SIZE = 19
    ERROR_NO_WIN_SERVICE_SUPPORT = 20
    ERROR_NO_USERGROUPS_SUPPORT = 21
    ERROR_UNKNOWN = 30


FIR_ERROR_DETAILS_SCHEME = DictScheme(MandatoryDictField('name', TypeInt),
                                      MandatoryDictField('rules', TypeSequence(TypeString)),
                                      OptionalDictField('rules_count', TypeInt),
                                      OptionalDictField('description', TypeString))

POLICY_FIT_DETAILS_SCHEME = DictScheme(MandatoryDictField('ok', TypeBool),
                                       MandatoryDictField('reason', TypeInt),
                                       MandatoryDictField('fit_errors', TypeSequence(FIR_ERROR_DETAILS_SCHEME)))


class ConfigurationFlags(IntEnum):
    AlertLikeBlockDerivation = 1
    UseCloudNetworkInfo = 2
    DerivationConsiderAssetExclusion = 3
    DerivationRemoteL7OnlyDrop = 4
    LabelDeriveSubnetsOnly = 5
    DerivationOneSidedAny = 6
    OffCorporateEnabled = 7
    FastLabelsDisabled = 8
    UserGroupsDisabled = 9
    WorksitesEnabled = 10
    EAASupportEnabled = 11


class StatusHeaderType(IntEnum):
    DerivationHeader = 1


@attr.s
class PolicyStatus(object):
    inventory_set = attr.ib(default=False)
    policy_set = attr.ib(default=False)
    revision = attr.ib(default=0)
    dc_inventory_revision = attr.ib(default=0)


class PolicyManagerException(GuardicoreException):
    pass


@add_metaclass(Singleton)
class PolicyManagerAddress:
    """
    This class stores the IP address of the policy manager in use.
    By default, 127.0.0.1 will be used. instantiate this class with another IP before using the Policy Manager API
    in order to use a different address
    """

    def __init__(self, ip='127.0.0.1'):
        self._ip = ip

    @classmethod
    def set_ip(cls, ip):
        cls(ip=ip)

    @classmethod
    def ip(cls):
        return cls()._ip


class PolicyManagerAPI(object):
    TCP_PORT = 9999
    SOCK_TIMEOUT = 60
    CHUNK_SIZE = 65536
    MAX_CMD_FAILURES_TO_RESTART = 10

    sock_timeout = SOCK_TIMEOUT

    class Commands(Enum):
        SET_LABELS = 1
        SET_ASSETS = 2
        SET_PRIVATE_SUBNETS = 3
        SET_POLICY = 4
        SWAP_INVENTORY = 5
        SWAP_POLICY = 6
        GET_AGENT_POLICY = 7
        GET_STATUS = 8
        GET_POLICY_STATUS = 9
        SET_CONFIGURATION = 10
        GET_CONFIGURATION = 11
        GET_K8S_POLICY = 12
        CONTROL = 13
        GET_AZURE_POLICY = 14

    class PolicyOutputFormat(Enum):
        POLICY_OUTPUT_FORMAT_YAML = 1
        POLICY_OUTPUT_FORMAT_JSON = 2
        POLICY_OUTPUT_FORMAT_PROTO = 3

    track_cmd_failures = [Commands.SET_LABELS, Commands.SET_ASSETS, Commands.SET_PRIVATE_SUBNETS,
                          Commands.SET_POLICY, Commands.SWAP_INVENTORY, Commands.SWAP_POLICY,
                          Commands.GET_AGENT_POLICY]
    cmd_failure_count = 0
    max_failure_count = MAX_CMD_FAILURES_TO_RESTART
    enforcement_client = None

    @classmethod
    def set_failure_count(cls, reset=True, max_count=10):
        if reset:
            cls.cmd_failure_count = 0
        cls.max_failure_count = max_count
        LOG.debug("max failure count set to %s", max_count)

    @classmethod
    def register_failure(cls, cmd=None):
        if cmd in cls.track_cmd_failures:
            cls.cmd_failure_count += 1
            LOG.debug("failure for command %s, failure_count=%s", cmd, cls.cmd_failure_count)

            if cls.enforcement_client:
                cls.enforcement_client.notify_policy_manager_failure(is_failure=True, command=cmd.value)
        else:
            LOG.debug("failure for command %s (not tracked), failure_count=%s", cmd, cls.cmd_failure_count)

    @classmethod
    def clear_failures(cls, cmd=None):
        if cmd and cmd not in cls.track_cmd_failures:
            return
        if cls.enforcement_client and cls.cmd_failure_count:    # notify only if going from failure to success
            cls.enforcement_client.notify_policy_manager_failure(is_failure=False, command=cmd.value)
        cls.cmd_failure_count = 0

    @classmethod
    def set_connection_params(cls, socket_timeout=None):
        if socket_timeout:
            LOG.debug("socket timeout set to %s sec", socket_timeout)
            cls.sock_timeout = socket_timeout

    @staticmethod
    def _recv_until_eol(sock):
        res_chunks = []
        last_chunk = None

        while last_chunk is None or not last_chunk.endswith(b"\n"):
            last_chunk = sock.recv(PolicyManagerAPI.CHUNK_SIZE)
            if not last_chunk:
                break

            res_chunks.append(last_chunk)

        if not res_chunks or not last_chunk:
            return None

        return b"".join(res_chunks)

    @classmethod
    def _send_command(cls, cmd, data=None, load_json=True, allow_failure=False):
        assert isinstance(cmd, PolicyManagerAPI.Commands)

        sock = socket.socket()
        sock.settimeout(cls.sock_timeout)

        try:
            sock.connect((PolicyManagerAddress.ip(), cls.TCP_PORT))

            # send command type and data
            encoded_data = fastjson.dumps(fast_to_dict(data)) if data is not None else ''
            sock.sendall(struct.pack("B", cmd.value) + to_bytes(encoded_data))

            # read command response
            res_data = cls._recv_until_eol(sock)
            LOG.debug("Policy Manager API call: %s: %s.\nReturned: %s", cmd.name, encoded_data, res_data)
            if not res_data:
                if allow_failure:
                    return None
                raise PolicyManagerException("Policy manager got disconnected during command %s read", cmd.name)
        except Exception as exc:
            if not allow_failure:
                if isinstance(exc, socket.error) and exc.errno == errno.ECONNREFUSED:
                    LOG.exception("Policy manager rejected connection (port=%d) for command %s, check if it is down",
                                  PolicyManagerAPI.TCP_PORT, cmd.name)
                else:
                    LOG.exception("Caught exception while trying to send command %s:", cmd.name)

                cls.register_failure(cmd)

            return None
        finally:
            sock.close()

        cls.clear_failures(cmd)

        if load_json:
            try:
                res_data = json.loads(res_data)
            except ValueError:
                if not allow_failure:
                    LOG.exception("Invalid JSON response received from policy manager for command %s : %s",
                                  cmd.name, res_data)
                return None

        return res_data

    @staticmethod
    def _get_error_reason(res):
        if res is None:
            return "policy manager disconnected"
        elif 'reason' not in res:
            reason = "missing reason"
        else:
            reason = PolicyDerivationErrors(res['reason']).name

        return reason

    @staticmethod
    def _get_error_pretty(res):
        reason = PolicyManagerAPI._get_error_reason(res)

        if res is not None:
            message = res.get('message')
            if message:
                return "%s (%s)" % (message, reason)

        return reason

    @staticmethod
    def update_inventory(dc_inventory_revision, labels, assets, private_subnets):
        assert isinstance(dc_inventory_revision, int), "'dc_inventory_revision' is expected to be of type int"
        assert isinstance(labels, dict), "'labels' is expected to be of type dict"
        assert isinstance(assets, dict), "'assets' is expected to be of type dict"
        assert isinstance(private_subnets, (list, tuple, set)), "'private_subnets' is expected to be of type sequence"

        res = PolicyManagerAPI._send_command(PolicyManagerAPI.Commands.SET_LABELS, labels)
        if res is None or not res.get('ok'):
            LOG.error("failed to send new labels to policy manager: %s", PolicyManagerAPI._get_error_pretty(res))
            return False

        res = PolicyManagerAPI._send_command(PolicyManagerAPI.Commands.SET_ASSETS, assets)
        if res is None or not res.get('ok'):
            LOG.error("failed to send new assets to policy manager: %s", PolicyManagerAPI._get_error_pretty(res))
            return False

        res = PolicyManagerAPI._send_command(PolicyManagerAPI.Commands.SET_PRIVATE_SUBNETS,
                                             {'private_subnets': private_subnets})
        if res is None or not res.get('ok'):
            res.get('res')
            LOG.error("failed to send new private subnets to policy manager: %s",
                      PolicyManagerAPI._get_error_pretty(res))
            return False

        res = PolicyManagerAPI._send_command(PolicyManagerAPI.Commands.SWAP_INVENTORY,
                                             {'dc_inventory_revision': dc_inventory_revision})
        if res is None or not res.get('ok'):
            LOG.error("failed to send new dc_inventory_revision to policy manager: %s",
                      PolicyManagerAPI._get_error_pretty(res))
            return False

        if res is None or not res.get('ok'):
            LOG.error("failed to swap inventory: %s", PolicyManagerAPI._get_error_pretty(res))
            return False

        return True

    @staticmethod
    def update_policy(rules, full_policy_revision):
        res = PolicyManagerAPI._send_command(PolicyManagerAPI.Commands.SET_POLICY,
                                             {'revision': full_policy_revision.policy_revision,
                                              'rules': rules})
        if res is None or not res.get('ok'):
            LOG.error("failed to send new policy to policy manager: %s", PolicyManagerAPI._get_error_pretty(res))
            return False

        res = PolicyManagerAPI._send_command(PolicyManagerAPI.Commands.SWAP_POLICY)
        if res is None or not res.get('ok'):
            LOG.error("failed to swap policy: %s", PolicyManagerAPI._get_error_pretty(res))
            return False

        return True

    @staticmethod
    def derive_policy(asset_id, os, agent_domain, supported_features, max_rules=0, max_entities=0,
                      max_err_rules_to_include=EN_DEFAULT_MAX_ERR_RULES_TO_REPORT, derive_ipv6=True):
        policy = PolicyManagerAPI._send_command(PolicyManagerAPI.Commands.GET_AGENT_POLICY,
                                                {"asset_id": asset_id,
                                                 "operating_system": os.value,
                                                 "supported_features": {
                                                     feature.name: True
                                                     for feature in list(supported_features)
                                                 },
                                                 "max_rules": max_rules,
                                                 "max_entities": max_entities,
                                                 "domain_name": agent_domain,
                                                 "max_err_rules_report": max_err_rules_to_include,
                                                 "derive_ipv6": derive_ipv6
                                                 },
                                                load_json=False)

        # Parse received response, it should contain --> <status_length><status><policy><hash>
        return PolicyDerivationResult.from_string(policy)

    @staticmethod
    def derive_k8s_policy(cluster_id, supported_features=None, max_entities=0,
                          max_err_rules_to_include=EN_DEFAULT_MAX_ERR_RULES_TO_REPORT,
                          output_format=PolicyOutputFormat.POLICY_OUTPUT_FORMAT_PROTO):
        policy = PolicyManagerAPI._send_command(PolicyManagerAPI.Commands.GET_K8S_POLICY,
                                                {"cluster_id": cluster_id,
                                                 "supported_features": {
                                                     feature.name: True
                                                     for feature in
                                                     list(supported_features or [])},
                                                 "output_format": output_format.value,
                                                 },
                                                load_json=False)

        # Parse received response, it should contain --> <status_length><status><policy><hash>
        return PolicyDerivationResult.from_string(policy)

    @staticmethod
    def derive_azure_policy(subscription_id, supported_features=None, output_format=PolicyOutputFormat.POLICY_OUTPUT_FORMAT_JSON):
        return PolicyManagerAPI._send_command(PolicyManagerAPI.Commands.GET_AZURE_POLICY,
                                                {"subscription_id": subscription_id,
                                                "supported_features": {
                                                    feature.name: True
                                                    for feature in
                                                    list(supported_features or [])},
                                                "output_format": output_format.value,
                                                 },
                                                load_json=True)


    @staticmethod
    def probe_status(status=ServiceStatus.RUNNING, timeout=2.0, probe_timeout=0.1):
        try:
            with Timeout(timeout):
                while PolicyManagerAPI.get_status() != status:
                    sleep(probe_timeout)
                return status
        except Timeout:
            pass
        return PolicyManagerAPI.get_status()

    @staticmethod
    def get_status():
        res = PolicyManagerAPI._send_command(PolicyManagerAPI.Commands.GET_STATUS, allow_failure=True)
        if res is None or not res.get('ok'):
            return ServiceStatus.DOWN

        return ServiceStatus.RUNNING

    @staticmethod
    def get_policy_status():
        LOG.info("Getting policy from %s:%s", PolicyManagerAddress.ip(), PolicyManagerAPI.TCP_PORT)
        res = PolicyManagerAPI._send_command(PolicyManagerAPI.Commands.GET_POLICY_STATUS)
        if res is None or not isinstance(res, dict) or not res.get('ok'):
            raise PolicyManagerException("Error reply while reading policy status: %s",
                                         PolicyManagerAPI._get_error_pretty(res))

        return PolicyStatus(inventory_set=res.get('inventory_set', False),
                            policy_set=res.get('policy_set', False),
                            revision=res.get('revision', 0),
                            dc_inventory_revision=res.get('dc_inventory_revision', 0)
                            )

    @staticmethod
    def _send_configuration(data):
        data["timestamp"] = int(datetime.datetime.utcnow().strftime('%y%m%d%H%M%S'))
        LOG.info("Send configuration to policy manager: %r", data)
        res = PolicyManagerAPI._send_command(PolicyManagerAPI.Commands.SET_CONFIGURATION, data)

        if res is None or not isinstance(res, dict) or not res.get('ok'):
            LOG.error("failed to send configuration to policy manager: %s", PolicyManagerAPI._get_error_pretty(res))
            return None

        return res

    @staticmethod
    def set_configuration(flags):
        data = {"configuration_flags": {flag.name: True for flag in list(flags)}}
        return PolicyManagerAPI._send_configuration(data)

    @staticmethod
    def update_single_flag(flag, value):
        LOG.debug("Update configuration flag: %r value %r", flag, value)
        conf = PolicyManagerAPI.get_configuration()
        LOG.info("Update_configuration_flag old value: %r flag %s value %r", conf, flag, value)
        if conf is None:
            return

        data = {"configuration_flags": conf["configuration_flags"]}
        data["configuration_flags"][flag.name] = value
        PolicyManagerAPI._send_configuration(data)

    @staticmethod
    def get_single_flag(flag):
        LOG.debug("get_single_flag flag: %r", flag)
        conf = PolicyManagerAPI.get_configuration()
        if not conf:
            LOG.error("failed to get flag: %r", flag)
            return False

        if flag.name in conf["configuration_flags"]:
            LOG.debug("get_single_flag flag: %r return %r", flag, conf["configuration_flags"][flag.name])
            return conf["configuration_flags"][flag.name]

        LOG.error("get_single_flag flag: %r not found in conf %r", flag, conf["configuration_flags"])
        return False

    @staticmethod
    def get_configuration():
        res = PolicyManagerAPI._send_command(PolicyManagerAPI.Commands.GET_CONFIGURATION)

        if res is None or not isinstance(res, dict) or not res.get('ok'):
            LOG.error("failed to send configuration to policy manager: %s", PolicyManagerAPI._get_error_pretty(res))
            return None

        return res

    @staticmethod
    def control_cmd(dump_stack=True):
        data = {"dump_stack": dump_stack}
        res = PolicyManagerAPI._send_command(PolicyManagerAPI.Commands.CONTROL, data)

        if res is not None:
            message = res.get('message')
            if message:
                LOG.info("Policy Manager stack dump:\n%s", message)

        return res


class PolicyDerivationResult(object):
    """
    PolicyDerivationResult represents message received from policy manager as
    the result of policy derivation procedure. Message is structured the following way:
    [ MAGIC(4 BYTES) | TYPE(1 BYTE) | STATUS LENGTH (4 BYTES) | STATUS (STATUS LENGTH bytes) | POLICY (rest - 32) | POLICY HASH (32 bytes)]
    """

    # Magic string received in first 4 bytes of policy derivation response from Policy Manager
    STATUS_HEADER_MAGIC = b"1ur1"
    # [ 4 bytes for magic string | 1 byte for type of response field | 4 bytes for status length ] = 9 bytes in total
    STATUS_HEADER_FMT = b"<4sBI"
    STATUS_HEADER_SIZE = struct.calcsize(STATUS_HEADER_FMT)
    # footer = [ 32 bytes hex-encoded MD5  + EOL ]
    MD5_STR_SIZE = 32  # MD5 digest-size * 2
    FOOTER_SIZE = MD5_STR_SIZE + 1

    def __init__(self, reason, status_json, policy_str, policy_hash=None, error=None):
        self._reason = reason
        self._status_json = status_json
        self._policy_str = policy_str
        self._policy_hash = policy_hash
        self._error = error

    @classmethod
    def from_string(cls, derivation_response):
        """from_string(derivation_response) -> PolicyDerivationResult
        Given policy derivation response message, it'll retrieves status and policy parts and prepares
        PolicyDerivationResult instance.
        :param derivation_response: bytes or dict
        """
        if derivation_response is None:
            return cls.generic_error("Cannot parse None 'derivation_response'")

        derivation_response_len = len(derivation_response)
        if derivation_response_len < cls.STATUS_HEADER_SIZE:
            return cls.generic_error("Cannot parse 'derivation_response', size is less then required (%d < %d) %r",
                                     derivation_response_len, cls.STATUS_HEADER_SIZE,
                                     derivation_response[:cls.STATUS_HEADER_SIZE])

        magic, header_type, status_length = struct.unpack(
            cls.STATUS_HEADER_FMT, derivation_response[:cls.STATUS_HEADER_SIZE])

        if magic != cls.STATUS_HEADER_MAGIC:
            return cls.generic_error("Cannot parse 'derivation_response', magic incorrect (%r != %r)",
                                     magic, cls.STATUS_HEADER_MAGIC)

        if header_type != StatusHeaderType.DerivationHeader.value:
            return cls.generic_error("Cannot parse 'derivation_response', incorrect header type (%d != %d)",
                                     StatusHeaderType.DerivationHeader.value, header_type)

        if (derivation_response_len - cls.STATUS_HEADER_SIZE) < status_length:
            return cls.generic_error("Cannot parse 'derivation_response', incorrect 'status_length' (%d > %d - %d)",
                                     status_length, derivation_response_len, cls.STATUS_HEADER_SIZE)

        status_part = slice(cls.STATUS_HEADER_SIZE, cls.STATUS_HEADER_SIZE + status_length)
        try:
            status_json = json.loads(derivation_response[status_part])
        except ValueError:
            return cls.generic_error("Cannot parse 'derivation_response', incorrect 'status' json '%s'",
                                     derivation_response[status_part])

        if POLICY_FIT_DETAILS_SCHEME(status_json) is None:
            return cls.generic_error("Cannot parse 'derivation_response', incorrect 'status' json format '%s'",
                                     derivation_response[status_part])

        try:
            err_code = PolicyDerivationErrors(status_json['reason'])
        except ValueError:
            return cls.generic_error("Cannot parse 'derivation_response', unknown err_code=%d", status_json['reason'])

        if status_json['ok'] is False:
            LOG.warning("Policy derivation failed (reason=%s): %r", PolicyDerivationErrors(err_code).name,
                        status_json)
            return cls(err_code, status_json, None)

        footer_size = cls.FOOTER_SIZE
        if (derivation_response_len - cls.STATUS_HEADER_SIZE - footer_size) < 1:
            return cls.generic_error("Cannot parse 'derivation_response', incorrect footer length %d. "
                                     "Should be > %d + %d", derivation_response_len, cls.STATUS_HEADER_SIZE,
                                     footer_size)

        return cls(err_code, status_json,
                   derivation_response[cls.STATUS_HEADER_SIZE + status_length:derivation_response_len - footer_size],
                   derivation_response[derivation_response_len - footer_size + 1:derivation_response_len - 1])

    @classmethod
    def generic_error(cls, error_msg, *args):
        return cls(PolicyDerivationErrors.ERROR_GENERIC, status_json=None, policy_str=None, error=error_msg % args)

    @property
    def reason(self):
        return self._reason

    @property
    def error(self):
        if not self._error:
            if self._reason:
                return "Derivation error: {}".format(self._reason.name)
            return "Unknown error"
        return self._error

    @property
    def status(self):
        return self._status_json

    @property
    def policy(self):
        return self._policy_str

    @property
    def err_code(self):
        return self._reason

    @property
    def derivation_details(self):
        return self._status_json

    @property
    def policy_hash(self):
        return self._policy_hash

    @property
    def ok(self):
        if self._status_json is None:
            return False
        return self._status_json['ok']
