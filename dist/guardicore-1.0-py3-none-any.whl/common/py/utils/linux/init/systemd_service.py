import dbus

from common.logger import get_logger
from common.py.utils.linux.init.init_service import InitService
from common.py.utils.linux.init.model import InitServiceStatus, SystemdUnitActiveState, SystemdServiceUnitSubState, \
    SystemdJobMode

LOG = get_logger(module_name=__name__)

SYSTEMD_SUB_STATE_MAPPING = {
    SystemdServiceUnitSubState.PRE_START: InitServiceStatus.STARTING,
    SystemdServiceUnitSubState.START: InitServiceStatus.STARTING,
    SystemdServiceUnitSubState.POST_START: InitServiceStatus.STARTING,
    SystemdServiceUnitSubState.AUTO_RESTART: InitServiceStatus.STARTING,
    SystemdServiceUnitSubState.RUNNING: InitServiceStatus.RUNNING,
    SystemdServiceUnitSubState.RELOAD: InitServiceStatus.RUNNING,
    SystemdServiceUnitSubState.EXITED: InitServiceStatus.STOPPED,
    SystemdServiceUnitSubState.STOP: InitServiceStatus.STOPPED,
    SystemdServiceUnitSubState.STOP_SIGABRT: InitServiceStatus.STOPPED,
    SystemdServiceUnitSubState.STOP_SIGTERM: InitServiceStatus.STOPPED,
    SystemdServiceUnitSubState.STOP_SIGKILL: InitServiceStatus.STOPPED,
    SystemdServiceUnitSubState.POST_STOP: InitServiceStatus.STOPPED,
    SystemdServiceUnitSubState.FINAL_SIGTERM: InitServiceStatus.STOPPED,
    SystemdServiceUnitSubState.FINAL_SIGKILL: InitServiceStatus.STOPPED,
    SystemdServiceUnitSubState.FAILED: InitServiceStatus.STOPPED,
    SystemdServiceUnitSubState.DEAD: InitServiceStatus.STOPPED,
}


class SystemdService(InitService):
    """
    Systemd dbus interface docs: https://www.freedesktop.org/software/systemd/man/org.freedesktop.systemd1.html
    """

    def __init__(self, service_name):
        super(SystemdService, self).__init__(service_name=service_name)

        self._unit = None
        self._systemd_unit_name = service_name + '.service'
        try:
            self._sysbus = dbus.SystemBus()
            self._service_proxy = self._sysbus.get_object('org.freedesktop.systemd1', '/org/freedesktop/systemd1')
            self._manager = dbus.Interface(self._service_proxy, 'org.freedesktop.systemd1.Manager')
            self._unit = self._sysbus.get_object('org.freedesktop.systemd1',
                                              object_path=self._manager.LoadUnit(self._systemd_unit_name))
            self._service_property = dbus.Interface(self._unit, 'org.freedesktop.DBus.Properties')
        except Exception:
            LOG.exception("Failed to create systemd service '%s'", self._systemd_unit_name)

    def start(self):
        try:
            if self._unit:
                self._manager.StartUnit(self._systemd_unit_name, SystemdJobMode.REPLACE.value)
                return InitServiceStatus.STARTING
            return InitServiceStatus.NOT_FOUND
        except Exception:
            LOG.exception("Failed to start unit '%s'", self._systemd_unit_name)
            return InitServiceStatus.FAIL_START

    def stop(self):
        try:
            if self._unit:
                self._manager.StopUnit(self._systemd_unit_name, SystemdJobMode.FAIL.value)
                return InitServiceStatus.STOPPED
            return InitServiceStatus.NOT_FOUND
        except Exception:
            LOG.exception("Failed to stop unit '%s'", self._systemd_unit_name)
            return InitServiceStatus.FAIL_STOP

    def restart(self):
        # If a service is restarted that isn't running, it will be started
        try:
            if self._unit:
                self._manager.RestartUnit(self._systemd_unit_name, SystemdJobMode.REPLACE.value)
                return InitServiceStatus.STARTING
            return InitServiceStatus.NOT_FOUND
        except Exception:
            LOG.exception("Failed to restart unit '%s'", self._systemd_unit_name)
            return InitServiceStatus.FAIL_START

    def reload_connection(self):
        # ReloadUnit, RestartUnit, TryRestartUnit, ReloadOrRestartUnit, or ReloadOrTryRestartUni) may be used to
        # restart and/or reload a unit. These methods take similar arguments as StartUnit.
        # Reloading is done only if the unit is already running and fails otherwise.
        LOG.info("Reloading systemd DBus connection for unit %s", self._systemd_unit_name)

        if self._unit:
            try:
                self._manager.ReloadUnit(self._systemd_unit_name, SystemdJobMode.REPLACE.value)
            except Exception:
                LOG.exception("Failed to reload unit '%s'", self._systemd_unit_name)

    def get_status(self):
        try:
            if self._unit:
                status = self._service_property.Get('org.freedesktop.systemd1.Unit', 'ActiveState')
                return self.translate_state(status)
            return InitServiceStatus.NOT_FOUND
        except Exception:
            return InitServiceStatus.UNKNOWN

    def enable(self):
        try:
            if self._unit:
                self._manager.EnableUnitFiles([self._systemd_unit_name], True, True)
                self._manager.Reload()
                return InitServiceStatus.STARTING
            return InitServiceStatus.NOT_FOUND
        except Exception:
            return InitServiceStatus.UNKNOWN

    def translate_state(self, state):
        try:
            active_state = SystemdUnitActiveState.from_str(str(state))
            if not active_state:
                LOG.warning("Failed to translate state for unit '%s' status: %s", self.service_name, state)
                return InitServiceStatus.UNKNOWN

            if active_state in (SystemdUnitActiveState.INACTIVE,
                                SystemdUnitActiveState.FAILED,
                                SystemdUnitActiveState.DEACTIVATING):
                return InitServiceStatus.STOPPED

            if active_state == SystemdUnitActiveState.ACTIVATING:
                return InitServiceStatus.STARTING

            if active_state == SystemdUnitActiveState.ACTIVE:
                return InitServiceStatus.RUNNING

            return InitServiceStatus.UNKNOWN
        except dbus.DBusException as exc:
            LOG.warning("Failed to get status for unit '%s': %s", self.service_name, exc)
            return InitServiceStatus.UNKNOWN
        except Exception:
            LOG.exception("Fail to get status for unit '%s'", self.service_name)
            return InitServiceStatus.UNKNOWN

    def get_log_location(self):
        return ' journalctl -u %s' % self.service_name

    def cleanup(self):
        pass
