from common.logger import get_logger
from common.py.collection.control.client.agents_server_client import AgentsServerComponentControlClient
from common.py.model.aggregator import AggregatorComponent

LOGGER = get_logger(module_name=__name__)


class BaseEnforcementWorkerControlClient(AgentsServerComponentControlClient):
    def __init__(self, component_name=AggregatorComponent.EnforcementServer, worker_index=0, **kwargs):
        super(BaseEnforcementWorkerControlClient, self).__init__(component_name=component_name,
                                                                 worker_index=worker_index,
                                                                 **kwargs)

    def update_policy(self, full_policy_revision, **kwargs):
        self.call("/enforcement/policy", method="POST", json=full_policy_revision, **kwargs)

    def update_inventory_change(self, **kwargs):
        self.call("/enforcement/inventory_change", method="GET", **kwargs)


class EnforcementWorkerControlClient(BaseEnforcementWorkerControlClient):
    def __init__(self, component_name=AggregatorComponent.EnforcementServer, worker_index=0, **kwargs):
        super(EnforcementWorkerControlClient, self).__init__(component_name=component_name,
                                                             worker_index=worker_index,
                                                             **kwargs)

    def update_blocklist(self, blocklist, **kwargs):
        self.call("/enforcement/blocklist", method="POST", json=blocklist, **kwargs)

    def update_blocklist_status(self, status, **kwargs):
        self.call("/enforcement/blocklist_status", method="POST", json=status, **kwargs)

    def traffic_encryption_status(self, status, **kwargs):
        self.call('/enforcement/traffic_encryption_status', method="POST", json=status, **kwargs)

    def update_off_corp_config(self, status, **kwargs):
        self.call("/enforcement/off_corp_status", method="POST", json=status, **kwargs)

    def update_fast_policy_config(self, status, **kwargs):
        self.call("/enforcement/fast_policy_config", method="POST", json=status, **kwargs)

    def update_usergroup_config(self, config, **kwargs):
        self.call("/enforcement/usergroups_config_update", method="POST", json=config, **kwargs)

    def update_usergroup_mapping(self, mapping, **kwargs):
        self.call("/enforcement/usergroup_mapping_update", method="POST", json=mapping, **kwargs)


class GrpcEnforcementWorkerControlClient(BaseEnforcementWorkerControlClient):
    def __init__(self, component_name=AggregatorComponent.EnforcementServer, worker_index=0, **kwargs):
        super(GrpcEnforcementWorkerControlClient, self).__init__(component_name=component_name,
                                                                 worker_index=worker_index,
                                                                 **kwargs)

    @staticmethod
    def update_blocklist(blocklist, **kwargs):
        LOGGER.debug("Updating blocklist is unsupported for gRPC enforcement worker, skipping")

    @staticmethod
    def update_blocklist_status(status, **kwargs):
        LOGGER.debug("Updating blocklist status is unsupported for gRPC enforcement worker, skipping")

    @staticmethod
    def update_off_corp_config(status, **kwargs):
        LOGGER.debug("Updating off corporate config is unsupported for gRPC enforcement worker, skipping")

    @staticmethod
    def update_fast_policy_config(status, **kwargs):
        LOGGER.debug("Updating fast policy config is unsupported for gRPC enforcement worker, skipping")

    def set_k8s_agent_configuration(self, configuration, **kwargs):
        self.call("/enforcement/k8s/set_agent_configuration", method="POST", json=configuration, **kwargs)

    @staticmethod
    def update_usergroup_mapping(mapping, **kwargs):
        LOGGER.debug("Updating usergroup mapping is unsupported for GRPC agents, skipping")

    @staticmethod
    def update_usergroup_config(config, **kwargs):
        LOGGER.debug("Updating usergroup mapping config is unsupported for GRPC agents, skipping")

    @staticmethod
    def traffic_encryption_status(self, status, **kwargs):
        LOGGER.debug("Updating traffic_encryption_status is unsupported for gRPC enforcement worker, skipping")
