import enum


class ResourceLimitationSuit(enum.Enum):
    Low = 'LOW'
    Medium = 'MEDIUM'
    High = 'HIGH'
    Unset = 'UNKNOWN'


class ResourcesOverrides(enum.Enum):
    CpuSoft = 'cpu-soft'
    CpuHard = 'cpu-hard'
    MemorySoft = 'memory-soft'
    MemoryHard = 'memory-hard'
    IO = 'io'


class AgentModule(enum.Enum):
    Reveal = 'reveal'
    RevealChannel = 'reveal-channel'
    Enforcement = 'enforcement'
    EnforcementChannel = 'enforcement-channel'
    Deception = 'deception'
    Detection = 'detection'
    Controller = 'controller'
    Unset = 'unknown'


class ContainerMode(enum.Enum):
    Unset = 0
    Off = 1
    Native = 2


class NatMode(enum.Enum):
    Unset = 0
    Off = 1
    On = 2


class LinkLocalTrafficReportingMode(enum.Enum):
    AllowTraffic = 0
    BlockTraffic = 1
    ReportAddresses = 2
