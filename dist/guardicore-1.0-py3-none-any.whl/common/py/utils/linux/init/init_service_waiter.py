
import time
import eventlet
from eventlet import Timeout

from common.logger import get_logger
from common.py.model.exceptions import GuardicoreException
from common.py.utils.linux.init.model import InitServiceStatus, InitServiceEvent

LOG = get_logger(module_name=__name__)


class InitWaiterException(GuardicoreException):
    pass


class InitServiceWaiter(object):
    EXPECTED_STATE = {
        InitServiceEvent.START: InitServiceStatus.RUNNING,
        InitServiceEvent.STOP: InitServiceStatus.STOPPED
    }
    MAX_TIME_UNKNOWN_STATE = 300  # 5 min

    def __init__(self, init_service, service_event, timeout=None, check_interval=20.0, reload_connection=False):
        assert isinstance(service_event, InitServiceEvent)

        self._init_service = init_service
        self._service_event = service_event
        self._timeout = timeout
        self._check_interval = check_interval
        self._reload_connection = reload_connection

    def get_status(self):
        return self._init_service.get_status()

    def wait(self):
        LOG.info("Waiting for service '%s' to %s", self._init_service.service_name, self._service_event.name.lower())
        try:
            with Timeout(seconds=self._timeout):
                expected_state = self.EXPECTED_STATE[self._service_event]
                service_state = last_service_state = self.get_status()
                start_time_in_status = time.time()
                while service_state != expected_state:
                    eventlet.sleep(self._check_interval)
                    service_state = self.get_status()
                    if service_state != last_service_state:
                        LOG.info("Service '%s' state changed %s-->%s", self._init_service.service_name,
                                 last_service_state, service_state)
                        last_service_state = service_state
                        start_time_in_status = time.time()

                    # GC-27598: DBus connection might get lost and we need to reload it
                    elif self._reload_connection and service_state == InitServiceStatus.UNKNOWN and \
                            (time.time() - start_time_in_status) > self.MAX_TIME_UNKNOWN_STATE:
                        start_time_in_status = time.time()
                        self._init_service.reload_connection()

                LOG.info("Service '%s' moved to state %s", self._init_service.service_name, expected_state.name.lower())

        except Timeout:
            LOG.warning("Timed out waiting for service '%s' %s", self._init_service.service_name,
                        self._service_event.name.lower())
            raise InitWaiterException('Timed out waiting for service')
