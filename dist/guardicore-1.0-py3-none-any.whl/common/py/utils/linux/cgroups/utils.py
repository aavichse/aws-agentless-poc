#! /usr/bin/env python
# -*- coding:utf-8 -*-

from __future__ import unicode_literals
from __future__ import print_function

import os
import getpass

BASE_CGROUPS_DIR = '/sys/fs/cgroup'
CGROUPS_DIRS = [
    'cpu',
    'memory',
]


def get_user_cgroups():
    user = getpass.getuser()
    user_cgroups = {}
    for cgroup in CGROUPS_DIRS:
        user_cgroup = os.path.join(BASE_CGROUPS_DIR, cgroup, user)
        # if not os.path.exists(user_cgroup):
        #     os.mkdir(user_cgroup)
        user_cgroups[cgroup] = user_cgroup
    return user_cgroups


def get_process_cgroups(pid, tasks=True):
    try:
        cgroup_info = [line.strip().split(":")
                       for line in open("/proc/%d/cgroup" % (pid, ))]
    except IOError:
        return {}

    process_cgroups = {}
    for index, cgroup_hierarchy, cgroup_path in cgroup_info:
        cgroup_path = cgroup_path.strip()

        if tasks:
            process_cgroups[cgroup_hierarchy] = os.path.join(BASE_CGROUPS_DIR, cgroup_hierarchy,
                                                             cgroup_path[1:], "tasks")
        else:
            process_cgroups[cgroup_hierarchy] = cgroup_path

    return process_cgroups