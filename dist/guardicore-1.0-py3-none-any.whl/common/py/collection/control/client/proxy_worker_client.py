from common.py.collection.control.client.component_client import AggregatorComponentControlClient
from common.py.model.aggregator import AggregatorComponent
from common.logger import get_logger

LOG = get_logger(module_name=__name__)


class ProxyWorkerControlClient(AggregatorComponentControlClient):
    def __init__(
            self,
            component_name=AggregatorComponent.ProxyServer,
            worker_index=0,
            **kwargs
    ):
        super().__init__(component_name=component_name, worker_index=worker_index, **kwargs)

    def _update_integration_config(self, integration_type, config, *args, **kwargs):
        return self.call("/cloud-proxy/integration_config", method="POST", json=[integration_type, config], *args, **kwargs)
