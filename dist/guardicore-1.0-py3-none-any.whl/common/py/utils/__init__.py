"""
Created on Jul 16, 2014

@author: itamar
"""

import re
import os
from pprint import pprint

try:
    from StringIO import StringIO
except ImportError:
    from io import StringIO


def pprint_string(obj):
    pprint_str = StringIO()
    pprint(obj, pprint_str)
    pprint_str.seek(0)
    return pprint_str.read().rstrip()


def first(seq):
    return seq[0]


PYTHON_EXT_RE = re.compile(r"^[.]pyo|.[.]py|[.]pyc$")
PYTHON_INIT_FILES = {"__init__.py", "__init__.pyc", "__init__.pyo"}

join, isdir = os.path.join, os.path.isdir


def is_python_file(filename):
    return PYTHON_EXT_RE.match(filename[-4:]) is not None


def is_init_file(filename):
    return filename in PYTHON_INIT_FILES


def to_relpath_file_module(relpath, filename):
    module_name = '.'.join([relpath, filename]) if relpath != '.' else filename
    return os.path.splitext(module_name)[0]


def to_module(path):
    return path.replace('\\', '.').replace('/', '.')


def safe_modules_walk(top):
    names = os.listdir(top)

    files = []
    found_init_file = False
    for name in names:
        new_path = join(top, name)
        if is_python_file(name):
            if is_init_file(name):
                found_init_file = True
            files.append(name)
        elif isdir(new_path):
            for x in safe_modules_walk(new_path):
                yield x
    if not found_init_file:
        return

    yield top, files


def find_modules(path, ignore_modules=None, include_directories=False, include_package_modules=False,
                 with_file_name=False):
    """
    Returns a set of importable python module names under a specific path.

    :param path:
    :param ignore_modules:
    :param include_directories: Should we also include directories as modules
    :param include_package_modules: Should we include __init__ package modules
    :param with_file_name: if True, return modules list in a form of [(filename, module_name), ...]
    """
    modules = set()

    if ignore_modules is None:
        ignore_modules = set()

    for dirpath, filenames in safe_modules_walk(path):
        relpath_dir_module = to_module(os.path.relpath(dirpath, path))
        if include_directories and relpath_dir_module != '.':
            modules.add(relpath_dir_module)

        for filename in filenames:
            module_name = filename

            # check for duplicates of py and pyo's, ignore the pyo
            if (filename[-1] == "o") and (filename[:-1] in filenames):
                continue

            elif is_init_file(filename):
                if not include_package_modules:
                    continue
                module_name = "."

            module_name = to_relpath_file_module(relpath_dir_module, module_name).rstrip(".")

            if with_file_name:
                modules.add((os.path.join(dirpath, filename), module_name))
            else:
                modules.add(module_name)

    modules -= ignore_modules
    return modules
