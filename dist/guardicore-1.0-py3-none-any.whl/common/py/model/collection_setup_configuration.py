import json
import logging
import pprint

import time

from common.logger import get_logger
from common.py.model.aggregator import AggregatorTypes, AggregatorCategory, AggregatorFeatures
from common.py.model.exceptions import GuardicoreException
from common.py.utils.setup_wizard.consts import SETUP_CONFIGURATION_PATH

LOG = get_logger(module_name=__name__)


class InvalidSetupConfiguration(GuardicoreException):
    pass


class SetupConfiguration(object):
    AGGREGATOR_ONLY_FEATURES = (AggregatorFeatures.AgentsLoadBalancer,
                                AggregatorFeatures.DeceptionAgentsServer,
                                AggregatorFeatures.DetectionAgentsServer,
                                AggregatorFeatures.RevealAgentsServer,
                                AggregatorFeatures.EnforcementAgentsServer)
    COLLECTOR_ONLY_FEATURES = (AggregatorFeatures.RevealDatapathVisibility, )
    
    def __init__(self, path=SETUP_CONFIGURATION_PATH, load=False, validate=False):
        self.path = path

        self.configuration = None

        if load:
            self.reload(validate=validate)

    def __repr__(self):
        return "<%s path='%s' %s>" % (self.__class__.__name__, self.path, "loaded" if self.loaded else "empty")

    def __getitem__(self, item):
        return self.configuration[item]

    def __setitem__(self, key, value):
        self.configuration[key] = value

    def __contains__(self, item):
        return item in self.configuration

    def __len__(self):
        return len(self.configuration)
    
    def get(self, item, default=None):
        return self.configuration.get(item, default)

    @property
    def loaded(self):
        return self.configuration is not None

    def reload(self, verbose=False, validate=False):
        try:
            with open(self.path, "r") as fp:
                conf_data = fp.read()
        except (IOError, OSError)as exc:
            raise InvalidSetupConfiguration("Error loading setup configuration file '%s': %s", self.path, exc)

        try:
            conf = json.loads(conf_data)
        except ValueError as exc:
            raise InvalidSetupConfiguration("Invalid setup configuration file '%s' JSON format (%s):\n%r", self.path, exc,
                                            conf_data)

        if not isinstance(conf, dict):
            raise InvalidSetupConfiguration("Invalid setup configuration file '%s' type (expected dict): %s", self.path, conf)

        self.configuration = conf

        if validate:
            self.validate()

        if verbose:
            LOG.debug("Loaded setup configuration file from '%s'")
            self.pretty_print(log_level=logging.DEBUG)

    def validate(self):
        assert self.loaded, "Setup configuration must be loaded before validation"

        self._validate_roles()

    def save(self, indent=4, separators=(',', ': '), sort_keys=True, path=None):
        assert self.loaded, "Need to reload() first to save"

        path = path or self.path

        self.configuration['conf_source'] = "Auto-generated (%s) onto path '%s'" % (time.ctime(), path)

        try:
            with open(path, "w") as fp:
                json.dump(self.configuration, fp, indent=indent, separators=separators, sort_keys=sort_keys)
        except (IOError, OSError)as exc:
            raise GuardicoreException("Error saving setup configuration file '%s': %s", path, exc)

    def pretty_print(self, log_level=logging.INFO):
        assert self.loaded, "Need to reload() first to pretty print"

        LOG.log(log_level, "Setup configuration:\n%s", pprint.pformat(self.configuration))

    @property
    def aggregator_type(self):
        assert self.loaded, "Need to reload() first to use property"

        component_mode = self.configuration.get('component_mode')
        if not component_mode:
            raise InvalidSetupConfiguration("Missing 'component_mode' in setup config: %s", self.path)

        aggregator_type = getattr(AggregatorTypes, component_mode, None)
        if not aggregator_type:
            raise InvalidSetupConfiguration("Invalid 'component_mode' in setup config '%s': %s", self.path, component_mode)

        return aggregator_type

    @property
    def supported_features(self):
        supported_features = self.configuration.get('supported_features', None)
        if not supported_features:
            return set()

        features = {getattr(AggregatorFeatures, feature, None) for feature in supported_features}
        if None in features:
            raise InvalidSetupConfiguration("Invalid value in 'supported_features': %s", supported_features)

        return features

    @property
    def aggregator_category(self):
        return self.aggregator_type.value.category

    @property
    def is_aggregator(self):
        return self.aggregator_category == AggregatorCategory.Aggregator

    @property
    def is_collector(self):
        return self.aggregator_category == AggregatorCategory.Collector

    def _validate_roles(self):
        """
        Validate conflicting features and aggregator categories. Raise InvalidSetupConfiguration in case
        of a conflict.
        """

        aggregator_category = self.aggregator_category
        supported_features = self.supported_features
        if aggregator_category in (AggregatorCategory.Collector, AggregatorCategory.Other):
            for feature in self.AGGREGATOR_ONLY_FEATURES:
                if feature in supported_features:
                    raise InvalidSetupConfiguration("Aggregator-only feature '%s' can't be configured for %s",
                                                    feature.value.title, aggregator_category.name)

        if aggregator_category in (AggregatorCategory.Aggregator, AggregatorCategory.Other):
            for feature in self.COLLECTOR_ONLY_FEATURES:
                if feature in supported_features:
                    raise InvalidSetupConfiguration("Collector-only feature '%s' can't be configured for %s",
                                                    feature.value.title, aggregator_category.name)
