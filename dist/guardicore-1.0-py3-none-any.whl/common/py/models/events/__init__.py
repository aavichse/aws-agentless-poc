import hashlib
import uuid
from enum import IntEnum

from common.py.utils.enum_utils import TransformableEnum

__author__ = 'Eddie'


class EventType(IntEnum):
    DatapathRedirectEvent = 1
    HoneypotRedirectEvent = 2
    HoneypotSecurityEvent = 3
    HoneypotSecurityNetworkEvent = 4
    SystemEvent = 5
    DatapathScanDetectionEvent = 6
    DatapathCrashEvent = 7
    HoneypotSystemEvent = 8


class EventSeverity(IntEnum):
    High = 50
    Medium = 40
    Low = 30
    All = 0

    @classmethod
    def get_non_empty_severity_names(cls):
        return [severity.name for severity in EventSeverity if severity != EventSeverity.All]


class EventStatus(IntEnum):
    COMPLETED = 5
    INFO = 10
    WARNING = 30
    ERROR = 40
    SUCCESS = 50  # deprecated


class AgentEventSeverity(IntEnum):
    DEBUG = 5
    INFO = 10
    WARNING = 30
    ERROR = 40


class ProtocolType(TransformableEnum):
    # TODO: merge with IPProtocol in common/py/events and STOP CREATING NEW ENUMS TO DESCRIBE THIS FFS!
    TCP = 1
    UDP = 2
    ICMP = 3


def get_exception_part(description):
    exception_text = ''
    description_lines = description.splitlines()

    if description_lines:
        exception_text = description_lines[-1]

    return exception_text.split(':')[0]


def get_files_part(description):
    return list(filter(lambda line: line.strip().startswith('File'), description.splitlines()))


# placed here because is used by common exporter also. (common.py.data_export.exporter.SystemAlertExporterMixin)
def get_error_code(description, aggregate_by_uuid=None):
    if aggregate_by_uuid:
        error_code_component = [aggregate_by_uuid]
    else:
        error_code_component = get_files_part(description)
        error_code_component.append(get_exception_part(description))

    return str(uuid.UUID(hashlib.md5(''.join(error_code_component).encode('utf-8')).hexdigest()))
