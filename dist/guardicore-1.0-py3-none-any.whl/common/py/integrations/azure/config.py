from common.py.utils.config import cfg
from common.py.utils.config.oslo_config import types

azure_cloud_app_opts = [
    cfg.StrOpt('name', help="cloud app name", required=True),
    cfg.StrOpt('cloud_app_type', required=True, help="CloudApp type"),
    cfg.StrOpt('orchestration_id', required=True, help="corrolating orchestration id for inventory reports"),
    cfg.StrOpt('manifest', required=True, help="Encoded azure CloudApp manifest data"),
    cfg.StrOpt('operation_mode', required=True, help="reveal/enforcement_and_reveal"),
    cfg.StrOpt('cluster_id', required=True, help="Centra cluster ID that handles the CloudApp"),
    cfg.StrOpt('api_version', default=None, help="CloudApp api version"),
    cfg.BoolOpt('auto_discover_subscriptions', default=False),
    cfg.StrOpt('coverage_mode'),
    cfg.Opt(name='subscription_list',
            type=types.List(item_type=types.String(quotes=True), bounds=True),
            default=[], help="list of monitored subscriptions"),
    cfg.Opt(name='management_group_list',
            type=types.List(item_type=types.String(quotes=True), bounds=True),
            default=[], help="list of monitored management groups")
]