from aggregator.services.enforcement.plugins.policy.model import PolicyRevisionAndInventory
from common.py.collection.control.client.component_client import AggregatorComponentControlClient
from common.py.collection.control.client import ControlClientError
from common.py.events.visibility.enforcement_policy import EnforcementPolicy
from common.py.model.aggregator import AggregatorComponent
from common.logger import get_logger


LOG = get_logger(module_name=__name__)


class EnforcementServerControlClient(AggregatorComponentControlClient):
    def __init__(self, component_name=AggregatorComponent.EnforcementServer, **kwargs):
        super(EnforcementServerControlClient, self).__init__(component_name=component_name, **kwargs)

    def get_policy_revisions(self):
        policy_revisions = self.call("/enforcement/policy/revisions", method="GET")
        if not policy_revisions:
            return None

        return PolicyRevisionAndInventory.from_json(policy_revisions)

    def get_policy_rules(self):
        policy = self.call("/enforcement/policy/rules", method="GET")
        if not policy:
            return None

        return EnforcementPolicy.from_json(policy)

    def get_system_configuration(self):
        try:
            return self.call_with_reconnect("/enforcement/system_configuration", method="GET")
        except (ControlClientError, UnicodeDecodeError) as exc:
            LOG.exception("Failed to get system configuration")
        return {}

    def send_alive_agents(self, agents):
        if agents is None:
            agents = []

        LOG.debug("Send alive agents to enforcement master %s", agents)
        try:
            self.call_with_reconnect(uri='/enforcement/send_agent_alive', method='POST', json=agents)
        except (ControlClientError, UnicodeDecodeError) as exc:
            LOG.exception("Failed to send alive agents - %s", exc)

    def get_agents_configuration(self, *agent_types):
        try:
            return self.call_with_reconnect(uri='/enforcement/get_agents_configuration',
                                            method='GET', json=agent_types)
        except (ControlClientError, UnicodeDecodeError) as exc:
            LOG.exception("Failed to get agents configuration - %s", exc)
        return {}

    def report_agents_config_update_results(self, update_results):
        self.call_with_reconnect(uri='/enforcement/report_update_results', method='POST', json=update_results)

    def send_k8s_agent_status(self, status):
        self.call_with_reconnect(uri='/enforcement/k8s/send_agent_status', method='POST', json=status)

    def notify_dcinventory_update(self, revision):
        self.call_with_reconnect(uri='/enforcement/dcinventory_update_notification', method='POST', json=revision)

    def notify_policy_manager_failure(self, is_failure, command):
        try:
            self.call_with_reconnect(uri='/enforcement/policy/failure', method='POST',
                                     json={'is_failure': is_failure, 'command': command})
        except Exception as exc:
            LOG.exception("Error during notification about policy manager failure/clear failure")

    def get_traffic_encryption_status(self):
        try:
            return self.call_with_reconnect(uri='/enforcement/traffic_encryption_status', method='GET', )
        except Exception:
            LOG.exception("Error during traffic_encryption_status fetch failure")