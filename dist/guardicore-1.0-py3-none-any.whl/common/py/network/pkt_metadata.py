
import struct
from common.logger import get_logger

__author__ = 'itamar'

LOG = get_logger(module_name=__name__)


class PacketMetaInfo(object):
    # Ethernet types in struct representation
    ETHERNET_TYPE_ARP = "\x08\x06"
    ETHERNET_TYPE_IPV4 = "\x08\0"
    ETHERNET_TYPE_IPV6 = "\x86\xDD"
    ETHERNET_TYPE_8021Q = "\x81\0"
    IPPROTO_TCP = "\x06"
    IPPROTO_UDP = "\x11"
    IPPROTO_ICMP = "\x01"

    def __init__(self, ethernet_type, tag, ip_header_offset, ip_proto, transport_header_offset, src_ip=None, dst_ip=None, src_port=None, dst_port=None):
        self.ethernet_type = ethernet_type
        self.tag = tag
        self.ip_header_offset = ip_header_offset
        self.ip_proto = ip_proto
        self.transport_header_offset = transport_header_offset
        self.src_ip = src_ip
        self.dst_ip = dst_ip
        self.src_port = src_port
        self.dst_port = dst_port
        self._is_tagged = (None != self.tag)
        self._is_ipv4 = (PacketMetaInfo.ETHERNET_TYPE_IPV4 == self.ethernet_type)

    def is_tagged(self):
        return self._is_tagged

    def is_ipv4(self):
        return self._is_ipv4

    def is_tcp(self):
        return (PacketMetaInfo.IPPROTO_TCP == self.ip_proto)

    def is_udp(self):
        return (PacketMetaInfo.IPPROTO_UDP == self.ip_proto)

    def is_icmp(self):
        return (PacketMetaInfo.IPPROTO_ICMP == self.ip_proto)


def extract_pkt_meta_info(pkt):
    pkt_len = len(pkt)
    if pkt_len < 14:
        LOG.warn("Ethernet packet too small (length = %d): %r",
                 pkt_len, pkt)
        return None

    ethernet_type = pkt[12:14]
    if PacketMetaInfo.ETHERNET_TYPE_8021Q == ethernet_type: # tagged traffic
        ethernet_type = pkt[16:18]
        ip_header_offset = 18
        tag = struct.unpack(">H", pkt[14:16])[0]
    else:
        ip_header_offset = 14
        tag = None

    if pkt_len < (ip_header_offset + 20):
        LOG.warn("IP packet too small (length = %d): %r",
                 pkt_len, pkt)
        return None

    transport_header_offset = ip_header_offset + 20
    ip_proto = pkt[ip_header_offset + 9]
    src_ip = pkt[ip_header_offset + 12:ip_header_offset + 16]
    dst_ip = pkt[ip_header_offset + 16:ip_header_offset + 20]

    if ip_proto in (PacketMetaInfo.IPPROTO_TCP, PacketMetaInfo.IPPROTO_UDP):
        src_port = pkt[transport_header_offset:transport_header_offset + 2]
        dst_port = pkt[transport_header_offset + 2:transport_header_offset + 4]
    else:
        src_port = None
        dst_port = None

    return PacketMetaInfo(ethernet_type, tag, ip_header_offset, ip_proto,
                          transport_header_offset, src_ip, dst_ip, src_port,
                          dst_port)