import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))

import argparse
from management.configuration import cfg

CONF_PROJECT_NAME = "guardicore"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('option', action='store', type=str, help='Configuration option to fetch')
    args = parser.parse_args()

    try:
        section_name, option_name = args.option.split('.')
    except ValueError:
        sys.stderr.write('Error: option expected in format <section_name.option_name>\n')
        return 1

    sys.argv = sys.argv[:1]

    cfg.CONF(project=CONF_PROJECT_NAME)

    try:
        section = getattr(cfg.CONF, section_name)
    except AttributeError:
        sys.stderr.write('Error: section "%s" not found\n' % section_name)
        return 1

    try:
        value = getattr(section, option_name)
    except AttributeError:
        sys.stderr.write('Error: option "%s" not found in section "%s"\n' % (option_name, section_name))
        return 1

    sys.stdout.write("%s" % value)
    return 0

if __name__ == '__main__':
    sys.exit(main())
