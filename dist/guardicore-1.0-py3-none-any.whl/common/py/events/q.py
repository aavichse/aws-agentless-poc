from enum import IntEnum

# Q answer origins:
# QClient: The answer directly originated from the Q client, such as an error message or a white list.
# QClientCache: The answer was cached because it had arrived from the Q server at a previous time.
# QServerCache: The answer arrived from the Q server right now, and it was cached there.
# QServer: The answer arrived from the Q server right now, but not via its cache - the actual Q service had run.
# QClientBlacklist: The answer is a blacklist answer originating from the Q client.

QAnswerOrigin = IntEnum('QAnswerOrigin', ('QClient', 'QClientCache', 'QServerCache', 'QServer', 'QClientBlacklist'))
