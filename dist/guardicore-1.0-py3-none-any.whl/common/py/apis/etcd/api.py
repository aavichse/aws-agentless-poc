import base64
import json
import requests
import time
from http import HTTPStatus
from requests.exceptions import HTTPError
from six import raise_from

from common.logger import get_logger

LOG = get_logger(module_name=__name__)

def _b64encode(value):
    return base64.b64encode(value.encode()).decode()

def _b64decode(value):
    return base64.b64decode(value).decode()

class EtcdResponseError(RuntimeError):
    pass

class EtcdTimeoutError(TimeoutError):
    pass

class EtcdWatchEvents(list):
    def __init__(self, latest_revision):
        self.latest_revision = latest_revision

class EtcdWatchPut:
    def __init__(self, key, value, revision):
        self.key = key
        self.value = value
        self.revision = revision

class EtcdWatchDelete:
    def __init__(self, key, revision):
        self.key = key
        self.revision = revision

class EtcdPutRequest:
    def __init__(self, key, value=None, lease=None):
        self.key = key
        self.value = value
        self.lease = lease

    def to_json(self):
        put_request = {'key': _b64encode(self.key)}
        if self.value is not None:
            put_request['value'] = _b64encode(self.value)
        if self.lease is not None:
            put_request['lease'] = self.lease

        return put_request

    def to_compare_json(self):
        compare = {'target': 'VALUE',
                   'key': _b64encode(self.key)}
        if self.value is not None:
            compare['value'] = _b64encode(self.value)

        return compare

class EtcdAPI:
    # API reference: https://etcd.io/docs/v3.5/dev-guide/api_reference_v3/
    # RPC endpoints reference: https://etcd.io/docs/v3.5/dev-guide/apispec/swagger/rpc.swagger.json
    _ENDPOINT_AUTH = '/v3/auth/authenticate'
    _ENDPOINT_KV_RANGE = '/v3/kv/range'
    _ENDPOINT_KV_PUT = '/v3/kv/put'
    _ENDPOINT_KV_TXN = '/v3/kv/txn'
    _ENDPOINT_WATCH = '/v3/watch'
    _ENDPOINT_LEASE_GRANT = '/v3/lease/grant'
    _ENDPOINT_LEASE_KEEPALIVE = '/v3/lease/keepalive'
    _ENDPOINT_LEASE_REVOKE = '/v3/lease/revoke'
    _ENDPOINT_DEFRAG = '/v3/maintenance/defragment'

    _REQUEST_TIMEOUT = 10
    _REQUEST_TIMEOUT_STREAM = 300  # 5 minutes

    MAX_TXN_OPS = 2048

    def __init__(self, url, username, password):
        self._url = url
        self._auth_params = {'name': username, 'password': password}
        self._auth_headers = None

    def _auth_etcd(self):
        LOG.debug('Authenticating with etcd. Username: %s', self._auth_params['name'])

        r = requests.post(self._url + self._ENDPOINT_AUTH, json=self._auth_params, timeout=self._REQUEST_TIMEOUT)
        r.raise_for_status()
        result = r.json()

        if 'token' not in result:
            raise ValueError('Got unexpected result from etcd when authenticating: {result}'.format(result=result))

        self._auth_headers = {'Authorization': result['token']}

    def _request_etcd(self, endpoint, json_args, timeout, stream=False, force_auth=False):
        if self._auth_headers is None or force_auth:
            self._auth_etcd()
            authed_now = True
        else:
            authed_now = False

        LOG.debug('Calling etcd (authed_now=%s): %s', authed_now, endpoint)
        start_time = time.time()
        r = requests.post(self._url + endpoint, json=json_args, timeout=timeout, stream=stream, headers=self._auth_headers)
        end_time = time.time()
        LOG.debug('etcd call took %s seconds: %s', end_time - start_time, endpoint)

        if not authed_now and r.status_code in (HTTPStatus.BAD_REQUEST, HTTPStatus.UNAUTHORIZED):
            LOG.debug('etcd call failed with status {status_code}, probably stale token'.format(status_code=r.status_code))

            # Reauthenticate and try again
            r.close()
            self._auth_headers = None
            return self._request_etcd(endpoint, json_args, timeout, stream)

        r.raise_for_status()
        return r

    def _call_etcd(self, endpoint, **kwargs):
        try:
            r = self._request_etcd(endpoint=endpoint, json_args=kwargs, timeout=self._REQUEST_TIMEOUT, stream=False, force_auth=False)
            return r.json()
        except requests.exceptions.Timeout as e:
            raise_from(EtcdTimeoutError('etcd request timed out.'), e)
        except requests.exceptions.RequestException as e:
            raise_from(EtcdResponseError('etcd request error.'), e)

    def _call_etcd_stream(self, endpoint, **kwargs):
        try:
            # Streams are long-running so we're likely to have an incorrect token if we restart the stream
            # To be sure, just force auth before starting the watch stream
            r = self._request_etcd(endpoint=endpoint, json_args=kwargs, timeout=self._REQUEST_TIMEOUT_STREAM, stream=True, force_auth=True)
            for line in r.iter_lines():
                yield json.loads(line)
        except requests.exceptions.Timeout as e:
            raise_from(EtcdTimeoutError('etcd stream timed out.'), e)
        except requests.exceptions.RequestException as e:
            raise_from(EtcdResponseError('etcd stream error.'), e)

    @staticmethod
    def _get_kv_from_range_response(range_response):
        if 'count' not in range_response or 'kvs' not in range_response:
            # Nothing found
            return None

        if int(range_response['count']) != 1 or len(range_response['kvs']) != 1:
            # Bad response
            raise EtcdResponseError('Unexpected range response: {range_response}'.format(range_response=range_response))

        kv = range_response['kvs'][0]

        # kv must have at least a key
        if 'key' not in kv:
            raise EtcdResponseError('Unexpected range response kv: {kv}'.format(kv=kv))

        return kv

    def _get_key(self, key):
        """
        Get the data associated with the given key.
        Returns None if the key is not found.
        """

        range_response = self._call_etcd(self._ENDPOINT_KV_RANGE, key=_b64encode(key))
        return self._get_kv_from_range_response(range_response)

    def _txn_get_keys(self, keys):
        """
        Get the data associated with given keys.
        Returns a dictionary of {key: data} containing all keys, but each `data` may be None if the key is not found.
        Raises a ValueError exception if len(keys) > MAX_TXN_OPS.
        """

        result = {key: None for key in keys}  # Prepare result dictionary and de-duplicate at the same time
        if len(result) > self.MAX_TXN_OPS:
            raise ValueError('Cannot query more than {max_txn_ops} in one transaction.'.format(max_txn_ops=self.MAX_TXN_OPS))

        success = [{'request_range': {'key': _b64encode(key)}} for key in result.keys()]
        txn_response = self._call_etcd(self._ENDPOINT_KV_TXN, success=success)

        for response in txn_response.get('responses', []):
            kv = self._get_kv_from_range_response(response.get('response_range', {}))
            if kv is not None:
                result[_b64decode(kv['key'])] = kv

        return result

    def _batch_get_keys(self, keys):
        """
        Get the data associated with given keys.
        Returns a dictionary of {key: data} containing all keys, but each `data` may be None if the key is not found.
        """

        result = {}
        keys = list(set(keys))
        while keys:
            result.update(self._txn_get_keys(keys[:self.MAX_TXN_OPS]))
            keys = keys[self.MAX_TXN_OPS:]

        return result

    def get_value(self, key):
        """
        Get the value associated with the given key.
        Returns None if the key is not found or has no value.
        """

        kv = self._get_key(key)
        if kv is None or 'value' not in kv:
            return None

        return _b64decode(kv['value'])

    @classmethod
    def _prefix_range_end(cls, prefix):
        if not prefix.endswith('/'):
            raise ValueError('Currently only prefixes ending with / are supported.')

        # From the etcd documentation:
        #   By convention, ranges for a request are denoted by the fields key and range_end.
        #   The key field is the first key of the range and should be non-empty.
        #   The range_end is the key following the last key of the range.
        #   If range_end is not given or empty, the range is defined to contain only the key argument.
        #   If range_end is key plus one (e.g., "aa"+1 == "ab", "a\xff"+1 == "b"), then the range represents
        #   all keys prefixed with key.
        #   If both key and range_end are '\0', then range represents all keys.
        #   If range_end is '\0', the range is all keys greater than or equal to the key argument.
        #
        # If we only allow prefixes that end with '/', we can simply replace this '/' with a '0' (the next
        # character after '/' by ASCII code).
        return prefix[:-1] + '0'

    def get_values(self, prefix):
        """
        Get the values for all keys with a given key prefix.
        In the current client implementation, `prefix` must end with '/'.
        Returns (kvrs, revision), where kvrs = list of (key, value, revision) (may be an empty list if no key is found).
        Each `value` is optional and may be None.
        """

        range_response = self._call_etcd(self._ENDPOINT_KV_RANGE,
                                         key=_b64encode(prefix),
                                         range_end=_b64encode(self._prefix_range_end(prefix)))

        if 'header' not in range_response or 'revision' not in range_response['header']:
            raise EtcdResponseError('Bad range response: {range_response}'.format(range_response=range_response))

        overall_revision = int(range_response['header']['revision'])
        kvs = range_response.get('kvs', [])
        count = int(range_response.get('count', 0))

        if len(kvs) != count:
            raise EtcdResponseError('kv count mismatch: Got {len_kvs}, expected {count}'.format(len_kvs=len(kvs), count=count))

        kvrs = []
        for kv in kvs:
            if 'key' not in kv or 'mod_revision' not in kv:
                raise EtcdResponseError('Missing key/revision in kv: {kv}'.format(kv=kv))

            key = _b64decode(kv['key'])
            value = _b64decode(kv['value']) if 'value' in kv else None
            item_revision = int(kv['mod_revision'])
            kvrs.append((key, value, item_revision))

        return kvrs, overall_revision

    def watch(self, prefix, start_revision):
        """
        Watches for changes under `prefix`.
        In the current client implementation, `prefix` must end with '/'.
        Generator that yields EtcdWatchEvents objects.
        Raises a TimeoutError when there are no events for a while.
        """

        create_request = {
            'key': _b64encode(prefix),
            'range_end': _b64encode(self._prefix_range_end(prefix)),
            'start_revision': start_revision,
            'progress_notify': True,
            'fragment': False
        }

        for events_json in self._call_etcd_stream(self._ENDPOINT_WATCH, create_request=create_request):
            LOG.debug('Watch: Got events json: {events_json}'.format(events_json=events_json))

            if events_json.get('canceled'):
                raise EtcdResponseError('Watch stream canceled: {events_json}'.format(events_json=events_json))

            if 'result' not in events_json:
                raise EtcdResponseError('Unexpected watch events json (no result): {events_json}'.format(events_json=events_json))

            result = events_json['result']
            if 'header' not in result:
                raise EtcdResponseError('Unexpected watch events json (no header): {events_json}'.format(events_json=events_json))
            
            header = result['header']
            if 'revision' not in header:
                raise EtcdResponseError('Unexpected watch events json (no revision): {events_json}'.format(events_json=events_json))

            etcd_watch_events = EtcdWatchEvents(latest_revision=int(header['revision']))

            events = result.get('events', [])
            for event in events:
                if 'kv' not in event:
                    raise EtcdResponseError('Unexpected watch event (no kv): {event}'.format(event=event))
                
                kv = event['kv']
                if 'key' not in kv or 'mod_revision' not in kv:
                    raise EtcdResponseError('Unexpected watch event (missing key/revision): {event}'.format(event=event))

                key = _b64decode(kv['key'])
                value = _b64decode(kv['value']) if 'value' in kv else None
                revision = int(kv['mod_revision'])

                if event.get('type') == 'DELETE':
                    etcd_watch_events.append(EtcdWatchDelete(key, revision))
                else:
                    etcd_watch_events.append(EtcdWatchPut(key, value, revision))
            
            yield etcd_watch_events

    def get_lease(self, key):
        """
        Get the lease associated with the given key.
        Returns None if the key is not found or has no lease.
        """

        kv = self._get_key(key)
        if kv is None or 'lease' not in kv:
            return None

        return int(kv['lease'])

    def get_leases(self, keys):
        """
        Get the leases associated with the given keys.
        Returns a dictionary of {key: lease} containing all keys, but each `lease` may be None if the key is not found.
        """

        kvs = self._batch_get_keys(keys)
        return {key: int(kv['lease']) if kv is not None and 'lease' in kv else None
                for key, kv in kvs.items()}

    def create_lease(self, lease_ttl):
        """
        Create a lease with the given TTL.
        Returns its ID.
        """

        grant_response = self._call_etcd(self._ENDPOINT_LEASE_GRANT, TTL=lease_ttl)
        return int(grant_response['ID'])

    def keepalive_lease(self, lease):
        """
        Keepalive the given lease.
        Returns True on success, False if the lease doesn't exist.
        """

        keepalive_response = self._call_etcd(self._ENDPOINT_LEASE_KEEPALIVE, ID=lease)

        # It appears that etcd responds with a TTL if the lease is found, or without one if the lease isn't found.
        # This is the only way to distinguish success from failure.
        return 'TTL' in keepalive_response.get('result', {})

    def revoke_lease(self, lease):
        """
        Revoke the given lease.
        Returns True on success, False if the lease doesn't exist.
        """

        try:
            self._call_etcd(self._ENDPOINT_LEASE_REVOKE, ID=lease)
            return True

        except HTTPError as e:
            if e.response is not None and e.response.status_code == HTTPStatus.NOT_FOUND:
                return False
            raise

    def put_one(self, key, value=None, lease=None):
        """
        Put a key in etcd, with the given key, value (optional) and lease (optional).
        """

        put_request = EtcdPutRequest(key=key, value=value, lease=lease).to_json()
        self._call_etcd(self._ENDPOINT_KV_PUT, **put_request)

    def put_one_ensure_new(self, key, value=None, lease=None):
        """
        Put a new key in etcd, with the given key, value (optional) and lease (optional).
        This function ensure the key is newly created, and fails if the key already exists.
        Returns True on success, False on failure (key already exists).
        """

        # Build PutRequest
        put_request = EtcdPutRequest(key=key, value=value, lease=lease).to_json()

        # Use a transaction to do a compare-and-put atomically, to ensure the key doesn't exist.
        # In etcd, a non-existing key is identified by having a zero version.
        compare = [
            {
                'key': put_request['key'],  # Avoid base64-encoding twice
                'target': 'VERSION',
                'version': 0,
            }
        ]
        success = [{'request_put': put_request}]

        txn_response = self._call_etcd(self._ENDPOINT_KV_TXN, compare=compare, success=success)
        return bool(txn_response.get('succeeded'))

    def compare_and_set_lease(self, key, old_lease=None, new_lease=None, value=None):
        """
        Update one key's lease in the etcd if it was belonged to old lease.
        This function ensure the key belonged to old_lease, and fails if not.
        Returns True on success, False on failure (key doesn't belong to old lease).
        """
        if not value:
            value = self.get_value(key=key)
            if not value:
                return False

        # Build PutRequest
        put_request = EtcdPutRequest(key=key, value=value, lease=new_lease).to_json()

        # Use a transaction to do a compare-and-put atomically, to ensure the key doesn't exist.
        # In etcd, a non-existing key is identified by having a zero version.
        compare = [
            {
                'key': put_request['key'],  # Avoid base64-encoding twice
                'target': 'LEASE',
                'lease': old_lease,
            }
        ]
        success = [{'request_put': put_request}]

        txn_response = self._call_etcd(self._ENDPOINT_KV_TXN, compare=compare, success=success)
        return bool(txn_response.get('succeeded', False))

    def _txn_put_many(self, put_requests, force=False):
        """
        Puts many keys in etcd.
        put_requests: A list of EtcdPutRequest objects.
        If force is set to False, puts will be issued only if they're not already set correctly in etcd.
        If force is set to True, puts will be issued anyway.
        Raises a ValueError exception if len(keys) > MAX_TXN_OPS.
        """

        if len(put_requests) > self.MAX_TXN_OPS:
            raise ValueError('Cannot put more than {max_txn_ops} keys in one transaction.'.format(max_txn_ops=self.MAX_TXN_OPS))

        if force:
            # Do a txn with the put requests as "success" with no comparison - they will be executed anyway
            success = [{'request_put': put_request.to_json()} for put_request in put_requests]
            self._call_etcd(self._ENDPOINT_KV_TXN, success=success)
        else:
            # Do a txn with "compare" and "failure", in other words it executes this logic:
            # if etcd[key1] == value1 and etcd[key2] == value2 and ...:
            #    pass
            # else:
            #    etcd[key1] = value1
            #    etcd[key2] = value2 ...
            compare = [put_request.to_compare_json() for put_request in put_requests]
            failure = [{'request_put': put_request.to_json()} for put_request in put_requests]
            self._call_etcd(self._ENDPOINT_KV_TXN, compare=compare, failure=failure)

    def put_many(self, put_requests, force=False):
        """
        Puts many keys in etcd.
        put_requests: A list of EtcdPutRequest objects.
        If force is set to False, puts will be issued only if they're not already set correctly in etcd.
        If force is set to True, puts will be issued anyway.
        """

        while put_requests:
            self._txn_put_many(put_requests[:self.MAX_TXN_OPS], force=force)
            put_requests = put_requests[self.MAX_TXN_OPS:]

    def _txn_delete_many(self, keys):
        """
        Deletes many keys in etcd. Keys that already don't exist are ignored.
        keys: A set of keys to delete.
        Raises a ValueError exception if len(keys) > MAX_TXN_OPS.
        """

        if len(keys) > self.MAX_TXN_OPS:
            raise ValueError('Cannot delete more than {max_txn_ops} keys in one transaction.'.format(max_txn_ops=self.MAX_TXN_OPS))

        success = [{'request_delete_range': {'key': _b64encode(key)}} for key in keys]
        self._call_etcd(self._ENDPOINT_KV_TXN, success=success)

    def delete_many(self, keys):
        """
        Deletes many keys in etcd. Keys that already don't exist are ignored.
        keys: Keys to delete.
        """

        keys = list(set(keys))
        while keys:
            self._txn_delete_many(keys[:self.MAX_TXN_OPS])
            keys = keys[self.MAX_TXN_OPS:]

    def defrag(self):
        self._call_etcd(self._ENDPOINT_DEFRAG)
