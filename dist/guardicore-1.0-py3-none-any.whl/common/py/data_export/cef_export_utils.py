import re
import time

import six

from common.logger import get_logger
from common.get_version.get_version import get_version
from common.py.events.mitigation.network import ManagementMatchingVerdict
from common.py.events.visibility.passive import PolicyViolationEvent
from common.py.models.events import EventSeverity
from common.py.models.incidents import IncidentType, GenericRevealIncidentType
from common.py.data_export.exporters.syslog_datetime import get_cef_timestamp

LOGGER = get_logger()


def encode_time(t):
    return t.strftime("%Y-%m-%d %H:%M:%S")


def escape_character(text, characters):
    if not isinstance(text, six.string_types):
        return text
    for character in characters:
        text = re.sub(r'(' + character + ')', r'\\\1', text)
    return text


def encode(text):
    if isinstance(text, six.string_types):
        return text.replace('\n', '\\\\n').replace('\r', '\\\\r').replace('"', '\'')
    else:
        return text


def dict_to_key_list(d):
    return ' '.join(['{}={}'.format(key, value) for key, value in d.items() if value is not None])


INCIDENT_MESSAGES_MAPPING = {
    'lateral_movements': 'Suspicious network activity detected between {source} and {dest}',
    'policy_violations': 'Suspicious network activity detected between {source} and {dest}',
    'bad_reputation': 'Suspicious activity detected on {source}',
    'network_scans': 'Network scan detected originated by {source}',
    'integrity_violations': 'Suspicious activity detected on {source}',
}
INCIDENT_DEFAULT_MESSAGE = '{severity} severity {incident_type} incident'
SECURITY_EVENT_DEFAULT_MESSAGE = '{severity} severity {incident_type} security event'


def classify_incident(incident_id, incident_type, severity, tags):
    incident_types = []
    if 'Acknowledged' not in tags:
        if incident_type == IncidentType.NETWORK_SCAN_INCIDENT_TYPE.value:
            incident_types.append('network_scans')
        if incident_type == IncidentType.INTEGRITY_INCIDENT_TYPE.value:
            incident_types.append('integrity_violations')
        if incident_type == IncidentType.HONEYPOT_INCIDENT_TYPE.value and \
                severity in {EventSeverity.High, EventSeverity.Medium} and \
                'Internal' in tags:
            incident_types.append('lateral_movements')
        if incident_type == IncidentType.NETWORK_VISIBILITY_INCIDENT_TYPE.value and \
                severity in {EventSeverity.High, EventSeverity.Medium} and \
                'Reputation' in tags:
            incident_types.append('bad_reputation')
        if GenericRevealIncidentType.POLICY_VIOLATION.value in tags:
            incident_types.append('policy_violations')
    LOGGER.info('Incident %s matched summary types: %s', incident_id, ', '.join(incident_types))
    return incident_types


class CefMessageExporter(object):
    """
    CEF formatting can be found here:
    https://community.softwaregrp.com/t5/ArcSight-Connectors/ArcSight-Common-Event-Format-CEF-Implementation-Standard/ta-p/1645557?attachment-id=68077
    """

    EMPTY_NAME_FIELD = 'Not Classified'

    def __init__(self, version=None, device_event_class_id=None, name=None, severity=None, extensions=None):
        self.version = get_version().get('version') if version is None else version
        self.device_event_class_id = device_event_class_id
        self.name = name
        self.severity = severity
        self.extensions = extensions or {}

    def create_cef_message(self, display_hostname, now_timestamp):
        """
        Generates CEF message
        template:
        Jan 18 11:07:53 host CEF:Version|Device Vendor|Device Product|Device Version|Device Event Class ID|Name|Severity|[Extension]
            * backslashes should be escaped (with backslash)
            * in the headers all pipes should be escaped. \n or \r are not allowed
            * extensions should be parsed as key=value. \n or \r characters should be escaped
        """

        cef_message = '{timestamp} {host} CEF:0|Guardicore|Centra|{version}|' \
                      '{id}|{name}|{severity}|'.format(timestamp=now_timestamp,
                                                       host=display_hostname,
                                                       version=self.version,
                                                       id=self.device_event_class_id,
                                                       name=self.name,
                                                       severity=self.severity)

        for extension, value in self.extensions.items():
            self.extensions[extension] = escape_character(value, [re.escape('\\'), '='])

        cef_message = escape_character(cef_message, [re.escape('\\')]) + dict_to_key_list(self.extensions)
        return encode(cef_message)

    @staticmethod
    def get_cef_timestamp(gm_time=None):
        if gm_time is None:
            gm_time = time.gmtime()
        # In CEF the day of the month is represented as a one-digit number without a leading zero for single-digit days
        timestamp = time.strftime("%b %e %H:%M:%S", gm_time).replace('  ', ' ')
        return timestamp

    def extract_incident_cef_fields(self, incident, start_time, max_tags_len=500, replace_incident_text=False):
        incident_type = incident.get('type')
        incident_name = ','.join(incident['summary_classification_types']) or self.EMPTY_NAME_FIELD
        self.device_event_class_id = incident_type + ' Incident'
        self.name = incident_name.replace("_", " ").title()
        self.severity = EventSeverity(incident['severity']).name.lower()

        self.extensions['start'] = start_time
        self.extensions['act'] = ManagementMatchingVerdict.ALERTED_BY_MANAGEMENT.name

        if incident_type == 'Reveal':
            event_data = incident.get('reveal_event_data', {})
            self.extensions['dpt'] = event_data.get('destination_port')
            self.extensions['proto'] = event_data.get('protocol')
            self.extensions['dproc'] = event_data.get('destination_process')
            self.extensions['sproc'] = event_data.get('source_process')
            if event_data.get('type') == PolicyViolationEvent.__name__:
                self.extensions['act'] = event_data['action']
        if incident_type == 'Deception':
            self.extensions['dpt'] = incident.get('destination_port')
            self.extensions['proto'] = incident.get('protocol')

        for affected_asset in incident['affected_assets']:
            for label in affected_asset['labels']:
                if label == 'source':
                    direction_address = 'src'
                    direction_mac_address = 'smac'
                    direction_host_name = 'shost'
                else:
                    direction_address = 'dst'
                    direction_mac_address = 'dmac'
                    direction_host_name = 'dhost'

            self.extensions[direction_host_name] = affected_asset.get('vm', {}).get('name', 'N/A')
            self.extensions[direction_address] = affected_asset.get('ip', 'N/A')

            if affected_asset.get('ip'):
                for nic in affected_asset.get('vm', {}).get('nics', []):
                    if affected_asset.get('ip') in nic.get('ip_addresses', []):
                        self.extensions[direction_mac_address] = nic.get('name', 'N/A')

        self.extensions['cs1Label'] = 'SecurityEventUUID' if replace_incident_text else 'IncidentUUID'
        self.extensions['cs1'] = incident['id']

        self.extensions['cs2Label'] = 'SecurityEventURI' if replace_incident_text else 'IncidentURI'
        self.extensions['cs2'] = incident['url']

        incident_tags = set(tag['display_name'] for tag in incident['tags'])
        incident_tags_csv = ','.join(incident_tags)
        if len(incident_tags_csv) > max_tags_len:
            incident_tags_csv = incident_tags_csv[:max_tags_len] + '...<truncated>'

        self.extensions['cs3Label'] = 'SecurityEventTags' if replace_incident_text else 'IncidentTags'
        self.extensions['cs3'] = incident_tags_csv

        if 'source_labels' in incident:
            self.extensions['cs4Label'] = 'SourceLabels'
            self.extensions['cs4'] = ','.join(incident.get('source_labels', []))

        if 'destination_labels' in incident:
            self.extensions['cs5Label'] = 'DestinationLabels'
            self.extensions['cs5'] = ','.join(incident.get('destination_labels', []))

        if incident_type == 'Integrity':
            self.extensions['cs6Label'] = 'FileModifiedTime'
            self.extensions['cs6'] = get_cef_timestamp(incident.get('file_modified_time'))
            self.extensions['cs7Label'] = 'FileOwnerName'
            self.extensions['cs7'] = incident.get('file_owner_name')

        self.extensions['msg'] = self.get_incident_cef_message(incident_name,
                                                               EventSeverity(incident['severity']).name,
                                                               incident_type,
                                                               self.extensions.get('src', ''),
                                                               self.extensions.get('dst', ''),
                                                               replace_incident_text)

    @staticmethod
    def get_incident_cef_message(incident_name, severity, incident_type, source, dest, replace_incident_text):
        message = INCIDENT_MESSAGES_MAPPING.get(incident_name,
                                                SECURITY_EVENT_DEFAULT_MESSAGE if replace_incident_text else INCIDENT_DEFAULT_MESSAGE)

        return message.format(source=source, dest=dest, severity=severity, incident_type=incident_type)
