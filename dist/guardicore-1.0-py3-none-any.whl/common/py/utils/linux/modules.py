import subprocess

__author__ = 'Eddie'


def load_module(mod_name, mod_path=None, with_fallback=False):
    """
    :param mod_name: module name
    :param mod_path:  path to the ko, None if in system path
    :param with_fallback: try modprobe, if fails use mod_path
    :return:
    """
    loaded_modules = []
    for line in open("/proc/modules", "r"):
        loaded_modules.append(line.split()[0])

    if mod_name in loaded_modules:
        return 0

    ret = 0
    if mod_path is None or with_fallback:
        args = ["modprobe", "%s" % (mod_name, )]
        ret = subprocess.call(args)
        if ret == 0:
            return 0

    if mod_path is not None:
        ret = subprocess.call(["insmod", "%s" % (mod_path, )])

    return ret
