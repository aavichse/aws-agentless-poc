import os
import pickle
import struct
import tempfile
import time
import sys
if not sys.platform.startswith('win'):
    import fcntl
else:
    import common.py.utils.linux.fcntl_stubs as fcntl

import errno
import select
import threading
import subprocess
from common.singleton import Singleton
from common.py.utils.linux.general import make_file_close_on_exec
from common.py.model.exceptions import GuardicoreException

__author__ = 'Izi'


class _ExclusiveLock(object):
    def __init__(self, name, lock_wrapper_func, base_path=None, suffix=".lock"):
        if base_path is None:
            base_path = tempfile.gettempdir()
        self._filename = os.path.join(base_path, ".%s%s" % (name, suffix))
        self._handle = open(self._filename, 'w')
        make_file_close_on_exec(self._handle)
        self._ref_count = 0
        self._lock_wrapper_func = lock_wrapper_func
        self._was_lock_error = False

    def get_filename(self):
        return os.path.abspath(self._filename)

    def try_acquire(self, timeout=0):
        """try_acquire(timeout=0) -> bool
        Try acquiring the lock. If the lock was locked, return True, else
        return False. If timeout is given, the process will try and lock the file for timeout seconds. If timeout
        is 0, then process will return immediately if lock is already acquired by another process.
        """

        if self._was_lock_error:
            raise GuardicoreException('Lock error has been previously encountered')

        if self._ref_count == 0:
            start_time = time.time()

            while True:
                try:
                    self._file_lock(flags=(fcntl.LOCK_EX | fcntl.LOCK_NB))
                    break
                except IOError as exc:
                    if exc.errno in (errno.EACCES, errno.EAGAIN):
                        if timeout and ((time.time() - start_time) < timeout):
                            time.sleep(0.3)
                            continue

                        return False

                    raise
                except Exception:
                    self._was_lock_error = True
                    raise

            self._ref_count = 1
        else:
            self._ref_count += 1

        return True

    def acquire(self):
        """acquire()
        Acquire the lock. If the lock is locked, block until it is
        available.
        """

        if self._was_lock_error:
            raise GuardicoreException('Lock error has been previously encountered')

        if self._ref_count == 0:
            try:
                self._file_lock(flags=fcntl.LOCK_EX)
            except Exception:
                self._was_lock_error = True
                raise
            self._ref_count = 1
        else:
            self._ref_count += 1

    def force_release(self):
        """force_release()
        Ensure the lock is released. Set ref count to 0.
        """
        if self._ref_count == 0:
            return

        try:
            self._file_unlock(flags=fcntl.LOCK_UN)
        except IOError:
            pass

        self._ref_count = 0

    def release(self):
        """release()
        Release the lock. If multiple calls to acquire were made, remove
        the ref-count and leave the lock locked.
        """

        if self._ref_count == 0:
            raise GuardicoreException("Attempt to release a non-acquired lock")

        if self._was_lock_error:
            raise GuardicoreException('Lock error has been previously encountered')

        if self._ref_count == 1:
            self._file_unlock(flags=fcntl.LOCK_UN)

        self._ref_count -= 1

    def _file_lock(self, flags=fcntl.LOCK_EX):
        self._lock_wrapper_func(fcntl.flock, self._handle, flags)
        self._handle.write(str(os.getpid()))
        self._handle.flush()

    def _file_unlock(self, flags=fcntl.LOCK_UN):
        fcntl.flock(self._handle, flags)
        self._handle.seek(0)
        self._handle.truncate(0)
        self._handle.flush()

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()

    def __del__(self):
        self._handle.close()


class EventletLockManager(object):
    __metaclass__ = Singleton

    def __init__(self):
        # filename ->lock
        self._locks = {}

    def get_lock(self, name, **kwargs):
        import eventlet.tpool
        if name not in self._locks:
            self._locks[name] = _ExclusiveLock(name=name, lock_wrapper_func=eventlet.tpool.execute, **kwargs)
        return self._locks[name]

    def clear_locks(self):
        self._locks.clear()


# TODO: Currently thread blocking, adapt to GEvent
class GEventLockManager(object):
    __metaclass__ = Singleton

    def __init__(self,):
        # filename ->lock
        self._locks = {}

    def get_lock(self, name, **kwargs):
        if name not in self._locks:
            self._locks[name] = _ExclusiveLock(name=name,
                                               lock_wrapper_func=lambda f, *_args, **_kwargs: f(*_args, **_kwargs),
                                               **kwargs)
        return self._locks[name]

    def clear_locks(self):
        self._locks.clear()


class ThreadLockManager(object):
    __metaclass__ = Singleton

    def __init__(self,):
        # filename ->lock
        self._locks = {}

    def get_lock(self, name, **kwargs):
        if name not in self._locks:
            self._locks[name] = _ExclusiveLock(name=name,
                                               lock_wrapper_func=lambda f, *_args, **_kwargs: f(*_args, **_kwargs),
                                               **kwargs)
        return self._locks[name]

    def clear_locks(self):
        self._locks.clear()


class AsyncFileReader(threading.Thread):
    """
    Helper class to implement asynchronous reading of a file in a separate thread. Pushes read lines on a queue to
    be consumed in another thread.
    """

    def __init__(self, fd):
        assert callable(fd.readline)
        threading.Thread.__init__(self)
        self.daemon = True
        self._fd = fd
        self._queue = []

    def close(self):
        self._fd.close()

    def run(self):
        """The body of the thread: read lines and put them on the queue."""
        try:
            while True:
                # check if there is something to read from the pipe
                rlist, _, _ = select.select([self._fd], [], [], 1)

                # if there is data, read it anyway, append it to the queue if possible
                if rlist:
                    line = self._fd.readline()
                    if not line:
                        break

                    if self._queue is not None:
                        self._queue.append(line)

                # if there is no data (timeout) and the pipe is closed, breakout
                elif not self._fd.closed:
                    break

                # if there is no data (timeout) and pipe is still open, wait again...
        except:
            if not self._fd.closed:
                raise

    def ignore_output(self):
        self._queue = None

    def readline(self):
        if self._queue:
            line = self._queue[0]
            self._queue = self._queue[1:]
            return line

        return ""

    def readlines(self):
        if self._queue:
            lines = self._queue
            self._queue = []
            return lines

        return []

    def eof(self):
        """Check whether there is no more content to expect."""
        return not self.is_alive() and not self._queue


class AsyncSubprocess(object):
    def __init__(self, *args, **kwargs):
        self._proc = subprocess.Popen(*args, **kwargs)

        if kwargs.get('stdout', None) == subprocess.PIPE:
            self.stdout = AsyncFileReader(self._proc.stdout)
            self.stdout.start()
        else:
            self.stdout = self._proc.stdout
        if kwargs.get('stderr', None) == subprocess.PIPE:
            self.stderr = AsyncFileReader(self._proc.stderr)
            self.stderr.start()
        else:
            self.stderr = self._proc.stderr

    def __repr__(self):
        return "<AsyncSubprocess pid=%d>" % (self._proc.pid, )

    def __getattr__(self, item):
        return getattr(self._proc, item)

    def communicate(self):
        raise NotImplementedError("communicate() isn't implemented for AsyncSubprocess")

    def ignore_output(self):
        self.ignore_stdout()
        self.ignore_stderr()

    def ignore_stdout(self):
        if not isinstance(self.stdout, AsyncFileReader):
            return

        self.stdout.ignore_output()

    def ignore_stderr(self):
        if not isinstance(self.stderr, AsyncFileReader):
            return

        self.stderr.ignore_output()

    def __del__(self):
        if isinstance(self.stdout, AsyncFileReader):
            self.stdout.close()
            self.stdout.join()
        if isinstance(self.stderr, AsyncFileReader):
            self.stderr.close()
            self.stderr.join()


class MultiprocessQueue(object):
    """Class MultiprocessQueue()

    A queue which can communicate between two processes where the parent process is
    the reading end and the child processes are the writing ends. In order for the
    queue to work, the parent process need to allow fd inheritance so the writing
    end of be left open in the child. To use the queue, you need to do as follow:
    >> queue = MultiprocessQueue.new()
    >> ...
    >> # create sub process, past it the value of queue.child_fd
    >> ...
    >> queue.parent_post_clone()
    >> ...
    >> # inside the child:
    >> queue_fd = <value passed by parent>
    >> child_queue = MultiprocessQueue.child_pos_clone(queue_fd)
    >> child_queue.put({'any': 'object'})
    >> ...
    >> # in the parent:
    >> obj = queue.get(block=True)
    >>
    >> # when done, both sides:
    >> queue.close()
    >> # not closing the queue might cause a fd leakage....
    On the reading side, it is possible to poll trigger events when there are objects to
    read off the queue using either select.select() or select.poll() poller.
    """

    LEN_SIZE = struct.calcsize("I")

    def __init__(self, queue_r, queue_w):
        self.queue_r = queue_r
        self.queue_w = queue_w

    def __del__(self):
        self.close()

    @staticmethod
    def new():
        """MultiprocessQueue.new() -> MultiprocessQueue()

        Create a parent-side R/W queue.
        """

        return MultiprocessQueue(*os.pipe())

    @staticmethod
    def child_post_clone(queue_fd):
        """MultiprocessQueue.child_post_clone(queue_fd) -> MultiprocessQueue()

        Create a write-only multiprocess queue.
        """

        return MultiprocessQueue(None, queue_fd)

    def parent_post_clone(self):
        """parent_post_clone()

        Should be called just after forking the last child process.
        """

        os.close(self.queue_w)
        self.queue_w = None

    @property
    def child_fd(self):
        """the fd (int value) to pass to the child process.
        """
        return self.queue_w

    def fileno(self):
        return self.queue_r

    def register_poller(self, poller):
        poller.register(self.queue_r, select.POLLIN)

    def close(self):
        if self.queue_r is not None:
            os.close(self.queue_r)
            self.queue_r = None

        if self.queue_w is not None:
            os.close(self.queue_w)
            self.queue_w = None

    def put(self, obj):
        """put(obj)

        Put an object on the queue. Should be called only inside the child process.
        In case the parent have died or closed its queue, IOError() is raised.
        """

        if self.queue_w is None:
            raise IOError("R/O instance of the queue")

        # write object to queue write end
        obj_pickle = pickle.dumps(obj)
        total_len = len(obj_pickle) + MultiprocessQueue.LEN_SIZE
        total_data = struct.pack("I", len(obj_pickle)) + obj_pickle
        if total_len != os.write(self.queue_w, total_data):
            raise IOError("Not all intended queue data has been written: length: %d, data: %r" % (total_len, total_data))

    def get(self, block=True):
        """get(block=True) -> obj

        Read an object off the queue. If all child process have died or closed their
        queue end, IOError is raised. If block is True, the function would block until there is
        an object to read or the other side was closed (IOError is raised). If block is False,
        the method returns immediately with a value of None.
        """

        if self.queue_r is None:
            raise IOError("W/O instance of the queue")

        # if we're non-blocking, check first if there is an object to read
        if not block:
            rlist, _, _ = select.select([self.queue_r], [], [], 0.01)
            if not rlist:
                return None

        # read object pickle size
        pickle_size = os.read(self.queue_r, MultiprocessQueue.LEN_SIZE)
        if not pickle_size or (MultiprocessQueue.LEN_SIZE != len(pickle_size)):
            raise IOError("Queue other end might have been closed, binary length: %r" % (pickle_size, ))

        # read object pickle
        pickle_size = struct.unpack("I", pickle_size)[0]
        obj_pickle = os.read(self.queue_r, pickle_size)
        if not obj_pickle or (len(obj_pickle) != pickle_size):
            raise IOError("Queue other end might have been closed, length: %d, data: %r" % (pickle_size, obj_pickle))

        try:
            return pickle.loads(obj_pickle)
        except Exception as exc:
            raise IOError("Error decoding multiprocess queue pickle (%s): %r" % (exc, obj_pickle))
