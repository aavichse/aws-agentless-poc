
import eventlet
from eventlet.green import socket

from common import logger
from common.py.network.comm_strategy import JsonCommunicationStrategy

LOG = logger.get_logger(module_name=__name__)

MAX_SO_RECV_SIZE = 8192


class SimpleNetDictSender(object):
    """
    Simple NetDict sender with no project dependencies
    """

    @staticmethod
    def send_dict(path, data, response_expected, communication_strategy=JsonCommunicationStrategy, timeout=2,
                  max_recv=MAX_SO_RECV_SIZE, attempt_failed_connect=3):
        assert attempt_failed_connect > 0

        # Connect to a listening unix socket. send data, receive response and then close the socket.
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET)
        sock.settimeout(timeout)

        try:
            for attempt in range(attempt_failed_connect):
                try:
                    sock.connect(path)
                    break
                except socket.error as exc:
                    if attempt == attempt_failed_connect - 1:
                        LOG.error("Failed connecting to '%s' (after %d attempts): %s", path, attempt_failed_connect,
                                  exc)
                        return None

                    eventlet.sleep(5.0)

            try:
                prep_data = communication_strategy.prepare_for_send(data)
                sock.sendall(prep_data)
            except socket.error as exc:
                LOG.error("Failed sending on '%s': %s", path, exc)
                return None

            if not response_expected:
                return None

            try:
                response = sock.recv(max_recv)
                unpacked_response = communication_strategy.prepare_after_receive(response)
            except socket.timeout:
                LOG.error("Response is empty (timeout)")
                return None
        finally:
            sock.close()

        return unpacked_response
