from datetime import timedelta, datetime
from enum import IntEnum
from functools import wraps
import hashlib
from copy import deepcopy
from common.py.utils.encoding.json import fast_json
from common.py.events import IPProtocol
from common.py.events.mitigation.network import NetworkConnectionEvent, ConnectionEventType, ProviderMatchingVerdict, \
    UNKNWON_RULE
from common.logger import get_logger
from management.elastic_models.barebones_connection import ConnectionType

LOGGER = get_logger()


def hashed_key(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        key = func(*args, **kwargs)
        return key, hashlib.sha256(key.encode('utf-8')).hexdigest()
    return wrapper


class ConnectionDirection(IntEnum):
    OUTGOING = 1
    INCOMING = 2
    MATCHED = 3

    @classmethod
    def from_string(cls, direction):
        return getattr(cls, direction.upper(), None)


class ProviderConnection:
    """ProviderConnection
    Helps to construct pair of NetworkConnectionEvent out of ConnectionObject
    pushed via Connection API
    """
    DEF_CLIENT = "Unknown Client"
    DEF_SERVER = "Unknown Server ({protocol}/{port})"
    CROSS_INSTANCE_INCOMINGS_PROVIDER = 'CentraCrossInstance'

    EVENT_TYPES = {
        (ConnectionDirection.INCOMING, ConnectionType.SUCCESSFUL): ConnectionEventType.NewSuccessIncomingConnection,
        (ConnectionDirection.INCOMING, ConnectionType.FAILED): ConnectionEventType.NewFailedIncomingConnection,
        (ConnectionDirection.OUTGOING, ConnectionType.SUCCESSFUL): ConnectionEventType.NewSuccessOutgoingConnection,
        (ConnectionDirection.OUTGOING, ConnectionType.FAILED): ConnectionEventType.NewFailedOutgoingConnection
    }

    EVENT_TYPES_MATCHED = {
        (ConnectionDirection.INCOMING, ConnectionEventType.NewSuccessMatchedConnection): ConnectionEventType.NewSuccessIncomingConnection,
        (ConnectionDirection.INCOMING, ConnectionEventType.NewFailedMatchedConnection): ConnectionEventType.NewFailedIncomingConnection,
        (ConnectionDirection.OUTGOING, ConnectionEventType.NewSuccessMatchedConnection): ConnectionEventType.NewSuccessOutgoingConnection,
        (ConnectionDirection.OUTGOING, ConnectionEventType.NewFailedMatchedConnection): ConnectionEventType.NewFailedOutgoingConnection
        }

    @classmethod
    def get_process_info(cls, side):
        process_info = side.get('process_info')
        if not process_info:
            return None, None

        process_properties = dict()
        process_name = process_info.get('name')
        username = process_info.get('username')
        full_path = process_info.get('full_path')

        if process_name:
            process_properties['process_name'] = process_name
            process_properties['app_name'] = process_name

        if full_path:
            process_properties['full_path'] = full_path

        if username:
            process_properties['username'] = username

        process_properties['aggregation_key_unhashed'], process_properties['aggregation_key'] =\
            cls.process_group_aggregation_key(process_properties)

        return process_properties, username

    @staticmethod
    def get_policy_info(connection_obj):
        info = connection_obj.get('policy_info') or {}

        return dict(
            rule_id=info.get('rule_id', UNKNWON_RULE),
            verdict=ProviderMatchingVerdict(info.get('verdict', ProviderMatchingVerdict.ALLOW.name).upper()),
            revision=info.get('revision'),
            provider_rule_id=info.get('provider_rule_id')
        )

    @classmethod
    def get_network_connection_pair(cls, connection_obj):
        """ Converts ConnectionObject dict into ConnectionPair
            returns None in case neither side of Connection has asset id.
        """
        outgoing, incoming = None, None

        connection_type = getattr(ConnectionType, connection_obj.get('connection_type'))
        protocol = getattr(IPProtocol, connection_obj.get('ip_protocol'))
        start_time = datetime(1970, 1, 1) + timedelta(milliseconds=connection_obj.get('timestamp'))
        end_time = datetime.utcnow()

        for direction in (ConnectionDirection.OUTGOING, ConnectionDirection.INCOMING):
            side = connection_obj.get('source') if direction == ConnectionDirection.OUTGOING else \
                connection_obj.get('destination')


            process_properties, username = cls.get_process_info(side=side)

            event = NetworkConnectionEvent(source_ip=connection_obj.get('source').get('ip_address'),
                                           destination_ip=connection_obj.get('destination').get('ip_address'),
                                           destination_port=connection_obj.get('destination').get('port'),
                                           ip_protocol=protocol,
                                           count=connection_obj.get('count'),
                                           event_type=cls.EVENT_TYPES[(direction, connection_type)],
                                           process_group_info=process_properties,
                                           vm_id=side.get('asset_id'),
                                           username=username,
                                           provider=connection_obj.get('provider'),
                                           provider_matching=cls.get_policy_info(connection_obj),
                                           bucket_start_time=start_time,
                                           bucket_end_time=end_time)

            if direction == ConnectionDirection.OUTGOING:
                outgoing = event
            else:
                incoming = event

        if outgoing.vm_id and not incoming.vm_id:
            incoming = None
        elif incoming.vm_id and not outgoing.vm_id:
            outgoing = None

        return (outgoing, incoming)

    @classmethod
    def get_network_connection_pairs(cls, connections_list):
        """Converts list of ConnectionObject dicts into list of ConnectionPair and filters
        ConnectionObject that has no asset id on either side of Connection.
        """
        return [pair for pair in (cls.get_network_connection_pair(connection_obj)
                                  for connection_obj in connections_list)
                if pair is not None]

    @staticmethod
    @hashed_key
    def process_group_aggregation_key(process_group_info):
        process_name_candidates = [process_group_info.get(k) for k in
                                   ['full_path', 'process_name']]
        process_names = ';'.join(list(map(str, process_name_candidates)))

        key_values = [process_names]

        username = process_group_info.get('username')
        if username:
            key_values.append(username)

        return ';'.join(list(map(str, key_values)))

    @classmethod
    def get_network_connection_pair_cloud_provider(cls, connection_obj):
        """ Converts ConnectionObject dict into ConnectionPair
            returns None in case neither side of Connection has asset id.
        """
        outgoing, incoming = None, None

        connection_obj = connection_obj.to_dict()
        connection_obj.pop('uuid')
        connection_type = connection_obj.pop('event_type')

        for direction in (ConnectionDirection.OUTGOING, ConnectionDirection.INCOMING):
            side = connection_obj.get('source_inventory_item_info') \
                if direction == ConnectionDirection.OUTGOING \
                else connection_obj.get('destination_inventory_item_info')
            if side is not None:
                connection_obj['provider'] = side.get('item_type')

            event = NetworkConnectionEvent(event_type=cls.EVENT_TYPES_MATCHED[(direction, connection_type)],
                                           **connection_obj)

            if direction == ConnectionDirection.OUTGOING:
                outgoing = event
            else:
                incoming = event

        if outgoing.vm_id and not incoming.vm_id:
            incoming = None
        elif incoming.vm_id and not outgoing.vm_id:
            outgoing = None

        return outgoing, incoming

    @classmethod
    def from_cross_instance_incoming_events(cls, network_events, cm_asset_id_by_asset_id):
        """from_cross_instance_incoming_events
        Given chunk of network events, prepare kwargs for connection objects
        that can be used to create Connection Objects that we can pass to Connections API
        e.g. Provider Connections
        """
        base_kwargs = dict(destination=dict(), source=dict(),
                           ip_protocol=IPProtocol.Tcp, connection_type='SUCCESSFUL',
                           provider=cls.CROSS_INSTANCE_INCOMINGS_PROVIDER, timestamp=0, count=0)

        events = []
        for network_event in network_events:
            if network_event.is_outgoing:
                LOGGER.warning('Only cross instance incoming connections are reported ! Skip outgoing connection')
                continue

            for vm_id, side in [(network_event.remote_vm_id, 'source'),
                                (network_event.vm_id, 'destination')]:
                if not cm_asset_id_by_asset_id.get(vm_id):
                    LOGGER.warning('Missing asset mapping for %r side asset: %r', side, vm_id)
                    break # filter out connections that does not have mapped remote/local asset id
            else:
                kwargs = deepcopy(base_kwargs)
                # Instance is forwarding incoming connections
                # On CM, source asset id is used to determine to which instance to forward connection
                kwargs['source']['asset_id'] = cm_asset_id_by_asset_id[network_event.remote_vm_id]
                kwargs['destination']['asset_id'] = cm_asset_id_by_asset_id[network_event.vm_id]
                kwargs['destination']['port'] = network_event.destination_port

                # Reset some of the data
                # verdicts will be re-calculated on target Instance, labels have different IDs 
                # and also will be re-calcualted
                # Process info will be reported anew on target instance, that's why we did not reset
                # some of the info in connections processor
                for attrs, value in [ # Reset not relevant fields to None
                                     (['management_matching', 'remote_mssp_info', 'remote_vm_id',
                                       'joint_matching'], None),
                                     # reset remote is foreign flag to false
                                     (['remote_is_foreign'], False),
                                     # reset vm to ID as on CM
                                     (['vm_id'], cm_asset_id_by_asset_id[network_event.vm_id]),
                                     # reset labels to emoty array
                                     (['local_vm_labels', 'remote_vm_labels', 'local_ip_labels', 'remote_ip_labels',
                                       'local_container_info_labels', 'remote_container_info_labels'], [])
                                    ]:
                    for attr in attrs:
                        setattr(network_event, attr, value)

                kwargs['raw'] = fast_json.dumps(network_event, drop_nons=True)
                events.append(kwargs)

        return events

    @classmethod
    def from_cross_instance_connection_objects(cls, connection_objects):
        """from_cross_instance_connection_objects
        Converts list of ConnectionObject dicts into list of Network Events
        """
        connections_list = []
        for connection_obj in connection_objects:
            try:
                kwargs = fast_json.loads(connection_obj['raw'],
                                         support_datetime=True)
                connections_list.append(NetworkConnectionEvent(**kwargs))
            except:
                LOGGER.exception('Failed to parse: %r', connection_obj)

        LOGGER.info('Processed: %r/%r cross instance incoming connections', len(connections_list),
                    len(connection_objects))
        return connections_list

    @classmethod
    def remap_asset_ids(cls, connections_list, assets_id_by_cm_asset_id):
        """remap_asset_ids
        Given chunk of events and mapping of CM Asset ID -> Instance Asset ID
        remap local vm_id of Network Events.
        return network events with reampped IDs
        """
        connections = []
        for connection in connections_list:
            try:
                connection.vm_id = assets_id_by_cm_asset_id[connection.vm_id]
                connections.append(connection)
            except:
                LOGGER.error('Failed to process connection, missing asset mapping for asset: %r',
                             connection.vm_id)
        return connections
