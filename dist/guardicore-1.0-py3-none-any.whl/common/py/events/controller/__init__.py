from enum import IntEnum


class AgentModule(IntEnum):
    REVEAL = 1
    DECEPTION = 2
    ENFORCEMENT = 3
    ENFORCEMENT_CHANNEL = 4
    DETECTION = 5
    REVEAL_CHANNEL = 6
    ACCESS = 7
