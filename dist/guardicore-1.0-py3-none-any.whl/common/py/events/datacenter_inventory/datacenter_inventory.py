import attr
from netaddr import IPAddress, IPNetwork

from common.py.events.attrs import string_attr, Dictable, datetime_attr, set_attr, list_attr, int_attr, \
    bool_attr, dictable_list_converter, optional_dictable_converter, dict_attr
from common.py.utils.asset_type import AssetType

DC_INV_SNAPSHOT_PRINT_MAX_LEN = 10000


@attr.s()
class DCNicInfo(Dictable):
    ip_addresses = list_attr()  # of strings
    is_cloud_public = bool_attr(default=False)
    cloud_network = string_attr(default=None)
    reachable_networks = list_attr(default=attr.Factory(list))


@attr.s()
class DCAssetSubtypeInfo(Dictable):
    entity_type = attr.ib(type=str, default=None)
    entity_subtype = attr.ib(type=str, default=None)
    entity_id = attr.ib(type=str, default=None)
    integration_name = attr.ib(type=str, default=None)


@attr.s()
class DCAssetInfo(Dictable):
    name = string_attr()
    asset_id = string_attr()
    agent_id = string_attr()
    nics = attr.ib(converter=lambda l: [nic if isinstance(nic, DCNicInfo) else DCNicInfo(**nic) for nic in l],
                   # default is here for backward compatibility only. delete this once it's no longer relevant
                   factory=list)
    k8s_cluster = bool_attr(default=False)
    asset_type = string_attr(default=AssetType.UNDEFINED.value)
    attributes = dict_attr(factory=dict)
    subtype = attr.ib(converter=optional_dictable_converter(DCAssetSubtypeInfo), default=None)

    @property
    def ip_addresses(self):
        return [ip for nic in self.nics for ip in nic.ip_addresses]

    @classmethod
    def from_json(cls, s):
        asset = super(DCAssetInfo, cls).from_json(s)

        # convert to IPAddress in an early stage
        for nic in asset.nics:
            nic.ip_addresses = [str(IPAddress(ip.split("%")[0], version=4)) if "." in ip and ":" not in ip else
                                str(IPAddress(ip.split("%")[0], version=6)) for ip in nic.ip_addresses]

        return asset


@attr.s
class Criterion(Dictable):
    field = string_attr()               # 'image_name', 'docker_labels', etc...
    argument = string_attr()            # 'busybox', 'docker_label1:application', etc.
    op = int_attr()                     # a number representing an op, like LabelCriterionOperation


@attr.s
class IntegrationCriterion(Criterion):
    integration_name = string_attr()


@attr.s
class ContainerCriteria(Dictable):
    criterions = list_attr(converter=dictable_list_converter(Criterion))


@attr.s
class IntegrationCriteria(Dictable):
    criteria = list_attr(converter=dictable_list_converter(IntegrationCriterion))


@attr.s()
class LabelInfo(Dictable):
    label_id = string_attr()
    key = string_attr()
    value = string_attr()
    vm_ids = set_attr(default=attr.Factory(set))
    subnets = set_attr(default=attr.Factory(set))
    container_criterias = list_attr(converter=dictable_list_converter(ContainerCriteria), default=attr.Factory(list))
    integration_criteria = list_attr(converter=dictable_list_converter(IntegrationCriteria), default=attr.Factory(list))
    is_fast = bool_attr(default=False)
    non_integration_vm_ids = attr.ib(factory=list)

    @classmethod
    def from_json(cls, s):
        label = super(LabelInfo, cls).from_json(s)

        # convert to IPNetwork in an early stage
        label.subnets = [str(IPNetwork(subnet, version=4)) if "." in subnet and ":" not in subnet \
                         else str(IPNetwork(subnet, version=6)) for subnet in label.subnets]
        return label


@attr.s()
class DatacenterInventorySnapshot(Dictable):
    # asset_id --> AssetInfo
    assets = attr.ib(
        converter=lambda d: {k: v if isinstance(v, DCAssetInfo) else DCAssetInfo(**v) for k, v in d.items()})
    # label_id --> LabelInfo
    labels = attr.ib(converter=lambda d: {k: v if isinstance(v, LabelInfo) else LabelInfo(**v) for k, v in d.items()})
    # list of subnets
    private_subnets = set_attr()

    snapshot_revision = int_attr()
    snapshot_timestamp = datetime_attr()

    @staticmethod
    def load_private_subnets(private_subnets):
        return {IPNetwork(subnet, version=4) if "." in subnet and ":" not in subnet else IPNetwork(subnet, version=6)
                for subnet in private_subnets}

    @classmethod
    def from_json(cls, s):
        snapshot = super(DatacenterInventorySnapshot, cls).from_json(s)

        # convert to IPNetwork in an early stage
        snapshot.private_subnets = DatacenterInventorySnapshot.load_private_subnets(snapshot.private_subnets)
        return snapshot

    def compare_data(self, other):
        """
        Compare the data of the two snapshots (all but the timestamp).
        :param other: another DatacenterInventorySnapshot object
        :return: True if snapshots are equal, False if they're different.
        """
        assert isinstance(other, DatacenterInventorySnapshot)

        return (self.assets == other.assets
                and self.labels == other.labels
                and self.private_subnets == other.private_subnets)
