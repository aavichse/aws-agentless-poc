import copy

import attr
from enum import Enum

from common.py.events.attrs import enum_attr, string_attr


class DockerContainerStatus(Enum):
    CREATED = 'created'
    RESTARTING = 'restarting'
    RUNNING = 'running'
    REMOVING = 'removing'
    PAUSED = 'paused'
    EXITED = 'exited'
    DEAD = 'dead'
    UNKNOWN = 'unknown'
    FAIL_CREATE = 'fail_create'
    TIMEOUT = 'timeout'
    NOT_FOUND = 'not_found'

    def __str__(self):
        return self.value

    @property
    def is_alive(self):
        return self in (DockerContainerStatus.CREATED, DockerContainerStatus.RUNNING, DockerContainerStatus.RESTARTING)

    @property
    def is_running(self):
        return self == DockerContainerStatus.RUNNING

    @property
    def fail_create(self):
        return self == DockerContainerStatus.FAIL_CREATE

    @staticmethod
    def from_str(status):
        return STATUS_MAP.get(status)


STATUS_MAP = {str(status): status for status in DockerContainerStatus}


@attr.s(slots=True, frozen=True)
class DockerContainerInfo(object):
    status = enum_attr(DockerContainerStatus)
    container_id = string_attr(default=None)
    status_msg = string_attr(default=None)
    logs = string_attr(default=None)

    @property
    def is_alive(self):
        return self.status.is_alive

    @property
    def is_running(self):
        return self.status.is_running

    @property
    def fail_create(self):
        return self.status.fail_create


class DockerMountMode(Enum):
    READ_WRITE = 'rw'
    READ_ONLY = 'ro'

    def __str__(self):
        return self.value


class DockerVolumes(object):
    def __init__(self):
        self._volumes = {}

    def add_volume(self, host_path, container_path, mode=DockerMountMode.READ_WRITE):
        self._volumes[host_path] = (container_path, mode,)
        return self

    def to_dict(self):
        return {
            host_path:
                {
                    'bind': container_path,
                    'mode': str(mode)
                }
            for host_path, (container_path, mode) in self._volumes.items()
        }

    def __add__(self, other_volumes):
        docker_volumes = DockerVolumes()
        docker_volumes._volumes = copy.copy(self._volumes)
        docker_volumes._volumes.update(other_volumes._volumes)
        return docker_volumes
