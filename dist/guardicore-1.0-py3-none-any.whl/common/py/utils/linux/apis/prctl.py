"""
Utility (Linux only) to ensure subprocesses exit when their parents do by sending
a specified signal when the parent dies.
Usage:
    subprocess.Popen(['some-executable'], preexec_fn=on_parent_exit('SIGHUP'))
"""

import sys
import warnings
from ctypes import cdll

# Constant taken from http://linux.die.net/include/linux/prctl.h
PR_SET_PDEATHSIG = 1


class PrCtlError(Exception):
    pass


def _unix_on_parent_exit(signum):
    """
    Return a function to be run in a child process which will trigger SIGNUM
    to be sent when the parent process dies
    """
    # http://linux.die.net/man/2/prctl
    result = cdll['libc.so.6'].prctl(PR_SET_PDEATHSIG, signum)
    if result != 0:
        raise PrCtlError('prctl failed with error code %s' % result)

    return result


def _win32_on_parent_exit(signum):
    return None


if sys.platform.startswith("win"):
    warnings.warn("on_parent_exit() not available on 'win32' platform")
    on_parent_exit = _win32_on_parent_exit
else:
    on_parent_exit = _unix_on_parent_exit
