from six import add_metaclass
from dbus import DBusException

from systemd_dbus.exceptions import SystemdError
from systemd_dbus.manager import Manager
from upstart.system import UpstartSystem

from common.logger import get_logger
from common.singleton import Singleton
from common.py.utils.linux.init.model import InitSystemType
from common.py.utils.linux.init.systemd_service import SystemdService
from common.py.utils.linux.init.upstart_service import UpstartService

DBUS_ERROR_ACCESS_DENIED = 'org.freedesktop.DBus.Error.AccessDenied'
DBUS_ERROR_SERVICE_UNKNOWN = 'org.freedesktop.DBus.Error.ServiceUnknown'

LOG = get_logger(module_name=__name__)


def get_init_system_type():
    try:
        UpstartSystem()
        return InitSystemType.UPSATRT
    except DBusException as e:
        if e.get_dbus_name() == DBUS_ERROR_ACCESS_DENIED:
            LOG.exception("Failed to access system DBus")
        elif e.get_dbus_name() == DBUS_ERROR_SERVICE_UNKNOWN:
            pass
        else:
            LOG.exception(
                "Unexpected exception when trying to access system DBus with destination='com.ubuntu.Upstart'")

    try:
        # Need to remove subscribtion to init it in SystemdService
        manager = Manager()
        manager.unsubscribe()
        del manager

        return InitSystemType.SYSTEMD
    except SystemdError:
        pass
    except DBusException as e:
        if e.get_dbus_name() == DBUS_ERROR_ACCESS_DENIED:
            LOG.exception("Failed to access system DBus")
        else:
            LOG.exception(
                "Unexpected exception when trying to access system DBus with destination='org.freedesktop.systemd1'")

    return InitSystemType.UNKNOWN


@add_metaclass(Singleton)
class InitServiceFactory(object):

    def __init__(self):
        self._init_system_type = None

    @property
    def init_system_type(self):
        if self._init_system_type is None:
            self._init_system_type = get_init_system_type()
            LOG.info("Init system type: %s", self._init_system_type)

        return self._init_system_type

    def create_service(self, service_name):
        if self.init_system_type == InitSystemType.UPSATRT:
            return UpstartService(service_name)

        if self.init_system_type == InitSystemType.SYSTEMD:
            return SystemdService(service_name)

        raise NotImplementedError()

