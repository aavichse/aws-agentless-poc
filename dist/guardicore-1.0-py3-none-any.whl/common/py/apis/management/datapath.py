import requests

from common.py.apis import RPCExchange, DEFAULT_RABBITMQ_USERNAME, \
    DEFAULT_RABBITMQ_PASSWORD, REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT, ComponentType, \
    AgentComponentType, AggregatorType, RPCMessage, ComponentIDPrefix
from common.py.apis.management import UNKNOWN_API_VERSION
from common.py.apis.management.aggregating_system_component import AggregatorBaseComponentManagementAPI
from common.py.apis.management.collector import CollectorAPI
from common.py.apis.management.system_component import disable_anonymous
from common.py.events.agent import ComponentState
from common.logger import get_logger
from common.py.models.events import EventType

LOG = get_logger(module_name=__name__)

__author__ = 'Lior'


class DatapathManagementAPI(AggregatorBaseComponentManagementAPI):
    AGENTS_COMPONENT_TYPE = AgentComponentType.DECEPTION_AGENT
    COMPONENT_TYPE = ComponentType.DATAPATH
    COMPONENT_BASE_URI = 'datapath-agents'

    HONEYPOT_FACING_ADDRESS_KEY = 'honeypot_facing_address'
    VERIFY_CERTIFICATE_KEY = 'verify_certificate'
    NAT_TRAVERSAL_KEY = 'nat_traversal'
    GET_EXTERNAL_IP_REST_API = "https://%s/whatismyip"

    RABBIT_API_CLASS = CollectorAPI

    def __init__(self, management_hosts, agent_id, version=UNKNOWN_API_VERSION, user=DEFAULT_RABBITMQ_USERNAME,
                 password=DEFAULT_RABBITMQ_PASSWORD, configuration_schema=None, aggregator_configuration_schema=None,
                 associated_mgmt_configuration=None, datapath_details=None, aggregator_type=AggregatorType.COLLECTOR,
                 aggregator_features=None, collector_type=None, **kwargs):
        component_id = ComponentIDPrefix.DATAPATH_ID_PREFIX + agent_id
        component_details = datapath_details if datapath_details is not None else {}
        component_details.update(dict(associated_mgmt_configuration=associated_mgmt_configuration,
                                      management_host=management_hosts[-1]))

        if self.HONEYPOT_FACING_ADDRESS_KEY not in component_details:
            component_details[self.HONEYPOT_FACING_ADDRESS_KEY] = None

        super(DatapathManagementAPI, self).__init__(management_hosts=management_hosts,
                                                    user=user,
                                                    password=password,
                                                    version=version,
                                                    exchange=RPCExchange.DATAPATH_EXCHANGE_NAME,
                                                    component_id=component_id,
                                                    agent_id=agent_id,
                                                    aggregator_type=aggregator_type,
                                                    aggregator_features=aggregator_features,
                                                    collector_type=collector_type,
                                                    configuration_schema=configuration_schema,
                                                    aggregator_configuration_schema=aggregator_configuration_schema,
                                                    component_details=component_details,
                                                    heartbeat=REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT,
                                                    **kwargs)

    def report_redirection_event2(self, event):
        """
        :param event: The event to report
        :type event: dict. contains all the relevant keys.
        """
        # FIXME: Replace the original method with this one. Add here some
        # validations or something so the structure of event dictionary will be clear.
        self._report_event(RPCMessage.Deception.REPORT_DECEPTION_EVENT_RPC_FUNC_NAME,
                           EventType.DatapathRedirectEvent,
                           event,
                           RPCExchange.NETWORK_EVENT_EXCHANGE_NAME,
                           '')

    def get_external_ip(self):
        response = requests.get(self.GET_EXTERNAL_IP_REST_API % self.component_details['management_host'],
                                verify=self.component_details[self.VERIFY_CERTIFICATE_KEY])
        return response.headers['X-remote-ip']

    @disable_anonymous
    def get_state(self):
        state = self.rabbitapi.call_management_rpc(RPCMessage.Datapath.DATAPATH_GET_STATE_RPC_FUNC_NAME,
                                                   component_id=self.component_id,
                                                   component_type=self.COMPONENT_TYPE,
                                                   component_details=self.component_details,
                                                   component_status=self.component_status,
                                                   blocking=True)
        return ComponentState[state]

    def add_state_update_callback(self, callback_func, initial_call=True):
        self.rabbitapi.add_callback(RPCMessage.Datapath.DATAPATH_STATE_CHANGE_MESSAGE_TYPE,
                                    lambda message: callback_func(ComponentState[message['state']]),
                                    initial_call=initial_call,
                                    initial_call_func=lambda: callback_func(self.get_state()))

