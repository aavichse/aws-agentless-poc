import uuid

from common.py.apis import DEFAULT_RABBITMQ_USERNAME, DEFAULT_RABBITMQ_PASSWORD, \
    numbered_queue_name, RPCExchange, RPCQueue, RPCMessage, REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT, ComponentIDPrefix, \
    ComponentType
from common.py.apis.management import UNKNOWN_API_VERSION, ManagementAPIError
from common.py.apis.management.system_component import SystemComponentManagementAPI, disable_anonymous, \
    CannotCalculateRoutingKey, calc_routing_key_suffix
from common.py.events.honeypot import HoneypotEvent
from common.py.events.hpvm import HPVMState, RedirectAction
from common.py.events.mitigation.machine_details import MachineDetailsUpdate, UpdateType, MachineDetails
from common.py.models.events import EventType

__author__ = 'Lior'


HPVM_RECORDING_ROUTING_KEY_SUFFIX = "_recording"


class HPVMManagementAPI(SystemComponentManagementAPI):
    COMPONENT_TYPE = ComponentType.HONEYPOT
    COMPONENT_BASE_URI = 'honeypots'

    RECORDING_MESSAGE_EXPIRATION_SEC = 30

    def __init__(self, management_hosts, honeypot_id,
                 version=UNKNOWN_API_VERSION,
                 user=DEFAULT_RABBITMQ_USERNAME, password=DEFAULT_RABBITMQ_PASSWORD,
                 configuration_schema=None,
                 transport_type='eventlet', config_callback=None, associated_mgmt_configuration=None, **kwargs):
        """

        :param management_host:
        :param honeypot_id:
        :param is_passive: Whether this is only a passive instance (doesn't notify mgmt about its existence)
        :param user:
        :param password:
        :param transport_type:
        """
        component_id = ComponentIDPrefix.HONEYPOT_ID_PREFIX + honeypot_id
        component_details = dict(agent_id=honeypot_id,
                                 version=version,
                                 db_auth_enabled=kwargs.pop('db_auth_enabled', False),
                                 db_password=kwargs.pop('db_password', None),
                                 associated_mgmt_configuration=associated_mgmt_configuration)

        if config_callback:
            self.config_callback = config_callback
        else:
            self.config_callback = HPVMManagementAPI._default_config_callback

        super(HPVMManagementAPI, self).__init__(management_hosts=management_hosts,
                                                user=user,
                                                password=password,
                                                version=version,
                                                exchange=RPCExchange.HONEYPOT_EXCHANGE_NAME,
                                                transport_type=transport_type,
                                                component_id=component_id,
                                                component_details=component_details,
                                                configuration_schema=configuration_schema,
                                                heartbeat=REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT,
                                                **kwargs)

    def report_redirection_event(self, source_ip, destination_ip, physical_network_id, source_mac, destination_mac,
                                 source_port, destination_port, action, incident_id=None, service_provider_id=None,
                                 **kwargs):
        """
        :param source_ip:
        :param destination_ip:
        :param physical_network_id:
        :param source_mac:
        :param destination_mac:
        :param source_port:
        :param destination_port:
        :type action: common.py.events.hpvm.RedirectAction
        :param service_provider_id:
        :param connection_state:
        :param kwargs:
        """
        description = "Connection directed to service emulation" if action == RedirectAction.Inspect else "Connection Rejected"
        event = {
            "source_ip": source_ip,
            "destination_ip": destination_ip,
            "physical_network_id": physical_network_id,
            "source_mac": source_mac,
            "destination_mac": destination_mac,
            "source_port": source_port,
            "destination_port": destination_port,
            "action": action.name,
            "description": description,
        }
        if incident_id is not None:
            event["incident_id"] = incident_id
        if service_provider_id is not None:
            event["service_provider_id"] = str(service_provider_id)
        event.update(kwargs)

        routing_key = self.calculate_event_routing_key(event, is_json=True)
        self._report_event(RPCMessage.Deception.REPORT_DECEPTION_EVENT_RPC_FUNC_NAME,
                           EventType.HoneypotRedirectEvent,
                           event,
                           RPCExchange.DECEPTION_EXCHANGE_NAME,
                           routing_key)

        if self.config_callback()['enable_recording_mode']:
            self._report_event(RPCMessage.Deception.REPORT_DECEPTION_EVENT_RPC_FUNC_NAME,
                               EventType.HoneypotRedirectEvent,
                               event,
                               RPCExchange.DECEPTION_EXCHANGE_NAME,
                               routing_key + HPVM_RECORDING_ROUTING_KEY_SUFFIX,
                               expiration_sec=HPVMManagementAPI.RECORDING_MESSAGE_EXPIRATION_SEC)

    def report_honeypot_event(self, event):
        """

        :type event: common.py.events.security.HoneypotEvent
        """
        if not isinstance(event, HoneypotEvent):
            raise ManagementAPIError("Event %s is not a HoneypotEvent" % (event, ))
        event.event_source = self.component_id

        routing_key = self.calculate_event_routing_key(event)
        self._report_mongoengine_event(event,
                                       RPCExchange.DECEPTION_EXCHANGE_NAME,
                                       routing_key,
                                       rpc_func_name=RPCMessage.Deception.REPORT_DECEPTION_MONGOENGINE_EVENT_RPC_FUNC_NAME)

        if self.config_callback()['enable_recording_mode']:
            self._report_mongoengine_event(event,
                                           RPCExchange.DECEPTION_EXCHANGE_NAME,
                                           routing_key + HPVM_RECORDING_ROUTING_KEY_SUFFIX,
                                           rpc_func_name=RPCMessage.Deception.REPORT_DECEPTION_MONGOENGINE_EVENT_RPC_FUNC_NAME,
                                           expiration_sec=HPVMManagementAPI.RECORDING_MESSAGE_EXPIRATION_SEC)

    @disable_anonymous
    def get_state(self):
        state = self.rabbitapi.call_management_rpc(RPCMessage.Honeypot.HONEYPOT_GET_STATE_RPC_FUNC_NAME,
                                                   component_id=self.component_id,
                                                   component_type=self.COMPONENT_TYPE,
                                                   component_details=self.component_details,
                                                   component_status=self.component_status,
                                                   blocking=True)
        return HPVMState[state]

    def add_state_update_callback(self, callback_func, initial_call=True):
        self.rabbitapi.add_callback(RPCMessage.Honeypot.HONEYPOT_STATE_CHANGE_MESSAGE_TYPE,
                                    lambda message: callback_func(HPVMState[message['state']]),
                                    initial_call=initial_call,
                                    initial_call_func=lambda: callback_func(self.get_state()))

    def get_machine_details(self):
        """
        Returns a list of all guest agent details obtained from Mitigation Agents.
        """
        return [MachineDetailsUpdate(vm_uuid=vm_uuid,
                                     update_type=UpdateType.MachineAdded,
                                     details=MachineDetails._from_son(details))
                for (vm_uuid, details)
                in self.rabbitapi.call_management_rpc(RPCMessage.Honeypot.HONEYPOT_GET_MACHINE_DETAILS_RPC_FUNC_NAME,
                                                      blocking=True)]

    def add_machine_details_update_callback(self, callback_func, initial_call=True):
        def _callback(message):
            callback_func([MachineDetailsUpdate.from_json(update) for update in message['updates']])
        self.rabbitapi.add_callback(RPCMessage.Honeypot.HONEYPOT_MACHINE_DETAILS_UPDATE_MESSAGE_TYPE,
                                    _callback,
                                    initial_call=initial_call,
                                    initial_call_func=lambda: callback_func(self.get_machine_details()))

    def get_ssh_key_pairs_seeds_pool(self):
        return self.rabbitapi.call_management_rpc(RPCMessage.Honeypot.HONEYPOT_GET_SSH_KEY_PAIRS_SEEDS_POOL_RPC_FUNC_NAME,
                                                  blocking=True,
                                                  timeout_sec=5 * 60)

    @staticmethod
    def _default_config_callback():
        return {'enable_recording_mode': False,
                }

    @classmethod
    def calculate_event_routing_key(cls, event, is_json=False):
        try:
            if not is_json:
                if not hasattr(event, 'service_provider_id'):
                    key = str(uuid.uuid4())
                else:
                    key = event.service_provider_id
            else:
                key = event.get('service_provider_id')
                if key is None:
                    key = str(uuid.uuid4())
        except:
            raise CannotCalculateRoutingKey(event)
        routing_key_suffix = calc_routing_key_suffix(key)
        return numbered_queue_name(RPCQueue.DECEPTION_EVENTS_RPC_QUEUE_NAME_TEMPLATE, routing_key_suffix)

    @disable_anonymous
    def send_sp_initial_state(self, sp_name, sp_build_time, sp_index, state):
        self.rabbitapi.call_management_rpc(RPCMessage.Honeypot.HONEYPOT_REPORT_NEW_SP_INITIAL_STATE,
                                           component_id=self.component_id,
                                           sp_name=sp_name,
                                           sp_build_time=sp_build_time,
                                           sp_index=sp_index,
                                           state=state)

    def list_all_honeypots(self, cluster_id_list=None):
        return self.rabbitapi.call_management_rpc(RPCMessage.Honeypot.HONEYPOT_LIST_ALL_HONEYPOTS_RPC_FUNC_NAME,
                                                  cluster_id_list=cluster_id_list,
                                                  blocking=True)

    def add_notify_honeypots_list_changed_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.Honeypot.HONEYPOT_NOTIFY_HONEYPOTS_LIST_CHANGE,
                                    lambda message: callback_func(changed_hpvm_id=message.get('changed_hpvm_id', None)))
