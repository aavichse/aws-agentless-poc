import os
from requests import ConnectionError, ReadTimeout, RequestException
from common.py.utils.config.six import integer_types
from common.py.collection.control.model import build_ctrl_sock_path, list_all_open_ctrl_servers
from common.py.apis.rabbitutils import RabbitMsgJSONDecoder, RabbitMsgJSONEncoder
from common.py.utils.config.six import fastjson

try:
    import requests_unixsocket as requests
except ImportError:
    import requests

from common.py.model.aggregator import AggregatorComponent
from common.py.model.exceptions import GuardicoreException


class ControlClientError(GuardicoreException):
    pass


class EndpointDownError(ControlClientError):
    pass


class ControlClientErrorReply(ControlClientError):
    def __init__(self, req, uri, err_msg, *args):
        super(ControlClientErrorReply, self).__init__(err_msg, *args)
        self.uri = uri
        self.req = req


class AggregatorControlClient(object):
    DEF_CONNECT_TIMEOUT = 12.0
    DEF_READ_TIMEOUT = 30.0

    def __init__(self, component_name, worker_index=0, component_type=None, connect_timeout=None, read_timeout=None, special_id=None):

        assert component_type is None or isinstance(component_type, AggregatorComponent)
        assert type(worker_index) in integer_types, \
            "Expecting 'worker_index' to be of int type, got: %r" % (worker_index,)

        if isinstance(component_name, AggregatorComponent):
            self.component_name = component_name.value
            self.component_type = component_name
        else:
            self.component_name = component_name
            self.component_type = component_type

        self.worker_index = worker_index
        self.path = build_ctrl_sock_path(self.component_name, worker_index=self.worker_index, special_id=special_id)
        self.quoted_path = self.path.replace("/", "%2F")
        self.session = None
        self.connect_timeout = connect_timeout if connect_timeout is not None else self.DEF_CONNECT_TIMEOUT
        self.read_timeout = read_timeout if read_timeout is not None else self.DEF_READ_TIMEOUT

    def __repr__(self):
        return "<%s %s%s>" % (self.__class__.__name__, self.name, " active" if self.session else "")

    @property
    def name(self):
        if self.component_type:
            name = "%s" % self.component_type.name
        else:
            name = "%s" % self.component_name
        if self.worker_index:
            name += " worker=%d" % self.worker_index
        return name

    @classmethod
    def from_component_type(cls, component_type, worker_index=0, *args, **kwargs):
        assert isinstance(component_type, AggregatorComponent)
        return cls(component_name=component_type.value,
                   worker_index=worker_index,
                   component_type=component_type, *args, **kwargs)

    @classmethod
    def from_another_client(cls, other_client, *args, **kwargs):
        assert isinstance(other_client, AggregatorControlClient)

        new_client = cls(component_name=other_client.component_name,
                         worker_index=other_client.worker_index,
                         component_type=other_client.component_type, *args, **kwargs)
        new_client.path = other_client.path
        new_client._new_session = other_client._new_session
        new_client._new_request = other_client._new_request
        return new_client

    @staticmethod
    def list_all_clients():
        for component_name, worker_index in list_all_open_ctrl_servers():
            yield AggregatorControlClient(component_name=component_name, worker_index=worker_index)

    def close(self):
        if self.session:
            self.session.close()
            self.session = None

    def reconnect(self):
        if self.session:
            self.session.close()
        self.session = self._new_session()

    def call_with_reconnect(self, *args, **kwargs):
        try:
            return self.call(*args, **kwargs)
        except:
            self.reconnect()
            return self.call(*args, **kwargs)

    def _error_repr(self, uri, method="GET", data=None, json=None):
        error_repr = "path '{}' with URI {} '{}'".format(self.path, method, uri)
        if data:
            error_repr += " with data '{}'".format(data)
        elif json:
            error_repr += " with JSON '{}'".format(json)
        return error_repr

    def _verify_server_up(self):
        if self.path is not None and not os.path.exists(self.path):
            raise EndpointDownError("Can't find component %s control socket '%s'", self.name, self.path)

    def call(self, uri, method="GET", data=None, json=None, expect_json=True, connect_timeout=None, read_timeout=None,
             **kwargs):
        """call(uri, method="GET", data=None) -> JSON obj

        Call the remote endpoint 'uri' over the control server.
        """

        connect_timeout = self.connect_timeout if connect_timeout is None else connect_timeout
        read_timeout = self.read_timeout if read_timeout is None else read_timeout

        self._verify_server_up()

        if not self.session:
            self.session = self._new_session()

        if not uri.startswith("/"):
            uri = "/" + uri

        if kwargs:
            uri += "?" + "&".join("%s=%s" % item for item in kwargs.items())
        try:
            req = self._new_request(self.session, self.quoted_path, uri, method=method, json=json, data=data,
                                    connect_timeout=connect_timeout, read_timeout=read_timeout)
        except ConnectionError as exc:
            raise EndpointDownError("Error sending request to remote endpoint on %s, server side seems to be down: %s",
                                    self._error_repr(uri=uri, method=method, data=data, json=json), exc)
        except RequestException as exc:
            raise ControlClientError("Error sending request to remote endpoint on %s: %s",
                                     self._error_repr(uri=uri, method=method, data=data, json=json), exc)

        if 200 != req.status_code:
            raise ControlClientErrorReply(req, uri,
                                          "Error reply (%d %s) from component %s trying to call %s:\n%s",
                                          req.status_code, req.reason, self.name,
                                          self._error_repr(uri=uri, method=method, data=data, json=json), req.text)

        if not expect_json:
            return req.content

        try:
            return fastjson.loads(req.content, cls=RabbitMsgJSONDecoder)
        except fastjson.JSONDecodeError as exc:
            raise ControlClientErrorReply(req, uri,
                                          "Failed parsing reply JSON for URI '%s' over component %s (%s):\n%s",
                                          uri, self.name, exc, req.content)

    def list_endpoints(self, verbose=False):
        """list_endpoints() -> [cmd1, cmd2, ...]

        List all endpoints in the remote control server.
        """
        return self.call("/control-server/list", verbose=str(verbose).lower())

    def on_config_update(self):
        """Notify all active components of a config update"""
        return self.call("/agents-config/on_config_update")

    @classmethod
    def _new_session(cls):
        return requests.Session()

    @classmethod
    def _build_url(cls, quoted_path, uri):
        return "http+unix://{}{}".format(quoted_path, uri)

    @classmethod
    def _new_request(cls, session, quoted_path, uri, method="GET", data=None, json=None, headers=None,
                     connect_timeout=DEF_CONNECT_TIMEOUT, read_timeout=DEF_READ_TIMEOUT):
        url = cls._build_url(quoted_path=quoted_path, uri=uri)
        try:
            if json:
                if data:
                    raise ControlClientError("Cannot send a request with both 'data' and 'json' defined")
                if not headers:
                    headers = dict()
                headers['Content-type'] = 'application/json'
                data = fastjson.dumps(json, cls=RabbitMsgJSONEncoder)

            return session.request(method=method, url=url, data=data, headers=headers,
                                   timeout=(connect_timeout, read_timeout))

        except ReadTimeout as exc:
            raise ControlClientError("Timeout waiting for request for '%s' (%s): %s", uri, method, exc)
