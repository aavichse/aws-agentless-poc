import hashlib


def get_hash(path, hash_type='sha256'):
    """
    Get hash of large file using read loop
    :param path: path of file calculate hash
    :param hash_type: type of hash to calculate
    :return: hash hex digest
    :rtype: str
    """
    BLOCK_SIZE = 4096
    file_hash = getattr(hashlib, hash_type)()
    with open(path, 'rb') as disk_file:
        chunk = disk_file.read(BLOCK_SIZE)
        while len(chunk) > 0:
            file_hash.update(chunk)
            chunk = disk_file.read(BLOCK_SIZE)
    return file_hash.hexdigest()


def get_string_hash(string):
    return int(hashlib.sha256(string.encode('utf-8')).hexdigest(), 16)