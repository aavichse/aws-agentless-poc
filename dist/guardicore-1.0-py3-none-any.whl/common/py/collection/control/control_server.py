import os
import posixpath
from six import add_metaclass
from eventlet.green import socket
import eventlet.wsgi
from flask import Flask, logging as flask_logging, request
from flask_socketio import SocketIO
from common.py.collection.control.model import control, build_ctrl_sock_path, register_service_control_commands, \
    ControlCommand
from common.component_service import ComponentService
from common.logger import get_logger
from common.service import ServiceState
from common.singleton import Singleton
from common.py.utils.config.oslo_config import cfg
from common.py.apis.rabbitutils import RabbitMsgJSONDecoder, RabbitMsgJSONEncoder
from common.py.utils.get_user_ids import get_service_user

LOG = get_logger(module_name=__name__)


@add_metaclass(Singleton)
class ControlServer(ComponentService):
    def __init__(self, app):
        super(ControlServer, self).__init__(name="control-server")

        self._app = app
        self._srv_sock = None
        self._ctrl_sock_path = None
        self._flask_socketio = None
        self._commands = {}
        self._srv_job = None

        flask_logging.create_logger = lambda flask_app: LOG
        self.flask_app = Flask(import_name=__name__)
        setattr(self.flask_app, '_logger', LOG)
        self.flask_app.json_decoder = RabbitMsgJSONDecoder
        self.flask_app.json_encoder = RabbitMsgJSONEncoder

    def _create_control_sock_server(self):
        ctrl_sock_dir = os.path.dirname(self._ctrl_sock_path)
        if not os.path.isdir(ctrl_sock_dir):
            os.makedirs(ctrl_sock_dir)
        if os.path.exists(self._ctrl_sock_path):
            os.unlink(self._ctrl_sock_path)

        LOG.info("Initialize control socket server at %s", self._ctrl_sock_path)
        control_sock = eventlet.listen(self._ctrl_sock_path, socket.AF_UNIX)
        os.chown(self._ctrl_sock_path, *get_service_user())

        return control_sock

    @control("list", help="List all command endpoints registered to the control server. If 'verbose' is"
                          " set as 'true', return a dict of endpoint with extra metadata.")
    def list_commands(self):
        verbose = request.values.get('verbose', "false") == "true"
        if not verbose:
            return list({cmd for cmd, method in self._commands.keys()})
        return {key: {'help': value.help, 'methods': value.methods}
                for (key, method), value in self._commands.items()}

    @staticmethod
    def _build_route_path(prefix, cmd):
        cmd_path = cmd.path.strip("/")
        prefix = cmd.prefix if cmd.prefix is not None else prefix
        prefix = prefix.strip("/")
        return posixpath.join("/", prefix, cmd_path)

    def register_ctrl_commands(self, prefix, ctrl_commands):
        for cmd in ctrl_commands:
            assert isinstance(cmd, ControlCommand)
            path_prefix = self._build_route_path(prefix, cmd)
            for method in cmd.methods:
                self._commands[(path_prefix, method)] = cmd
            self.flask_app.add_url_rule(rule=path_prefix, endpoint=path_prefix, view_func=cmd, methods=cmd.methods)
            if cmd.help is not None:
                self.flask_app.add_url_rule(rule=posixpath.join(path_prefix, "help"),
                                            endpoint="%s/help" % (path_prefix,),
                                            view_func=cmd.do_help, methods=("GET",))
            LOG.debug("Registered command %s under '%s'", cmd, path_prefix)

    def _initialize_ctrl_srv(self):
        self._ctrl_sock_path = build_ctrl_sock_path(component_name=self._app.get_component_type().value,
                                                    worker_index=self._app.get_worker_index(),
                                                    special_id=self._app.get_special_id())
        self._srv_sock = self._create_control_sock_server()

    def initialize(self):
        super(ControlServer, self).initialize()

        # activate Flask-socketIO
        self._flask_socketio = SocketIO(self.flask_app, async_mode="eventlet", logger=LOG)

        self._initialize_ctrl_srv()

        register_service_control_commands(self, prefix=self.name)

    def restart(self):
        if self._srv_job:
            self._wait_job(self._srv_job, kill=True)
            self._srv_sock.close()

        self._initialize_ctrl_srv()

        self._srv_job = self._run_job(name="control-server-spawn", func=self._run_wsgi_server,
                                      cleanup_timeout=0)

    def verify(self):
        pass

    def start(self):
        super(ControlServer, self).start()

        self._srv_job = self._run_job(name="control-server-spawn", func=self._run_wsgi_server,
                                      cleanup_timeout=0)

    def _run_wsgi_server(self):
        assert self._srv_sock is not None

        try:
            LOG.debug("Start control server (%s)", self._ctrl_sock_path)
            eventlet.wsgi.server(self._srv_sock, self.flask_app,
                                 log_output=cfg.CONF.log.debug, log=LOG)
        except:
            if self.get_state() == ServiceState.Started:
                raise

    def cleanup(self):
        super(ControlServer, self).cleanup()

        if self._srv_sock:
            self._srv_sock.close()

        if self._ctrl_sock_path and os.path.exists(self._ctrl_sock_path):
            os.unlink(self._ctrl_sock_path)
