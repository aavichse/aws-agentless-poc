from common.py.clouds import common_opts, label_opts
from common.py.utils.config import cfg
from common.py.utils.config.types import Structure
from common.py.utils.config.oslo_config import types
from common.py.model.exceptions import GuardicoreException

azure_opts = [
                 cfg.StrOpt('tenant_id'),
                 cfg.Opt('subscriptions_list', default=[],
                         type=types.List(item_type=types.String(quotes=True), bounds=True),
                         help="A list of subscriptions formatted as 'Name: ID'"),
                 cfg.StrOpt('application_id'),
                 cfg.StrOpt('application_key', secret=True),
                 cfg.BoolOpt('display_computer_name', default=False,
                             help='Display computer name as asset name instead of VM resource name'),
                 cfg.BoolOpt('full_cloud_discovery', default=False,
                             help='Collect all the available data on as many resources as we possibly can'),
                 cfg.StrOpt('proxy_url', default=None, help="Optional HTTP/HTTPS proxy URL"),
                 cfg.BoolOpt('fetch_scale_sets', default=False, help="Fetch Scale Set VM's and include as assets"),
                 cfg.StrOpt('alternative_cloud_environment',
                            choices=sorted(['default', 'AzureChinaCloud', 'AzureUSGovernment', 'AzureGermanCloud']),
                            default='default',
                            help="Change if the tenant is in an alternative azure cloud environment."),
             ] + common_opts + label_opts
AZURE_AUTH_STRUCTURE = Structure(azure_opts)

AZURE_AUTH_OPTS = [cfg.IntOpt('update_timeout_seconds',
                              default=10 * 60,
                              help="Azure update timeout in seconds")]


def register_opts():
    cfg.CONF.register_opt(cfg.Opt('azure_configuration', type=AZURE_AUTH_STRUCTURE), group="orchestration")

    cfg.CONF.register_opts(opts=AZURE_AUTH_OPTS, group="azure_auth")


class CloudInputValidationException(GuardicoreException):
    pass


def validate_subscriptions_list(subscriptions_list):
    subscriptions = {}
    for subscription in subscriptions_list:
        try:
            subscription_name, subscription_id = subscription.replace(' ', '').split(':', 1)
        except Exception:
            raise CloudInputValidationException('Subscription "%s"', subscription)

        subscriptions[subscription_id] = subscription_name

    return subscriptions
