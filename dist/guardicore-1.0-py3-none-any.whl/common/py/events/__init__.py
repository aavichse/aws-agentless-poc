from enum import IntEnum


class IPVersion(IntEnum):
    IPv4 = 4
    IPv6 = 6


class IPProtocol(IntEnum):
    Tcp = 6
    Udp = 17


class LongHashType(IntEnum):
    SHA256 = 1
    MD5 = 2
