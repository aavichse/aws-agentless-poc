from common.py.utils.config import cfg
from common.py.utils.config.types import Structure

# azure_ad_graph specific configurations
azure_ad_graph_opts = [
    cfg.StrOpt('application_id'),
    cfg.StrOpt('application_key', secret=True),
    cfg.StrOpt('tenant_id'),
    cfg.BoolOpt('fetch_nested_group_members', default=True),
    cfg.IntOpt('orchestration_full_report_interval', help="Interval in which to run a full report (in seconds)",
               default=1800),
]

AZURE_AD_GRAPH_AUTH_STRUCTURE = Structure(azure_ad_graph_opts)

AZURE_AD_GRAPH_AUTH_OPTS = [cfg.IntOpt('update_timeout_seconds',
                                       default=10 * 60,
                                       help="Azure AD Graph update timeout in seconds")]


def register_opts():
    cfg.CONF.register_opt(cfg.Opt('azure_ad_graph_configuration', type=AZURE_AD_GRAPH_AUTH_STRUCTURE),
                          group="orchestration")
    cfg.CONF.register_opts(opts=AZURE_AD_GRAPH_AUTH_OPTS, group="azure_ad_graph_auth")
