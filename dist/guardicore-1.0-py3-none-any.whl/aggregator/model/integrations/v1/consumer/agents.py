from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field


class AgentsInfo(BaseModel):
    mac_addresses: Optional[List[str]] = Field(
        None,
        alias='mac-addresses',
        description='Known agents MAC addresses without separator',
        examples=[['000000000000', '112233445566']],
    )