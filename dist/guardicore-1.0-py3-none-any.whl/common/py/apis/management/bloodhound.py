import datetime
from enum import IntEnum

import attr

from common.py.events.attrs import Dictable


class BloodHoundTaskState(IntEnum):
    PENDING = 0
    RUNNING = 1
    UPLOADING_TO_MGMT = 2  # BloodHound report is being uploaded to MGMT
    UPLOADED_TO_MGMT = 3  # BloodHound report has been uploaded to MGMT
    UPLOADING_TO_GCP = 4  # File is being uploaded to GCP
    DONE = 5
    ABORTED = 6
    FAILED = 7


@attr.s()
class BloodHoundTaskReport(Dictable):
    task_id = attr.ib(type=str)
    task_state = attr.ib(type=BloodHoundTaskState)
    fail_reason = attr.ib(type=str, default="")
    report_file_names = attr.ib(default=attr.Factory(list))
    statistics = attr.ib(factory=list)
    bloodhound_version = attr.ib(type=str, default="1.6.1")
    last_updated_time = attr.ib(type=datetime.datetime, default=datetime.datetime.utcnow())
    logs = attr.ib(type=str, default="")


@attr.s()
class BloodHoundTargetInfo(Dictable):
    collection_method = attr.ib(type=str)
    customer_folder = attr.ib(type=str)
    file_type = attr.ib(type=str)
    domain_name = attr.ib(type=str)
    username = attr.ib(type=str)
    password = attr.ib(type=str)
    workers = attr.ib(type=int)
    dns_timeout = attr.ib(type=int)
    disable_autogc = attr.ib(type=bool)
    exclude_dcs = attr.ib(type=bool)
    nameserver = attr.ib(type=str)
    dns_tcp = attr.ib(type=bool)
    disable_pooling = attr.ib(type=bool)
    kerberos = attr.ib(type=bool)
    hashes = attr.ib(type=str)
    no_pass = attr.ib(type=bool)
    aes_key = attr.ib(type=str)
    auth_method = attr.ib(type=str)
    domain_controller = attr.ib(type=str)
    global_catalog = attr.ib(type=str)
    cluster = attr.ib(type=str)
    enhanced_arguments = attr.ib(default=attr.Factory(list))

    @classmethod
    def from_dict(cls, data):
        return cls(**data)


@attr.s()
class BloodHoundTaskInfo(Dictable):
    id = attr.ib(type=str)
    state = attr.ib(type=int)
    target = attr.ib(converter=lambda v: BloodHoundTargetInfo(**v) if isinstance(v, dict) else v)

    @classmethod
    def from_dict(cls, data):
        return cls(id=data["_id"],
                   state=data["state"],
                   target=data["target"])
