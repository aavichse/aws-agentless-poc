import attr

from common.py.events import LongHashType
from common.py.events.attrs import string_attr, list_attr, Dictable, enum_attr


@attr.s
class FIMFile(Dictable):
    path = string_attr()
    hashes = list_attr()  # of strings


@attr.s
class FIMTemplate(Dictable):
    template_id = string_attr()
    title = string_attr()

    affected_asset_ids = list_attr()  # of strings (asset ids)
    affected_label_ids = list_attr()  # of strings (label ids)
    files = list_attr(
        converter=lambda l: [FIMFile(**f) if not isinstance(f, FIMFile) else f
                             for f in l]
    )
    hash_type = enum_attr(LongHashType)


@attr.s
class FIMPolicy(Dictable):
    revision_number = string_attr()
    templates = list_attr(
        converter=lambda l: [FIMTemplate(**template) if not isinstance(template, FIMTemplate) else template
                             for template in l]
    )
    def is_empty(self):
        return True if not self.templates else False

