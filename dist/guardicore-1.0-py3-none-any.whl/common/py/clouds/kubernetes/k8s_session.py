from common.py.model.exceptions import GuardicoreException


class K8sSession(object):
    def __init__(self, auth_host, auth_port, service_account_token, validate_certificate, ca_cert_data):
        self.auth_host = auth_host
        self.auth_port = auth_port
        self.service_account_token = service_account_token
        self.validate_certificate = validate_certificate
        self.ca_cert_data = ca_cert_data

    def connectivity_check(self):
        if not self.auth_host:
            raise GuardicoreException('Orchestration configuration error: Missing orchestration "Auth Host"')
        if not self.auth_port:
            raise GuardicoreException('Orchestration configuration error: Missing orchestration "Auth Port"')
        if not self.service_account_token:
            raise GuardicoreException(
                'Orchestration configuration error: Missing orchestration "Service Account Token"')
        if self.validate_certificate and \
                (not self.ca_cert_data or (len(self.ca_cert_data) == 1 and not self.ca_cert_data[0])):
            raise GuardicoreException('Orchestration configuration error: Missing orchestration "CA Cert Data"')
