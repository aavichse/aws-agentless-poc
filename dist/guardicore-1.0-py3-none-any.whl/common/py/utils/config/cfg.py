from common.py.models.events import EventSeverity
from common.py.utils.config.oslo_config.cfg import *
from common.py.utils.config.types import Severity, ChoicesString


class SeverityOpt(Opt):
    def __init__(self, name='severity', default=EventSeverity.High.name, help='Detection severity'):
        super(SeverityOpt, self).__init__(name, type=Severity(), default=default, help=help)


class ExtendedOpt(Opt):
    def __init__(self, *args, **kwargs):
        self.hidden = kwargs.pop('hidden', False)
        self.restart = kwargs.pop('restart', False)
        self.rebuild = kwargs.pop('rebuild', False)
        self.change_cb = kwargs.pop('change_cb', None)
        self.multi_line_text = kwargs.pop('multi_line_text', False)

        super(ExtendedOpt, self).__init__(*args, **kwargs)


class StrChoicesOpt(Opt):
    def __init__(self, name, choices_dict=None, **kwargs):
        super(StrChoicesOpt, self).__init__(name,
                                            type=ChoicesString(choices_dict=choices_dict),
                                            **kwargs)
