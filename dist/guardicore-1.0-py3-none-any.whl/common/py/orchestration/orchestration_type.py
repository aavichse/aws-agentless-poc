from enum import Enum

__author__ = 'Sagy'


class OrchestrationType(Enum):
    VSPHERE = 'vSphere'
    AWS = 'AWS'
    AZURE = 'Azure'
    GCP = 'GCP'
    KUBERNETES = 'Kubernetes'
    INVENTORY_API = "InventoryAPI"
    ORACLE = "Oracle"
    AGENT = 'Agent'
    ACTIVE_DIRECTORY = 'ActiveDirectory'
    AZURE_AD_GRAPH = 'AzureADGraph'
    F5 = 'F5'
    CITRIX = 'Citrix'
    OPENSTACK = 'OpenStack'
    GENERIC_INVENTORY = 'GenericInventory'
    AS400 = 'AS400'
    API = 'API'
    CENTRA_MULTI_CLUSTER = 'GuardicoreCluster'
    EAA = 'EAA'
    CLOUD_APP_AZURE = 'CloudAppAzure'
    PACKETFENCE = "PacketFence"

    def __str__(self):
        return self.value

    @staticmethod
    def from_str(orch_type):
        return ORCHESTRATION_TYPE_MAP.get(orch_type.lower())

    @classmethod
    def cloud_apps(cls):
        return [cls.CLOUD_APP_AZURE.value]

    @classmethod
    def cloud_app_types(cls):
        return [cls.CLOUD_APP_AZURE]


ORCHESTRATION_TYPE_MAP = {str(orch_type).lower(): orch_type for orch_type in OrchestrationType}
INVENTORY_ORCHESTRATIONS = {OrchestrationType.KUBERNETES.value,
                            OrchestrationType.GENERIC_INVENTORY.value}
