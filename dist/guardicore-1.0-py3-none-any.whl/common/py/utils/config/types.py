import copy
import sys
from enum import Enum
from common.py.models.events import EventSeverity
from common.py.utils.config.copyable_config_opt import CopyableConfig
from common.py.utils.config.oslo_config import types
from common.py.utils.config.oslo_config.types import *
from common.py.utils.config.string_types import CaseSensitiveString, Path
from six import string_types


def recursive_argument_builder(arg):
    if isinstance(arg, (int, string_types, float, bool)):
        return str(arg)
    elif isinstance(arg, list):
        return "[%s]" % ", ".join(['%s' % (recursive_argument_builder(value), ) for value in arg])
    elif isinstance(arg, dict):
        return "{%s}" % ", ".join(['%s: %s' % (key, recursive_argument_builder(value)) for (key, value) in arg.items()])
    elif isinstance(arg, Enum):
        return arg.name
    elif isinstance(arg, CaseSensitiveString):
        res = "{string: %s, case_sensitive: %s}" % (arg.string, arg.case_sensitive)
        if isinstance(arg, Path):
            res = res[:-1] + ", sep: %s}" % (arg.sep,)
        return res
    else:
        raise ValueError('Unsupported type %s' % type(arg))


class Structure(Dict):
    """Structure type.

    Structure type values are key:value pairs separated by commas.
    The resulting value is a ConfigOpts object parsing the given
    values.

    :param structure: Opts to parse
    """

    BASE_TYPES = (dict,)

    def __init__(self, structure=None, conf_type=CopyableConfig, name="Unnamed"):
        super(Structure, self).__init__(bounds=True)

        if structure is None:
            structure = []

        for opt in structure:
            if isinstance(opt.type, (Dict, List)):
                if not opt.type.bounds:
                    raise TypeError('Structure Opts must be bound')

        self.conf = conf_type()
        self.conf.register_cli_opts(structure)
        self.structure = structure
        self.name = name

    def __call__(self, *args, **kwargs):
        if len(args) == 1:
            value = args[0]
        elif len(args) == 0 and len(kwargs) != 0:
            value = kwargs
        else:
            raise ValueError("Bad initialization of %s Stucture" % self.name)

        if isinstance(value, self.conf.__class__):
            return value

        if isinstance(value, str):
            value = value.replace("\'", "")
        result = super(Structure, self).__call__(value)
        conf = copy.deepcopy(self.conf)

        try:
            conf(args=["--%s=%s" % (key, recursive_argument_builder(value))
                       for (key, value) in result.items() if value is not None])
        except SystemExit:
            raise ValueError

        return conf

    def __repr__(self):
        return "<Structure type %s>" % self.name

    def __eq__(self, other):
        return (
            (self.__class__ == other.__class__) and
            (self.structure == other.structure)
        )


class Port(Integer):
    def __init__(self):
        super(Port, self).__init__(min=0, max=65535)


class Severity(String):
    def __init__(self):
        super(Severity, self).__init__(choices=EventSeverity.get_non_empty_severity_names())

    def __call__(self, value):
        if isinstance(value, EventSeverity):
            return value

        if isinstance(value, int):
            return EventSeverity(value)

        result = super(Severity, self).__call__(value)
        return EventSeverity[result]


# The range stuff (min/max) from Integer does not exist in Float, and is copied below to a new type FloatRange.
class FloatRange(Float):
    def __init__(self, min=None, max=None, *args, **kwargs):
        super(FloatRange, self).__init__(*args, **kwargs)

        if min is not None and max is not None and max < min:
            raise ValueError('Max value is less than min value')

        self.min = min
        self.max = max

    def __call__(self, value):
        value = super(FloatRange, self).__call__(value)

        if value is not None:
            self._check_range(value)

        return value

    def _check_range(self, value):
        if self.min is not None and value < self.min:
            raise ValueError('Should be greater than or equal to %g' % self.min)
        if self.max is not None and value > self.max:
            raise ValueError('Should be less than or equal to %g' % self.max)


class ChoicesString(types.String):
    """String type.

    String values do not get transformed and are returned as str objects.

    :param choices: Optional sequence of valid values.
    :param quotes: If True and string is enclosed with single or double
                   quotes, will strip those quotes. Will signal error if
                   string have quote at the beginning and no quote at
                   the end. Turned off by default. Useful if used with
                   container types like List.
    """

    BASE_TYPES = string_types

    def __init__(self, choices_dict=None, quotes=False):
        choices = None if choices_dict is None else choices_dict.keys()
        super(ChoicesString, self).__init__(choices=choices, quotes=quotes)
        self.choices_dict = choices_dict

    def __call__(self, value):
        value = super(ChoicesString, self).__call__(value)
        return self.choices_dict[value]
