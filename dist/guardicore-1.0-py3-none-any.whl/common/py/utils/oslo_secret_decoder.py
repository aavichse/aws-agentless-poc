import base64
import re
import sys

import six

OSLO_SECRET = 0x12
SECRET_PREFIX = "$2g$1C$:"


class OsloSecret(object):
    @staticmethod
    def encode(s):
        if not s or s.startswith(SECRET_PREFIX):
            return s
        return SECRET_PREFIX + re.sub('=', '', base64.urlsafe_b64encode(''.join(chr(ord(x) ^ OSLO_SECRET) for x in s)))

    @staticmethod
    def decode(s):
        if s and s.startswith(SECRET_PREFIX):
            s = s[len(SECRET_PREFIX):]
            s = base64.urlsafe_b64decode(str(s.rstrip() + '=' * (-len(s) % 4)))
            return ''.join(chr(x ^ OSLO_SECRET) for x in six.iterbytes(s))
        return s


def main():
    sys.argv = sys.argv[1:]
    print(OsloSecret.decode(sys.argv[0]))


if __name__ == "__main__":
    main()
