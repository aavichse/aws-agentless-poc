import datetime
import uuid

from bson import ObjectId
from mongoengine import StringField, DateTimeField, ListField, BooleanField

from common.gc_document import GCDynamicDocument


class BaseEvent(GCDynamicDocument):
    meta = {
        'abstract': True,
    }
    uuid = StringField(required=True, default=lambda: str(uuid.uuid4()), unique=True)
    time = DateTimeField(required=True, default=datetime.datetime.utcnow)  # Reported time
    received_time = DateTimeField(required=True, default=datetime.datetime.utcnow)
    processed_time = DateTimeField(required=True, default=datetime.datetime.utcnow)
    event_source = StringField(required=True)
    event_source_hostname = StringField()
    event_type = StringField()  # Duplication with class type; sometimes needed.
    tag_refs = ListField(field=StringField(), default=[])
    is_experimental = BooleanField(default=False)

    @classmethod
    def duplicate_experimental(cls, incident_id, new_incident_id):
        if not hasattr(cls, 'incident_id'):
            return

        collection = cls._get_collection()
        events = collection.find({'incident_id': incident_id})
        if not events.count():
            return

        bulk = collection.initialize_unordered_bulk_op()
        for event in events:
            event['_id'] = ObjectId()
            event['uuid'] = str(uuid.uuid4())
            event['incident_id'] = new_incident_id
            bulk.insert(event)
        bulk.execute()