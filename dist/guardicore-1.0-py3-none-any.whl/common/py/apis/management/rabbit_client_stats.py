import attr
from functools import partial
from collections import defaultdict


@attr.s
class RabbitMQCallbackStats(object):
    messages_received = attr.ib(default=0)
    spawn_fails = attr.ib(default=0)
    callback_not_registered = attr.ib(default=0)

    def __str__(self):
        return "messages received: {}, failed to spawn: {}, "\
               "callback not registered: {}".format(self.messages_received,
                                                    self.spawn_fails,
                                                    self.callback_not_registered)


@attr.s
class RabbitMQClientStats(object):
    callback_stats_per_message_type =\
        attr.ib(default=attr.Factory(partial(defaultdict, lambda: RabbitMQCallbackStats())))

    def __str__(self):
        callback_stats =\
            "\n".join({"Message: '{}', {}".format(k, v) for k, v in self.callback_stats_per_message_type.items()})

        return "Callback stats per message:\n{}".format(callback_stats)

    def dump_stats(self):
        """dump_stats
        Prepare stats message and clean stats
        """
        stats = "{}".format(self)
        self.callback_stats_per_message_type = defaultdict(lambda: RabbitMQCallbackStats())
        return stats

    def on_message_received(self, message):
        self.callback_stats_per_message_type[message].messages_received += 1

    def on_callback_spawn_failed(self, message):
        self.callback_stats_per_message_type[message].spawn_fails += 1

    def on_callback_not_registered(self, message):
        self.callback_stats_per_message_type[message].callback_not_registered += 1
