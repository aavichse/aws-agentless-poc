from common.py.collection.control.client.component_client import AggregatorComponentControlClient
from common.py.model.aggregator import AggregatorComponent
from common.logger import get_logger

LOG = get_logger(module_name=__name__)


class ProxyMasterControlClient(AggregatorComponentControlClient):
    def __init__(self, component_name=AggregatorComponent.ProxyServer, **kwargs):
        super().__init__(component_name=component_name, **kwargs)

    def report_reveal_events(self, events, **kwargs):
        self.call("/cloud-proxy/report-reveal-events", method="POST", json=events, **kwargs)

    def get_integration_config(self, **kwargs):
        return self.call("/cloud-proxy/get-integration-config", method="GET", **kwargs)

