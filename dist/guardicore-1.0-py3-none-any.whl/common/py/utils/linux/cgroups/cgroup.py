#! /usr/bin/env python
# -*- coding:utf-8 -*-

from __future__ import unicode_literals
from __future__ import print_function
from __future__ import division

import os
import sys
import time
import glob
import signal
import getpass
import warnings

from eventlet.green import subprocess
from common.py.utils.generic import is_process_alive, get_process_name
from common.py.utils.linux.cgroups import BASE_CGROUPS, CgroupsException
from common.py.utils.linux.cgroups.user import create_user_cgroups
from common.logger import get_logger

LOG = get_logger(module_name=__name__)

HIERARCHIES = [ 'cpu', 'memory', ]
MEMORY_DEFAULT = -1
CPU_DEFAULT = 1024


class Cgroup(object):
    @staticmethod
    def init():
        if sys.platform.startswith("win"):
            warnings.warn("cgroup isn't available on 'win32' platform")
            return False

        global HIERARCHIES
        cgroups_mount_path = os.path.join(os.path.dirname(sys.modules[Cgroup.__module__].__file__), "cgroups-mount.sh")
        with open(os.devnull, "w") as devnull:
            subprocess.check_call(["bash", cgroups_mount_path], stdout=devnull, stderr=subprocess.STDOUT)

        for hierarchy in os.listdir(BASE_CGROUPS):
            if hierarchy not in HIERARCHIES and \
                    os.path.exists(os.path.join(BASE_CGROUPS, hierarchy, "tasks")):
                HIERARCHIES.append(hierarchy)

        LOG.debug("Cgroup file system is mounted and initialized (system hierarchies are %r)", HIERARCHIES)

        return True

    def __init__(self, name, hierarchies='all', user='current', initial_pids=None, create_cgroup=True):
        self.name = name

        # get user
        self.user = user
        if self.user == 'current':
            self.user = getpass.getuser()

        # get hierarchies
        if hierarchies == 'all':
            hierarchies = HIERARCHIES
        self.hierarchies = [h for h in hierarchies if h in HIERARCHIES]

        # get user cgroups
        self.user_cgroups = {}
        system_hierarchies = os.listdir(BASE_CGROUPS)
        for hierarchy in self.hierarchies:
            if hierarchy not in system_hierarchies:
                raise CgroupsException("Hierarchy %s is not mounted" % hierarchy)
            user_cgroup = os.path.join(BASE_CGROUPS, hierarchy, self.user)
            self.user_cgroups[hierarchy] = user_cgroup

        self.cgroups = {}
        if create_cgroup:
            create_user_cgroups(self.user, script=False)

            # create name cgroups
            for hierarchy, user_cgroup in self.user_cgroups.items():
                cgroup = os.path.join(user_cgroup, self.name)
                if not os.path.exists(cgroup):
                    os.mkdir(cgroup)
                self.cgroups[hierarchy] = cgroup
        else:
            self.cgroups = {}
            for hierarchy, user_cgroup in self.user_cgroups.items():
                self.cgroups[hierarchy] = os.path.join(user_cgroup, self.name)

        if initial_pids:
            initial_pids_tasks = "\n".join(map(str, initial_pids)) + "\n"
            for hierarchy, cgroup in self.cgroups.items():
                tasks_file = self._get_cgroup_file(hierarchy, 'tasks')
                with open(tasks_file, 'w+') as f:
                    f.write(initial_pids_tasks)

    @classmethod
    def get_cgroup_path(cls, hierarchy, user, name=None):
        if user == 'current':
            user = getpass.getuser()

        paths = [BASE_CGROUPS, hierarchy, user]
        if name:
            paths.append(name)
        return os.path.join(*paths)

    @classmethod
    def exists(cls, name, hierarchies='all', user='current'):
        if user == 'current':
           user = getpass.getuser()
        if hierarchies == 'all':
            hierarchies = os.listdir(BASE_CGROUPS)

        for hierarchy in hierarchies:
            user_cgroup = os.path.join(BASE_CGROUPS, hierarchy, user, name)
            if os.path.exists(user_cgroup):
                return True

        return False

    @staticmethod
    def _ensure_process_dead(pid):
        if not is_process_alive(pid):
            return True

        try:
            os.kill(pid, signal.SIGTERM)
        except OSError as exc:
            LOG.warn("Error sending SIGTERM signal to PID %d (%s): %s", pid, get_process_name(pid), exc)

        time.sleep(0.1)

        if not is_process_alive(pid):
            return True

        try:
            os.kill(pid, signal.SIGKILL)
        except OSError as exc:
            LOG.warn("Error sending SIGKILL signal to PID %d (%s): %s", pid, get_process_name(pid), exc)

        return not is_process_alive(pid)

    @classmethod
    def delete_cgroup(cls, name, hierarchies='all', user='current', task_kill_cb=None):
        if task_kill_cb is None:
            task_kill_cb = cls._ensure_process_dead

        def _read_cgroup_processes(name, hierarchy, user):
            cgroup_procs_file = os.path.join(BASE_CGROUPS, hierarchy, user, name, 'cgroup.procs')
            if not os.path.exists(cgroup_procs_file):
                return set()

            try:
                with open(cgroup_procs_file, "r+") as fp:
                    return set(map(int, fp.readlines()))
            except (IOError, OSError) as exc:
                LOG.warn("Error reading cgroup procs file %s: %s", cgroup_procs_file, exc)
                return set()

        def _append_task_file(tasks, user_tasks_file):
            if not tasks:
                return

            with open(user_tasks_file, 'a+') as f:
                for task in tasks:
                    if is_process_alive(task):
                        try:
                            f.write(task + "\n")
                        except:
                            pass

        if user == 'current':
           user = getpass.getuser()
        if hierarchies == 'all':
            if user:
                cgroup_full_name = os.path.join(user, name)
            else:
                cgroup_full_name = os.path.join(name)

            hierarchies_path = glob.glob(os.path.join(BASE_CGROUPS, "*", cgroup_full_name))
            hierarchies = [hierarchy[len(BASE_CGROUPS) + 1:-(len(cgroup_full_name) + 1)]
                           for hierarchy in hierarchies_path]

        killed_pids = set()

        LOG.debug("Destroying cgroup %s (user %s, hierarchies %s, task_kill_cb=%r)", name, user, hierarchies,
                  task_kill_cb)

        for hierarchy in hierarchies:
            cgroup_tasks = _read_cgroup_processes(name, hierarchy, user)
            top_user_tasks = os.path.join(BASE_CGROUPS, hierarchy, user, 'tasks')

            LOG.debug("Removing cgroup '%s' hierarchy '%s' (with tasks %r)", name, hierarchy,
                      {pid: get_process_name(pid) for pid in cgroup_tasks})

            if task_kill_cb:
                # if current process is part of the cgroup, move it to user cgroup first
                self_pid = os.getpid()
                if self_pid in cgroup_tasks:
                    LOG.debug("Current process (PID %d) is found inside cgroup %s in hierarchy %s, moving it out of"
                              " the cgroup before it could be safely deleted", self_pid, name, hierarchy)
                    cgroup_tasks.remove(self_pid)

                    _append_task_file([self_pid], top_user_tasks)

                cgroup_tasks -= killed_pids

                if cgroup_tasks:
                    LOG.debug("Killing all processes inside cgroup %s in hierarchy %s: %r", name, hierarchy,
                              {pid: get_process_name(pid) for pid in cgroup_tasks})

                    # try and kill all processes inside cgroup
                    non_killed_tasks = [pid for pid in cgroup_tasks if not task_kill_cb(pid)]

                    if non_killed_tasks:
                        LOG.warn("Couldn't kill all tasks inside cgroup %s in hierarchy %s (%r), moving it to user"
                                 " cgroup", name, hierarchy, non_killed_tasks)

                        _append_task_file(non_killed_tasks, top_user_tasks)

                    killed_pids = killed_pids.union(cgroup_tasks)
            else:
                _append_task_file(cgroup_tasks,
                                  os.path.join(BASE_CGROUPS, hierarchy, user, 'tasks'))

            cgroup_dir = os.path.join(BASE_CGROUPS, hierarchy, user, name)
            if os.path.exists(cgroup_dir):
                try:
                    os.rmdir(cgroup_dir)
                except OSError as exc:
                    LOG.warn("Error while trying to delete cgroup %s directory (%s): %s", name, cgroup_dir, exc)

        if task_kill_cb and killed_pids:
            LOG.debug("Killed %d processes during the removal of cgroup %s: %r", len(killed_pids), name,
                      list(killed_pids))

    def _get_cgroup_file(self, hierarchy, file_name):
        return os.path.join(self.cgroups[hierarchy], file_name)

    def _get_user_file(self, hierarchy, file_name):
        return os.path.join(self.user_cgroups[hierarchy], file_name)

    def delete(self):
        for hierarchy, cgroup in self.cgroups.items():
            # Put all pids of name cgroup in user cgroup
            tasks_file = self._get_cgroup_file(hierarchy, 'tasks')
            if os.path.exists(tasks_file):
                with open(tasks_file, 'r+') as f:
                    tasks = [task for task in f.read().splitlines() if task]
                user_tasks_file =  self._get_user_file(hierarchy, 'tasks')

                # because copyings tasks from older cgroup to the general cgroup isn't an atomic action
                # some tasks might have died in the time passed between reading and writing tasks from
                # both files, there for we must check for each task if it's still running and expect
                # the write operation to fail with "Invalid Argument" error
                if tasks:
                    try:
                        with open(user_tasks_file, 'a+') as f:
                            for task in tasks:
                                if is_process_alive(int(task)):
                                    try:
                                        f.write(task + "\n")
                                    except:
                                        pass
                    except:
                        pass

            if os.path.exists(cgroup):
                try:
                    os.rmdir(cgroup)
                except OSError as exc:
                    LOG.warn("Error while trying to delete cgroup %s directory (%s): %s", self.name, cgroup, exc)

    # PIDS

    def add(self, pid):
        try:
            os.kill(pid, 0)
        except OSError:
            raise CgroupsException('Pid %s does not exists' % pid)
        for hierarchy, cgroup in self.cgroups.items():
            tasks_file = self._get_cgroup_file(hierarchy, 'tasks')
            with open(tasks_file, 'r+') as f:
                cgroups_pids = f.read().split('\n')
            if not str(pid) in cgroups_pids:
                with open(tasks_file, 'a+') as f:
                    f.write('%s\n' % pid)

    def remove(self, pid):
        try:
            os.kill(pid, 0)
        except OSError:
            raise CgroupsException('Pid %s does not exists' % pid)
        for hierarchy, cgroup in self.cgroups.items():
            tasks_file = self._get_cgroup_file(hierarchy, 'tasks')
            with open(tasks_file, 'r+') as f:
                pids = f.read().split('\n')
                if str(pid) in pids:
                    user_tasks_file = self._get_user_file(hierarchy, 'tasks')
                    with open(user_tasks_file, 'a+') as f:
                        f.write('%s\n' % pid)

    @property
    def pids(self):
        hierarchy = self.hierarchies[0]
        tasks_file = self._get_cgroup_file(hierarchy, 'tasks')
        if not os.path.exists(tasks_file):
            return []

        with open(tasks_file, 'r+') as f:
            pids = f.read().split('\n')[:-1]
        pids = [int(pid) for pid in pids]
        return pids

    @property
    def processes(self):
        hierarchy = self.hierarchies[0]
        tasks_file = self._get_cgroup_file(hierarchy, 'cgroup.procs')
        if not os.path.exists(tasks_file):
            return []

        with open(tasks_file, 'r+') as f:
            pids = f.read().split('\n')[:-1]
        pids = [int(pid) for pid in pids]
        return pids

    # CPU

    def _format_cpu_value(self, limit=None):
        if limit is None:
            value = CPU_DEFAULT
        else:
            try:
                limit = float(limit)
            except ValueError:
                raise CgroupsException("Limit must be convertible to a float")
            else:
                if limit <= float(0) or limit > float(100):
                    raise CgroupsException("Limit must be between 0 and 100")
                else:
                    limit = limit / 100
                    value = int(round(CPU_DEFAULT * limit))
        return value

    def set_cpu_limit(self, limit=None):
        if 'cpu' in self.cgroups:
            value = self._format_cpu_value(limit)
            cpu_shares_file = self._get_cgroup_file('cpu', 'cpu.shares')
            with open(cpu_shares_file, 'w+') as f:
                f.write('%s\n' % value)
        else:
            raise CgroupsException("CPU hierarchy not available in this cgroup")

    @property
    def cpu_limit(self):
        if 'cpu' in self.cgroups:
            cpu_shares_file = self._get_cgroup_file('cpu', 'cpu.shares')
            with open(cpu_shares_file, 'r+') as f:
                value = int(f.read().split('\n')[0])
                value = int(round((value / CPU_DEFAULT) * 100))
                return value
        else:
            return None

    # MEMORY

    def _format_memory_value(self, unit, limit=None):
        units = ('bytes', 'kilobytes', 'megabytes', 'gigabytes')
        if unit not in units:
            raise CgroupsException('Unit must be in %s' % units)
        if limit is None:
            value = MEMORY_DEFAULT
        else:
            try:
                limit = int(limit)
            except ValueError:
                raise CgroupsException('Limit must be convertible to an int')
            else:
                if unit == 'bytes':
                    value = limit
                elif unit == 'kilobytes':
                    value = limit * 1024
                elif unit == 'megabytes':
                    value = limit * 1024 * 1024
                elif unit == 'gigabytes':
                    value = limit * 1024 * 1024 * 1024
        return value

    def set_memory_limit(self, limit=None, unit='megabytes'):
        if 'memory' in self.cgroups:
            value = self._format_memory_value(unit, limit)
            memory_limit_file = self._get_cgroup_file(
                'memory', 'memory.limit_in_bytes')
            with open(memory_limit_file, 'w+') as f:
                f.write('%s\n' % value)
        else:
            raise CgroupsException(
                'MEMORY hierarchy not available in this cgroup')

    @property
    def memory_limit(self):
        if 'memory' in self.cgroups:
            memory_limit_file = self._get_cgroup_file(
                'memory', 'memory.limit_in_bytes')
            with open(memory_limit_file, 'r+') as f:
                value = f.read().split('\n')[0]
                value = int(int(value) / 1024 / 1024)
                return value
        else:
            return None
