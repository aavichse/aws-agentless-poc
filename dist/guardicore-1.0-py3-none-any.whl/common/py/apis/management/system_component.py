import datetime
import logging
import mmh3
import socket
import uuid
from functools import wraps, reduce
from operator import xor
import json
import os

from common.py.apis import DATA_RPC_QUEUE_POOL_SIZE, numbered_queue_name, RPCExchange, RPCMessage, \
    RPCRoutingKey, MessagePriority
from common.py.apis.management import UNKNOWN_API_VERSION, RPCTimeoutError, ManagementAPIError
from common.py.apis.management.rabbit import RabbitMQManagementAPI
from common.get_version.get_version import get_version
from common.get_version.get_install_time import get_install_time
from common.logger import get_logger
from common.py.models.events import EventStatus
from common.py.network.funcs import get_best_connect_ip, get_interfaces_info
from common.py.utils.config.to_jsonschema import intersect_jsonschema_config, union_jsonschemas
from common.py.utils.dictutils import recursive_update_dict
from common.py.utils.encoding.json.json_convert import encode_obj_class
from common.py.utils.setup_wizard.consts import SETUP_CONFIGURATION_PATH
from common.py.model.collection_setup_configuration import SetupConfiguration, InvalidSetupConfiguration

__author__ = 'Amit'

LOG = get_logger(module_name=__name__)


def disable_anonymous(f):
    @wraps(f)
    def decorated(self, *args, **kwargs):
        if self.anonymous:
            return

        return f(self, *args, **kwargs)

    return decorated


class SystemComponentManagementAPI(object):
    COMPONENT_TYPE = None  #: overridden by subclasses
    COMPONENT_BASE_URI = None  #: overridden by subclasses
    RABBIT_API_CLASS = RabbitMQManagementAPI

    def __init__(self, component_id, management_hosts, component_details=None, version=UNKNOWN_API_VERSION,
                 anonymous=False, configuration_schema=None, do_component_handshake=True, extra_routing_keys=None,
                 component_ip_address=None, **kwargs):
        """
        :param component_id: unique component id
        :param management_hosts: list of management host addresses
        :param component_details: optional component details dict
        :param version: api version
        :param anonymous: if True, component is an anonymous listener on the exchange (does not register itself
            to the management).
        :param do_component_handshake: if True, component do connectivity check and i-am-alive procedure
        :param extra_routing_keys: any extra routing keys to bind this API to
        :param component_ip_address: by default ip address is inferred from interface connected
            to mgmt host, but if it is behind proxy, needs to be explictly set
        :param kwargs: rabbit connection arguments
        """
        assert management_hosts

        self.logger = logging.getLogger('guardicore.SystemComponentManagementAPI')

        routing_keys = [component_id, RPCRoutingKey.BROADCAST_ROUTING_KEY]
        if extra_routing_keys:
            routing_keys += extra_routing_keys

        management_host = None
        for index, management_host in enumerate(management_hosts):
            LOG.info("Attempting rabbit connection for component '%s' toward management host '%s'",
                     component_id, management_host)
            try:
                self.rabbitapi = self.RABBIT_API_CLASS(management_host=management_host, component_id=component_id,
                                                       routing_keys=routing_keys, **kwargs)
                break
            except Exception as exc:
                if index < len(management_hosts) - 1:
                    LOG.warn("Error connecting to rabbit from component '%s' to over management host '%s': %s",
                             component_id, management_host, exc)
                else:
                    raise
        self.management_host = management_host

        self.component_id = component_id
        self.version = version
        self.component_details = component_details
        self.component_details['version'] = version
        self.component_details['configuration_schema'] = configuration_schema

        if component_ip_address is None:
            best_connect_ips = map(get_best_connect_ip, management_hosts)
            best_connect_ips = list(filter(lambda ip: not ip.startswith("127.0."), best_connect_ips))
            if not best_connect_ips:
                best_connect_ip = get_best_connect_ip(self.management_host)
            else:
                best_connect_ip = best_connect_ips[0]
        else:
            best_connect_ip = component_ip_address

        version_info = get_version()

        self.component_details['ip_address'] = best_connect_ip
        self.component_details['interfaces'] = get_interfaces_info()
        self.component_details['full_version'] = version_info.get('full_version')
        self.component_details['build_commit'] = version_info.get('build')
        self.component_details['build_date'] = version_info.get('creation time')
        self.component_details['install_date'] = get_install_time()
        self.component_details.setdefault('hostname', socket.gethostname())
        self.component_status = None

        self.anonymous = anonymous

        public_zk_address = self.get_external_aggr_address()
        if public_zk_address:
            self.component_details['public_aggr_address'] = public_zk_address

        if do_component_handshake:
            if not self.check_management_connectivity():
                raise ManagementAPIError("Management Connectivity Check Failed.")

            try:
                self.send_i_am_alive()
            except:
                self.rabbitapi.close()
                raise

    @property
    def closed(self):
        return self.rabbitapi.close_required

    def close(self):
        self.rabbitapi.close()

    def add_error_callback(self, callback_func):
        """
        See rabbitapi.add_error_callback
        """
        self.rabbitapi.add_error_callback(callback_func)

    def add_read_loop_error_callback(self, callback_func):
        """
        See rabbitapi.add_read_loop_error_callback
        """
        self.rabbitapi.add_read_loop_error_callback(callback_func)

    def add_msg_callback_error_callback(self, callback_func):
        """
        See rabbitapi.add_msg_callback_error_callback
        """
        self.rabbitapi.add_msg_callback_error_callback(callback_func)

    def get_management_utcnow(self):
        """
        Get current datetime utctimestamp, adjusted to management time.
        :return:
        """
        return self.rabbitapi.get_management_utcnow()

    def get_configuration(self):
        return self.rabbitapi.call_management_rpc(RPCMessage.Control.COMPONENT_GET_CONFIGURATION_RPC_FUNC_NAME,
                                                  component_id=self.component_id,
                                                  component_type=self.COMPONENT_TYPE,
                                                  component_details=self.component_details,
                                                  component_status=self.component_status,
                                                  anonymous=self.anonymous,
                                                  blocking=True)

    def check_management_connectivity(self):
        """
        Check connectivity to management server.
        :return:
        """
        try:
            self.logger.info("doing mgmt connectivity check with low priority")
            response = self.rabbitapi.call_management_rpc(RPCMessage.Control.CONNECTIVITY_CHECK_RPC_FUNC_NAME,
                                                          component_id=self.component_id,
                                                          blocking=True,
                                                          priority=MessagePriority.LOW_MESSAGE_PRIORITY)
            assert response is True, "Assertion Error: got unexpected response %r from '%s' for '%s'" % \
                                     (response, RPCMessage.Control.CONNECTIVITY_CHECK_RPC_FUNC_NAME, self.component_id)
            self.logger.debug("Management connectivity check successfull")
            return True
        except RPCTimeoutError:
            self.logger.warning("Management connectivity check failed!")
            return False

    @disable_anonymous
    def send_i_am_alive(self):
        self.rabbitapi.call_management_rpc(RPCMessage.Control.COMPONENT_ALIVE_RPC_FUNC_NAME,
                                           component_id=self.component_id,
                                           component_type=self.COMPONENT_TYPE,
                                           component_details=self.component_details,
                                           blocking=True)

    @disable_anonymous
    def send_details_update(self):
        self.rabbitapi.call_management_rpc(RPCMessage.Control.COMPONENT_UPDATE_DETAILS_RPC_FUNC_NAME,
                                           component_id=self.component_id,
                                           component_type=self.COMPONENT_TYPE,
                                           component_details=self.component_details,
                                           component_status=self.component_status)

    def update_schema(self, schema, unite_with_old_schema=True):
        if unite_with_old_schema:
            self.component_details['configuration_schema'] = union_jsonschemas(
                self.component_details['configuration_schema'], schema)
        else:
            self.component_details['configuration_schema'] = schema
        self.send_details_update()

    def _extract_component_configuration(self, source_configuration):
        """
        Given source configuration as sent from the management (which includes group configuration & private
        components configuration), extract the per-component configuration.
        :param source_configuration:
        :return:
        """
        configuration = {}
        recursive_update_dict(configuration, source_configuration['group'])
        recursive_update_dict(configuration, source_configuration['components'].get(self.component_id, {}))
        configuration = intersect_jsonschema_config(self.component_details['configuration_schema'], configuration)
        return configuration

    def update_configuration_and_run_callback(self, callback_func):
        conf = self.get_configuration()
        return callback_func(conf)

    def add_configuration_update_callback(self, callback_func, initial_call=True):
        """

        :param callback_func: A function which will be called on config updates with a configuration dict
        :param initial_call: Should the callback function be called once anyway
        :return:
        """

        def _initial_call_cb():
            return self.update_configuration_and_run_callback(callback_func)

        self.rabbitapi.add_callback(RPCMessage.Control.CONFIGURATION_CHANGE_MESSAGE_TYPE,
                                    lambda message: callback_func(
                                        self._extract_component_configuration(message['configuration'])),
                                    initial_call=initial_call,
                                    initial_call_func=_initial_call_cb)

    def add_system_configuration_update_callback(self, callback_func, initial_call=True):
        """

        :param callback_func: A function which will be called on config updates with a configuration dict
        :param initial_call: Should the callback function be called once anyway
        :return:
        """

        self.rabbitapi.add_callback(RPCMessage.Configuration.CONFIGURATION_CHANGED_MESSAGE,
                                    lambda message: callback_func(message['configuration']),
                                    initial_call=initial_call,
                                    initial_call_func=lambda: callback_func(self.get_system_configuration()))

    def _report_event(self, rpc_func_name, event_type, event, exchange, routing_key, **kwargs):
        event.setdefault('time', datetime.datetime.utcnow())
        event.update(dict(event_type=int(event_type),
                          uuid=str(uuid.uuid4()),
                          event_source=self.component_id), )
        self.rabbitapi.call_management_rpc(rpc_func_name, raw_event=event, exchange=exchange, routing_key=routing_key,
                                           **kwargs)

    def _report_mongoengine_event(self, event, exchange, routing_key,
                                  rpc_func_name=RPCMessage.Control.REPORT_MONGOENGINE_EVENT_RPC_FUNC_NAME, **kwargs):
        event.validate()  # Make sure all fields are OK before sending; throws ValidationError if not
        self.rabbitapi.call_management_rpc(rpc_func_name,
                                           exchange=exchange,
                                           routing_key=routing_key,
                                           event_json=event.to_json(),
                                           event_class=encode_obj_class(event),
                                           **kwargs)

    def report_system_event(self, event_type, cause, description, status=EventStatus.INFO, **kwargs):
        """

        :param event_type:
        :param cause: A short description of event's cause
        :param description: A long description
        :param status: event status (out of EventStatus values).
        :param kwargs:
        :return:
        """
        assert isinstance(status, EventStatus)

        event = {
            "description": description,
            "status": status,
            "cause": cause,
        }
        event.update(kwargs)
        self._report_event(rpc_func_name=RPCMessage.Logs.REPORT_COMPONENT_SYSTEM_EVENT_RPC_FUNC_NAME,
                           event_type=event_type,
                           event=event,
                           exchange=RPCExchange.LOG_EVENTS_EXCHANGE_NAME,
                           routing_key=RPCMessage.Logs.REPORT_COMPONENT_SYSTEM_EVENT_RPC_FUNC_NAME)

    def get_system_configuration(self):
        """
        Get system configuration.
        :return: current system configuration, as a dict instance.
        """
        return self.rabbitapi.call_management_rpc(RPCMessage.Aggregator.AGGREGATOR_GET_SYSTEM_CONFIGURATION_RPC_FUNC_NAME,
                                                  blocking=True)

    def get_external_aggr_address(self, file_path=SETUP_CONFIGURATION_PATH):
        """
        Reads a configuration file and extracts the 'public_aggr_address' value.
        Necessary for zk cross-region function.
        :param file_path: Path to the configuration file.
        :return: The 'public_aggr_address' value or None if not found or any error occurs.
        """
        public_address = None

        try:
            setup_conf = SetupConfiguration(path=file_path, load=True)
            public_address = setup_conf.get('public_aggr_address', None) or None

            if public_address is None:
                LOG.warn("Field 'public_aggr_address' does not exist in the file: %s", file_path)

        except InvalidSetupConfiguration as e:
            pass

        return public_address


def build_destination_routing_key(event, queue_name_template, key_names, is_json=False):
    """
    Used to build a routing key that matches a queue for that event
    :param event: the event from which to calculate the routing key suffix
    :param queue_name_template: a template for the queue name to use
    :param key_names: the key names to look for in the event
    :param is_json: is the event in json form or not (otherwise some kind of object)
    :return: a routing key that matches the form of <queue_prefix>_<queue_number>
            i.e. deception_rpc_server_82
    """
    keys = {}
    if not is_json:
        for key_name in key_names:
            keys[key_name] = getattr(event, key_name)
    else:
        for key_name in key_names:
            keys[key_name] = event[key_name]

    routing_key_suffix = calc_routing_key_suffix(*keys.values())
    numbered_queue_name(queue_name_template, routing_key_suffix)


def calc_routing_key_suffix(*items):
    """
    Calculates the routing key for the items.
    This function is order-invariant, meaning it does not care about the order of the items passed to it.
    :param items Strings to be hashed.
    """
    output_hash = reduce(xor, map(mmh3.hash, items))
    return output_hash % DATA_RPC_QUEUE_POOL_SIZE + 1


class CannotCalculateRoutingKey(Exception):
    def __init__(self, event):
        message = 'Unable to calculate routing key for event {}'.format(event)
        super(CannotCalculateRoutingKey, self).__init__(message)
