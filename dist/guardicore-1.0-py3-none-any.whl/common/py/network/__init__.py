from enum import IntEnum

__author__ = 'Eddie'


class ConnectionTestResult(IntEnum):
    Success = 0
    Failure = 1
