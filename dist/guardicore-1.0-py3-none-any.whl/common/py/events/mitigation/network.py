import datetime
import ipaddress
import uuid
from enum import Enum, IntEnum

import attr

from common.py.events import IPVersion, IPProtocol
from common.py.events.attrs import string_attr, datetime_attr, enum_attr, Dictable, dict_attr, bool_attr, int_attr, \
    unicode_attr, list_attr, NO_DEFAULT
from common.py.events.mitigation.machine_details import AgentType, AgentAggregateType
from common.py.events.mitigation.process import ImageHashType
from common.py.events.visibility.enforcement_policy import DEFAULT_CORPORATE_FLAG_IF_NOT_EXIST

UNKNOWN_SOURCE_IP = '0.0.0.0'
ANY_PORT_IDENTIFIER = '*'

# Special rule IDs used by the enforcement agent in special operation modes
DEFAULT_RULE = 'default'
MONITOR_MODE_RULE_ID = 'monitor mode'
FAIL_OPEN_RULE_ID = 'EmptyPolicyFailOpen'
IMPLICIT_RULES_PREFIX = 'implicit'
UNKNWON_RULE = 'unknown'
DNS_SECURITY_RULE = 'DNS Security'


class ContainerNetworkMode(Enum):
    BRIDGE = "bridge"
    HOST = "host"
    DEFAULT = "default"


class TrafficDirection(IntEnum):
    EastWest = 1
    NorthSouth = 2
    SouthNorth = 3
    NorthNorth = 4


class EnforcementMode(IntEnum):
    RevealOnly = 1
    Monitoring = 2
    Enforcing = 3


class InterfaceProfile(IntEnum):
    Unknown = 0
    Corporate = 1
    OffCorporate = 2


class NATType(Enum):
    SNAT = "SNAT"
    DNAT = "DNAT"
    SNAT_AND_DNAT = "SNAT_AND_DNAT"


class ConnectionEventType(IntEnum):
    NewSuccessOutgoingConnection = 0
    NewSuccessIncomingConnection = 1
    NewFailedOutgoingConnection = 2
    NewFailedIncomingConnection = 3
    NewAllowedOutgoingConnection = 4  # allowed but unknown if failed/successful.
    ConnectionClosed = 5
    ServerListen = 6
    ServerClosed = 7
    NatConnection = 8
    NewSuccessMatchedConnection = 9
    NewFailedMatchedConnection = 10

    @property
    def is_new_connection(self):
        return self in [ConnectionEventType.NewSuccessOutgoingConnection,
                        ConnectionEventType.NewSuccessIncomingConnection,
                        ConnectionEventType.NewFailedOutgoingConnection,
                        ConnectionEventType.NewFailedIncomingConnection,
                        ConnectionEventType.NewAllowedOutgoingConnection]

    @property
    def is_closed_connection(self):
        return self in [ConnectionEventType.ConnectionClosed]

    @property
    def is_server(self):
        return self in [ConnectionEventType.ServerListen,
                        ConnectionEventType.ServerClosed]

    @property
    def is_incoming(self):
        return self in [ConnectionEventType.NewSuccessIncomingConnection,
                        ConnectionEventType.NewFailedIncomingConnection]

    @property
    def is_outgoing(self):
        return self in [ConnectionEventType.NewSuccessOutgoingConnection,
                        ConnectionEventType.NewFailedOutgoingConnection,
                        ConnectionEventType.NewAllowedOutgoingConnection]

    @property
    def is_successful(self):
        return self in [ConnectionEventType.NewSuccessIncomingConnection,
                        ConnectionEventType.NewSuccessOutgoingConnection,
                        ConnectionEventType.NewFailedMatchedConnection]

    @property
    def is_failed(self):
        return self in [ConnectionEventType.NewFailedIncomingConnection,
                        ConnectionEventType.NewFailedOutgoingConnection,
                        ConnectionEventType.NewSuccessMatchedConnection]

    @property
    def is_allowed(self):
        return self in [ConnectionEventType.NewAllowedOutgoingConnection]

    @property
    def is_matched_type(self):
        return self in [ConnectionEventType.NewSuccessMatchedConnection, ConnectionEventType.NewFailedMatchedConnection]

    @property
    def is_nat(self):
        return self in [ConnectionEventType.NatConnection]


@attr.s
class GenericMatchingInfo(Dictable):
    rule_id = string_attr(default=None)
    ruleset_name = string_attr(default=None)
    revision = int_attr(default=0)


class AgentMatchingVerdict(Enum):
    # TODO this duplicates enforcement.model.rule.AgentRule.Verdict.
    ALLOW = "ALLOW"
    BLOCK = "BLOCK"
    ALERT = "ALERT"


class ProviderMatchingVerdict(Enum):
    ALLOW = "ALLOW"
    BLOCK = "BLOCK"


@attr.s
class AgentMatchingInfo(GenericMatchingInfo):
    verdict = enum_attr(AgentMatchingVerdict, default=NO_DEFAULT)
    source_ip = string_attr(default=None)
    destination_ip = string_attr(default=None)
    dc_inventory_revision = int_attr(default=0)
    section_position = string_attr(default=None)
    connector_src_rule_id = string_attr(default=None)
    connector_dst_rule_id = string_attr(default=None)
    rule_name = string_attr(default=None)

    def as_dict(self):
        # to storage-compatible dict.
        return dict(verdict=self.verdict.name,
                    rule_id=self.rule_id,
                    ruleset_name=self.ruleset_name,
                    revision=self.revision,
                    source_ip=self.source_ip,
                    destination_ip=self.destination_ip,
                    dc_inventory_revision=self.dc_inventory_revision,
                    section_position=self.section_position,
                    connector_src_rule_id=self.connector_src_rule_id,
                    connector_dst_rule_id=self.connector_dst_rule_id)


@attr.s
class RedirectionInfo(Dictable):
    hpvm_component_id = string_attr(default=None)
    service_provider_id = string_attr(default=None)
    incident_id = string_attr(default=None)


class ManagementMatchingVerdict(IntEnum):
    # combined verdict - management + two agents
    BLOCKED_BY_SOURCE = 1
    BLOCKED_BY_DESTINATION = 2
    ALERTED_BY_MANAGEMENT = 3
    BLOCKED_BY_MANAGEMENT = 4
    ALLOWED = 5

    @property
    def normal(self):
        return self.name.lower()


@attr.s
class ManagementMatchingInfo(GenericMatchingInfo):
    rule_action = int_attr(default=NO_DEFAULT)
    verdict = enum_attr(ManagementMatchingVerdict, default=None)


@attr.s
class ProviderMatchingInfo(GenericMatchingInfo):
    provider_rule_id = string_attr(default=None)
    verdict = enum_attr(ProviderMatchingVerdict, default=ProviderMatchingVerdict.ALLOW)


class JointMatchingVerdict(IntEnum):
    BLOCKED_BY_SOURCE = 1
    BLOCKED_BY_DESTINATION = 2
    BLOCKED_BY_SOURCE_ALLOWED_BY_MANAGEMENT = 3
    BLOCKED_BY_DESTINATION_ALLOWED_BY_MANAGEMENT = 4
    BLOCKED_BY_SOURCE_ALERTED_BY_MANAGEMENT = 5
    BLOCKED_BY_DESTINATION_ALERTED_BY_MANAGEMENT = 6
    BLOCKED_BY_MANAGEMENT = 7
    ALLOWED = 8
    ALLOWED_BY_AGENTS_ALERTED_BY_MANAGEMENT = 9
    ALLOWED_BY_AGENTS_BLOCKED_BY_MANAGEMENT = 10
    ALERTED_BY_SOURCE = 11
    ALERTED_BY_DESTINATION = 12
    ALERTED_BY_SOURCE_ALLOWED_BY_MANAGEMENT = 13
    ALERTED_BY_DESTINATION_ALLOWED_BY_MANAGEMENT = 14
    ALERTED_BY_AGENTS_BLOCKED_BY_MANAGEMENT = 15
    ALERTED_BY_MANAGEMENT = 16
    WILL_BE_BLOCKED_BY_SOURCE = 17
    WILL_BE_BLOCKED_BY_DESTINATION = 18
    WILL_BE_BLOCKED_BY_SOURCE_ALLOWED_BY_MANAGEMENT = 19
    WILL_BE_BLOCKED_BY_DESTINATION_ALLOWED_BY_MANAGEMENT = 20
    WILL_BE_BLOCKED_BY_SOURCE_ALERTED_BY_MANAGEMENT = 21
    WILL_BE_BLOCKED_BY_DESTINATION_ALERTED_BY_MANAGEMENT = 22

    ALLOW_AND_ENCRYPTED = 30
    ALERTED_BY_SOURCE_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT = 31
    ALERTED_BY_DESTINATION_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT = 32
    BLOCKED_BY_SOURCE_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT = 34
    BLOCKED_BY_DESTINATION_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT = 35
    WILL_BE_BLOCKED_BY_SOURCE_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT = 36
    WILL_BE_BLOCKED_BY_DEST_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT = 37

    @classmethod
    def get_could_not_block(cls):
        return [
            JointMatchingVerdict.BLOCKED_BY_MANAGEMENT,
            JointMatchingVerdict.ALLOWED_BY_AGENTS_BLOCKED_BY_MANAGEMENT,
            JointMatchingVerdict.ALERTED_BY_AGENTS_BLOCKED_BY_MANAGEMENT
        ]

    @property
    def is_could_not_block(self):
        return self in self.get_could_not_block()

    @classmethod
    def get_blocked_by_source_agent(cls):
        return [
            JointMatchingVerdict.BLOCKED_BY_SOURCE,
            JointMatchingVerdict.BLOCKED_BY_SOURCE_ALLOWED_BY_MANAGEMENT,
            JointMatchingVerdict.BLOCKED_BY_SOURCE_ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.BLOCKED_BY_SOURCE_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT
        ]

    @classmethod
    def get_blocked_by_destination_agent(cls):
        return [
            JointMatchingVerdict.BLOCKED_BY_DESTINATION,
            JointMatchingVerdict.BLOCKED_BY_DESTINATION_ALLOWED_BY_MANAGEMENT,
            JointMatchingVerdict.BLOCKED_BY_DESTINATION_ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.BLOCKED_BY_DESTINATION_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT
        ]

    @classmethod
    def get_will_be_blocked_by_source_agent(cls):
        return [
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_SOURCE,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_SOURCE_ALLOWED_BY_MANAGEMENT,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_SOURCE_ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_SOURCE_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT
        ]

    @classmethod
    def get_will_be_blocked_by_destination_agent(cls):
        return [
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_DESTINATION,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_DESTINATION_ALLOWED_BY_MANAGEMENT,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_DESTINATION_ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_DEST_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT
        ]

    @classmethod
    def get_blocked_by_agents(cls):
        return cls.get_blocked_by_source_agent() + cls.get_blocked_by_destination_agent()

    @classmethod
    def get_will_be_blocked_by_agents(cls):
        return cls.get_will_be_blocked_by_source_agent() + cls.get_will_be_blocked_by_destination_agent()

    @property
    def is_blocked_by_source_agent(self):
        return self in self.get_blocked_by_source_agent()

    @property
    def is_blocked_by_destination_agent(self):
        return self in self.get_blocked_by_destination_agent()

    @property
    def is_will_be_blocked_by_destination_agent(self):
        return self in self.get_will_be_blocked_by_destination_agent()

    @property
    def is_will_be_blocked_by_source_agent(self):
        return self in self.get_will_be_blocked_by_source_agent()

    @property
    def is_blocked_by_agents(self):
        return self.is_blocked_by_source_agent or self.is_blocked_by_destination_agent

    @property
    def is_will_be_blocked_by_agents(self):
        return self.is_will_be_blocked_by_source_agent or self.is_will_be_blocked_by_destination_agent

    @classmethod
    def get_allowed_and_encrypted(cls):
        return [
            JointMatchingVerdict.ALLOW_AND_ENCRYPTED,
            JointMatchingVerdict.ALERTED_BY_SOURCE_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT,
            JointMatchingVerdict.ALERTED_BY_DESTINATION_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT,
            JointMatchingVerdict.BLOCKED_BY_SOURCE_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT,
            JointMatchingVerdict.BLOCKED_BY_DESTINATION_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_SOURCE_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_DEST_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT,
        ]

    @property
    def is_allowed_and_encrypted(self):
        return self in self.get_allowed_and_encrypted()

    @classmethod
    def get_alerted(cls):
        return [
            JointMatchingVerdict.ALLOWED_BY_AGENTS_ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.ALERTED_BY_SOURCE_ALLOWED_BY_MANAGEMENT,
            JointMatchingVerdict.ALERTED_BY_DESTINATION_ALLOWED_BY_MANAGEMENT,
            JointMatchingVerdict.ALERTED_BY_SOURCE,
            JointMatchingVerdict.ALERTED_BY_DESTINATION,
            JointMatchingVerdict.ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.ALERTED_BY_AGENTS_BLOCKED_BY_MANAGEMENT,
            JointMatchingVerdict.BLOCKED_BY_SOURCE_ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.BLOCKED_BY_DESTINATION_ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_SOURCE_ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_DESTINATION_ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.ALERTED_BY_SOURCE_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT,
            JointMatchingVerdict.ALERTED_BY_DESTINATION_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT,
        ]

    @property
    def is_alerted(self):
        return self in self.get_alerted()

    @classmethod
    def get_not_mismatched(cls):
        return [
            JointMatchingVerdict.BLOCKED_BY_SOURCE,
            JointMatchingVerdict.BLOCKED_BY_DESTINATION,
            JointMatchingVerdict.BLOCKED_BY_MANAGEMENT,
            JointMatchingVerdict.ALLOWED,
            JointMatchingVerdict.ALERTED_BY_SOURCE,
            JointMatchingVerdict.ALERTED_BY_DESTINATION,
            JointMatchingVerdict.ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_DESTINATION,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_SOURCE,
            JointMatchingVerdict.ALLOW_AND_ENCRYPTED,
        ]

    @classmethod
    def get_mismatched(cls):
        return [
            JointMatchingVerdict.BLOCKED_BY_SOURCE_ALLOWED_BY_MANAGEMENT,
            JointMatchingVerdict.BLOCKED_BY_DESTINATION_ALLOWED_BY_MANAGEMENT,
            JointMatchingVerdict.BLOCKED_BY_SOURCE_ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.BLOCKED_BY_DESTINATION_ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.ALLOWED_BY_AGENTS_ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.ALLOWED_BY_AGENTS_BLOCKED_BY_MANAGEMENT,
            JointMatchingVerdict.ALERTED_BY_SOURCE_ALLOWED_BY_MANAGEMENT,
            JointMatchingVerdict.ALERTED_BY_DESTINATION_ALLOWED_BY_MANAGEMENT,
            JointMatchingVerdict.ALERTED_BY_AGENTS_BLOCKED_BY_MANAGEMENT,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_SOURCE_ALLOWED_BY_MANAGEMENT,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_DESTINATION_ALLOWED_BY_MANAGEMENT,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_SOURCE_ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_DESTINATION_ALERTED_BY_MANAGEMENT,
            JointMatchingVerdict.BLOCKED_BY_SOURCE_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT,
            JointMatchingVerdict.BLOCKED_BY_DESTINATION_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT,
            JointMatchingVerdict.ALERTED_BY_SOURCE_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT,
            JointMatchingVerdict.ALERTED_BY_DESTINATION_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_SOURCE_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT,
            JointMatchingVerdict.WILL_BE_BLOCKED_BY_DEST_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT,
        ]

    @property
    def has_mismatch_alert(self):
        return self in self.get_mismatched()

    @property
    def has_verdict_mismatch(self):
        return self.has_mismatch_alert or self.is_could_not_block

    @classmethod
    def get_blocked_by_source(cls, enforcement_mode):
        if enforcement_mode == EnforcementMode.Monitoring:
            return JointMatchingVerdict.WILL_BE_BLOCKED_BY_SOURCE

        return JointMatchingVerdict.BLOCKED_BY_SOURCE

    @classmethod
    def get_blocked_by_destination(cls, enforcement_mode):
        if enforcement_mode == EnforcementMode.Monitoring:
            return JointMatchingVerdict.WILL_BE_BLOCKED_BY_DESTINATION

        return JointMatchingVerdict.BLOCKED_BY_DESTINATION

    @classmethod
    def get_blocked_by_source_alerted_by_management(cls, enforcement_mode):
        if enforcement_mode == EnforcementMode.Monitoring:
            return JointMatchingVerdict.WILL_BE_BLOCKED_BY_SOURCE_ALERTED_BY_MANAGEMENT

        return JointMatchingVerdict.BLOCKED_BY_SOURCE_ALERTED_BY_MANAGEMENT

    @classmethod
    def get_blocked_by_destination_alerted_by_management(cls, enforcement_mode):
        if enforcement_mode == EnforcementMode.Monitoring:
            return JointMatchingVerdict.WILL_BE_BLOCKED_BY_DESTINATION_ALERTED_BY_MANAGEMENT

        return JointMatchingVerdict.BLOCKED_BY_DESTINATION_ALERTED_BY_MANAGEMENT

    @classmethod
    def get_blocked_by_source_allowed_by_management(cls, enforcement_mode):
        if enforcement_mode == EnforcementMode.Monitoring:
            return JointMatchingVerdict.WILL_BE_BLOCKED_BY_SOURCE_ALLOWED_BY_MANAGEMENT

        return JointMatchingVerdict.BLOCKED_BY_SOURCE_ALLOWED_BY_MANAGEMENT

    @classmethod
    def get_blocked_by_source_allowed_and_encrypted_by_management(cls, enforcement_mode):
        if enforcement_mode == EnforcementMode.Monitoring:
            return JointMatchingVerdict.WILL_BE_BLOCKED_BY_SOURCE_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT

        return JointMatchingVerdict.BLOCKED_BY_SOURCE_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT

    @classmethod
    def get_blocked_by_destination_allowed_by_management(cls, enforcement_mode):
        if enforcement_mode == EnforcementMode.Monitoring:
            return JointMatchingVerdict.WILL_BE_BLOCKED_BY_DESTINATION_ALLOWED_BY_MANAGEMENT

        return JointMatchingVerdict.BLOCKED_BY_DESTINATION_ALLOWED_BY_MANAGEMENT

    @classmethod
    def get_blocked_by_destination_allowed_and_encrypted_by_management(cls, enforcement_mode):
        if enforcement_mode == EnforcementMode.Monitoring:
            return JointMatchingVerdict.WILL_BE_BLOCKED_BY_DEST_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT

        return JointMatchingVerdict.BLOCKED_BY_DESTINATION_ALLOWED_AND_ENCRYPTED_BY_MANAGEMENT

    @classmethod
    def get_connections_matching_verdict_filter(cls, verdict):
        if verdict.is_blocked_by_source_agent:
            return ExtendedConnectionsManagementMatchingVerdictFilter.BLOCKED_BY_SOURCE.name.lower()

        if verdict.is_blocked_by_destination_agent:
            return ExtendedConnectionsManagementMatchingVerdictFilter.BLOCKED_BY_DESTINATION.name.lower()

        if verdict.is_will_be_blocked_by_source_agent:
            return ExtendedConnectionsManagementMatchingVerdictFilter.WILL_BE_BLOCKED_BY_SOURCE.name.lower()

        if verdict.is_will_be_blocked_by_destination_agent:
            return ExtendedConnectionsManagementMatchingVerdictFilter.WILL_BE_BLOCKED_BY_DESTINATION.name.lower()

        if verdict.is_could_not_block:
            return ConnectionsJointMatchingVerdictFilter.BLOCKED_BY_MANAGEMENT.name.lower()

        if verdict.is_alerted:
            return ConnectionsJointMatchingVerdictFilter.ALERTED_BY_MANAGEMENT.name.lower()

        if verdict.is_allowed_and_encrypted:
            return ConnectionsJointMatchingVerdictFilter.ALLOWED_AND_ENCRYPTED.name.lower()

        return ConnectionsJointMatchingVerdictFilter.ALLOWED.name.lower()


class ConnectionsJointMatchingVerdictFilter(Enum):
    BLOCKED = "Blocked"
    WILL_BE_BLOCKED = "Will be blocked"
    ALERTED_BY_MANAGEMENT = "Alerted"
    BLOCKED_BY_MANAGEMENT = "Could not block"
    ALLOWED = "Allowed"
    ALLOWED_AND_ENCRYPTED = "Allowed and Encrypted"


class ExtendedConnectionsManagementMatchingVerdictFilter(Enum):
    BLOCKED_BY_SOURCE = "Blocked by source"
    BLOCKED_BY_DESTINATION = "Blocked by destination"
    WILL_BE_BLOCKED_BY_SOURCE = "Will be blocked by source"
    WILL_BE_BLOCKED_BY_DESTINATION = "Will be blocked by destination"


@attr.s
class JointMatchingInfo(GenericMatchingInfo):
    violates_policy = bool_attr(default=False)
    verdict = enum_attr(JointMatchingVerdict, default=None)
    create_policy_incident = bool_attr(default=False)
    verdict_mismatch_id = string_attr(default=None)
    provider_rule_id = string_attr(default=None)


@attr.s
class NATInfo(Dictable):
    source_ip = attr.ib(hash=True, eq=True, order=True)
    dest_ip = attr.ib(hash=True, eq=True, order=True)
    dest_port = attr.ib(hash=True, eq=True, order=True)
    type = attr.ib(hash=True, eq=True, order=True)


@attr.s
class DockerInfo(Dictable):
    container_names = attr.ib(factory=list, hash=False, eq=False, order=False)
    labels = attr.ib(factory=dict, hash=False, eq=False, order=False)
    image_name = attr.ib(default=None, hash=True, eq=True, order=True)
    command = attr.ib(default=None, hash=True, eq=True, order=True)
    container_id = attr.ib(default=None, hash=False, eq=False, order=False)
    image_id = attr.ib(default=None, hash=True, eq=True, order=True)
    network_mode = attr.ib(default=None, hash=True, eq=True, order=True)


@attr.s
class PodId(Dictable):
    id = attr.ib(default=None, hash=True, eq=True, order=True)


@attr.s
class KubernetesPodInfo(Dictable):
    controller_id = attr.ib(default=None, hash=True, eq=True, order=True)
    k8s_labels = attr.ib(factory=dict, hash=False, eq=False, order=False)
    k8s_annotations = attr.ib(factory=dict, hash=False, eq=False, order=False)
    k8s_namespace = attr.ib(default=None, hash=True, eq=True, order=True)
    pod_id = attr.ib(default=None, hash=True, eq=True, order=True)
    pod_name = attr.ib(default=None, hash=True, eq=True, order=True)
    containers_info = attr.ib(factory=list, hash=False, eq=False, order=False)
    # @deprecated - new location: NetworkConnectionEvent.kubernetes_cluster
    kubernetes_cluster = attr.ib(default=None, hash=True, eq=True, order=False)


class DeceptionPolicyVerdict(IntEnum):
    Unknown = 0
    Ignore = 1
    Bypass = 2
    Inspect = 3
    NoMatch = 4


class DeceptionNoRedirectReason(IntEnum):
    Unknown = 0
    RedirectionDisabled = 1
    PolicyVerdict = 2
    NoConnectionToDeceptionServer = 3
    AgentRedirectionRateLimit = 4
    AgentSamplingRateLimit = 5
    AgentSamplingDisabled = 6
    TcpNonServiceablePort = 7
    NetworkLearningPhaseInProgress = 8


@attr.s(slots=True, hash=True)
class DeceptionInfo(Dictable):
    is_redirected = bool_attr()
    policy_rule_id = string_attr(default=None)
    policy_verdict = enum_attr(enum_type=DeceptionPolicyVerdict, default=None)
    no_redirect_reason = enum_attr(enum_type=DeceptionNoRedirectReason, default=None)


@attr.s
class InventoryItem(Dictable):
    item_type = string_attr(default=None, hash=True, eq=True, order=True)  # Optional e.g. 'asset'. If not set can assumed to be an asset
    item_id = string_attr(default=None, hash=True, eq=True, order=True)  # reference to inventory item id, e.g. 'orchestration_obj_id'
    metadata_attributes = dict_attr(default=None, hash=True, eq=True, order=True)
    external_ids = list_attr(default=None, hash=True, eq=True, order=True)  # Unused, added for compatibility with reveal models


@attr.s(slots=True)
class ProcessGroupInfo(Dictable):
    aggregation_key = string_attr(default=None)
    aggregation_key_unhashed = string_attr(default=None)
    docker_aggregation_key = string_attr(default=None)
    docker_aggregation_key_unhashed = string_attr(default=None)

    full_path = string_attr(default=None)
    process_name = string_attr(default=None)
    app_name = string_attr(default=None)
    script_name = string_attr(default=None)
    script_path = string_attr(default=None)
    process_group = int_attr(default=None)
    parent_name = string_attr(default=None)
    username = string_attr(default=None)
    cmdline = attr.ib(default=None)  # ListField(ListField(StringField()), required=False)  TODO type check
    image_hash = string_attr(default=None)
    image_hash_type = enum_attr(enum_type=ImageHashType, default=None)
    container = string_attr(default=None)
    docker_info = attr.ib(default=None, converter=lambda v: DockerInfo(**v) if isinstance(v, dict) else v)
    is_gc_image = bool_attr(default=False)
    pod_id = attr.ib(default=None)
    kubernetes_info = attr.ib(default=None, converter=lambda v: KubernetesPodInfo(**v) if isinstance(v, dict) else v)


@attr.s(slots=True, hash=True)
class MSSPInfo(Dictable):
    cluster_id = string_attr(default=None)
    tenant_id = string_attr(default=None)
    is_infra_tenant = bool_attr(default=False)


@attr.s(slots=True, hash=True)
class DnsSecurityInfo(Dictable):
    dns_query_domain = string_attr(default=None)
    blocklist_id = string_attr(default=None)
    blocklist_name = string_attr(default=None)


class KubernetesServiceType(Enum):
    CLUSTER_IP = "CLUSTER_IP"
    NODE_PORT = "NODE_PORT"
    LOAD_BALANCER = "LOAD_BALANCER"


@attr.s(slots=True)
class KubernetesServiceInfo(Dictable):
    service_id = string_attr()
    service_name = string_attr()
    service_namespace = string_attr()
    service_type = enum_attr(KubernetesServiceType, default=KubernetesServiceType.CLUSTER_IP)
    k8s_labels = dict_attr(default=None)
    k8s_label_selector = dict_attr(default=None)


@attr.s(slots=True)
class KubernetesInfo(Dictable):
    pod_info = attr.ib(default=None, converter=lambda v: KubernetesPodInfo(**v) if isinstance(v, dict) else v)


@attr.s(slots=True)
class RemoteKubernetesInfo(KubernetesInfo):
    service_info = attr.ib(default=None, converter=lambda v: KubernetesServiceInfo(**v) if isinstance(v, dict) else v)


@attr.s(slots=True)
class NetworkConnectionEvent(Dictable):
    INNER_TO_TRAFFIC_DIRECTION = {(True, True): TrafficDirection.EastWest,
                                  (True, False): TrafficDirection.SouthNorth,
                                  (False, True): TrafficDirection.NorthSouth,
                                  (False, False): TrafficDirection.NorthNorth}

    uuid = string_attr(default=attr.Factory(lambda: str(uuid.uuid4())))
    event_type = enum_attr(enum_type=ConnectionEventType, default=None)
    event_aggregation_hash = string_attr(default=None)

    source_ip = unicode_attr(default=None)
    source_ip_subnet = unicode_attr(default=None)
    destination_ip = unicode_attr(default=None)
    destination_ip_subnet = unicode_attr(default=None)
    destination_port = int_attr(default=None)
    ip_version = enum_attr(enum_type=IPVersion, default=IPVersion.IPv4)
    ip_protocol = enum_attr(enum_type=IPProtocol, default=IPProtocol.Tcp)
    dns_name = unicode_attr(default=None)
    dns_pattern = unicode_attr(default=None)
    win_service_name = unicode_attr(default=None)
    win_service_display = unicode_attr(default=None)
    enforcement_state = enum_attr(enum_type=EnforcementMode, default=None)
    interface_profile = enum_attr(enum_type=InterfaceProfile, default=None)

    count = int_attr(default=0)
    rx = int_attr(default=0)
    tx = int_attr(default=0)
    rx_tx_total = int_attr(default=0)
    duration = int_attr(default=0)

    src_is_reliable = bool_attr(default=None)

    # -- Filled by the management server --
    bucket_start_time = datetime_attr(default=None)
    bucket_end_time = datetime_attr(default=None)
    event_source = string_attr(default=None)
    traffic_direction = enum_attr(enum_type=TrafficDirection, default=None)

    parent_visibility_event_uuid = string_attr(default=None)
    remote_vm_id = string_attr(default=None)
    remote_vm_is_covered = bool_attr(default=None)

    local_vm_labels = list_attr(default=[])
    local_vm_object_type = string_attr(default=None)
    remote_vm_labels = list_attr(default=[])
    remote_vm_object_type = string_attr(default=None)

    local_ip_labels = list_attr(default=[])
    remote_ip_labels = list_attr(default=[])

    local_container_info_hash = string_attr(default=None)
    remote_container_info_hash = string_attr(default=None)
    local_container_info_labels = list_attr(default=[])
    remote_container_info_labels = list_attr(default=[])

    local_ip_info = dict_attr(default=None)
    remote_ip_info = dict_attr(default=None)
    is_matchable = bool_attr(default=False)
    remote_is_foreign = bool_attr(default=False)

    bucket_id = string_attr(default=None)

    # @deprecated - Worksite is replacing MSSP
    is_mssp_enabled = bool_attr(default=False)
    mssp_info = attr.ib(factory=MSSPInfo, converter=lambda v: MSSPInfo(**v) if isinstance(v, dict) else v)
    remote_mssp_info = attr.ib(factory=MSSPInfo, converter=lambda v: MSSPInfo(**v) if isinstance(v, dict) else v)

    # HPVMNetworkConnectionEvent
    redirection = attr.ib(default=None,
                          converter=lambda v: RedirectionInfo(**v) if isinstance(v, dict) else v)

    # AggregatedNetworkConnectionEvent
    process_group_info = attr.ib(default=None,              # EmbeddedDocumentField(ProcessGroupInfo)
                                 converter=lambda v: ProcessGroupInfo(**v) if isinstance(v, dict) else v)

    agent_matching = attr.ib(default=None,
                             converter=lambda v: AgentMatchingInfo(**v) if isinstance(v, dict) else v)
    nat_info = attr.ib(default=None,
                       converter=lambda v: NATInfo(**v) if isinstance(v, dict) else v)

    management_matching = attr.ib(default=None,
                                  converter=lambda v: ManagementMatchingInfo(**v) if isinstance(v, dict) else v)

    joint_matching = attr.ib(default=None,
                             converter=lambda v: JointMatchingInfo(**v) if isinstance(v, dict) else v)

    deception_info = attr.ib(default=None,
                             converter=lambda v: DeceptionInfo(**v) if isinstance(v, dict) else v)

    provider_matching = attr.ib(default=None,
                                converter=lambda v: ProviderMatchingInfo(**v) if isinstance(v, dict) else v)

    # ----------------------------------------------------------------
    # Cloud application information
    source_inventory_item_info = attr.ib(default=None,
                                         converter=lambda v: InventoryItem(**v) if isinstance(v, dict) else v)

    destination_inventory_item_info = attr.ib(default=None,
                                              converter=lambda v: InventoryItem(**v) if isinstance(v, dict) else v)

    # -- Filled by the management server --
    # copied from the containing AggregatedNetworkVisibilityEvent
    agent_id = string_attr(default=None)
    vm_id = string_attr(default=None)
    agent_type = enum_attr(enum_type=AgentType, default=None)
    is_case_sensitive_process = bool_attr(default=None)
    stale = bool_attr(default=None)
    username = string_attr(default=None)
    cloud_network = string_attr(default=None)

    # Kubernetes Data
    pod_id = string_attr(default=None)
    pod_namespace = string_attr(default=None)
    kubernetes_cluster = string_attr(default=None)  # k8s cluster id
    destination_kubernetes_service_info_id = string_attr(default=None)
    destination_kubernetes_service_name = string_attr(default=None)
    destination_kubernetes_service_namespace = string_attr(default=None)
    remote_kubernetes_cluster = attr.ib(default=None)
    pod_name = string_attr(default=None)
    remote_kubernetes_info = attr.ib(default=None,
                                     converter=lambda v: RemoteKubernetesInfo(**v) if isinstance(v, dict) else v)

    # External Provider Connections
    provider = string_attr(default=None)

    # Used for DatapathRedirectionEvent reporting
    processed_time = datetime_attr(default=attr.Factory(datetime.datetime.utcnow))
    received_time = datetime_attr(default=attr.Factory(datetime.datetime.utcnow))

    dns_security_info = attr.ib(default=None,
                                converter=lambda v: DnsSecurityInfo(**v) if isinstance(v, dict) else v)

    # K8s matching
    is_k8s_matching_enabled = bool_attr(default=True)

    is_corporate = bool_attr(default=DEFAULT_CORPORATE_FLAG_IF_NOT_EXIST)
    is_external_provider = bool_attr(default=False)
    process_id = string_attr(default=None)

    # Worksite matching
    worksite = string_attr(default=None)

    eviction_time = datetime_attr(default=None)
    skip_verdict_verification = bool_attr(default=False)
    traced = bool_attr(default=False)
    trace_info = dict_attr(factory=dict)

    is_stitchable = bool_attr(default=False)
    k8s_options = list_attr(default=[])

    @property
    def base_connection_tuple(self):
        return self.source_ip, self.destination_ip, self.destination_port, self.ip_protocol, self.cloud_network

    def _construct_connection_tuple(self, *tuple_fields):
        tenant_id, cluster_id = None, None

        if self.is_mssp_enabled:
            tenant_id = self.mssp_info.tenant_id

        if self.is_k8s_matching_enabled:
            cluster_id = self.kubernetes_cluster

        return tuple_fields + (self.worksite, cluster_id, tenant_id)

    @property
    def connection_tuple(self):
        return self._construct_connection_tuple(
            self.source_ip, self.destination_ip, self.destination_port, self.ip_protocol, self.cloud_network
        )

    @property
    def connection_tuple_no_source_ip(self):
        return self._construct_connection_tuple(
            self.destination_ip, self.destination_port, self.ip_protocol, self.cloud_network
        )

    @property
    def connection_tuple_no_source_ip_after_nat(self):
        source_ip, destination_ip, destination_port, ip_protocol, cloud_network = self.base_connection_tuple_after_nat
        return self._construct_connection_tuple(
            destination_ip, destination_port, ip_protocol, cloud_network
        )

    @property
    def connection_tuple_with_type(self):
        return self._construct_connection_tuple(
            self.source_ip, self.destination_ip, self.destination_port, self.ip_protocol, self.event_type,
            bool(self.redirection), self.cloud_network
        )

    @property
    def connection_tuple_with_type_after_nat(self):
        source_ip, destination_ip, destination_port, ip_protocol, cloud_network = self.base_connection_tuple_after_nat
        return self._construct_connection_tuple(
            source_ip, destination_ip, destination_port, ip_protocol, self.event_type,
            bool(self.redirection), cloud_network
        )

    @property
    def connection_tuple_based_on_asset_ids(self):
        source = self.source_vm_id if self.source_vm_id else self.source_ip
        dest = self.destination_vm_id if self.destination_vm_id else self.destination_ip

        # IPs needed here for internet service tags which have the same asset IDs but different IPs
        return source, dest, self.destination_port, self.ip_protocol, self.source_ip, self.destination_ip

    @property
    def base_connection_tuple_after_nat(self):
        if not self.nat_info:
            return self.base_connection_tuple

        src_ip, dest_ip, dest_port, protocol, cloud_network = self.base_connection_tuple

        if self.nat_info.type == NATType.DNAT.value:
            dest_ip = self.nat_info.dest_ip
        elif self.nat_info.type == NATType.SNAT_AND_DNAT.value:
            dest_ip = self.nat_info.dest_ip
            src_ip = self.nat_info.source_ip
        else:
            src_ip = self.nat_info.source_ip

        dest_port = self.nat_info.dest_port

        return src_ip, dest_ip, dest_port, protocol, cloud_network

    @property
    def connection_tuple_after_nat(self):
        return self._construct_connection_tuple(*self.base_connection_tuple_after_nat)

    @property
    def is_incoming(self):
        if self.event_type.is_incoming or self.event_type.is_server:
            return True

        if self.event_type == ConnectionEventType.ConnectionClosed:
            return self.src_is_reliable is not None and not self.src_is_reliable

        return False

    @property
    def is_outgoing(self):
        if self.event_type.is_outgoing:
            return True

        if self.event_type == ConnectionEventType.ConnectionClosed:
            return self.src_is_reliable is not None and self.src_is_reliable

        return False

    @property
    def direction(self):
        if self.event_type.is_outgoing:
            return 'source'
        else:
            return 'destination'

    @property
    def opposite_direction(self):
        if self.event_type.is_outgoing:
            return 'destination'
        else:
            return 'source'

    @property
    def local_ip_address(self):
        if self.is_incoming:
            return self.destination_ip
        elif self.is_outgoing:
            return self.source_ip
        elif self.event_type.is_nat:
            return self.nat_info.source_ip
        elif self.event_type.is_matched_type:
            return self.source_ip
        return None

    @property
    def remote_ip_address(self):
        source_ip, destination_ip, _, _, _, _, _, _ = self.connection_tuple_after_nat
        if self.is_incoming:
            return source_ip
        elif self.is_outgoing:
            return destination_ip
        elif self.event_type.is_nat:
            return self.destination_ip
        elif self.event_type.is_matched_type:
            return self.destination_ip
        return None

    @property
    def local_port(self):
        if self.is_incoming:
            return self.destination_port
        elif self.is_outgoing:
            return ANY_PORT_IDENTIFIER
        return None

    @property
    def remote_port(self):
        if self.is_incoming:
            return ANY_PORT_IDENTIFIER
        elif self.is_outgoing:
            return self.destination_port
        return None

    @property
    def local_vm_id(self):
        return self.vm_id

    @property
    def source_vm_id(self):
        return self.local_vm_id if self.is_outgoing else self.remote_vm_id

    @property
    def destination_vm_id(self):
        return self.local_vm_id if self.is_incoming else self.remote_vm_id

    @property
    def local_inventory_item_info(self):
        if self.is_outgoing:
            return self.source_inventory_item_info
        elif self.is_incoming:
            return self.destination_inventory_item_info
        return None

    @property
    def remote_inventory_item_info(self):
        if self.is_outgoing:
            return self.destination_inventory_item_info
        elif self.is_incoming:
            return self.source_inventory_item_info
        return None

    def is_external_provider_type(self):
        return self.agent_type in AgentAggregateType.EXTERNAL_PROVIDERS

    def set_traffic_direction(self):
        local_ip_info = self.local_ip_info or {}
        remote_ip_info = self.remote_ip_info or {}

        remote_is_inner = self.remote_vm_id is not None or remote_ip_info.get('is_inner', False)
        local_is_inner = self.local_vm_id is not None or local_ip_info.get('is_inner', False)

        def _calc_traffic_direction(source_is_inner, dest_is_inner):
            return NetworkConnectionEvent.INNER_TO_TRAFFIC_DIRECTION[(source_is_inner, dest_is_inner)]

        if self.is_incoming:  # remote -> local
            self.traffic_direction = _calc_traffic_direction(source_is_inner=remote_is_inner,
                                                             dest_is_inner=local_is_inner)
        elif self.is_outgoing:  # local -> remote
            self.traffic_direction = _calc_traffic_direction(source_is_inner=local_is_inner,
                                                             dest_is_inner=remote_is_inner)

    def is_exact_match(self, other_connection):
        # If mssp is disabled, an exact match is determined by the base connection tuples equality
        if not self.is_mssp_enabled or not other_connection.is_mssp_enabled:
            return self.base_connection_tuple_after_nat == other_connection.base_connection_tuple_after_nat

        # When mssp is enabled, if the base connection tuples are not the same, it can't be an exact match
        if self.base_connection_tuple_after_nat != other_connection.base_connection_tuple_after_nat:
            return False

        # If the base connection tuples are the same, and one of the connections if of the infra tenant,
        # then it's an exact match (since the infra tenant matches any tenant)
        if self.mssp_info.is_infra_tenant or other_connection.mssp_info.is_infra_tenant:
            return True

        # If both are regular tenants, it's an exact match iff they're of the same tenant
        return self.mssp_info.tenant_id == other_connection.mssp_info.tenant_id

    def fill_details_from_parent_event(self, parent_event):
        """
        Copy some of the connection event details from its parent AggregatedNetworkVisibilityEvent.
        :param parent_event: AggregatedNetworkVisibilityEvent
        """
        self.parent_visibility_event_uuid = parent_event.uuid
        if parent_event.agent_type in AgentAggregateType.EXTERNAL_PROVIDERS:
            self.agent_type = parent_event.agent_type
        elif not self.event_type.is_nat:  # NAT events are sourced from the NAT provider - parent event vm is not relevant
            self.agent_id = parent_event.vm_uuid
            self.vm_id = parent_event.vm_id
            self.agent_type = parent_event.agent_type
        self.event_source = parent_event.event_source
        self.bucket_start_time = (self.bucket_start_time + parent_event.time_diff).replace(tzinfo=None)
        self.bucket_end_time = (self.bucket_end_time + parent_event.time_diff).replace(tzinfo=None)
        self.stale = parent_event.stale

    def canonicalize(self):
        if self.ip_version == IPVersion.IPv6:
            self.source_ip = ipaddress.ip_address(self.source_ip).compressed
            self.destination_ip = ipaddress.ip_address(self.destination_ip).compressed

    def update_closed_event_details(self):
        self.count = 0
        self.duration = self.duration if self.duration else 0
        self.rx = self.rx if self.rx else 0
        self.tx = self.tx if self.tx else 0
        self.rx_tx_total = self.rx + self.tx

    def get_time_elapsed_since_receipt(self, now, default):

        if self.processed_time is None:
            elapsed = default
        else:
            elapsed = (now - self.processed_time).total_seconds()
        return elapsed

    def get_time_elapsed_since_bucket_start_time(self, now, default):
        if self.bucket_start_time is None:
            elapsed = default
        else:
            elapsed = (now - self.bucket_start_time).total_seconds()
        return elapsed

    @property
    def debug_str(self):
        debug_string = 'uuid: {}, src_ip: {}, dst_ip: {}, ' \
                       'dst_port: {}, protocol: {}, ' \
                       'vm_id: {}, remote_vm_id: {}, type: {}, ' \
                       'agent_matching: {}'.format(self.uuid,
                                                   self.source_ip,
                                                   self.destination_ip,
                                                   self.destination_port,
                                                   self.ip_protocol.name,
                                                   self.vm_id,
                                                   self.remote_vm_id,
                                                   self.event_type.name,
                                                   self.agent_matching)
        return debug_string

    @staticmethod
    def pull_connection_vm_ids(network_events):
        """Pull local and remote VM IDs from network events
        """
        vm_ids = {network_event.vm_id for network_event in network_events}
        vm_ids.update({network_event.remote_vm_id for network_event in network_events})
        vm_ids -= {None}
        return vm_ids

@attr.s
class AggregatedNetworkVisibilityEvent(Dictable):
    agent_type = enum_attr(enum_type=AgentType, default=None)
    vm_uuid = string_attr(default=None)
    hostname = string_attr(default=None)  # hostname of the vm
    source = string_attr(default=None)  # ip address of the vm
    vm_id = string_attr(default=None)
    connections = attr.ib(default=None)  # ListField(EmbeddedDocumentField(NetworkConnectionEvent))  TODO type check

    uuid = string_attr(default=attr.Factory(lambda: str(uuid.uuid4())))
    time = datetime_attr(default=attr.Factory(datetime.datetime.utcnow))
    received_time = datetime_attr(default=attr.Factory(datetime.datetime.utcnow))
    processed_time = datetime_attr(default=attr.Factory(datetime.datetime.utcnow))
    event_source = string_attr(default=None)
    event_source_hostname = string_attr(default=None)
    event_type = string_attr(default=None)
    stale = bool_attr(default=None)

    @property
    def is_sent_by_agent(self):
        return self.agent_type == AgentType.RevealAgent
