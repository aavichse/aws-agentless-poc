"""
Created on Sep 24, 2014

@author: itamar
"""

import errno
import logging
import os
import socket
import sys
import traceback
import uuid
from uuid import UUID
from hashlib import md5
from six import add_metaclass

from common.service import Service
from common.py.model.status.application_lifecycle import ApplicationLifecyclePhase
from common.py.model.status.application_status import ApplicationStatus
from common.py.model.exceptions import EnvironmentSetupException
from common.py.model.status.service_status import ServiceStatus

try:
    import fcntl
except ImportError:
    fcntl = None
    if not sys.platform.startswith('win'):  # on Linux, re-raise the error
        raise

from common.singleton import Singleton
from common.logger import log_init, get_logger
from common.py.utils.config import cfg


LOG = get_logger(module_name=__name__)

CLI_OPTS = [
    cfg.BoolOpt("pdb", default=False, help="start the interactive Python debugger on errors.")
]

OVERRIDING_UUID_FILE_PATH = r'/etc/guardicore/uuid'
MACHINE_UNIQUE_ID_FILE_PATH = r'/sys/class/dmi/id/product_uuid'

# temp logger config
logging.basicConfig(stream=sys.stderr)

@add_metaclass(Singleton)
class Application(Service):
    """Class Application(Service)
    
    General purpose application class.
    """


    BASE_PID_PATH = "/var/run/%(app_name)s.pid"
    MONICORE_SERVICES_CONFIG_PATH = "/etc/guardicore/monicore.d/%(app_name)s.conf"
    APP_ID = None
    SUCCESS_EXIT_CODE = 0
    ERROR_EXIT_CODE = 1

    def __init__(self, name, project_name=None, logger_name=None,
                 default_config_files=None, logger_opts=None):
        super(Application, self).__init__()

        self.id = self.get_id()
        self._app_name = name
        self._project_name = project_name if project_name else name
        self._logger_name = logger_name if logger_name else name
        self._logger = logging.getLogger()  # temp logger, will be replaces once config is loaded
        self._logger_opts = logger_opts or {}
        self._default_config_files = default_config_files
        self._pid_handle = None
        self.app_status = ApplicationStatus()
        self._status_reporter = None

    def get_logger(self):
        return self._logger

    @classmethod
    def get_default_pid_file_path(cls, app_name):
        return os.path.join(cls.BASE_PID_PATH % {'app_name': app_name.lower().replace(" ", "_")})

    @classmethod
    def get_app_last_pid(cls, app_name, path=None):
        """get_app_last_pid(app_name, path=None) -> pid

        Get the last PID saved to the PID file of an application.
        """

        if path is None:
            path = cls.get_default_pid_file_path(app_name=app_name)

        try:
            return int(open(path, "rb").read().strip())
        except Exception as exc:
            LOG.debug("Couldn't find previous PID file for '%s' on %s: %s",
                      app_name, path, exc)

        return None

    @staticmethod
    def remove_app_pid_file(app_name, path=None):
        if path is None:
            path = Application.get_default_pid_file_path(app_name=app_name)

        if not os.path.isfile(path):
            return

        try:
            os.remove(path)
        except Exception as exc:
            LOG.warning("Error removing PID file to %s: %s", path, exc)
        else:
            LOG.warning("Removed PID file on %s", path)

    def write_lock_pid_file(self, path=None, attempt=True):
        if sys.platform.startswith("win") or fcntl is None:
            return True

        if path is None:
            path = self.get_default_pid_file_path(app_name=self._app_name)

        if not os.path.exists(os.path.dirname(path)):
            os.makedirs(os.path.dirname(path))

        try:
            if os.path.isfile(path):
                self._pid_handle = open(path, "r+b")
            else:
                self._pid_handle = open(path, "wb")

            try:
                if attempt:  # non-block
                    fcntl.flock(self._pid_handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                else:  # block
                    fcntl.flock(self._pid_handle, fcntl.LOCK_EX)
            except IOError as exc:
                if exc.errno in (errno.EACCES, errno.EAGAIN):
                    return False
                raise

            pid_bytes = str(os.getpid()).encode('utf-8')
            self._pid_handle.write(pid_bytes)
            self._pid_handle.flush()

            # if possible, force PID file handle to not be copied over to subprocesses
            if hasattr(fcntl, 'FD_CLOEXEC'):
                fcntl.fcntl(self._pid_handle.fileno(), fcntl.F_SETFD, fcntl.FD_CLOEXEC)

            return True
        except Exception as exc:
            self._logger.warning("Error writing PID file to %s: %s", path, exc)
        return False

    def write_pid_file(self, path=None):
        """write_pid_file(path=None)

        Write a PID file for this application.
        """

        if path is None:
            path = self.get_default_pid_file_path(app_name=self._app_name)

        try:
            open(path, "wb").write(str(os.getpid()))

            return path
        except Exception as exc:
            self._logger.warning("Error writing PID file to %s: %s", path, exc)

        return None

    def delete_pid_file(self):
        """delete_pid_file(path=None)

        Delete the PID file for this application.
        """

        if self._pid_handle:
            self._pid_handle.close()
            self._pid_handle = None

        self.remove_app_pid_file(app_name=self._app_name)
    
    @classmethod
    def get_id(cls):
        if cls.APP_ID is None:
            cls.APP_ID = cls.get_machine_unique_id()
        return cls.APP_ID

    # noinspection PyMethodMayBeStatic
    def _log_init(self, base_name, *args, **kwargs):
        return log_init(base_name=base_name, *args, **kwargs)
        
    def initialize(self):
        """initialize()
        
        Initialize the application. Raise an exception in case of error.
        """
        super(Application, self).initialize()
        self._load_config()
        self._logger = self._log_init(base_name=self._logger_name, **self._logger_opts)
        if self._status_reporting_enabled():
            self._initialize_status_reporter()

    def verify(self):
        """verify()
        
        Verify environment for the application and raise an exception in case
        of verification error.
        """

        super(Application, self).verify()

        if self._status_reporter:
            self._status_reporter.verify()

    def start(self):
        """start()
        
        Start running the application and block until something dies.
        """

        super(Application, self).start()

    def cleanup(self):
        """cleanup()
        
        After application died, do some cleanups.
        """
        
        super(Application, self).cleanup()

        self.update_lifecycle_phase(ApplicationLifecyclePhase.CLEANING_UP)
        if self._status_reporter:
            self._status_reporter.cleanup()

    def _post_exception_handler(self, exc):
        pass
    
    def main(self):
        success = self._app_main()

        # use os._exit() and not sys.exit() to avoid hanging on non-daemonic threads
        os._exit(Application.SUCCESS_EXIT_CODE if success else Application.ERROR_EXIT_CODE)

        logging.fatal("This line should never run!!")

    def _app_main(self):
        try:
            self.update_lifecycle_phase(ApplicationLifecyclePhase.INITIALIZING)
            self.initialize()
            self.update_lifecycle_phase(ApplicationLifecyclePhase.VERIFYING)
            self.verify()
        except (SystemExit, KeyboardInterrupt):
            LOG.debug("Breaking out of %s during initialization:\n%s", self._app_name, traceback.format_exc())
            self.cleanup()
            return True
        except:
            LOG.exception("Error while initializing %s application", self._app_name)
            self.cleanup()
            return False
    
        try:
            self.update_lifecycle_phase(ApplicationLifecyclePhase.STARTING)
            self.start()
        except (SystemExit, KeyboardInterrupt) as exc:
            LOG.debug("Breaking out of %s:\n%s", self._app_name, traceback.format_exc())
            self._post_exception_handler(exc)
            return True
        except Exception as exc:
            LOG.exception("Exception in %s application (%s)", self._app_name, exc)
            self._post_exception_handler(exc)
            return False
        finally:
            self.cleanup()

        LOG.info("Exiting %s application", self._app_name)

        return True

    def get_current_lifecycle_phase(self):
        """
        Get the current lifecycle phase
        :return: ApplicationLifecyclePhase
        """
        return self.app_status.current_lifecycle_phase

    def update_lifecycle_phase(self, lifecycle_phase):
        """
        Update the lifecycle phase of the Application

        :param lifecycle_phase:
        :type: ApplicationLifecyclePhase
        """
        self.app_status.set_lifecycle_phase(lifecycle_phase)
        if self._status_reporter:
            self._status_reporter.send_status_updates()

    def list_app_status_services(self):
        """
        List microservices within the Application scope
        """
        return self.app_status.list_app_status_services()

    @staticmethod
    def format_status_message(status_msg, *args):
        if status_msg is None:
            return None

        if args:
            try:
                status_msg = status_msg % args
            except TypeError:
                status_msg = "{} args={}".format(status_msg, args)
                LOG.error("Failed formatting service update status message: msg=%r args=%r", status_msg, args)

        return status_msg

    def update_service_status(self, service_name, service_status, status_msg=None, *args):
        """
        Update status of microservice within the Application scope

        :param service_name:
        :type: str
        :param service_status:
        :type: ServiceStatus
        :param status_msg:
        :type: str
        """

        status_msg = self.format_status_message(status_msg, *args)

        self.app_status.add_service_status(service_name=service_name, service_status=service_status,
                                           msg=status_msg)

        LOG.info("Add status %r for service '%s'", self.app_status.get_service_status(service_name), service_name)
        #if status is error/down/failure update monicore immediately
        if service_status == ServiceStatus.FAILED or ServiceStatus.TERMINATED or ServiceStatus.DOWN:
            if self._status_reporter:
                self._status_reporter.send_status_updates()

    def remove_app_status_service(self, service_name):
        """
        Remove microservice from the Application scope

        :param service_name:
        :type: str
        """
        self.app_status.remove_app_status_service(service_name=service_name)
        LOG.info("Removed service '%s'", service_name)

    def _load_config(self, allow_cli_args=True):
        cfg.CONF.register_cli_opts(CLI_OPTS)
        cfg.CONF(project=self._project_name,
                 default_config_files=self._default_config_files,
                 args=sys.argv[1:] if allow_cli_args else [])
        return cfg.CONF

    @staticmethod
    def get_machine_unique_id():
        file_path = ''
        if os.path.isfile(OVERRIDING_UUID_FILE_PATH):
            file_path = OVERRIDING_UUID_FILE_PATH
        elif not sys.platform.startswith("win") and os.path.exists(MACHINE_UNIQUE_ID_FILE_PATH):
            file_path = MACHINE_UNIQUE_ID_FILE_PATH

        if file_path:
            with open(file_path) as file_obj:
                machine_id = file_obj.read().strip()
                if machine_id:
                    LOG.info("Machine UUID (%s) was read from file: %s", machine_id, file_path)
                    return machine_id

        try:
            with open(OVERRIDING_UUID_FILE_PATH, 'w') as file:
                machine_id = str(uuid.uuid4())
                file.write(machine_id)
                LOG.info("Generated machine UUID: %s and wrote it to file: %s",
                         machine_id, OVERRIDING_UUID_FILE_PATH)
                return machine_id
        except Exception:
            # fallback - hash hostname into a UUID string
            hostname_hash = md5(socket.gethostname().encode('utf-8')).digest()
            machine_id = str(UUID(bytes=hostname_hash[:16], version=4)).upper()
            LOG.info("Generated machine UUID: %s", machine_id)
            return machine_id

    def _status_reporting_enabled(self):
        app_name = self.get_monicore_app_name()
        if not app_name:
            LOG.info("Application status reporting disabled. Monicore application name not defined")
            return False

        service_config_path = self.MONICORE_SERVICES_CONFIG_PATH % {'app_name': app_name}
        service_config_file_exist = os.path.exists(service_config_path)
        LOG.info("Application status reporting %s for %s %s %s",
                 'enabled' if service_config_file_exist else 'disabled', app_name, service_config_path,
                 'found' if service_config_file_exist else 'not found')
        return service_config_file_exist

    def _initialize_status_reporter(self):
        from common.py.model.status.application_status_reporter import ApplicationStatusReporter
        self._status_reporter = ApplicationStatusReporter(app=self)
        self._status_reporter.initialize()
        self._status_reporter.start()

    def get_monicore_app_name(self):
        app_name = self._get_monitored_app_name()
        if not app_name:
            return None

        app_prefix = self._get_monitored_app_prefix()
        return app_prefix + '-' + app_name if app_prefix else app_name

    def _get_monitored_app_name(self):
        """
        Applications reporting status using ApplicationStatusReporter must return the actual
        application name used by monicore e.g. datapath, enforcement, honeypot.
        The name together with optional app_prefix will form the application name returned by monicore-ctrl
        :return:
        """
        return None

    @classmethod
    def _get_monitored_app_prefix(cls):
        """
        Applications reporting status using ApplicationStatusReporter must return the actual
        application prefix used by monicore e.g. 'gc', 'aggr'
        The prefix together with monitored app-name will form the application name returned by monicore-ctrl
        :return:
        """
        return None

    def raise_env_exception_update_status(self, service_name, service_status, status_msg=None, *args):
        """ Applications that call this function get to raise an EnvironmentSetupException while
        reporting the error_msg to monicore-status before"""
        if status_msg is not None:
            msg = status_msg % args
            self.update_service_status(service_name, service_status, msg)
        else:
            self.update_service_status(service_name, service_status)
        # if status is error/down/failure update monicore immediately
        if self._status_reporter:
            self._status_reporter.send_status_updates()
        raise EnvironmentSetupException(msg)

