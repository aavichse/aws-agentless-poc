from collections import defaultdict

import pydantic
import eventlet
from confluent_kafka import Consumer

from aggregator.model.integrations import IntegrationModels
from common.logger import get_logger


LOG = get_logger(module_name=__name__)


class BaseProxyClient:
    AGENT_TYPE = None
    TOPIC_NAME_TO_MSG_TYPE = None
    TOPIC_NAME_TO_MODEL = None

    def __init__(self, kafka_config, request_timeout):
        self.models = IntegrationModels.get_all_versions()
        self.kafka_config = kafka_config
        self.request_timeout = request_timeout
        self._consumer = None

    def initialize(self):
        LOG.info("Initializing kafka with config: %s", self.kafka_config)
        self._consumer = Consumer(self.kafka_config)
        #topics = list(self._consumer.list_topics(timeout=self.request_timeout).topics.keys())
        topics = [ 'gcapp-flowlogs-ehub' ]
        LOG.debug("Topics found: %s", topics)
        self._consumer.subscribe(topics)

    def consume_messages(self, msg_bulk_size):
        LOG.info('ARIK: Starting consuming messages')
        json_msgs = defaultdict(list)
        invalid_json_messages = defaultdict(list)
        # Do not change the timeout here. eventlet is a sneaky foe, when we can't beat him, we have to trick him.
        messages = self._consumer.consume(num_messages=msg_bulk_size, timeout=0)
        for msg in messages:
            if msg.error():
                LOG.warning("Got error from Eventhub: %s", msg.error())
                continue
            if msg.topic() not in self.TOPIC_NAME_TO_MSG_TYPE:
                LOG.warning("Got proxy msg on an unknown topic %s. skipping", msg.topic())
                continue
            msg_type = self.TOPIC_NAME_TO_MSG_TYPE[msg.topic()]
            try:
                json_msgs[msg_type].append(self.parse_message(msg))
            except pydantic.ValidationError as e:
                LOG.warning("pydantic raised ValidationError when trying to parse message: %s", msg.value())
                LOG.warning(e)
                invalid_json_messages[msg_type].append(msg)
                continue
            except Exception as e:
                LOG.error("Got unexpected exception %s while parsing message: %s", e, msg.value())
                invalid_json_messages[msg_type].append(msg)
                continue
        eventlet.sleep(0)
        return json_msgs, invalid_json_messages

    def parse_message(self, msg):
        model_cls = getattr(self.models[self.get_api_version(msg)], self.TOPIC_NAME_TO_MODEL[msg.topic()]) # noqa
        return model_cls.model_validate_json(msg.value())

    def cleanup(self):
        self._consumer.close()

    @staticmethod
    def get_api_version(msg):
        return NotImplementedError()

    @classmethod
    def from_config(cls, connection_info, service_config):
        raise NotImplementedError()
