import datetime
import json

import attr
import six

from common.py.apis.rabbitutils import RabbitMsgJSONDecoder, RabbitMsgJSONEncoder
from common.py.utils.config.six import fastjson

NO_DEFAULT = object()


def int_attr(**kwargs):
    return attr.ib(validator=lambda i, a, v: isinstance(v, (int, type(None))),
                   **kwargs)


def float_attr(**kwargs):
    return attr.ib(validator=lambda i, a, v: isinstance(v, (float, type(None))),
                   **kwargs)


def string_attr(**kwargs):
    return attr.ib(validator=lambda i, a, v: isinstance(v, (six.string_types, type(None))),
                   **kwargs)


def bytes_attr(**kwargs):
    return attr.ib(validator=lambda i, a, v: isinstance(v, (bytes, type(None))),
                   **kwargs)


def unicode_attr(**kwargs):
    return attr.ib(validator=lambda i, a, v: isinstance(v, (six.string_types, type(None))),
                   converter=lambda v: six.text_type(v) if v is not None else None,
                   **kwargs)


def attr_attr(attr_type, **kwargs):
    """set attributes of attr.s type"""
    converter_func = lambda v: v if isinstance(v, (attr_type, type(None))) else attr_type(**v)
    return attr.ib(converter=converter_func, **kwargs)


def enum_attr(enum_type, str_op=None, by_value=True, **kwargs):
    """
    str_op:         func to apply on the value. eg, str.upper: tcp -> TCP
    by_value:       whether it's enum.value or enum.name. eg, given IPProtocol.Tcp = 6
                    Fail: IPProtocol("Tcp") - ValueError: 'Tcp' is not a valid IPProtocol
                    Success: IPProtocol["Tcp"] (by_value=False) or IPProtocol(6) (by_value=True)
    """
    def enum_converter(value):
        if isinstance(value, (six.integer_types, six.string_types)):
            value = str_op(value) if str_op else value
            return enum_type(value) if by_value else enum_type[value]

        if isinstance(value, (enum_type, type(None))) or value == NO_DEFAULT:
            return value

        # For BC with old enum encoding based on common.py.utils.encoding.json.json_convert.encode_objects
        if isinstance(value, dict) and '__obj_class__' in value and '__obj_value__' in value:
            return enum_type(value['__obj_value__'])

    return attr.ib(validator=lambda i, a, v: isinstance(v, (enum_type, type(None))) or v == NO_DEFAULT,
                   converter=enum_converter, **kwargs)


def bool_attr(**kwargs):
    return attr.ib(validator=lambda i, a, v: isinstance(v, (bool, type(None))),
                   **kwargs)


def datetime_attr(**kwargs):
    return attr.ib(validator=lambda i, a, v: isinstance(v, (datetime.datetime, type(None))),
                   **kwargs)


def dict_attr(**kwargs):
    return attr.ib(validator=lambda i, a, v: isinstance(v, (dict, type(None))),
                   **kwargs)


def list_attr(**kwargs):
    return attr.ib(validator=lambda i, a, v: isinstance(v, (list, tuple, type(None))),
                   **kwargs)


def set_attr(**kwargs):
    return attr.ib(validator=lambda i, a, v: isinstance(v, (set, type(None))),
                   **kwargs)


def type_attr(**kwargs):
    return attr.ib(validator=lambda i, a, v: isinstance(v, (type, type(None))),
                   **kwargs)


def dictable_attr(**kwargs):
    return attr.ib(validator=lambda i, a, v: isinstance(v, (Dictable, type(None))),
                   **kwargs)


def callable_validator(instance, attribute, value):
    if not callable(value):
        raise TypeError("%s attribute '%s' must be callable, got %s" % (type(instance).__name__, attribute.name, value))


def optional_dictable_converter(dictable_type):
    def converter(v):
        if v is None:
            return None

        if isinstance(v, dictable_type):
            return v

        return dictable_type(**v)
    return converter


def dictable_list_converter(dictable_type):
    def converter(v):
        if v is None:
            return None

        return [dictable_type(**item) if not isinstance(item, dictable_type) else item for item in v]

    return converter


def dictable_dict_converter(dictable_type):
    def converter(v):
        if v is None:
            return None

        return {key: dictable_type(**value) if not isinstance(value, dictable_type) else value
                for key, value in six.iteritems(v)}

    return converter


def fast_to_dict(obj):
    if not isinstance(obj, (Dictable, list, tuple, set, dict)):
        return obj
    elif isinstance(obj, Dictable):
        if attr.has(type(obj)):
            return {k.name: fast_to_dict(getattr(obj, k.name)) for k in attr.fields(type(obj))}
        if hasattr(obj, '__slots__'):
            return {k: fast_to_dict(getattr(obj, k)) for k in obj.__slots__}
        return {k: fast_to_dict(v) for k, v in obj.__dict__.items()}
    elif isinstance(obj, (list, tuple, set)):
        return [fast_to_dict(item) for item in obj]
    else:  # dict
        return {k: fast_to_dict(v) for k, v in obj.items()}


class NoDefaultAttributesPostInitMixin(object):
    def __attrs_post_init__(self):
        for key, value in self.__dict__.items():
            if value is NO_DEFAULT:
                raise TypeError(
                    "__init__ missing 1 required argument: '{key}'".format(key=key)
                )


class Dictable(NoDefaultAttributesPostInitMixin):
    """
    Using rapidjson under the hood for JSON encoding/decoding
    Note enum attributes must be marked as enum_attr in order to
    be decoded to Enum/IntEnum
    """
    def to_dict(self):
        return fast_to_dict(self)

    def to_json(self):
        return fastjson.to_json(self.to_dict())

    @classmethod
    def from_json(cls, s):
        return cls(**fastjson.from_json(s))


class LegacyDictable(Dictable):
    """
    Use this class only if trying to encode mixed types that
    can't be represented in a robust scheme e.g. dict with mixed values containing enums
    """
    def to_json(self):
        # using RabbitMsgJSONEncoder to encode/decode enums
        return json.dumps(self.to_dict(), cls=RabbitMsgJSONEncoder)

    @classmethod
    def from_json(cls, s):
        # using RabbitMsgJSONEncoder to encode/decode enums
        return cls(**json.loads(s, cls=RabbitMsgJSONDecoder))
