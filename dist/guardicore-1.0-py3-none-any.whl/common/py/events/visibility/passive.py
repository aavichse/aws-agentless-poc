from enum import IntEnum  # USE enum34 PACKAGE FOR THIS

from mongoengine import StringField, IntField, ListField, DictField, DateTimeField, FloatField

from common.py.events.q import QAnswerOrigin
from common.py.models.events.base_event import BaseEvent
from common.py.utils.mongo import IntEnumField


class VisibilityDetectionEvent(BaseEvent):
    class Visibility(IntEnum):
        Invisible = 1
        Background = 2
        Front = 3

    DEFAULT_VISIBILITY = Visibility.Invisible
    GROUP = None
    TYPE_TITLE = None

    meta = {
        'allow_inheritance': True,
        'indexes': ['time',
                    ('incident_id', 'time')]
    }

    visibility = IntEnumField(enum_type=Visibility, default=None)

    # Added by management:
    incident_id = StringField()

    flow_id = StringField(default=None)
    flow = DictField()

    source_asset = DictField()
    destination_asset = DictField()
    connection_type = StringField()

    def process(self):
        self.save()

    def get_visibility(self):
        return self.visibility if self.visibility is not None else self.DEFAULT_VISIBILITY


class PassiveDetectionNodeEvent(VisibilityDetectionEvent):
    GROUP = 'Passive Detection'
    DEFAULT_VISIBILITY = VisibilityDetectionEvent.Visibility.Front

    meta = {
        'allow_inheritance': True,
        'indexes': [
            {'fields': ['incident_id', 'flow_id'], 'cls': False},
            {'fields': ['flow_id'], 'cls': False}
        ]
    }

    side = IntField()
    date = DateTimeField()
    result = DictField()
    answer_origin = IntEnumField(QAnswerOrigin)
    destination_port = IntField(default=None)
    source_process_name = StringField(default=None)
    destination_process_name = StringField(default=None)

    @property
    def should_use_experimental(self):
        return self.result.get('experimental_verdict') == 'malicious' and \
               self.result.get('verdict') != 'malicious'

    def get_verdict(self, experimental=False):
        if experimental and self.should_use_experimental:
            return self.result.get('experimental_verdict')

        return self.result.get('verdict')

    def get_reasons(self, experimental=False):
        if experimental and self.should_use_experimental:
            return self.result.get('experimental_reasons')

        return self.result.get('reasons')

    def get_severity(self, experimental=False):
        if experimental and self.should_use_experimental:
            return self.result.get('experimental_severity')

        return self.result.get('severity')


class PassiveDetectionProcessEvent(PassiveDetectionNodeEvent):
    TYPE_TITLE = 'suspicious process'
    process_name = StringField()
    process_path = StringField()
    process_hash = StringField()
    asset_name = StringField(default=None)
    ip_address = StringField(default=None)


class PassiveDetectionScriptEvent(PassiveDetectionNodeEvent):
    TYPE_TITLE = 'suspicious script'
    process_id = StringField()
    process_name = StringField()
    process_path = StringField()
    process_hash = StringField()
    script_path = StringField()
    asset_name = StringField(default=None)
    ip_address = StringField(default=None)


class PassiveDetectionIPEvent(PassiveDetectionNodeEvent):
    TYPE_TITLE = 'suspicious IP address'
    ip_address = StringField()
    remote_asset_name = StringField(default=None)
    remote_ip_address = StringField(default=None)

    @property
    def tuple(self):
        if self.side == NetworkSide.Source:
            return self.ip_address, None, None, None
        elif self.side == NetworkSide.Destination:
            return None, None, self.ip_address, None
        else:
            raise ValueError('Invalid event NetworkSide: %r' % self.side)


class PassiveDetectionDomainIPEvent(PassiveDetectionNodeEvent):
    TYPE_TITLE = 'suspicious network entity'
    domain_name = StringField()
    ip_address = StringField()
    remote_asset_name = StringField(default=None)
    remote_ip_address = StringField(default=None)


class PolicyViolationEvent(VisibilityDetectionEvent):
    GROUP = 'Segmentation Policy'
    TYPE_TITLE = 'policy violation'
    DEFAULT_VISIBILITY = VisibilityDetectionEvent.Visibility.Front

    meta = {
        'indexes': [
             {'fields': ['flow_id'], 'cls': False}
        ]
    }

    policy_revision = IntField()
    locked_asset_names = ListField(StringField())

    violating_policy_rule_id = StringField()
    violating_policy_ruleset_name = StringField()
    violating_policy_verdict = StringField()

    source_agent_matching = DictField()
    destination_agent_matching = DictField()
    management_matching = DictField()


class PassiveDetectionDNSTunnelEvent(VisibilityDetectionEvent):
    GROUP = 'Passive Detection'
    TYPE_TITLE = 'DNS tunneling'
    DEFAULT_VISIBILITY = VisibilityDetectionEvent.Visibility.Front

    requested_tlds = ListField(StringField())
    byterate = FloatField()
    transferred_bytes = IntField()


class NetworkSide(IntEnum):
    Source = 1
    Destination = 2
