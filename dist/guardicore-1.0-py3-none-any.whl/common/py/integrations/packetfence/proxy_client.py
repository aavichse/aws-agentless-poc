from common.logger import get_logger
from common.py.integrations.base import BaseProxyClient
from common.py.integrations.model import MsgType
from common.py.events.mitigation.machine_details import AgentType
from aggregator.model.integrations import DEFAULT_VERSION
LOG = get_logger(module_name=__name__)


class PFProxyClient(BaseProxyClient):
    AGENT_TYPE = AgentType.Packetfence
    TOPIC_NAME_TO_MSG_TYPE = {
        'network_events': MsgType.FLOWS,
    }
    TOPIC_NAME_TO_MODEL = {
        "network_events": "provider.reveal.ConnectionInfo"
    }

    def get_api_version(self, msg):
        return DEFAULT_VERSION

    @classmethod
    def from_config(cls, connection_info, service_config):
        kafka_config = {
            'bootstrap.servers': connection_info["connection_info"]["pf_kafka_name"] + ":9092",
            'security.protocol': 'SASL_PLAINTEXT',
            'sasl.mechanism': 'PLAIN',
            'sasl.username': connection_info["connection_info"]['username'],
            'sasl.password': connection_info["connection_info"]['password'],
            'group.id': service_config['consumer_group'],
            'enable.auto.commit': True,
        }
        return cls(kafka_config=kafka_config, request_timeout=service_config['kafka_request_timeout'])
