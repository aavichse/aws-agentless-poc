from enum import IntEnum

__author__ = 'itamar'


class ImageHashType(IntEnum):
    none = 0
    sha1 = 1
    sha256 = 2
    md5 = 3
