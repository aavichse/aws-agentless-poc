from common.py.collection.control.client.agents_server_client import AgentsServerComponentControlClient
from common.py.model.aggregator import AggregatorComponent


class IntegrationControllerServerControlClient(AgentsServerComponentControlClient):
    def __init__(self, **kwargs):
        super(IntegrationControllerServerControlClient, self).__init__(component_name=AggregatorComponent.IntegrationController, **kwargs)

    def get_onboard_info(self):
        return self.call("/integration/onboarding/get_last_onboard_info", method="GET")

