from common.py.apis import DEFAULT_RABBITMQ_USERNAME, DEFAULT_RABBITMQ_PASSWORD, \
    REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT, ComponentType, \
    AgentComponentType, AggregatorType, RPCExchange, RPCMessage
from common.py.apis.management import UNKNOWN_API_VERSION
from common.py.apis.management.aggregating_system_component import AggregatorBaseComponentManagementAPI
from common.py.apis.management.collector import CollectorAPI


class EnforcementServerManagementAPI(AggregatorBaseComponentManagementAPI):
    COMPONENT_TYPE = ComponentType.ENFORCEMENT_SERVER
    AGENTS_COMPONENT_TYPE = AgentComponentType.ENFORCEMENT_AGENT
    RABBIT_API_CLASS = CollectorAPI
    COMPONENT_BASE_URI = 'aggregators'

    def __init__(self, management_hosts, agent_id, version=UNKNOWN_API_VERSION, user=DEFAULT_RABBITMQ_USERNAME,
                 password=DEFAULT_RABBITMQ_PASSWORD, configuration_schema=None, aggregator_configuration_schema=None,
                 associated_mgmt_configuration=None, agent_details=None, guest_installation_details=None,
                 aggregator_type=AggregatorType.COLLECTOR, aggregator_features=None, collector_type=None, **kwargs):
        component_id = self.COMPONENT_TYPE.prefix + agent_id
        component_details = agent_details if agent_details is not None else {}
        component_details.update(dict(version=version,
                                      associated_mgmt_configuration=associated_mgmt_configuration,
                                      management_host=management_hosts[-1],
                                      guest_installation_details=guest_installation_details))
        component_details['agent_id'] = agent_id

        super(EnforcementServerManagementAPI, self).__init__(management_hosts=management_hosts,
                                                             agent_id=agent_id,
                                                             user=user,
                                                             password=password,
                                                             version=version,
                                                             exchange=RPCExchange.ENFORCEMENT_SERVER_EXCHANGE_NAME,
                                                             component_id=component_id,
                                                             aggregator_type=aggregator_type,
                                                             aggregator_features=aggregator_features,
                                                             collector_type=collector_type,
                                                             component_details=component_details,
                                                             heartbeat=REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT,
                                                             configuration_schema=configuration_schema,
                                                             aggregator_configuration_schema=aggregator_configuration_schema,
                                                             **kwargs)

    def get_enforcement_policy(self):
        """
        Get the current enforcement policy.
        :return: current enforcement policy, as an EnforcementPolicy instance.
        """
        return self.rabbitapi.call_management_rpc(RPCMessage.EnforcementServer.ENFORCEMENT_POLICY_RPC_FUNC_NAME,
                                                  blocking=True)

    def get_enforcement_policy_revision_number(self):
        """
        Get the current enforcement policy revision number.
        """
        return self.rabbitapi.call_management_rpc(RPCMessage.EnforcementServer.CURRENT_REVISION_NUMBER_RPC_FUNC_NAME,
                                                  blocking=True)

    def add_enforcement_policy_update_callback(self, callback_func, initial_call=True):
        """
        Register a callback to be called whenever the enforcement policy is updated.
        :param callback_func: callback function. Expected to receive a single argument for the policy,
            as an EnforcementPolicy instance.
        :param initial_call: should the callback be called after registration with the current policy?
        """
        self.rabbitapi.add_callback(
            RPCMessage.EnforcementServer.ENFORCEMENT_POLICY_UPDATE_MESSAGE_TYPE,
            lambda message: callback_func(message['policy']),
            initial_call=initial_call,
            initial_call_func=lambda: callback_func(self.get_enforcement_policy()))

    def add_enforcement_policy_revision_update_callback(self, callback_func, initial_call=True):
        """
        Register a callback to be called whenever the current enforcement policy revision number is received.
        :param callback_func: callback function. Expected to receive the current policy revision number.
        :param initial_call: should the callback be called after the current policy revision number being received?
        """
        self.rabbitapi.add_callback(
            RPCMessage.EnforcementServer.CURRENT_REVISION_NUMBER,
            lambda message: callback_func(message['current_revision_number']),
            initial_call=initial_call,
            initial_call_func=lambda: callback_func(self.get_enforcement_policy_revision_number()))

    def add_blocklist_update_callback(self, callback_func):
        """
        A block list looks like so:
        {
            "revision": 123456789013,
            "block-list": ["evil.com", "*.bad.co.uk"],
            "exclude-list": ["service.com", "*.guardicore.com"],
        }
        :return: current blocklist policy as an dict.
        """
        self.rabbitapi.add_callback(RPCMessage.EnforcementServer.DNS_BLOCKLISTS_MESSAGE_TYPE,
                                    lambda message: callback_func(message),
                                    initial_call=False)

    def get_dns_blocklists(self):
        """
        Get the current blocklist.
        A block list looks like so:
        {
            "revision": 123456789013,
            "block-list": ["evil.com", "*.bad.co.uk"],
            "exclude-list": ["service.com", "*.guardicore.com"],
        }
        :return: current blocklist policy as an dict.
        """
        return self.rabbitapi.call_management_rpc(RPCMessage.EnforcementServer.DNS_BLOCKLISTS_RPC_FUNC_NAME,
                                                  blocking=True)

    def add_blocklist_status_callback(self, callback_func):
        """
        dns_blocking_status
        {
            "revision": 12345,
            "status_timestamp": 1622105790
            "enabled": True,
        }
        """
        self.rabbitapi.add_callback(RPCMessage.EnforcementServer.DNS_SECURITY_STATUS_MESSAGE_TYPE,
                                    lambda message: callback_func(message),
                                    initial_call=False)

    def add_off_corporate_config_callback(self, callback_func):
        """
        configuration
        {
            'enabled': True,
            'corporate_detection_method': 'NLA'
            'internal_domain': 'akamai.com',
            'resolution_addresses': '192.168.1.15'
        }
        """
        self.rabbitapi.add_callback(RPCMessage.EnforcementServer.OFF_CORPORATE_CONFIG_MESSAGE_TYPE,
                                    lambda message: callback_func(message),
                                    initial_call=False)

    def add_fast_policy_status_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.EnforcementServer.FAST_POLICY_MESSAGE_TYPE,
                                    lambda message: callback_func(message.get('configuration')))

    def add_worksites_status_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.EnforcementServer.WORKSITES_CONFIG_MESSAGE_TYPE,
                                    lambda message: callback_func(message.get('configuration')))

    def add_traffic_encryption_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.EnforcementServer.TRAFFIC_ENCRYPTION_NOTIFY_STATUS,
                                    lambda message: callback_func(message.get('configuration')))

    def get_dns_blocking_status(self):
        return self.rabbitapi.call_management_rpc(RPCMessage.EnforcementServer.DNS_SECURITY_STATUS_RPC_FUNC_NAME,
                                                  blocking=True)

    def get_off_corporate_status(self):
        return self.rabbitapi.call_management_rpc(RPCMessage.EnforcementServer.OFF_CORPORATE_CONFIG_RPC_FUNC_NAME,
                                                  blocking=True)

    def get_fast_policy_status(self):
        return self.rabbitapi.call_management_rpc(RPCMessage.EnforcementServer.FAST_POLICY_RPC_FUNC_NAME,

                                                  blocking=True)

    def get_traffic_encryption_status(self):
        return self.rabbitapi.call_management_rpc(RPCMessage.EnforcementServer.TRAFFIC_ENCRYPTION_GET_STATUS,
                                                  blocking=True)

    def get_worksites_status(self):
        return self.rabbitapi.call_management_rpc(RPCMessage.EnforcementServer.WORKSITES_CONFIG_RPC_FUNC_NAME,
                                                  blocking=True)

    def send_k8s_agent_status(self, status):
        self.rabbitapi.call_management_rpc(
            RPCMessage.K8sOperations.K8S_CLUSTER_OPERATIONS_UPDATE_CLUSTER_INFO_RPC_FUNC_NAME,
            exchange=RPCExchange.ORCHESTRATION_EXCHANGE_NAME,
            k8s_enforcement_status=status,
            blocking=False)

    def add_k8s_agent_config_update_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.K8sOperations.K8S_CLUSTER_CONFIG_UPDATE_MESSAGE_TYPE,
                                    lambda message: callback_func(message.get('configuration_update')))

    def get_usergroup_mapping(self):
        return self.rabbitapi.call_management_rpc(RPCMessage.EnforcementServer.USERGROUP_MAPPING_GET_RPC_FUNC,
                                                  exchange=RPCExchange.USER_GROUPS_SNAPSHOT_EXCHANGE_NAME,
                                                  blocking=True)

    def add_usergroup_mapping_changed_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.EnforcementServer.USERGROUP_MAPPING_CHANGED_RPC_FUNC,
                                    lambda message: callback_func(message),
                                    initial_call=False)

    def get_usergroup_mapping_config(self):
        return self.rabbitapi.call_management_rpc(RPCMessage.EnforcementServer.USER_GROUP_MAPPING_CONFIG_GET_RPC_FUNC,
                                                  blocking=True)

    def add_usergroup_mapping_config_changed_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.EnforcementServer.USER_GROUP_MAPPING_MESSAGE_TYPE,
                                    lambda message: callback_func(message),
                                    initial_call=False)
