import json

AGGR_SERVICE_USERS_PATH = "/etc/guardicore/guardicore_users_ids"
AGGR_DEFAULT_SERVICE_USER = "guardicore-svc"


def get_service_user(name=AGGR_DEFAULT_SERVICE_USER):
    if name == "root":
        return 0, 0

    with open(AGGR_SERVICE_USERS_PATH, "r") as f:
        users = json.load(f)
    return users[name]['uid'], users[name]['gid']
