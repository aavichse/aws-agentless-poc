
from enum import IntEnum
from mongoengine import StringField, IntField, DateTimeField, ListField, DictField, BinaryField, LongField, \
    EmbeddedDocument, GenericEmbeddedDocumentField
from mongoengine.fields import BooleanField, EmbeddedDocumentField

from common.py.model.reversible_enum import ReversibleEnum
# these imports are left here to allow BC from previous location
# noinspection PyUnresolvedReferences
from common.py.model.system import OperatingSystem, FsEntityType, OperatingSystemStringToEnum
from common.py.models.events import EventSeverity, ProtocolType
from common.py.models.events.base_event import BaseEvent
from common.py.utils.mongo import IntEnumField, IPField, PortField, Path, Username, NullableStringField


__author__ = 'Lior'

EVENT_SPAMMING_THRESHOLD = 100


class Service(IntEnum):
    Unknown = 1
    SMB = 2
    SSH = 3
    RDP = 4
    SFTP = 5
    SCP = 6
    DNS = 7
    MSRPC = 8
    NetBIOS = 9
    NTP = 10
    HTTP = 11
    FTP = 12
    MYSQL = 13
    Telnet = 14
    ICMP = 15
    SSL = 16
    RemoteRegistry = 17
    NetworkService = 18
    RMIRegistry = 19
    MSSQL = 20
    WinRM = 21


# This is used to reverse some ports to specific services
SERVICE_PORTS = {
    21: Service.FTP,
    22: Service.SSH,
    23: Service.Telnet,
    53: Service.DNS,
    80: Service.HTTP,
    123: Service.NTP,
    135: Service.MSRPC,
    137: Service.NetBIOS,
    138: Service.NetBIOS,
    139: Service.NetBIOS,
    443: Service.SSL,
    445: Service.SMB,
    1099: Service.RMIRegistry,
    1433: Service.MSSQL,
    3306: Service.MYSQL,
    3389: Service.RDP,
    5985: Service.WinRM,
    5986: Service.WinRM,
}


class OperationType(IntEnum):
    Access = 1
    Create = 2
    Delete = 3
    Change = 4
    Execution = 5
    PermissionsChange = 6
    DirectoryListing = 7
    OwnerChange = 8
    HardLink = 9
    SoftLink = 10
    Rename = 11


class SkipReason(IntEnum):
    NoReason = 0
    LowStorage = 1
    NoData = 2
    Directory = 3


class DnsQueryType(IntEnum):
    # http://www.iana.org/assignments/dns-parameters/dns-parameters.xhtml

    A = 1
    NS = 2
    MD = 3
    MF = 4
    CNAME = 5
    SOA = 6
    MB = 7
    MG = 8
    MR = 9
    NULL = 10
    WKS = 11
    PTR = 12
    HINFO = 13
    MINFO = 14
    MX = 15
    TXT = 16
    RP = 17
    AFSDB = 18
    X25 = 19
    ISDN = 20
    RT = 21
    NSAP = 22
    NSAP_PTR = 23
    SIG = 24
    KEY = 25
    PX = 26
    GPOS = 27
    AAAA = 28
    LOC = 29
    NXT = 30
    EID = 31
    NIMLOC = 32
    SRV = 33
    ATMA = 34
    NAPTR = 35
    KX = 36
    CERT = 37
    A6 = 38
    DNAME = 39
    SINK = 40
    OPT = 41
    APL = 42
    DS = 43
    SSHFP = 44
    IPSECKEY = 45
    RRSIG = 46
    NSEC = 47
    DNSKEY = 48
    DHCID = 49
    NSEC3 = 50
    NSEC3PARAM = 51
    TLSA = 52
    HIP = 55
    NINFO = 56
    RKEY = 57
    TALINK = 58
    CDS = 59
    CDNSKEY = 60
    OPENPGPKEY = 61
    CSYNC = 62
    SPF = 99
    UINFO = 100
    UID = 101
    GID = 102
    UNSPEC = 103
    NID = 104
    L32 = 105
    L64 = 106
    LP = 107
    EUI48 = 108
    EUI64 = 109
    TKEY = 249
    TSIG = 250
    IXFR = 251
    AXFR = 252
    MAILB = 253
    MAILA = 254
    ANY = 255  # Sometimes known as "ALL"
    URI = 256
    CAA = 257
    TA = 32768
    DLV = 32769

    # See DnsRecordTypes in honeypot/hp_vm/dsm/linux_dsm/debug_plugins/dns_debug_plugin.py
    GLIBC_UNSPEC = 62321
    # See DnsRecordTypes in honeypot/hp_vm/dsm/windows_dsm/debug_plugins/dns_debug_plugin.py
    WIN_ADDRS = 248
    WINS = 65281
    WINSR = 65282


class SecurityLogonType(ReversibleEnum):
    Interactive = 2
    Network = 3
    Batch = 4
    Service = 5
    Proxy = 6
    Unlock = 7
    NetworkCleartext = 8
    NewCredentials = 9
    RemoteInteractive = 10
    CachedInteractive = 11
    CachedRemoteInteractive = 12
    CachedUnlock = 13


class HoneypotEvent(BaseEvent):
    def _repr_id(self):
        return "%s object" % self.__class__.__name__

    def __repr__(self):
        return "<%s: %s>" % (self.__class__.__name__, self._repr_id())

    class Visibility(IntEnum):
        Invisible = 1
        Background = 2
        Front = 3

    DEFAULT_VISIBILITY = Visibility.Invisible
    GROUP = None

    meta = {
        'allow_inheritance': True,
        'indexes': ['time',
                    ('incident_id', 'time')]
    }

    service = IntEnumField(enum_type=Service, default=Service.Unknown)
    os = IntEnumField(enum_type=OperatingSystem, required=True)
    service_provider_id = StringField(required=True)
    visibility = IntEnumField(enum_type=Visibility, default=None)

    # Added by management:
    incident_id = StringField()

    def process(self):
        self.save()

    def get_visibility(self):
        return self.visibility if self.visibility is not None else self.DEFAULT_VISIBILITY


class ServiceProviderClose(HoneypotEvent):
    pass


class RedirectionEvent(HoneypotEvent):
    source_ip = IPField(required=True)
    destination_ip = IPField(required=True)
    source_mac = StringField(required=True)
    destination_mac = StringField(required=True)
    source_port = PortField(required=True)
    destination_port = PortField(required=True)
    protocol = IntEnumField(ProtocolType)


class SecurityEvent(HoneypotEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Front

    severity = IntEnumField(enum_type=EventSeverity, default=EventSeverity.Low, required=True)

    # All security events could be reported with connection_id if it is identified.
    # For those who are connection specific events it is required (see ConnectionSpecificEvent class).
    connection_id = StringField()

    is_call_from_stack = BooleanField(default=None)


class ApplyInitialStateEvent(SecurityEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible

    sp_name = StringField(required=True)
    sp_build_time = DateTimeField(default=None)
    sp_index = IntField(default=0)


class ConnectionSpecificEvent(SecurityEvent):
    connection_id = StringField(required=True)


class ConnectionStart(ConnectionSpecificEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible

    source_ip = IPField()
    source_port = PortField()
    connection_details = DictField()


class RdpConnectionStart(ConnectionStart):
    rdp_source_ip = IPField(required=True)


class ConnectionEnd(ConnectionSpecificEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible


class SmbConnectToShare(SecurityEvent):
    GROUP = 'Network'

    network_path = StringField()
    server_name = StringField()
    share_name = StringField()
    share_proxied = StringField()


class SmbOpenFile(SecurityEvent):
    class CreateDisposition(IntEnum):
        Supersede = 0    # Exists -> Supersede; Doesn't exist -> Create. "Create new file or supersede existing file."
        Create = 1       # Exists -> Fail;      Doesn't exist -> Create. "Create new file (only if it doesn't exist)."
        Open = 2         # Exists -> Open;      Doesn't exist -> Fail.   "Open file (only if it exists)."
        OpenIf = 3       # Exists -> Open;      Doesn't exist -> Create. "Create new file or open existing file."
        Overwrite = 4    # Exists -> Overwrite; Doesn't exist -> Fail.   "Overwrite file (only if it exists)."
        OverwriteIf = 5  # Exists -> Overwrite; Doesn't exist -> Create. "Create new file or overwrite existing file."
        # The difference between "supersede" and "overwrite" is small: In the case of "overwrite", the existing file's
        # attributes are preserved, but in the case of "supersede", the attributes are deleted and replaced.

    GROUP = 'Files'
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Front

    path = EmbeddedDocumentField(Path, required=True)
    relative_path = EmbeddedDocumentField(Path)
    share_path = EmbeddedDocumentField(Path)
    share_name = StringField()

    desired_access = IntField()
    desired_access_verbose = ListField(StringField())
    desired_access_read = BooleanField()
    desired_access_write = BooleanField()
    desired_access_execute = BooleanField()
    file_attributes = IntField()
    file_attributes_verbose = ListField(StringField())
    share_access = IntField()
    share_access_verbose = ListField(StringField())
    create_disposition = IntEnumField(enum_type=CreateDisposition)
    create_options = IntField()
    create_options_verbose = ListField(StringField())

    result_error_code = IntField()
    result_error_code_name = StringField()


class RpcRequest(SecurityEvent):
    GROUP = 'Network'

    packet = BinaryField()
    parsed_packet = DictField()
    transport_protocol_sequence = StringField()
    transport_endpoint = StringField()
    interface_uuid = NullableStringField()
    interface_version = NullableStringField()
    interface_type = NullableStringField()
    interface_description = NullableStringField()
    op_num = IntField()
    op_name = NullableStringField()


class SessionSpecificEvent(ConnectionSpecificEvent):
    """This indicates an RDP session-specific event
    """
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible
    GROUP = 'Sessions'

    session_id = IntField(required=True)


class SessionAttach(SessionSpecificEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible


class SessionDetach(SessionSpecificEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible


class SessionLogon(SessionSpecificEvent):
    username = EmbeddedDocumentField(Username)
    domain = StringField()


class SessionLogoff(SessionSpecificEvent):
    pass


class SessionLock(SessionSpecificEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible


class SessionUnlock(SessionSpecificEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible


class ChannelStart(ConnectionSpecificEvent):
    """This indicates an SSH shell start
    """
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible

    channel_id = IntField(required=True)
    session_id = IntField(required=True)

    shell_name = StringField(required=True)
    shell_command = BinaryField(required=True)

    # List of argument split commands
    parsed_commands = ListField(field=ListField(field=StringField()), default=[])


class ChannelEnd(ConnectionSpecificEvent):
    """This indicates an SSH shell termination
    """
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible

    channel_id = IntField(required=True)
    session_id = IntField(required=True)

    environment_variables = ListField()
    shell_output = StringField(required=True)
    shell_error = StringField(required=True)
    shell_input = StringField(required=True)
    shell_name = StringField(required=True)
    shell_command = BinaryField(required=True)
    shell_open_time = DateTimeField(required=True)
    shell_first_command_id = IntField(required=True)


class LoginAttempt(ConnectionSpecificEvent):
    class LoginAttemptResult(IntEnum):
        Failed = 1
        Succeeded = 2

    class ResultReason(IntEnum):
        InvalidUser = 1
        WhiteList = 2
        WrongPassword = 3
        AlreadyFailedPassword = 4
        ReachedMaxAttempts = 5
        CorrectPassword = 6
        UnknownLogonType = 7
        Unknown = 8
        PreviouslyApprovedUser = 9
        PasswordTooShort = 10

    GROUP = 'Credentials'

    service = IntEnumField(enum_type=Service)
    username = EmbeddedDocumentField(Username)
    password = StringField()
    result = IntEnumField(enum_type=LoginAttemptResult)
    reason = IntEnumField(enum_type=ResultReason)


class BaseWindowsLogonRequest(LoginAttempt):
    process_id = IntField()
    process_name = StringField()
    logon_type = StringField()
    origin_name = StringField()
    result_error_code = IntField()
    result_error_code_name = StringField()
    result_sub_status_code = IntField()
    logon_protocol = StringField()
    username_proxied = StringField()
    # Workstation: filled by debug plugin for NetworkLogonRequest events, during enrichment for rest of events
    workstation = StringField()


class InteractiveLogonRequest(BaseWindowsLogonRequest):
    domain_name = StringField()
    is_workstation_unlock = BooleanField()


class NetworkLogonRequest(BaseWindowsLogonRequest):
    domain_name = StringField()
    server_challenge = BinaryField()
    challenge_response = BinaryField()
    case_insensitive_challenge_response = BinaryField()
    parameter_control = ListField()


class CommandExecution(ConnectionSpecificEvent):
    GROUP = 'Command Executions'

    host_shell_pid = IntField(required=True)
    cmd_in = BinaryField(required=True)
    stdout_data = BinaryField(required=True)
    stderr_data = BinaryField(required=True)
    cmd_id = IntField(required=True)  # A unique command ID, per service provider instance

    channel_id = IntField()
    session_id = IntField()

    # List of argument split commands
    parsed_commands = ListField(field=ListField(field=StringField()), default=[])


class ShellOperation(ConnectionSpecificEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible

    class Operation(IntEnum):
        COMPLETE = 0
        BACKSPACE = 1
        GET_PREVIOUS_HISTORY = 2
        BACKWARD_CHAR = 3
        FORWARD_CHAR = 4
        GET_NEXT_HISTORY = 5
        BEG_OF_LINE = 6
        END_OF_LINE = 7
        DELETE = 8
        OVERWRITE_MODE = 9
        SIGNAL = 10

    host_shell_pid = IntField(required=True)
    channel_id = IntField()
    session_id = IntField()

    operation = IntEnumField(enum_type=Operation)
    operation_args = DictField(default=None)


class ShellExecution(ConnectionSpecificEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible

    process_id = IntField(required=True)

    channel_id = IntField()
    session_id = IntField()


class IPInfo(EmbeddedDocument):
    class Type(IntEnum):
        VM = 1
        DOMAIN = 2

    name = StringField()
    type = IntEnumField(enum_type=Type)
    whois = DictField()
    is_external = BooleanField()


class NetworkOperation(SecurityEvent):
    class Direction(IntEnum):
        Incoming = 1
        Outgoing = 2

    GROUP = 'Network'

    direction = IntEnumField(enum_type=Direction)
    source_mac = StringField()
    destination_mac = StringField()
    source_ip = IPField()
    destination_ip = IPField()
    source_port = PortField()
    destination_port = PortField()

    source_info = EmbeddedDocumentField(IPInfo)
    destination_info = EmbeddedDocumentField(IPInfo)


class NtpPacketReceived(SecurityEvent):
    GROUP = 'NTP'

    configure_overflow = BooleanField()
    ctl_putdata_overflow = BooleanField()
    crypto_recv_overflow = BooleanField()


class FtpCodes(IntEnum):
    # From vsftpd-3.0.3/ftpcodes.h
    FTP_DATACONN = 150
    FTP_NOOPOK = 200
    FTP_TYPEOK = 200
    FTP_PORTOK = 200
    FTP_EPRTOK = 200
    FTP_UMASKOK = 200
    FTP_CHMODOK = 200
    FTP_EPSVALLOK = 200
    FTP_STRUOK = 200
    FTP_MODEOK = 200
    FTP_PBSZOK = 200
    FTP_PROTOK = 200
    FTP_OPTSOK = 200
    FTP_ALLOOK = 202
    FTP_FEAT = 211
    FTP_STATOK = 211
    FTP_SIZEOK = 213
    FTP_MDTMOK = 213
    FTP_STATFILE_OK = 213
    FTP_SITEHELP = 214
    FTP_HELP = 214
    FTP_SYSTOK = 215
    FTP_GREET = 220
    FTP_GOODBYE = 221
    FTP_ABOR_NOCONN = 225
    FTP_TRANSFEROK = 226
    FTP_ABOROK = 226
    FTP_PASVOK = 227
    FTP_EPSVOK = 229
    FTP_LOGINOK = 230
    FTP_AUTHOK = 234
    FTP_CWDOK = 250
    FTP_RMDIROK = 250
    FTP_DELEOK = 250
    FTP_RENAMEOK = 250
    FTP_PWDOK = 257
    FTP_MKDIROK = 257
    FTP_GIVEPWORD = 331
    FTP_RESTOK = 350
    FTP_RNFROK = 350
    FTP_IDLE_TIMEOUT = 421
    FTP_DATA_TIMEOUT = 421
    FTP_TOO_MANY_USERS = 421
    FTP_IP_LIMIT = 421
    FTP_IP_DENY = 421
    FTP_TLS_FAIL = 421
    FTP_BADSENDCONN = 425
    FTP_BADSENDNET = 426
    FTP_BADSENDFILE = 451
    FTP_BADCMD = 500
    FTP_BADOPTS = 501
    FTP_COMMANDNOTIMPL = 502
    FTP_NEEDUSER = 503
    FTP_NEEDRNFR = 503
    FTP_BADPBSZ = 503
    FTP_BADPROT = 503
    FTP_BADSTRU = 504
    FTP_BADMODE = 504
    FTP_BADAUTH = 504
    FTP_NOSUCHPROT = 504
    FTP_NEEDENCRYPT = 522
    FTP_EPSVBAD = 522
    FTP_DATATLSBAD = 522
    FTP_LOGINERR = 530
    FTP_NOHANDLEPROT = 536
    FTP_FILEFAIL = 550
    FTP_NOPERM = 550
    FTP_UPLOADFAIL = 553


class FtpBaseEvent(SecurityEvent):
    GROUP = 'File Transfer Protocol'
    tid = IntField(required=True)
    command = StringField(required=True)
    response_code = IntField(required=True)
    response_message = StringField(required=True)


g_ftp_command_mapper = {}


class FtpPluginHelper(object):
    @staticmethod
    def supported_commands(command_list):
        def wrapper(cls):
            if not issubclass(cls, FtpBaseEvent):
                raise TypeError("Class must be a subclass of FtpBaseEvent")
            for command in command_list:
                g_ftp_command_mapper[command] = cls
            return cls

        return wrapper


@FtpPluginHelper.supported_commands(['ABOR'])
class FtpAbort(FtpBaseEvent):
    pass


@FtpPluginHelper.supported_commands(['ACCT'])
class FtpAccount(FtpBaseEvent):
    account_info = StringField()


@FtpPluginHelper.supported_commands(['ALLO'])
class FtpAllocate(FtpBaseEvent):
    size = StringField()


@FtpPluginHelper.supported_commands(['APPE'])
class FtpAppend(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['CDUP', 'XCUP'])
class FtpCdup(FtpBaseEvent):
    pass


@FtpPluginHelper.supported_commands(['CWD', 'XCWD'])
class FtpChangeWorkingDirectory(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['DELE'])
class FtpDelete(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['EPRT'])
class FtpExtendedPort(FtpBaseEvent):
    ip = StringField()
    port = IntField()


@FtpPluginHelper.supported_commands(['EPSV'])
class FtpExtendedPassive(FtpBaseEvent):
    port = IntField()


@FtpPluginHelper.supported_commands(['FEAT'])
class FtpFeatures(FtpBaseEvent):
    pass


@FtpPluginHelper.supported_commands(['HELP'])
class FtpHelp(FtpBaseEvent):
    pass


@FtpPluginHelper.supported_commands(['LIST'])
class FtpList(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['MDTM'])
class FtpModificationTime(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['MKD', 'XMKD'])
class FtpMakeDir(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['MODE'])
class FtpMode(FtpBaseEvent):
    mode_character = StringField()


@FtpPluginHelper.supported_commands(['NLST'])
class FtpNameList(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['NOOP'])
class FtpNoOperation(FtpBaseEvent):
    pass


@FtpPluginHelper.supported_commands(['OPTS'])
class FtpOpts(FtpBaseEvent):
    opts = StringField()


@FtpPluginHelper.supported_commands(['PASV'])
class FtpPassive(FtpBaseEvent):
    ip = StringField()
    port = IntField()


@FtpPluginHelper.supported_commands(['PORT'])
class FtpPort(FtpBaseEvent):
    ip = StringField()
    port = IntField()


@FtpPluginHelper.supported_commands(['PWD', 'XPWD'])
class FtpPrintWorkingDirectory(FtpBaseEvent):
    pass


@FtpPluginHelper.supported_commands(['QUIT'])
class FtpQuit(FtpBaseEvent):
    pass


@FtpPluginHelper.supported_commands(['REIN'])
class FtpReinitialize(FtpBaseEvent):
    pass


@FtpPluginHelper.supported_commands(['REST'])
class FtpRestartTransfer(FtpBaseEvent):
    position = StringField()


@FtpPluginHelper.supported_commands(['RETR'])
class FtpRetrieve(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['RMD', 'XRMD'])
class FtpRemoveDirectory(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['RNFR'])
class FtpRenameFrom(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['RNTO'])
class FtpRenameTo(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['SITE'])
class FtpSite(FtpBaseEvent):
    site_specific_command = StringField()


@FtpPluginHelper.supported_commands(['SIZE'])
class FtpSize(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['SMNT'])
class FtpStructureMount(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['STAT'])
class FtpStat(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['STOR'])
class FtpStore(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['STOU'])
class FtpStoreUnique(FtpBaseEvent):
    path = EmbeddedDocumentField(Path, required=True)


@FtpPluginHelper.supported_commands(['STRU'])
class FtpStructure(FtpBaseEvent):
    structure_character = StringField()


@FtpPluginHelper.supported_commands(['SYST'])
class FtpSystem(FtpBaseEvent):
    pass


@FtpPluginHelper.supported_commands(['TYPE'])
class FtpType(FtpBaseEvent):
    types = StringField()


@FtpPluginHelper.supported_commands(['UNKNOWN'])
class FtpUnknown(FtpBaseEvent):
    args = StringField()


class MysqlResponseOK(EmbeddedDocument):
    response_time = DateTimeField()
    server_status = IntField()
    server_status_verbose = ListField(StringField())
    statement_warn_count = IntField()
    affected_rows = LongField()
    last_insert_id = LongField()
    response_message = StringField()


class MysqlResponseError(EmbeddedDocument):
    response_time = DateTimeField()
    sql_errno = IntField()
    err_msg = StringField()
    sql_state = StringField()


class MysqlResponseData(EmbeddedDocument):
    response_time = DateTimeField()
    server_status = IntField()
    server_status_verbose = ListField(StringField())
    statement_warn_count = IntField()
    columns = ListField(DictField())
    rows = ListField(ListField(NullableStringField()))
    error_getting_table = BooleanField()


class MysqlBaseEvent(SecurityEvent):
    GROUP = 'Databases'

    tid = IntField(required=True)


class MysqlEvent(MysqlBaseEvent):
    response = GenericEmbeddedDocumentField(choices=[MysqlResponseOK, MysqlResponseError, MysqlResponseData])


class MysqlCommandBase(MysqlEvent):
    class MysqlCommandEnum(IntEnum):
        # mysql-server/include/mysql_com.h: enum enum_server_command (MySQL 5.5.41)
        COM_SLEEP = 0
        COM_QUIT = 1
        COM_INIT_DB = 2
        COM_QUERY = 3
        COM_FIELD_LIST = 4
        COM_CREATE_DB = 5
        COM_DROP_DB = 6
        COM_REFRESH = 7
        COM_SHUTDOWN = 8
        COM_STATISTICS = 9
        COM_PROCESS_INFO = 10
        COM_CONNECT = 11
        COM_PROCESS_KILL = 12
        COM_DEBUG = 13
        COM_PING = 14
        COM_TIME = 15
        COM_DELAYED_INSERT = 16
        COM_CHANGE_USER = 17
        COM_BINLOG_DUMP = 18
        COM_TABLE_DUMP = 19
        COM_CONNECT_OUT = 20
        COM_REGISTER_SLAVE = 21
        COM_STMT_PREPARE = 22
        COM_STMT_EXECUTE = 23
        COM_STMT_SEND_LONG_DATA = 24
        COM_STMT_CLOSE = 25
        COM_STMT_RESET = 26
        COM_SET_OPTION = 27
        COM_STMT_FETCH = 28
        COM_DAEMON = 29
        COM_END = 30

    command = IntEnumField(enum_type=MysqlCommandEnum)
    command_data = StringField()


class MysqlOK(MysqlCommandBase):
    response = EmbeddedDocumentField(MysqlResponseOK)


class MysqlError(MysqlCommandBase):
    response = EmbeddedDocumentField(MysqlResponseError)


class MysqlData(MysqlCommandBase):
    response = EmbeddedDocumentField(MysqlResponseData)


class MysqlNoResponse(MysqlCommandBase):
    pass


class MysqlDisconnect(MysqlCommandBase):
    pass


class MysqlConnect(MysqlEvent):
    class MysqlConnectionType(IntEnum):
        # mysql-server/include/violate.h: enum enum_vio_type (MySQL 5.5.41)
        Closed = 0
        TCPIP = 1
        Socket = 2
        NamedPipe = 3
        SSL = 4
        SharedMemory = 5

    login_success = BooleanField(required=True)
    is_localhost = BooleanField()
    connection_type = IntEnumField(enum_type=MysqlConnectionType)
    source_host = StringField()
    source_ip = IPField()
    source_port = PortField()
    user = EmbeddedDocumentField(Username)
    initial_db = StringField()
    response = GenericEmbeddedDocumentField(choices=[MysqlResponseOK, MysqlResponseError, MysqlResponseData])


class MysqlOperation(MysqlBaseEvent):
    is_successful = BooleanField(default=False)


class MysqlCreateFunction(MysqlOperation):
    function_name = StringField()
    library_path = EmbeddedDocumentField(Path, required=True)


class MysqlInstallPlugin(MysqlOperation):
    plugin_name = StringField()
    library_path = EmbeddedDocumentField(Path, required=True)


class MysqlDropTable(MysqlOperation):
    dropped_table_name = StringField(default='')
    dropped_table_db_name = StringField(default='')


class MysqlCreateTable(MysqlOperation):
    created_table_name = StringField(default='')
    created_table_db_name = StringField(default='')
    like_table_name = StringField(default=None)
    like_table_db_name = StringField(default=None)


class DnsRequestPacket(NetworkOperation):
    query_type = IntEnumField(required=True, enum_type=DnsQueryType)
    query_name = StringField(required=True)


class EchoRequest(NetworkOperation):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Background


class ConnectAttempt(NetworkOperation):
    protocol = ProtocolType.TCP


class OsNetworkOperation(SecurityEvent):
    GROUP = 'Network'

    process_name = StringField()  # The process which attempted the network operation
    process_id = IntField()


class BindNetworkOperation(OsNetworkOperation):
    bind_ip = IPField()
    bind_port = PortField()


class AcceptNetworkOperation(OsNetworkOperation):
    local_ip = IPField()
    service_port = PortField()
    source_ip = IPField()
    source_port = PortField()


class ConnectNetworkOperation(OsNetworkOperation):
    source_ip = IPField()
    source_port = PortField()
    destination_ip = IPField()
    destination_port = PortField()

    source_info = EmbeddedDocumentField(IPInfo)
    destination_info = EmbeddedDocumentField(IPInfo)


class TcpConnectOperation(ConnectNetworkOperation):
    pass


class UdpSendOperation(ConnectNetworkOperation):
    pass


class UdpReceiveOperation(AcceptNetworkOperation):
    pass


class ResolveNetworkOperation(OsNetworkOperation):
    query_name = StringField(required=True)  # This field must be called "query_name" so it can be fused with DnsRequest events
    query_type = IntEnumField(required=True, enum_type=DnsQueryType)
    nameservers = ListField(DictField())
    extra_info = DictField()


class FileTransfer(SecurityEvent):
    # Note: Transport protocol is always TCP
    class Direction(IntEnum):
        ToHoneypot = 1
        FromHoneypot = 2

    class RemotePathType(IntEnum):
        URL = 1
        SFTP = 2
        SCP = 3
        MYSQL_DUMPFILE = 4
        SMB = 5
        FTP = 6

    GROUP = 'File Transfers'

    direction = IntEnumField(enum_type=Direction, required=True)
    remote_type = IntEnumField(enum_type=RemotePathType, required=True)
    remote_path = StringField(required=False)  # path on the attacker machine
    path = EmbeddedDocumentField(Path, required=True)  # local path on honeypot machine
    is_completed = BooleanField(required=True, default=True)

    protocol = ProtocolType.TCP


class FileSystemObjectOperation(SecurityEvent):
    operation = IntEnumField(enum_type=OperationType, required=True)
    path = StringField(required=True)
    process_name = StringField()
    pid = IntField()
    access_denied = BooleanField()
    is_directory = BooleanField(default=False)

    # in case we could store the file but chose not, state the reason
    storage_skip_reason = IntEnumField(enum_type=SkipReason,
                                       default=SkipReason.NoReason)


class ReportedFilesValidation(HoneypotEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible

    files_meta = DictField()


class FileOperation(SecurityEvent):
    meta = {
                'indexes': ['file_id']
    }
    GROUP = 'Files'

    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Background

    entity_type = IntEnumField(enum_type=FsEntityType,
                               required=True,
                               default=FsEntityType.File)
    path = EmbeddedDocumentField(Path, required=True)
    process_name = StringField()
    storage_skip_reason = IntEnumField(enum_type=SkipReason,
                                       default=SkipReason.NoReason)

    file_id = StringField()  # The ID of the stored file; if not available, file wasn't stored in persistent storage
    original_file_id = StringField()  # The ID of the stored file; if not available, file wasn't stored in persistent storage
    file_meta_data = DictField()
    original_file_meta_data = DictField()
    is_file_content_available = BooleanField(default=False)
    is_original_file_content_available = BooleanField(default=False)
    is_file_content_saved = BooleanField(default=False)

    rule_visible = BooleanField(default=False)
    rule_name = StringField()
    context = DictField()

    cert_subject = DictField(default={})
    cert_valid = BooleanField(default=True)  # No certificate subject and valid flag means no certificate.
    file_type_desc = StringField()
    file_type_mime = StringField()


class ReportFileOperation(FileOperation):
    pass


class FileChangeOperation(FileOperation):
    pass


class FileDeleteOperation(FileOperation):
    pass


class FileReadOperation(FileOperation):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible


class FileExecuteOperation(FileOperation):
    pass


class FileCreateOperation(FileOperation):
    pass


class FileRenameOperation(FileOperation):
    new_file_name = EmbeddedDocumentField(Path, required=True)


class FileHardlinkOperation(FileOperation):
    new_file_name = EmbeddedDocumentField(Path, required=True)


class FileTruncateOperation(FileOperation):
    pass


class FilePermissionChangeOperation(FileOperation):
    class PermissionOp(IntEnum):
        Read = 1
        Write = 2
        Execute = 3

    new_user_mode = ListField(IntEnumField(PermissionOp))
    new_group_mode = ListField(IntEnumField(PermissionOp))
    new_others_mode = ListField(IntEnumField(PermissionOp))
    old_user_mode = ListField(IntEnumField(PermissionOp))
    old_group_mode = ListField(IntEnumField(PermissionOp))
    old_others_mode = ListField(IntEnumField(PermissionOp))


class FileOwnerChangeOperation(FileOperation):
    old_gid = IntField()
    old_uid = IntField()
    new_gid = IntField()
    new_uid = IntField()


class FileEntirePathReported(FileOperation):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Background


class RegistryOperation(FileSystemObjectOperation):
    class ValueType(IntEnum):
        REG_NONE = 0
        REG_SZ = 1
        REG_EXPAND_SZ = 2
        REG_BINARY = 3
        REG_DWORD_LITTLE_ENDIAN = 4
        REG_DWORD = 4
        REG_DWORD_BIG_ENDIAN = 5
        REG_LINK = 6
        REG_MULTI_SZ = 7
        REG_RESOURCE_LIST = 8
        REG_FULL_RESOURCE_DESCRIPTOR = 9
        REG_RESOURCE_REQUIREMENTS_LIST = 10
        REG_QWORD_LITTLE_ENDIAN = 11
        REG_QWORD = 11
        REG_UNKNOWN = 0xFF

    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible
    GROUP = 'Registry'

    hive = StringField(required=True)
    value_type = IntEnumField(enum_type=ValueType, default=ValueType.REG_NONE)
    value = StringField()
    value_data = BinaryField()
    value_data_size = IntField(default=0)


class SuspiciousRegistryOperation(RegistryOperation):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Front


class ProcessOperation(SecurityEvent):
    def _repr_id(self):
        return "%s %d" % (self.operation.name, self.process_id)

    class ProcessOperationType(IntEnum):
        ProcessCreation = 1
        LoadLibrary = 2
        LoadLibraryAttempt = 3

    GROUP = 'Processes'

    operation = IntEnumField(enum_type=ProcessOperationType, default=ProcessOperationType.ProcessCreation)
    process_id = IntField(required=True)
    app_name = EmbeddedDocumentField(Path, required=True)
    command_line = StringField()
    parent_pid = IntField(required=True)
    parent_name = EmbeddedDocumentField(Path)
    environment_variables = DictField()
    is_successful = BooleanField()


class PreAllocationProcessOperation(ProcessOperation):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible

    creation_time = DateTimeField(default=None)

    def update(self, **kwargs):
        if self.pk:
            super(PreAllocationProcessOperation, self).update(**kwargs)


class DownloadedURL(EmbeddedDocument):
    url = StringField(required=True)
    file_id = StringField(required=True)
    is_file_content_available = BooleanField(default=False, required=True)


class DownloadOperation(SecurityEvent):
    GROUP = 'Processes'

    process_id = IntField(required=True)
    app_name = EmbeddedDocumentField(Path, required=True)
    command_line = StringField()
    handler = StringField(required=True)
    namespace = DictField()
    unknown = StringField()

    # attempted file download by the management - these are matched one for one
    downloads = ListField(field=EmbeddedDocumentField(DownloadedURL), required=True)


class Attachments(HoneypotEvent):
    class AttachmentType(IntEnum):
        PCAP = 1
        Screenshot = 2

    class AttachmentStatus(IntEnum):
        Success = 0
        UnknownError = 1
        SystemOverloadError = 2
        NoStorageError = 3

    GROUP = 'Attachments'

    attachment_type = IntEnumField(enum_type=AttachmentType, required=True)
    status = IntEnumField(enum_type=AttachmentStatus, default=AttachmentStatus.Success)
    file_id = StringField()  # ID of stored file in Honeypot's persistent storage, might be None in case of attachment error


class UserOperation(ConnectionSpecificEvent):
    GROUP = 'Users'

    username = EmbeddedDocumentField(Username)


class GroupOperation(SecurityEvent):
    GROUP = 'Users'

    group = StringField(required=True)


class HostOperation(SecurityEvent):
    GROUP = 'Network'

    host_name = StringField(required=True)


class UserCreation(UserOperation):
    password = StringField()


class UserDeletion(UserOperation):
    pass


class GroupCreation(GroupOperation):
    pass


class GroupDeletion(GroupOperation):
    pass


class UserPasswordChanged(UserOperation):
    password = StringField()


class MemberAddedToGroup(UserOperation):
    group = StringField(required=True)


class DnsPoisoning(HostOperation):
    ip_address = IPField(required=True)
    aliases = ListField(StringField())


class RemoteProcedureCall(SecurityEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Background
    GROUP = 'RPC'

    procedure_name = StringField(required=True)
    buffer = BinaryField()
    is_exploited = BooleanField(required=True)


class Eternalblue(SecurityEvent):
    GROUP = 'Network'

    param = IntField(required=True)


class KernelModuleOperation(SecurityEvent):
    GROUP = 'Services'

    process_id = IntField()
    return_value = IntField()


class LoadKernelModuleOperation(KernelModuleOperation):
    file_path = EmbeddedDocumentField(Path)
    file_id = StringField()
    parameters = StringField()


class UnloadKernelModuleOperation(KernelModuleOperation):
    module_name = StringField()


class SetProcessExecutionFlags(SecurityEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Background
    GROUP = 'Processes'

    class ExecutionOptions(IntEnum):
        ExecuteDisable = 1
        ExecuteEnable = 2
        DisableThunkEmulation = 3
        Permanent = 4
        ExecuteDispatchEnable = 5
        ImagePatchEnable = 6
        Spare1 = 7
        Spare2 = 8

    process_id = IntField()
    process_name = StringField()
    current_execution_flags = ListField(field=IntEnumField(ExecutionOptions))
    new_execution_flags = ListField(field=IntEnumField(ExecutionOptions))
    is_set = BooleanField()


class WindowsShutdown(SecurityEvent):
    GROUP = 'Processes'

    process_id = IntField(required=True)
    process_name = StringField(required=True)
    flags = IntField(required=True)
    reason = IntField(required=True)
    flags_description = StringField(required=True)
    reason_description = StringField(required=True)


class SystemBugCheck(SecurityEvent):
    process_id = IntField(required=True)
    process_name = StringField(required=True)
    code = IntField(required=True)


class UnhandledExceptionFilter(SecurityEvent):
    GROUP = 'Processes'

    process_id = IntField()
    process_name = StringField()
    exception_code = IntField()
    exception_code_name = StringField()
    exception_flags = ListField()
    has_associated_exception = BooleanField()
    exception_address = IntField()
    exception_params = ListField()
    exception_description = StringField()


# The following enum types are common to more than one service-related class below

class ServiceType(IntEnum):
    Unknown = 0
    KernelDriver = 1
    FileSystemDriver = 2
    RecognizerDriver = 3
    UserModeService = 4
    UserModeInteractiveService = 5
    UserModeSharedProcessService = 6
    UserModeSharedProcessInteractiveService = 7


class ServiceStartType(IntEnum):
    BootStart = 0
    SystemStart = 1
    AutoStart = 2
    DemandStart = 3
    Disabled = 4


class ServiceErrorControl(IntEnum):
    Ignore = 0
    Normal = 1
    Severe = 2
    Critical = 3


class ServiceSecurityEvent(ConnectionSpecificEvent):
    GROUP = 'Services'

    service_name = StringField()
    display_name = StringField()
    is_remote_operation = BooleanField()

    service_type = IntEnumField(enum_type=ServiceType)
    is_driver = BooleanField()
    service_type_internal = IntField()

    result_error_code = IntField()
    result_error_code_name = StringField()


class ServiceCreation(ServiceSecurityEvent):
    start_type = IntEnumField(enum_type=ServiceStartType)
    error_control = IntEnumField(enum_type=ServiceErrorControl)
    binary_path = StringField()
    load_order_group = StringField()
    tag_requested = BooleanField()
    dependencies = ListField(StringField())
    username = EmbeddedDocumentField(Username)
    password = StringField()
    is_wow64 = BooleanField()
    tag = IntField()


class ServiceStart(ServiceSecurityEvent):
    arguments = ListField(StringField())


class ServiceStop(ServiceSecurityEvent):
    pass


class ServicePause(ServiceSecurityEvent):
    pass


class ServiceResume(ServiceSecurityEvent):
    pass


class ServiceDeletion(ServiceSecurityEvent):
    pass


class ServiceConfigUnsupportedInfoLevel(EmbeddedDocument):
    info_level = IntField()
    info_level_verbose = StringField()


class ServiceConfigServiceType(EmbeddedDocument):
    service_type = IntEnumField(enum_type=ServiceType)
    is_driver = BooleanField()
    service_type_internal = IntField()


class ServiceConfigStartType(EmbeddedDocument):
    start_type = IntEnumField(enum_type=ServiceStartType)


class ServiceConfigErrorControl(EmbeddedDocument):
    error_control = IntEnumField(enum_type=ServiceErrorControl)


class ServiceConfigBinaryPath(EmbeddedDocument):
    binary_path = StringField()


class ServiceConfigLoadOrderGroup(EmbeddedDocument):
    load_order_group = StringField()


class ServiceConfigTag(EmbeddedDocument):
    tag_requested = BooleanField()
    tag = IntField()


class ServiceConfigDependencies(EmbeddedDocument):
    dependencies = ListField(StringField())


class ServiceConfigUsername(EmbeddedDocument):
    username = EmbeddedDocumentField(Username)
    password = StringField()


class ServiceConfigDisplayName(EmbeddedDocument):
    new_display_name = StringField()


class ServiceConfigDescription(EmbeddedDocument):
    description = StringField()


class ServiceConfigFailureActions(EmbeddedDocument):
    class ServiceFailureAction(EmbeddedDocument):
        class ActionType(IntEnum):
            NoAction = 0
            RestartService = 1
            RebootSystem = 2
            RunCommand = 3

        action_type = IntEnumField(enum_type=ActionType)
        action_delay = IntField()

    reset_period = IntField()
    reboot_message = StringField()
    command = StringField()
    actions = ListField(EmbeddedDocumentField(ServiceFailureAction))
    valid_params = ListField(StringField())


class ServiceConfiguration(ServiceSecurityEvent):
    info = ListField(GenericEmbeddedDocumentField(choices=[ServiceConfigUnsupportedInfoLevel,
                                                           ServiceConfigServiceType,
                                                           ServiceConfigStartType,
                                                           ServiceConfigErrorControl,
                                                           ServiceConfigBinaryPath,
                                                           ServiceConfigLoadOrderGroup,
                                                           ServiceConfigTag,
                                                           ServiceConfigDependencies,
                                                           ServiceConfigUsername,
                                                           ServiceConfigDisplayName,
                                                           ServiceConfigDescription,
                                                           ServiceConfigFailureActions]))


class ServicesShutdown(ConnectionSpecificEvent):
    GROUP = 'Services'


class TrafficAnalysisSummary(HoneypotEvent):
    start_time = DateTimeField()
    end_time = DateTimeField()
    incoming_packets = IntField()
    incoming_bytes = IntField()
    outgoing_packets = IntField()
    outgoing_bytes = IntField()
    incoming_histogram = DictField()
    outgoing_histogram = DictField()
    ip_protocols_histogram = DictField()
    transports = ListField()


class DebugRawMessage(HoneypotEvent):
    msg = StringField(required=True)


class IDSEvent(HoneypotEvent):
    class Direction(IntEnum):
        Inbound = 1
        Outbound = 2

    class Protocol(IntEnum):
        UNKNOWN = 255
        ICMP = 1
        TCP = 6
        UDP = 17
        IPv6 = 41

    src_ip = IPField()
    src_port = PortField()
    dest_ip = IPField()
    dest_port = PortField()
    direction = IntEnumField(enum_type=Direction)
    protocol = IntEnumField(enum_type=Protocol)

    process_id = IntField()
    app_name = EmbeddedDocumentField(Path)  # The process which attempted the network operation


class IDSAlert(IDSEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Background
    GROUP = 'IDS'

    class Severity(IntEnum):
        LOW = 3
        MEDIUM = 2
        HIGH = 1

    generator_id = IntField()
    signature_id = IntField()
    signature = StringField(required=True)
    category = StringField(default='IDS Alert')
    severity = IntEnumField(enum_type=Severity, required=True)


class IDSHttp(IDSEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Front
    GROUP = 'Network'

    hostname = StringField()
    http_method = StringField()
    http_user_agent = StringField()
    http_version = StringField()
    url = StringField(required=True)

    cookie = StringField(default=None)
    http_content_type = StringField(default=None)
    http_refer = StringField(default=None)
    status = IntField(default=None)
    content_size = IntField(default=0)
    whois = DictField()


class IDSTls(IDSEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Front
    GROUP = 'Network'

    subject = StringField()
    issuerdn = StringField()
    fingerprint = StringField()
    version = StringField()


class IDSDns(IDSEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible
    GROUP = 'Network'

    class DnsType(IntEnum):
        QUERY = 1
        ANSWER = 2

    type = IntEnumField(enum_type=DnsType)
    transaction_id = IntField()
    rrname = StringField()
    rrtype = IntEnumField(enum_type=DnsQueryType)
    ttl = IntField()
    rdata = StringField()


class YaraEvent(HoneypotEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible
    GROUP = 'Files'

    path = EmbeddedDocumentField(Path, required=True)

    tags = ListField()
    namespace = StringField()
    rule = StringField()
    metadata = DictField()
    description = StringField()
    # Left the `strings` parameter out of this event. Returned as a list of tuples in the form of (name, offset, value)
    # To add this we need to create an Embedded Document, and for now I have no idea what to do with it - so there we go


class YaraAlert(YaraEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Background


class HttpEmulationEvent(HoneypotEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Front
    GROUP = 'Network'

    src_ip = IPField()
    src_port = PortField()
    dest_ip = IPField()
    dest_port = PortField()

    process_id = IntField()
    app_name = EmbeddedDocumentField(Path)  # The process which attempted the network operation

    hostname = StringField()
    http_method = StringField()
    http_user_agent = StringField()
    http_version = StringField()
    url = StringField(required=True)

    cookie = StringField(default=None)
    http_content_type = StringField(default=None)
    http_refer = StringField(default=None)
    status = StringField(default=None)
    content_size = IntField(default=0)

    direction = IntEnumField(enum_type=IDSEvent.Direction, default=IDSEvent.Direction.Inbound)


class WmiEvent(HoneypotEvent):
    GROUP = 'WMI'


class WmiQuery(WmiEvent):
    query = StringField(required=True)
    ret_val = IntField(required=True)


class WmiMethod(WmiEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Front
    namespace = StringField(required=True)
    object_path = StringField(required=True)
    method_name = StringField(required=True)
    parameters = DictField()


class WmiFilter(WmiEvent):
    filter_type = StringField(required=True)
    filter_name = StringField(required=True)
    filter_params = DictField(required=True)


class WmiConsumer(WmiEvent):
    consumer_type = StringField(required=True)
    consumer_name = StringField(required=True)
    consumer_params = DictField(required=True)


class WmiBinding(WmiEvent):
    filter_namespace = StringField(required=True)
    filter_type = StringField(required=True)
    filter_name = StringField(required=True)
    consumer_namespace = StringField(required=True)
    consumer_type = StringField(required=True)
    consumer_name = StringField(required=True)


class WmiPersistence(WmiEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Front
    filter_namespace = StringField(required=True)
    filter_type = StringField(required=True)
    filter_name = StringField(required=True)
    filter_params = DictField()
    consumer_namespace = StringField(required=True)
    consumer_type = StringField(required=True)
    consumer_name = StringField(required=True)
    consumer_params = DictField()


class MsSqlEvent(ConnectionSpecificEvent):
    GROUP = 'Databases'

    mssql_session_id = IntField()


class MsSqlLoginAttempt(LoginAttempt):
    username_proxied = StringField()
    mssql_session_id = IntField()


class MsSqlQuery(MsSqlEvent):
    query = StringField()


class MsSqlInfoMessage(MsSqlEvent):
    info_msg = StringField()
    info_msg_id = IntField()
    info_state = IntField()
    info_severity = IntField()


class MsSqlError(MsSqlEvent):
    class Severity(IntEnum):
        # https://msdn.microsoft.com/en-us/library/ms164086.aspx
        # User-level errors
        DoesNotExist = 11
        QueryWithoutLocking = 12
        TransactionDeadlock = 13
        SecurityError = 14
        SyntaxError = 15
        GeneralError = 16
        # Sysadmin-level errors
        OutOfResources = 17
        DatabaseEngineInternalError = 18
        NonConfigurableLimitExceeded = 19
        # Fatal errors
        FatalErrorWithStatement = 20
        FatalErrorWithDatabaseTasks = 21
        FatalErrorDamageToTableOrIndex = 22
        FatalErrorDamageToDatabase = 23
        FatalErrorMediaFailure = 24
        FatalErrorUndefined = 25

    err_msg = StringField()
    err_msg_id = IntField()
    err_state = IntField()
    err_severity = IntEnumField(enum_type=Severity)


class MsSqlExecCmd(MsSqlEvent):
    cmd = StringField()


class MsSqlSwitchDb(MsSqlEvent):
    db = StringField()


class MsSqlCreateTable(MsSqlEvent):
    table = StringField()


class MsSqlCreateFunction(MsSqlEvent):
    function = StringField()


class MsSqlCreateProcedure(MsSqlEvent):
    procedure = StringField()


class MsSqlDropTable(MsSqlEvent):
    table = StringField()


class MsSqlDropFunction(MsSqlEvent):
    function = StringField()


class MsSqlDropProcedure(MsSqlEvent):
    procedure = StringField()


class MsSqlVersion(MsSqlEvent):
    version_tag = StringField()
    version_str = StringField()


class MsSqlData(MsSqlEvent):
    columns = ListField(NullableStringField())
    rows = ListField(ListField(NullableStringField()))


class ScheduledTask(SecurityEvent):
    GROUP = 'Scheduled Task'
    cmd_lines = StringField()


class ScheduledTaskCreation(ScheduledTask):
    pass


class ScheduledTaskRun(ScheduledTask):
    pass


class PowershellCommand(SecurityEvent):
    # This event is no longer used because we now have more powerful PowerShell session detection
    # (The PowerShellSession... event classes)
    GROUP = 'Powershell Commands'

    command = StringField(required=True)


class ConnectionClosed(HoneypotEvent):
    class CloseReason(IntEnum):
        HardTimeout = 0
        IdleTimeout = 1

    reason = IntEnumField(enum_type=CloseReason, required=True)


class PowerShellSessionEvent(SecurityEvent):
    GROUP = 'PowerShell'

    process_id = IntField()
    process_path = StringField()


class PowerShellSessionStart(PowerShellSessionEvent):
    started_at = DateTimeField()


class PowerShellSessionEnd(PowerShellSessionEvent):
    ended_at = DateTimeField()


class PowerShellSessionCommand(PowerShellSessionEvent):
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible

    command = StringField()
    command_at = DateTimeField()


class PowerShellSessionCommandOutput(PowerShellSessionEvent):
    # This event is generated when command output starts. At the beginning we only know output_at, and no output_text.
    # The event has a text_id.
    # PowerShellSessionCommandOutputMoreText events append text to output_text, identified by the text_id.
    text_id = StringField()

    commands = ListField(StringField())
    output_at = DateTimeField()
    output_text = StringField(default='')


class PowerShellSessionCommandOutputMoreText(PowerShellSessionEvent):
    # Invisible event that just appends text to the PowerShellSessionCommandOutput with the same text_id,
    # using the PowerShell detector.
    DEFAULT_VISIBILITY = HoneypotEvent.Visibility.Invisible

    text_id = StringField()
    more_text = StringField()
