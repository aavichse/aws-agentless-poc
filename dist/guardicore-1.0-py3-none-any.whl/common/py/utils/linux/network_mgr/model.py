from enum import Enum

from common.py.model.exceptions import GuardicoreException
from common.py.model.fastenum import IntEnum


class ConnectionConfigMethod(Enum):
    """
    IP configuration method.
    NMSettingIP4Config and NMSettingIP6Config both support "auto", "manual", and "link-local"
    See https://developer.gnome.org/NetworkManager/1.0/ref-settings.html Table 13. ipv4 setting
    """
    AUTO = 'auto'
    MANUAL = 'manual'
    LINK_LOCAL = 'link-local'

    def __str__(self):
        return self.value


class ActiveConnectionState(IntEnum):
    """
     Indicate the state of a connection to a specific network
     while it is starting, connected, or disconnecting from that network
     See https://developer.gnome.org/NetworkManager/stable/nm-dbus-types.html#NMActiveConnectionState
    """
    UNKNOWN = 0
    ACTIVATING = 1
    ACTIVATED = 2
    DEACTIVATING = 3
    DEACTIVATED = 4


class NetworkConfigException(GuardicoreException):
    pass
