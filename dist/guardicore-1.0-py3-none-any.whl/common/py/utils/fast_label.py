import hashlib

IS_WORKSTATION_LABEL_KEY = hashlib.md5('gc_internal_workstation'.encode()).hexdigest()
IS_WORKSTATION_LABEL_VALUE = hashlib.md5('internal_use_only'.encode()).hexdigest()
