import bigsuds


class F5Client(object):
    def __init__(self, name, ip, user, password, port=8443):
        self.display_name = name
        self.ip = ip
        self.user = user
        self.password = password
        self.port = port
        self.client = None
        self.initialized = False
        self._name = None

    def initialize(self):
        self.client = bigsuds.BIGIP(self.ip, username=self.user, password=self.password, port=self.port)
        self.initialized = True

    @property
    def name(self):
        if not self._name:
            local_device = self.client.Management.Device.get_local_device()
            self._name = self.client.Management.Device.get_hostname([local_device, ])[0]

        return self._name

