from __future__ import annotations

from enum import Enum
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, conint


class LogStart(BaseModel):
    id: UUID
    max_size: Optional[conint(ge=0, le=5242880)] = None
    rotated_logs: Optional[bool] = False
    local_config: Optional[bool] = True


class Status(Enum):
    NOT_STARTED = 'not_started'
    STARTED = 'started'
    DONE = 'done'
    FAILED = 'failed'


class LogStatus(BaseModel):
    status: Status
