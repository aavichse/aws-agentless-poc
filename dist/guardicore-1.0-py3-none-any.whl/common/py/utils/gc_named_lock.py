"""Gevent/Eventlet based synchronization utilities
"""


from common.py.model.exceptions import GuardicoreException


Lock = None


try:
    import eventlet.semaphore
    Lock = eventlet.semaphore.Semaphore
except ImportError:
    pass


try:
    import gevent.lock
    Lock = gevent.lock.Semaphore
except ImportError:
    pass


class FailedToAquireLockException(GuardicoreException):
    """Exception to raise in case lock was not aquired on time with gc_named_lock

    Parameters:
    name (str): Name of the lock

   """
    def __init__(self, name):
        super(FailedToAquireLockException, self).__init__(
            "Failed to aquire lock: {}".format(name))


class gc_named_lock:
    """Context manager for aquiring named lock.
    Using eventlet/gevent Semaphore.
    In case eventlet/gevent is not installed context manager does nothing.

    Parameters:
    name (str): Name of the lock
    timeout (int): Time we block on aquire
   """

    _LOCKS = {}

    def __init__(self, name, timeout = 30):
        self._name = name
        self._timeout = timeout
        self._current_lock = self._LOCKS.get(self._name, Lock() if Lock else None)
        self._LOCKS.setdefault(self._name, self._current_lock)

    def __enter__(self):
        if not self._current_lock:
            return

        locked = self._current_lock.acquire(True, self._timeout)
        if not locked:
            raise FailedToAquireLockException(self._name)

    def __exit__(self, *args, **kwargs):
        if not self._current_lock:
            return

        self._current_lock.release()
