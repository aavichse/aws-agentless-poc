from common.py.utils.config import cfg

pf_opts = [
    cfg.StrOpt('name', help="pf cluster name", required=True),
    cfg.StrOpt('cluster_id', required=True, help="Centra cluster ID that handles the CloudApp"),
    cfg.StrOpt('orchestration_id', required=True, help="correlating orchestration id for inventory reports"),
    cfg.StrOpt('connection_info', required=True, help="Encoded azure CloudApp manifest data"),
    cfg.StrOpt('api_version', default=None, help="Packetfence api version"),
]
