import attr
import six

from common.py.apis.management.agent_details import AdminLockState
from common.py.configuration.consts import *
from common.py.configuration.model import ResourceLimitationSuit, ResourcesOverrides, AgentModule, ContainerMode, \
    NatMode, \
    LinkLocalTrafficReportingMode
from common.py.events.agent import ModuleState, EnforcementMode, WindowsFirewallMode, DriverLogLevel, DriverLogTarget, \
    RedirectionMode
from common.py.events.attrs import Dictable, string_attr, dict_attr, datetime_attr, bool_attr, dictable_dict_converter
from common.py.events.mitigation.process import ImageHashType
from common.py.utils.config import cfg
from common.py.apis import AgentComponentType
from common.py.events.mitigation.machine_details import AgentType
from common.py.utils.config import types
from common.py.utils.config.types import Structure
from common.logger import get_logger

LOGGER = get_logger()

__author__ = 'Rony'

COMMON_AGENT_OPTS = (
    cfg.Opt('agent_log_debug', default=False, type=cfg.types.Boolean(),
            help='Put the agent logging in debug mode'),
    cfg.Opt('debug_metrics', default=False, type=cfg.types.Boolean(),
            help='Enable debug metrics from agent'),
    cfg.Opt('log_rotate_threshold', default=DEF_LOG_ROTATE_THRESHOLD_MB,
            type=cfg.types.Integer(min=1, max=MAX_LOG_ROTATE_THRESHOLD_MB),
            help='Max size of a log file in MBs'),
    cfg.Opt('log_rotate_count', default=DEF_LOG_ROTATE_COUNT, type=cfg.types.Integer(min=0, max=MAX_LOG_ROTATE_COUNT),
            help='Max count of saved rotated logs'),
    cfg.Opt('log_rotate_compressed', default=DEF_LOG_ROTATE_COMPRESSED, type=cfg.types.Boolean(),
            help='Compress rotated log files, already rotated log files will not be affected'),
)

ENFORCEMENT_MODES = [_x for _x in EnforcementMode.__members__.keys() if
                     _x not in (EnforcementMode.MetricsOnly.name, EnforcementMode.Unused4.name)]

ENFORCEMENT_OPTS = COMMON_AGENT_OPTS + (
    cfg.StrOpt('agent_operating_mode', choices=ENFORCEMENT_MODES,
               default=EnforcementMode.Unset.name, help="Enforcement Operating Mode"),
    cfg.StrOpt('agent_windows_firewall_mode', choices=list(WindowsFirewallMode.__members__.keys()),
               default=WindowsFirewallMode.CoexistWithWindowsFirewallExceptForImplicitAllows.name,
               help="Windows Firewall Interoperability Mode"),
    cfg.StrOpt('driver_log_level', choices=list(DriverLogLevel.__members__.keys()),
               default=DriverLogLevel.Info.name, help="Enforcement Driver Log Level"),
    cfg.StrOpt('driver_log_target', choices=list(DriverLogTarget.__members__.keys()),
               default=DriverLogTarget.FileLogOnly.name, help="Enforcement Driver Log Target"),
    cfg.Opt('agent_drop_out_of_session', default=False, type=cfg.types.Boolean(),
            help='Enforcement Agent out-of-session packets dropping behavior'),
    cfg.Opt('conn_request_size', default=DEFAULT_CONN_REQUEST_SIZE,
            type=cfg.types.Integer(min=MIN_CONN_REQUEST_SIZE, max=MAX_CONN_REQUEST_SIZE),
            help='Max number of connections per request'),
    cfg.Opt('keepalive_interval', default=DEFAULT_KEEPALIVE_INTERVAL_MICROSECONDS,
            type=cfg.types.Integer(min=MIN_KEEPALIVE_INTERVAL_MICROSECONDS, max=MAX_KEEPALIVE_INTERVAL_MICROSECONDS),
            help='The interval for sending keepalive event to reveal (in microseconds)'),
    cfg.Opt('max_policy_chains', default=0, type=cfg.types.Integer(min=0, max=1024),
            help='Max amount of policy chains'),
    cfg.Opt('max_policy_rules', default=0, type=cfg.types.Integer(min=0, max=EN_MAX_RULES_NUM),
            help='Max amount of policy rules per chain'),
    cfg.Opt('max_policy_entity_fields', default=0, type=cfg.types.Integer(min=0, max=EN_MAX_ENTITY_FIELD_NUM),
            help='Max amount of policy entities'),
    cfg.Opt('max_policy_rule_buff_len', default=0, type=cfg.types.Integer(min=0, max=EN_MAX_POLICY_RULE_BUFF_LEN),
            help='Max amount of allocated bytes per policy rule'),
    cfg.Opt('max_json_policy_buffer_len', default=0, type=cfg.types.Integer(min=0, max=EN_MAX_JSON_POLICY_BUFFER_LEN),
            help='Max total size of JSON policy buffer in bytes'),
    cfg.Opt('max_index_vectors_in_bag', default=0, type=cfg.types.Integer(min=0, max=1073741824),
            help='Max amount of index vectors in policy index bag'),
    cfg.Opt('max_index_range_count', default=0, type=cfg.types.Integer(min=0, max=1073741824),
            help='Max amount of ranges in policy index'),
    cfg.Opt('max_rule_index_size', default=0, type=cfg.types.Integer(min=0, max=1073741824),
            help='Max amount of allocated bytes per policy_index'),
    cfg.Opt('agent_dns_enable', default=True, type=cfg.types.Boolean(),
            help='Enable Enforcement Agent DNS parsing'),
    cfg.Opt('agent_windows_rst_injection_fix', default=True, type=cfg.types.Boolean(),
            help='Enable Windows Enforcement/Deception RST injection co-existence'),
    cfg.Opt('agent_dns_rate_limit', default=DEFAULT_DNS_RATE_LIMIT,
            type=cfg.types.Integer(min=MIN_DNS_RATE_LIMIT, max=MAX_DNS_RATE_LIMIT),
            help='Enforcement Agent DNS rate limit (packets per second)'),
    cfg.Opt('implicit_dns_rule', default=True, type=cfg.types.Boolean(),
            help='Add an implicit rule to always allow machine DNS server address'),
    cfg.StrOpt('container_mode', choices=list(ContainerMode.__members__.keys()), default=ContainerMode.Unset.name,
               help='Define the current container mode'),
    cfg.StrOpt('enable_dockerd_monitor', choices=list(NatMode.__members__.keys()), default=NatMode.Unset.name,
               help='Turn on/off tracking of NAT events'),
    cfg.StrOpt('blacklist_label_prefixes', default=DEF_BLACKLIST_LABEL_PREFIXES,
               help='Comma separated list of Docker Labels that will NOT be reported as part of container info'),
    cfg.Opt('en_driver_log_rotate_threshold', default=DEF_DRIVER_LOG_ROTATE_THRESHOLD_MB,
            type=cfg.types.Integer(min=1, max=MAX_LOG_ROTATE_THRESHOLD_MB), help='Max size of driver log file in MBs'),
    cfg.Opt('en_driver_log_rotate_count', default=DEF_DRIVER_LOG_ROTATE_COUNT,
            type=cfg.types.Integer(min=0, max=MAX_LOG_ROTATE_COUNT), help='Max count of saved rotated driver logs'),
    cfg.Opt('en_driver_log_rotate_compressed', default=DEF_LOG_ROTATE_COMPRESSED,
            type=cfg.types.Boolean(),
            help='Compress rotated log files, already rotated driver log files will not be affected'),
    cfg.Opt('policy_log_rotate_threshold', default=DEF_LOG_ROTATE_THRESHOLD_MB,
            type=cfg.types.Integer(min=1, max=MAX_LOG_ROTATE_THRESHOLD_MB), help='Max size of policy log file in MBs'),
    cfg.Opt('policy_log_rotate_count', default=DEF_LOG_ROTATE_COUNT,
            type=cfg.types.Integer(min=0, max=MAX_LOG_ROTATE_COUNT), help='Max count of saved rotated policy logs'),
    cfg.Opt('policy_log_rotate_compressed', default=DEF_LOG_ROTATE_COMPRESSED,
            type=cfg.types.Boolean(),
            help='Compress rotated log files, already rotated policy log files will not be affected'),
    cfg.Opt('enable_roaming_mode', default=False, type=cfg.types.Boolean(),
            help='Turn on/off roaming mode for Windows Laptops'),
    cfg.Opt('roaming_domain_name', default=None, type=cfg.types.String(),
            help='Active Directory domain name for roaming mode NIC tagging'),
    cfg.Opt('enable_off_corporate_policy', default=False, type=cfg.types.Boolean(),
            help='The Enforcement module will enforce policy per network profile'),
    cfg.Opt('local_usergroups_enabled', default=True, type=cfg.types.Boolean(),
            help='The Enforcement module will get usergroups from external sources (such as Azure Active Directory)'),
    cfg.Opt('dns_security', default=True, type=cfg.types.Boolean(),
            help='Enable DNS Security'),
    cfg.Opt('max_events_batch', default=1000, type=cfg.types.Integer(min=1, max=100000),
            help='Max amount of events in batch'),
    cfg.Opt('upgrade_grace_period', default=DEF_ENFORCEMENT_UPGRADE_GRACE_PERIOD,
            type=cfg.types.Integer(min=1, max=60 * 60 * 3),
            help="Upgrade grace period timer"),
    cfg.Opt('enable_win_services', default=True, type=cfg.types.Boolean(),
            help='Enable inspection of Windows services'),
    cfg.StrOpt('link_local_ipv4_action', choices=list(LinkLocalTrafficReportingMode.__members__.keys()),
               default=LinkLocalTrafficReportingMode.AllowTraffic.name,
               help='Choose whether to report IPv4 Link-Local (APIPA) addresses interfaces as regular interfaces, '
                    'or allow/block the traffic by default'),
    cfg.StrOpt('link_local_ipv6_action', choices=list(LinkLocalTrafficReportingMode.__members__.keys()),
               default=LinkLocalTrafficReportingMode.AllowTraffic.name,
               help='Choose whether to report IPv6 Link-Local (APIPA) addresses interfaces as regular interfaces, '
                    'or allow/block the traffic by default'),
    cfg.Opt('enable_k8s_node_enforcement', default=False, type=cfg.types.Boolean(),
            help='Enable K8s Node Enforcement'),
    cfg.StrOpt('k8s_node_operating_mode', choices=ENFORCEMENT_MODES,
               default=EnforcementMode.RevealOnly.name, help='K8s Node Enforcement Operating Mode'),
    cfg.Opt('enable_encryption', default=False, type=cfg.types.Boolean(), help='enable encrypting of traffic'),
    cfg.StrOpt('encryption_swanctl_dir', default='/etc/strongswan/swanctl', help='location of swanctl directory'),
    cfg.StrOpt('encryption_client_cert_filename', default='client_cert.pem', help='filename of client certificate'),
    cfg.StrOpt('encryption_root_cert_cn', default='Encryption root CA RSA', help='root certificate CN')
)

VALID_IMAGE_HASH_TYPES = list(ImageHashType.__members__.keys())
VALID_IMAGE_HASH_TYPES.remove(ImageHashType.none.name)

REVEAL_OPTS = COMMON_AGENT_OPTS + (
    cfg.Opt('disable_polling_mode', default=False, type=cfg.types.Boolean(),
            help='Disable agent going into polling mode (doesn\'t work on OS with polling mode mandatory)'),
    cfg.Opt('timeout_without_enforcement', default=DEF_TIMEOUT_WITHOUT_EN_MILLISECONDS,
            type=cfg.types.Integer(min=MIN_TIMEOUT_WITHOUT_EN_MILLISECONDS, max=MAX_TIMEOUT_WITHOUT_EN_MILLISECONDS),
            help='The time to wait between last enforcement event seen to starting polling mode (in milliseconds)'),
    # There is min+max limit in agent as well. in agents/reveal/framework/ra_matching_table.h
    cfg.Opt('matching_table_timeout', default=DEF_MATCHING_TABLE_TIMEOUT, type=cfg.types.Integer(min=5, max=150),
            help='Timeout of matching reveal events between Enforcement and Dig components'),
    cfg.Opt('polling_mode_interval', default=POLLING_MODE_INTERVAL,
            type=cfg.types.Integer(min=MIN_POLLING_MODE_INTERVAL, max=MAX_POLLING_MODE_INTERVAL),
            help='when agent in polling mode this is the interval used'),
    cfg.StrOpt('query_image_hash_type', default=ImageHashType.sha256.name,
               choices=VALID_IMAGE_HASH_TYPES,
               help='Type of process image hash to query with the network event'),
    cfg.Opt('max_hashed_size', default=10 * 1024 * 1024, type=cfg.types.Integer(min=1024 ** 2, max=1024 ** 3),
            help='Max amount of bytes to read from files when calculating hashes'),
    cfg.Opt('query_process_full_path', default=True, type=cfg.types.Boolean(),
            help="Query the process full path with the network event"),
    cfg.Opt('query_process_image_attributes', default=True, type=cfg.types.Boolean(),
            help="Query the process image attributes with the network event"),
    cfg.Opt('query_process_image_crc32', default=False, type=cfg.types.Boolean(),
            help='Query the process image CRC32 with the network event'),
    cfg.Opt('query_process_cmdline', default=True, type=cfg.types.Boolean(),
            help='Query the process command line with the network event'),
    cfg.Opt('max_accumulated_network_events', default=16384, type=cfg.types.Integer(min=1024, max=131072),
            help='Max amount of unread network events stored in the agent memory'),
    cfg.Opt('net_event_bin_log_rotate_threshold', default=10,
            type=cfg.types.Integer(min=1, max=MAX_LOG_ROTATE_THRESHOLD_MB),
            help='Max size of a net events binary log file in MBs'),
    cfg.Opt('net_event_bin_log_rotate_count', default=1, type=cfg.types.Integer(min=0, max=MAX_LOG_ROTATE_COUNT),
            help='Max count of saved rotated net events binary logs'),
    cfg.Opt('net_event_bin_log_rotate_compressed', default=False, type=cfg.types.Boolean(),
            help='Compress rotated log files, already rotated net events binary log files will not be affected'),
    cfg.Opt('net_event_bin_log_enabled', default=True, type=cfg.types.Boolean(),
            help="Turn on/off net event binary logging, already written net events binary log "
                 "files will not be affected"),
    cfg.StrOpt('container_mode', choices=list(ContainerMode.__members__.keys()), default=ContainerMode.Unset.name,
               help='Define the current container mode'),
    cfg.StrOpt('is_nat_enabled', choices=list(NatMode.__members__.keys()), default=NatMode.Unset.name,
               help='Turn on/off tracking of NAT events'),
    cfg.StrOpt('blacklist_label_prefixes', default=DEF_BLACKLIST_LABEL_PREFIXES,
               help='Comma separated list of Docker Labels that will NOT be reported as part of container info'),
    cfg.Opt('report_polling', default=False, type=cfg.types.Boolean(),
            help='Enables reporting of Polling mode events to Management'),
    cfg.Opt('nat_sessions_queue_max_len', default=DEF_QUEUED_NAT_EVENTS,
            type=cfg.types.Integer(min=MIN_QUEUED_NAT_EVENTS, max=MAX_QUEUED_NAT_EVENTS),
            help='Max number of queued NAT sessions'),
)

DETECTION_OPTS = COMMON_AGENT_OPTS + (
    cfg.Opt('fim_scan_interval_period', type=cfg.types.Integer(min=60 * 60, max=7 * 24 * 60 * 60),
            default=24 * 60 * 60, help="Period between scans in seconds"),
    cfg.Opt('fim_max_file_size_threshold', type=cfg.types.Integer(min=0, max=1024 ** 3), default=100 * (1024 ** 2),
            help='Maximum file size above which integrity monitoring will be skipped'),
    cfg.Opt('fim_enable_network_scan', type=cfg.types.Boolean(), default=False,
            help="Enable file integrity monitoring on network drives"),
    cfg.Opt('disable_osquery', type=cfg.types.Boolean(), default=False,
            help="Disable OSQuery integration"),
    cfg.Opt('osquery_auto_bootstrap', type=cfg.types.Boolean(), default=False,
            help="Enable OSQuery bootstrap in background without running a query"),
    cfg.Opt('osquery_enable', type=cfg.types.Boolean(), default=False,
            help="(Deprecated. use Disable OSQuery instead)"), # Deprecated. Does not affect. Should be removed when config deletion is safe
    cfg.Opt('etw_enable', type=cfg.types.Boolean(), default=False,
            help="Enable ETW"),
)

DECEPTION_OPTS = COMMON_AGENT_OPTS + (
    cfg.StrOpt('redirection_mode', choices=list(RedirectionMode.__members__.keys()),
               default=RedirectionMode.Unset.name, help="Redirection Mode"),
    cfg.Opt('idle_timeout', type=cfg.types.Integer(min=DEC_MIN_IDLE_TIMEOUT, max=DEC_MAX_IDLE_TIMEOUT),
            default=DEC_DEFAULT_IDLE_TIMEOUT, help="Idle Timeout"),
    cfg.Opt('hard_timeout', type=cfg.types.Integer(min=DEC_MIN_HARD_TIMEOUT, max=DEC_MAX_HARD_TIMEOUT),
            default=DEC_DEFAULT_HARD_TIMEOUT, help="Hard Timeout"),
    cfg.Opt('max_concurrent_redirections', type=cfg.types.Integer(min=DEC_MIN_MAX_CONCURRENT,
                                                                  max=DEC_MAX_MAX_CONCURRENT),
            default=DEC_DEFAULT_MAX_CONCURRENT, help="Max Concurrent Redirections"),
    cfg.Opt('tcp_service_ports', type=types.List(item_type=types.Integer(min=1, max=65535)),
            default=[21, 22, 80, 445, 3389, 135, 139, 3306, 1433, 5985, 5986],
            help='TCP ports which will be redirected to the Deception Server'),
    cfg.Opt('sampling_enabled', default=True, type=cfg.types.Boolean(),
            help='Enable or disable deception connection sampling'),
    cfg.Opt('sampling_rdr_period', type=cfg.types.Integer(min=DEC_MIN_SAMPLING_RDR_PERIOD,
                                                          max=DEC_MAX_SAMPLING_RDR_PERIOD),
            default=DEC_DEFAULT_SAMPLING_RDR_PERIOD, help='Deception sampling redirect period (seconds)'),
    cfg.Opt('sampling_ignore_period', type=cfg.types.Integer(min=DEC_MIN_SAMPLING_IGNORE_PERIOD,
                                                             max=DEC_MAX_SAMPLING_IGNORE_PERIOD),
            default=DEC_DEFAULT_SAMPLING_IGNORE_PERIOD, help='Deception sampling ignore period (seconds)'),
    cfg.Opt('rdr_failed_connections_enabled', default=True, type=cfg.types.Boolean(),
            help='Enable or disable deception redirection of failed connections'),
    cfg.Opt('rdr_ignore_src_port', default=True, type=cfg.types.Boolean(),
            help='Redirect similar connections to the same honeypot instance'),
)

ACCESS_OPTS = COMMON_AGENT_OPTS

class ResourceOverridesController(object):
    def __init__(self):
        self._overridesList = list()

    def change_callback(self, opt, old_value, new_value):
        self._overridesList.append(new_value)


resource_limit_override_opts = Structure([cfg.StrOpt('Module name', help="Choose the Agent module to modify",
                                                     choices=list(AgentModule.__members__.keys()), required=True),
                                          cfg.StrOpt('Resource', help="Choose the resource attribute to modify",
                                                     choices=list(ResourcesOverrides.__members__.keys())),
                                          cfg.IntOpt('Value',
                                                     help="Set the value of resource usage. Memory usage is \
                                                     measured in MB, IO usage in IOPs, CPU in %")])

MODULE_OPTIONS = list(ModuleState.__members__.keys())
MODULE_FILTERED = [_x for _x in MODULE_OPTIONS if _x != ModuleState.MetricsOnly.name]

CONTROLLER_OPTS = COMMON_AGENT_OPTS + (
    cfg.Opt('agent_update_version', type=cfg.types.String(), default="",
            help="Agent update version"),
    cfg.StrOpt('enable_reveal', choices=MODULE_FILTERED, default=ModuleState.Unset.name,
               help="Enable Reveal Module"),
    cfg.StrOpt('enable_deception', choices=MODULE_FILTERED, default=ModuleState.Unset.name,
               help="Enable Deception Module"),
    cfg.StrOpt('enable_enforcement', choices=MODULE_OPTIONS, default=ModuleState.Unset.name,
               help="Enable Enforcement Module"),
    cfg.StrOpt('enable_detection', choices=MODULE_FILTERED, default=ModuleState.Unset.name,
               help="Enable Detection Module"),
    cfg.StrOpt('enable_access', choices=MODULE_FILTERED, default=ModuleState.Unset.name,
               help="Enable Access Module"),
    cfg.Opt('agentui_disabled', default=False, type=cfg.types.Boolean(),
            help='Stop and disable the Agent UI process'),
    cfg.StrOpt('reveal_suit', choices=list(ResourceLimitationSuit.__members__.keys()),
               default=ResourceLimitationSuit.Unset.name, help="Limit the amount of resources the module can use"),
    cfg.StrOpt('reveal_channel_suit', choices=list(ResourceLimitationSuit.__members__.keys()),
               default=ResourceLimitationSuit.Unset.name, help="Limit the amount of resources the module can use"),
    cfg.StrOpt('detection_suit', choices=list(ResourceLimitationSuit.__members__.keys()),
               default=ResourceLimitationSuit.Unset.name, help="Limit the amount of resources the module can use"),
    cfg.StrOpt('enforcement_suit', choices=list(ResourceLimitationSuit.__members__.keys()),
               default=ResourceLimitationSuit.Unset.name, help="Limit the amount of resources the module can use"),
    cfg.StrOpt('enforcement_channel_suit', choices=list(ResourceLimitationSuit.__members__.keys()),
               default=ResourceLimitationSuit.Unset.name, help="Limit the amount of resources the module can use"),
    cfg.StrOpt('deception_suit', choices=list(ResourceLimitationSuit.__members__.keys()),
               default=ResourceLimitationSuit.Unset.name, help="Limit the amount of resources the module can use"),
    cfg.StrOpt('controller_suit', choices=list(ResourceLimitationSuit.__members__.keys()),
               default=ResourceLimitationSuit.Unset.name, help="Limit the amount of resources the module can use"),
    cfg.Opt('override_values', type=types.List(item_type=resource_limit_override_opts), default=[],
            help="Override some of the values of current suit"),
    cfg.Opt('enforcement_channel_log_verbose', default=False, type=cfg.types.Boolean(),
            help='Put the enforcement channel logging in debug mode'),
    cfg.Opt('enforcement_channel_log_rotate_threshold', default=DEF_LOG_ROTATE_THRESHOLD_MB,
            type=cfg.types.Integer(min=1, max=MAX_LOG_ROTATE_THRESHOLD_MB),
            help='Max size of a log file in MBs'),
    cfg.Opt('enforcement_channel_log_rotate_count', default=DEF_LOG_ROTATE_COUNT,
            type=cfg.types.Integer(min=0, max=MAX_LOG_ROTATE_COUNT),
            help='Max count of saved rotated logs'),
    cfg.Opt('enforcement_channel_log_rotate_compressed', default=DEF_LOG_ROTATE_COMPRESSED, type=cfg.types.Boolean(),
            help='Compress rotated log files, already rotated log files will not be affected'),
    cfg.Opt('reveal_channel_log_verbose', default=False, type=cfg.types.Boolean(),
            help='Put reveal channel logging in debug mode'),
    cfg.Opt('reveal_channel_log_rotate_threshold', default=DEF_LOG_ROTATE_THRESHOLD_MB,
            type=cfg.types.Integer(min=1, max=MAX_LOG_ROTATE_THRESHOLD_MB),
            help='Max size of a log file in MBs'),
    cfg.Opt('reveal_channel_log_rotate_count', default=DEF_LOG_ROTATE_COUNT,
            type=cfg.types.Integer(min=0, max=MAX_LOG_ROTATE_COUNT),
            help='Max count of saved rotated logs'),
    cfg.Opt('reveal_channel_log_rotate_compressed', default=DEF_LOG_ROTATE_COMPRESSED, type=cfg.types.Boolean(),
            help='Compress rotated log files, already rotated log files will not be affected'),
    cfg.Opt('service_log_verbose', default=False, type=cfg.types.Boolean(),
            help='Put the agent-service logging in debug mode'),
    cfg.Opt('service_log_rotate_threshold', default=DEF_LOG_ROTATE_THRESHOLD_MB,
            type=cfg.types.Integer(min=1, max=MAX_LOG_ROTATE_THRESHOLD_MB), help='Max size of a log file in MBs'),
    cfg.Opt('service_log_rotate_count', default=DEF_LOG_ROTATE_COUNT,
            type=cfg.types.Integer(min=0, max=MAX_LOG_ROTATE_COUNT),
            help='Max count of saved rotated logs'),
    cfg.Opt('service_log_rotate_compressed', default=DEF_LOG_ROTATE_COMPRESSED, type=cfg.types.Boolean(),
            help='Compress rotated log files, already rotated log files will not be affected'),
    cfg.Opt('agentui_enable_notifications', default=True, type=cfg.types.Boolean(),
            help='Enable desktop notifications when the agent blocks network connections'),
    cfg.Opt('agentui_ignore_notifications_time', default=DEF_TIME_IGNORE_NOTIFICATION,
            type=cfg.types.Integer(min=0, max=MAX_TIME_IGNORE_NOTIFICATION),
            help='Ignore new notifications with the same tuple, timeout is in seconds'),
    cfg.Opt('agentui_blocked_events_count', default=DEF_NET_EVENTS_COUNT,
            type=cfg.types.Integer(min=0, max=MAX_NET_EVENTS_COUNT),
            help='The maximum amount of blocked network events stored by the Agent UI'),
    cfg.StrOpt('agentui_resource_limitations', choices=list(ResourceLimitationSuit.__members__.keys()),
               default=ResourceLimitationSuit.Unset.name, help="Limit the amount of resources the module can use"),
    cfg.StrOpt('adminlock_management_defined_state', choices=list(AdminLockState.__members__.keys()),
               default=AdminLockState.UNSET.name, help="State of the admin-lock defined on management"),
    cfg.StrOpt('adminlock_password', default="", help="Password to be used to disable admin-lock"),
    cfg.Opt('ignore_deprecated_config_flag', default=False, type=cfg.types.Boolean(),
            help='Ignore deprecated installation configuration flags alert'),
    cfg.Opt('ignore_security_sw_installed_flags', default=False, type=cfg.types.Boolean(),
            help='Do not verify security software installed on this machine'),
    cfg.Opt('automatic_ko_upgrade', default=False, type=cfg.types.Boolean(),
            help='Enable automatic download of kernel modules'),
    cfg.Opt('aggregator_watchdog_timeout', default=DEF_AGGR_CONN_WATCHDOG_TIMER,
            type=cfg.types.Integer(min=MIN_AGGR_CONN_WATCHDOG_TIMER, max=MAX_AGGR_CONN_WATCHDOG_TIMER),
            help='Time interval between reconnections to aggregator in minutes'),
    cfg.Opt('health_check_interval_sec', default=DEF_HEALTH_CHECK_INTERVAL,
            type=cfg.types.Integer(min=MIN_HEALTH_CHECK_INTERVAL, max=MAX_HEALTH_CHECK_INTERVAL),
            help='Time interval between health checks in seconds'),
    cfg.Opt('reload_implicit_docker_rules', default=False, type=cfg.types.Boolean(),
            help='Reload implicit docker rules on interface change'),
)

configuration_schema_opts = cfg.ConfigOpts()
configuration_schema_opts.register_opts(ENFORCEMENT_OPTS, AgentType.EnforcementAgent.name.lower())
configuration_schema_opts.register_opts(REVEAL_OPTS, AgentType.RevealAgent.name.lower())
configuration_schema_opts.register_opts(DETECTION_OPTS, AgentType.DetectionAgent.name.lower())
configuration_schema_opts.register_opts(CONTROLLER_OPTS, AgentType.Controller.name.lower())
configuration_schema_opts.register_opts(DECEPTION_OPTS, AgentType.DeceptionAgent.name.lower())
configuration_schema_opts.register_opts(ACCESS_OPTS, AgentType.AccessAgent.name.lower())

AGENT_COMPONENT_TYPE_TO_CONFIGURATION_CATEGORY = {
    AgentComponentType.REVEAL_AGENT: AgentType.RevealAgent,
    AgentComponentType.ENFORCEMENT_AGENT: AgentType.EnforcementAgent,
    AgentComponentType.DECEPTION_AGENT: AgentType.DeceptionAgent,
    AgentComponentType.DETECTION_AGENT: AgentType.DetectionAgent,
    AgentComponentType.CONTROLLER: AgentType.Controller,
    AgentComponentType.ACCESS_AGENT: AgentType.AccessAgent
}

CONFIGURABLE_AGENT_TYPES = {AgentType.RevealAgent, AgentType.EnforcementAgent, AgentType.DeceptionAgent,
                            AgentType.DetectionAgent, AgentType.Controller, AgentType.AccessAgent}

CONFIGURATIONS_ALLOWED_KEYS = {agent_type.name.lower() for agent_type in CONFIGURABLE_AGENT_TYPES}


def agent_configurations_attr(**kwargs):
    return attr.ib(validator=lambda i, a, v: (isinstance(v, dict) and
                                              all(key in CONFIGURATIONS_ALLOWED_KEYS and isinstance(value, dict)
                                                  for key, value in six.iteritems(v))
                                              ) if v is not None else True,
                   **kwargs)


def replace_configuration(default_enforcement_agent_operating_mode):
    if configuration_schema_opts.enforcementagent.agent_operating_mode != default_enforcement_agent_operating_mode:
        LOGGER.info('Changing default enforcement agent operating mode from %s to %s ',
                    configuration_schema_opts.enforcementagent.agent_operating_mode,
                    default_enforcement_agent_operating_mode)
        configuration_schema_opts.set_override('agent_operating_mode',
                                               default_enforcement_agent_operating_mode,
                                               AgentType.EnforcementAgent.name.lower())
        LOGGER.info('Changed default enforcement agent operating mode to %s successfully',
                    configuration_schema_opts.enforcementagent.agent_operating_mode)


@attr.s
class AgentModuleConfiguration(Dictable):
    configuration = dict_attr()
    revision_id = datetime_attr()


@attr.s
class AgentConfigurations(Dictable):
    configurations = agent_configurations_attr(converter=dictable_dict_converter(AgentModuleConfiguration))
    installation_profile = string_attr()

    def get_module_config(self, agent_module):
        if self.configurations.get(agent_module, {}):
            return self.configurations.get(agent_module, {}).configuration
        return {}

    def get_module_revision_id(self, agent_module):
        if self.configurations.get(agent_module, {}):
            return self.configurations.get(agent_module, {}).revision_id
        return None


@attr.s
class ConfigurationKeyUpdateResult(Dictable):
    success = bool_attr()
    error = string_attr()


@attr.s
class AgentModuleConfigurationUpdateResult(Dictable):
    configuration = dict_attr(converter=dictable_dict_converter(ConfigurationKeyUpdateResult))
    revision_id = datetime_attr()


@attr.s
class AgentConfigurationsUpdateResult(Dictable):
    source = string_attr()
    hostname = string_attr()
    report = agent_configurations_attr(converter=dictable_dict_converter(AgentModuleConfigurationUpdateResult))


