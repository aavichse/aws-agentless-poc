from common.logger import get_logger

LOG = get_logger(module_name=__name__)


class InventoryProcessor:
    # The entity-data types supported by the integration. Override with values on child
    ENTITY_SUPPORTED_TYPES = []

    def __init__(self, config, models):
        self._config = config
        self.models = models

    @property
    def name(self):
        """
        The name of the integration object as was configured by the user in UI
        """
        raise NotImplementedError

    @property
    def id(self):
        """
        The orchestration id of the inventory update
        """
        raise NotImplementedError

    @property
    def type(self):
        """
        The orchestration type of the inventory update
        """
        raise NotImplementedError

    def start(self):
        pass

    def config_change(self, config_name, old_value, new_value):
        pass

    def get_labels_and_metadata(self, asset, nics):
        """

        :param asset: InventoryItem model object (defined in contracts repo)
        :param nics: AggregatorNicInfoAPIModel list
        :return: tuple of labels (=set of tuples) and metadata (=tuple of tuples)
        """
        labels = self._create_labels(asset)
        metadata = self._create_metadata(asset)
        return labels, metadata

    @staticmethod
    def _create_labels(asset):
        return {(l.key, l.value) for l in asset.labels} if asset.labels else set()

    @staticmethod
    def _create_metadata(asset):
        if hasattr(asset.entity_data, 'power_state') and asset.entity_data.power_state is not None:
            power = asset.entity_data.power_state.value
            return (('power state', power),)
        return ()

    def is_on(self, asset):
        """
        :return: Return True if asset is explicitly in RUNNING state, or when the power state is not reported.
                Not all entity types have a power status, the default is to show it as ON!!
        """

        if hasattr(asset.entity_data, 'type') and asset.entity_data.type is self.models.common.inventory.Type.VM:
            return asset.entity_data.power_state is self.models.common.inventory.PowerState.RUNNING
        return True

    def is_supported(self, asset):
        """
        :return: Return True if the entity data type is known to the processor
        """
        if asset.entity_data and not isinstance(asset.entity_data, dict) and \
                asset.entity_data.type.value in self.ENTITY_SUPPORTED_TYPES:
            return True
        return False

