import dbus
import uuid
from ipaddress import ip_network as IPNetwork
from common.logger import get_logger
from common.py.utils.linux.network_mgr.model import ConnectionConfigMethod, NetworkConfigException, \
    ActiveConnectionState
from common.py.utils.network import ip2int

LOG = get_logger(module_name=__name__)

DEFAULT_DHCLIENT_TIMEOUT = 10


class NetworkConfigManager(object):
    """
    Configure network interfaces via NetworkManager https://developer.gnome.org/NetworkManager
    DBus API https://developer.gnome.org/NetworkManager/stable/spec.html
    """

    def __init__(self):
        self._bus = dbus.SystemBus()
        net_setting_proxy = self._bus.get_object("org.freedesktop.NetworkManager",
                                                 "/org/freedesktop/NetworkManager/Settings")
        network_mgr_proxy = self._bus.get_object("org.freedesktop.NetworkManager", "/org/freedesktop/NetworkManager")
        self._settings = dbus.Interface(net_setting_proxy, "org.freedesktop.NetworkManager.Settings")
        self._properties = dbus.Interface(network_mgr_proxy, "org.freedesktop.DBus.Properties")
        self._network_mgr = dbus.Interface(network_mgr_proxy, "org.freedesktop.NetworkManager")
        self._active_connections = self._get_active_connections()

    def config_interface(self, name, method, config=None):
        """
        Create or update network interface configuration
        Example config dict for method=manual
        {
           'IP address': '192.168.0.100',
           'Subnet mask': '255.255.255.0',
           'Default gateway': '192.168.0.1',
           'DNS server': '1.1.1.254',
           'Route network': '1.1.1.100',
           'Route netmask': '255.0.0.0',
           'Route gateway': '1.1.1.1',
        }

        :param name: network interface name as appear in nmcli device show GENERAL.DEVICE
        :param method: InterfaceConfigMethod
        :param config: if method is manual config is a dict containing IP address, network mask etc.
        :return:
        :raise NetworkConfigException if network configuration fails
        """
        assert isinstance(method, ConnectionConfigMethod)

        try:
            connection = self._get_connection(name)
            if not connection:
                self._add_connection(name=name, method=method, config=config)
            else:
                self._update_connection(name, method, connection, config)
        except Exception as e:
            LOG.exception("Failed to configure network interface '%s' method %s config %s", name, method, config)
            raise NetworkConfigException(e)

    def _get_connection(self, name):
        for connection in self._settings.ListConnections():
            conn_proxy = self._bus.get_object("org.freedesktop.NetworkManager", connection)
            conn_obj = dbus.Interface(conn_proxy, "org.freedesktop.NetworkManager.Settings.Connection")
            conn_settings = conn_obj.GetSettings()
            if conn_settings['connection']['interface-name'] == name and self._is_active_connection(conn_settings):
                LOG.debug("Found existing connection for %s with UUID %s", name, conn_settings['connection']['uuid'])
                return conn_obj

        return None

    def _add_connection(self, name, method, config):
        conn_uuid = uuid.uuid4()
        LOG.debug("Add new connection for %s with UUID %s", name, conn_uuid)
        ipv4_conn_settings = dict()
        self._update_ipv4_connection(name=name, method=method, ipv4_conn_settings=ipv4_conn_settings, config=config)
        connection_info = dbus.Dictionary({
            'interface-name': name,
            'type': '802-3-ethernet',
            'uuid': str(conn_uuid),
            'id': name
        })

        ethernet_info = {'duplex': 'full'}
        mtu = self._get_configured_mtu(config)
        if mtu:
            ethernet_info['mtu'] = mtu

        connection = dbus.Dictionary({
            '802-3-ethernet': dbus.Dictionary(ethernet_info),
            'connection': connection_info,
            'ipv4': dbus.Dictionary(ipv4_conn_settings),
            'ipv6': dbus.Dictionary({'method': 'ignore'})
        })

        self._settings.AddConnection(connection)

    def _update_connection(self, name, method, connection, config):
        conn_settings = connection.GetSettings()
        # add IPv4 setting if it doesn't yet exist
        if 'ipv4' not in conn_settings:
            conn_settings['ipv4'] = dict()
        else:
            # clear existing address info
            for key in ('addresses', 'address-data', 'gateway', 'route-data', 'routes'):
                conn_settings['ipv4'].pop(key, None)
        self._update_ipv4_connection(name=name, method=method, ipv4_conn_settings=conn_settings['ipv4'],
                                     config=config)

        mtu = self._get_configured_mtu(config)
        if mtu:
            if '802-3-ethernet' not in conn_settings:
                conn_settings['802-3-ethernet'] = dict()
            conn_settings['802-3-ethernet']['mtu'] = mtu

        # Save all the updated settings back to NetworkManager
        connection.Update(conn_settings)
        # Active the new configuration
        device = self._get_device(name=name)
        if not device:
            raise NetworkConfigException("Failed to find device for %s", name)

        self._disconnect_device(device=device)
        self._network_mgr.ActivateConnection(connection, device, "/")

    def _get_active_connections(self):
        """
        Get a list of active connections expresses the relationship between device and settings-connections
        :return:
        """
        active_connections = {}
        nmgr_active_connections = self._properties.Get("org.freedesktop.NetworkManager", "ActiveConnections")

        for conn in nmgr_active_connections:
            conn_proxy = self._bus.get_object("org.freedesktop.NetworkManager", conn)
            conn_proxy_prop = dbus.Interface(conn_proxy, "org.freedesktop.DBus.Properties")
            conn_state = conn_proxy_prop.Get("org.freedesktop.NetworkManager.Connection.Active", "State")
            conn_path = conn_proxy_prop.Get("org.freedesktop.NetworkManager.Connection.Active", "Connection")
            service_proxy = self._bus.get_object("org.freedesktop.NetworkManager", conn_path)
            conn_iface = dbus.Interface(service_proxy, "org.freedesktop.NetworkManager.Settings.Connection")
            conn_settings = conn_iface.GetSettings()
            conn_name = conn_settings['connection']['id']
            conn_uuid = conn_settings['connection']['uuid']
            active_connections[conn_uuid] = conn_name
            LOG.info("Found active connection '%s' UUID %s in state %s", conn_name, conn_uuid,
                     ActiveConnectionState(conn_state).name.lower())

        return active_connections

    def _is_active_connection(self, conn_settings):
        conn_uuid = conn_settings['connection']['uuid']
        return conn_uuid in self._active_connections and \
               self._active_connections[conn_uuid] == conn_settings['connection']['id']

    def _get_device(self, name):
        devices = self._network_mgr.GetDevices()
        for device in devices:
            device_proxy = self._bus.get_object("org.freedesktop.NetworkManager", device)
            interface_prop = dbus.Interface(device_proxy, "org.freedesktop.DBus.Properties")
            interface_name = interface_prop.Get("org.freedesktop.NetworkManager.Device", "Interface")
            if interface_name == name and len(device):
                return device

        return None

    def _disconnect_device(self, device):
        device_proxy = self._bus.get_object("org.freedesktop.NetworkManager", device)
        device_interface = dbus.Interface(device_proxy, "org.freedesktop.NetworkManager.Device")
        device_interface.Disconnect()

    @staticmethod
    def _update_ipv4_connection(name, method, ipv4_conn_settings, config):
        # set the method and change properties
        ipv4_conn_settings['method'] = str(method)

        if method == ConnectionConfigMethod.MANUAL:
            if not isinstance(config, dict):
                raise NetworkConfigException(
                    "Failed to configure interface '%s' with method %s. Invalid interface config provided ", name,
                    config)

            ip_address = config.get('IP address')
            network_mask = config.get('Subnet mask')
            if not ip_address or not network_mask:
                raise NetworkConfigException(
                    "Failed to configure interface '%s' with method manual. Missing mandatory parameters in config %s",
                    config)

            # Add the static IP address, prefix, and (optional) gateway
            prefix = IPNetwork('%s/%s' % (ip_address, network_mask)).prefixlen
            addr = dbus.Dictionary({'address': ip_address, 'prefix': dbus.UInt32(prefix)})
            ipv4_conn_settings['address-data'] = dbus.Array([addr], signature=dbus.Signature('a{sv}'))
            gateway = config.get('Default gateway')
            dns_server = config.get('DNS server')

            if gateway:
                ipv4_conn_settings['gateway'] = gateway
            if dns_server:
                ipv4_conn_settings['dns'] = dbus.Array([dbus.UInt32(ip2int(dns_server))], signature=dbus.Signature('u'))

            route_network = config.get('Route network')
            route_netmask = config.get('Route netmask')
            route_gateway = config.get('Route gateway')
            if route_network and route_netmask and route_gateway:
                route_prefix = IPNetwork('%s/%s' % (route_network, route_netmask)).prefixlen
                route = dbus.Dictionary(
                    {'dest': route_network, 'prefix': dbus.UInt32(route_prefix), 'gateway': route_gateway})
                ipv4_conn_settings['route-data'] = dbus.Array([route], signature=dbus.Signature('a{sv}'))
        elif method == ConnectionConfigMethod.AUTO:
            dhclient_timeout = config.get('DHCP Timeout',
                                          DEFAULT_DHCLIENT_TIMEOUT) if config else DEFAULT_DHCLIENT_TIMEOUT
            ipv4_conn_settings['dhcp-timeout'] = dhclient_timeout

    @staticmethod
    def _get_configured_mtu(config):
        return int(config['MTU']) if config and 'MTU' in config else None
