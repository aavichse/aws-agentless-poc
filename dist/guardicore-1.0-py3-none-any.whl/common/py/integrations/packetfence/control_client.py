import base64
import json
from aggregator.model.integrations import DEFAULT_VERSION
from common.py.integrations.base import BaseControlClient
from common.logger import get_logger

LOG = get_logger(module_name=__name__)


class PFControlClient(BaseControlClient):
    def __init__(self, url, user, passwd, *args, **kwargs):
        super().__init__(url, *args, **kwargs)
        self.user = user
        self.passwd = passwd

    @classmethod
    def from_config(cls, conf, api_version=None):
        if isinstance(conf, dict):
            connection_info = conf["connection_info"]
        else:
            connection_info = base64.b64decode(conf.connection_info)
            connection_info = json.loads(connection_info)
        api_version = api_version if api_version else conf.api_version
        if not api_version:
            api_version = connection_info['api_version']
            LOG.info("Using initial onboarding provided api version: {v}".format(v=api_version))
        return cls(
            url=connection_info["api_url"],
            user=connection_info["api_user"],
            passwd=connection_info["api_pswd"],
            api_version=api_version
        )
