from enum import Enum


class AgentQueryActions(Enum):
    NEW_QUERY = 'new_query'
    ABORT_QUERY = 'abort_query'


class AgentQueryErrorTypes(Enum):
    ABORTED = 'aborted'
    FAILED_INSTALLATION = 'failed_installation'
    NOT_SUPPORTED = 'not_supported'
    BAD_SYNTAX = 'bad_syntax'
    TIMEOUT = 'timeout'
    GENERAL_ERROR = 'general_error'
    DISABLED = 'disabled'


AGENT_QUERY_ERROR_TYPE_TITLES = {error_type.value: error_type.name.replace('_', ' ').title()
                                 for error_type in AgentQueryErrorTypes}
