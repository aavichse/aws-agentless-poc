import base64
import json
import requests
from common.py.integrations.base import BaseControlClient, IntegrationControlClientException
from common.logger import get_logger

LOG = get_logger(module_name=__name__)

# Since Azure API Management (APIM) is adding openapi yaml name to the endpoint path,
# we also add here the yaml name on each mapping uri (the prefix before 'v1/..').


class AzureControlClient(BaseControlClient):
    FUNC_TRANSLATION = {
        "get_env_info":             dict(request_type="get", uri="info/{version}/operations/env-info",
                                         response_model='operations.info.IntegrationEnvInfo'),
        "onboard":                  dict(request_type="post", uri="onboard/{version}/operations/onboarding",
                                         request_model='operations.onboard.Onboard'),
        "onboard_status":           dict(request_type="post", uri="onboard/{version}/operations/status",
                                         request_model='operations.onboard.StatusRequest',
                                         response_model='operations.onboard.StatusResponse'),
        "health":                   dict(request_type="get", uri="health/{version}/operations/health",
                                         response_model="operations.health.ComponentHealth"),
        "metrics":                  dict(request_type="get", uri="health/{version}/operations/metrics",
                                         response_model='operations.health.ComponentMetrics'),
        "get_config_options":       dict(request_type="get", uri="config/{version}/operations/internal/config_metadata",
                                         response_model='operations.config.InternalConfigMetadata'),
        "set_service_configs":      dict(request_type="post", uri="config/{version}/operations/internal/internal_config",
                                         request_model='operations.config.InternalConfig'),
        "asset_lookup":             dict(request_type="post", uri="lookup/{version}/provider/lookup", ign_codes=(432,),
                                         request_model='provider.lookup.LookupRequest',
                                         response_model='common.inventory.InventoryItem'),
        "version_handshake":        dict(request_type="post", uri="version/version-handshake",
                                         request_model='version.VersionHandshakeData',
                                         response_model='version.VersionHandshakeData'),
        "policy":                   dict(request_type="post", uri="enforcement/{version}/consumer/policy",
                                         request_model='consumer.enforcement.EnforcementPolicy'),
        "policy_inventory":         dict(request_type="post", uri="enforcement/{version}/consumer/inventory",
                                         request_model='consumer.enforcement.EnforcementPolicyInventory')
    }

    FUNC_PAGINATION_TRANSLATION = {
        "full_inventory": dict(request_type="get", uri="inventory/{version}/provider/inventory",
                               response_model="provider.inventory.Inventory"),
        "subscriptions": dict(request_type="get", uri="info/{version}/operations/env-units-list",
                              response_model="operations.info.EnvUnits"),
        "network_topology": dict(request_type="get", uri="inventory/{version}/provider/topology",
                                 response_model='provider.inventory.NetworkTopology')
    }

    def __init__(self, url, key, api_version, *args, **kwargs):
        super().__init__(url, api_version)
        self.headers["Ocp-Apim-Subscription-Key"] = key

    @classmethod
    def from_config(cls, conf, api_version=None):
        if isinstance(conf, dict):
            manifest = conf["manifest"]
        else:
            manifest = base64.b64decode(conf.manifest)
            manifest = json.loads(manifest)
        api_version = api_version if api_version else conf.get("api_version")
        if not api_version:
            api_version = manifest['contract_version']['value']
            LOG.info("Using manifest provided api version: {v}".format(v=api_version))
        return cls(
            url=manifest['apim_gateway_url']['value'],
            key=manifest['apim_subscription_key']['value'],
            api_version=api_version
        )

    def get_environment_details(self):
        rsp = self.get_env_info()
        if rsp is None:
            raise IntegrationControlClientException("Internal Collector Error")
        if not rsp.ok:
            msg = rsp.reason if rsp.reason is not None else "Internal Collector Error"
            raise IntegrationControlClientException(msg)

        details = rsp.model.model_dump(exclude_none=True, by_alias=True, mode="json")
        rsp = self.subscriptions()
        if rsp is None:
            raise IntegrationControlClientException("Internal Collector Error")
        details['subscriptions'] = rsp.model_dump(exclude_none=True, by_alias=True, mode="json")
        return details
