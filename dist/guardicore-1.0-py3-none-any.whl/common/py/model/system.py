
from enum import IntEnum
from collections import defaultdict


class FsEntityType(IntEnum):
    Directory = 1
    File = 2
    SymLink = 3
    FileNode = 4


class OperatingSystem(IntEnum):
    Unknown = 0
    Windows = 1
    Linux = 2
    HTTP = 3
    SMBLure = 4
    Solaris = 5
    HPUX = 6
    AIX = 7
    F5 = 8
    FreeBSD = 9
    LPAR = 10
    macOS = 11


OperatingSystemStringToEnum = defaultdict(lambda: OperatingSystem.Unknown)
OperatingSystemStringToEnum['windows'] = OperatingSystem.Windows
OperatingSystemStringToEnum['linux'] = OperatingSystem.Linux
OperatingSystemStringToEnum['solaris'] = OperatingSystem.Solaris
OperatingSystemStringToEnum['hpux'] = OperatingSystem.HPUX
OperatingSystemStringToEnum['aix'] = OperatingSystem.AIX
OperatingSystemStringToEnum['freebsd'] = OperatingSystem.FreeBSD
OperatingSystemStringToEnum['lpar'] = OperatingSystem.LPAR
OperatingSystemStringToEnum['macos'] = OperatingSystem.macOS
