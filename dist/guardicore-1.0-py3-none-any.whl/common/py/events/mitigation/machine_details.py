from enum import IntEnum, Enum
from mongoengine import EmbeddedDocumentField, DynamicEmbeddedDocument
from mongoengine.document import EmbeddedDocument
from mongoengine.fields import StringField, ListField, IntField, DictField, BooleanField, DateTimeField, \
    EmbeddedDocumentListField

from common.py.apis import AgentComponentType
from common.py.events import IPVersion
from common.py.events.controller.cloud_info import CloudProvider
from common.py.model.system import OperatingSystem
from common.py.models.events.base_event import BaseEvent
from common.py.utils.mongo import IntEnumField, EnumField

__author__ = 'Amit'


class PackageType(Enum):
    Unknown = 'unknown'
    Windows = 'windows'
    Docker = 'docker'
    DEB = 'deb'
    RPM = 'rpm'
    TGZ = 'tgz'
    AIX = 'aix_pkg'
    MAC = 'mac_pkg'
    Solaris = 'solaris_pkg'
    Mock = 'mock'
    RPM_OLD = 'old_rpm'


class MachineUpdateSource(IntEnum):
    AgentUpdateSource = 0


class UpdateType(IntEnum):
    MachineAdded = 0
    MachineRemoved = 1
    MachineDetailsChanged = 2


class AgentType(IntEnum):
    RevealAgent = 2
    Test = 5
    DatapathVisibility = 7
    IPFlowVisibility = 8

    DeceptionAgent = 12
    EnforcementAgent = 13
    DetectionAgent = 14
    Controller = 15
    AccessAgent = 16

    # handling assets with duplicate IPs in dhcp environment by creating a new machine update for the relevant assets
    # in order to separate between agent machine details with duplicate ips machine details.
    # feature jira issue: GC-26765
    DuplicateIPs = 29

    # deprecated and should be deleted
    KubernetesNode = 101
    KubernetesPod = 102

    CloudApplication = 110
    Packetfence = 111


class AgentAggregateType:
    EXTERNAL_PROVIDERS = [AgentType.CloudApplication, AgentType.Packetfence]


class AgentInstallationMode(Enum):
    DEFAULT = "default"
    AZTC = "aztc"                   # Akamai Zero Trust Client (EAA)


class MachineAddressDetails(DynamicEmbeddedDocument):
    address_type = IntEnumField(enum_type=IPVersion, required=True)
    address = StringField(required=True)
    prefix_len = IntField(required=False)


class MachineInterfaceDetails(DynamicEmbeddedDocument):
    interface_name = StringField(required=True)
    hardware_address = StringField(required=False)
    ip_addresses = ListField(EmbeddedDocumentField(MachineAddressDetails), required=False)
    is_virtual = BooleanField(required=False, default=False)
    is_bond = BooleanField(required=False, default=False)
    is_up = BooleanField(required=False, default=True)
    is_loopback = BooleanField(required=False, default=False)
    is_cloud_public = BooleanField(required=False, default=False)
    cloud_network = StringField(required=False)
    is_corporate_interface = BooleanField(required=False, default=True)


class OperatingSystemDetails(DynamicEmbeddedDocument):
    os_type = IntEnumField(enum_type=OperatingSystem)
    os_display_name = StringField(required=False)
    os_version_name = StringField(required=True)
    os_guest_name = StringField(required=True)
    num_of_processors = IntField(required=False, default=1)
    os_kernel_minor = IntField(required=False)
    os_kernel_major = IntField(required=False)
    full_kernel_version = StringField(required=False)
    kernel_config_hash = StringField(required=False)
    distribution = StringField(required=False)
    install_date = DateTimeField(required=False)


class HardwareDetails(DynamicEmbeddedDocument):
    hw_uuid = StringField(required=False)
    bios_uuid = StringField(required=False)
    vendor = StringField(required=False)
    serial = StringField(required=False)
    instance_id = StringField(required=False)
    cloud_provider = IntEnumField(required=False, enum_type=CloudProvider, default=CloudProvider.OnPremise)
    architecture = StringField(required=False)


class ResourceLimitationModuleDetails(DynamicEmbeddedDocument):
    limit_type = StringField(required=True)
    limit_support = StringField(required=True)
    suit = StringField(required=True)
    override_limits = DictField(required=False)
    limit_failures = ListField(StringField(), required=False)
    applied_limits = DictField(required=False)


class ResourceLimitationAgentDetails(DynamicEmbeddedDocument):
    enforcement = EmbeddedDocumentField(document_type=ResourceLimitationModuleDetails, required=False)
    detection = EmbeddedDocumentField(document_type=ResourceLimitationModuleDetails, required=False)
    reveal = EmbeddedDocumentField(document_type=ResourceLimitationModuleDetails, required=False)
    deception = EmbeddedDocumentField(document_type=ResourceLimitationModuleDetails, required=False)
    controller = EmbeddedDocumentField(document_type=ResourceLimitationModuleDetails, required=False)


class BundleStatus(EmbeddedDocument):
    bundle_name = StringField(required=False)
    bundle_version = StringField(required=False)
    bundle_state = StringField(required=False)


class ModuleBundlesStatus(EmbeddedDocument):
    module_type = IntEnumField(required=True, enum_type=AgentComponentType)
    bundles_status = EmbeddedDocumentListField(document_type=BundleStatus)


class K8sClusterDetails(EmbeddedDocument):
    cluster_id = StringField(required=False)
    cluster_name = StringField(required=False)


class MachineDetails(EmbeddedDocument):
    os = IntEnumField(enum_type=OperatingSystem, required=True)
    name = StringField(required=False)
    hostname = StringField(required=True)
    display_name = StringField(required=False)
    network = ListField(EmbeddedDocumentField(MachineInterfaceDetails), required=False)
    os_details = EmbeddedDocumentField(document_type=OperatingSystemDetails, required=False)
    hardware = EmbeddedDocumentField(document_type=HardwareDetails, required=False)
    agent_type = IntEnumField(enum_type=AgentType, required=True)
    agent_version = StringField(required=False)
    agent_bundles_status = EmbeddedDocumentListField(document_type=ModuleBundlesStatus, required=False)
    build_commit = StringField(required=False)
    build_date = DateTimeField(required=False)
    install_date = DateTimeField(required=False)
    supported_features = ListField(StringField(), required=False)
    resource_limits = EmbeddedDocumentField(document_type=ResourceLimitationAgentDetails, required=False)
    containers = ListField(StringField(), required=False)
    labels = DictField()
    client_cert_ssl_cn_name = StringField(required=False)
    client_cert_ssl_expire_date = IntField(required=False)
    protocol_versions = DictField()
    k8s_cluster_details = EmbeddedDocumentField(document_type=K8sClusterDetails, required=False)
    profile = StringField(required=False)
    installation_mode = EnumField(enum_type=AgentInstallationMode, required=False)


class MachineDetailsUpdate(BaseEvent):
    meta = {
        'allow_inheritance': True
    }

    vm_uuid = StringField(required=True)
    update_type = IntEnumField(enum_type=UpdateType)
    is_foreign = BooleanField(required=False, default=False)
    details = EmbeddedDocumentField(document_type=MachineDetails, required=False)

    @classmethod
    def get_vm_addresses_from_vm_nics(cls, vm_nics):
        vm_addresses_details = [ip_addresses for interfaces in vm_nics
                                for ip_addresses in interfaces['ip_addresses']]
        # address['address'] may contain address with spaces ('100 . 100 . 100 . 100')
        return [address['address'].replace(' ', '') for address in vm_addresses_details]

    def __repr__(self):
        return self.details.to_json()
