#! /usr/bin/env python
# -*- coding:utf-8 -*-

from __future__ import unicode_literals
from __future__ import print_function

import os
import errno
from pwd import getpwnam
from common.logger import get_logger
from common.py.utils.linux.cgroups import BASE_CGROUPS, CgroupsException

LOG = get_logger(module_name=__name__)


def get_user_info(user):
    try:
        user_system = getpwnam(user)
    except KeyError:
        uid = os.getuid()
        gid = os.getgid()
    else:
        uid = user_system.pw_uid
        gid = user_system.pw_gid
    return uid, gid


def create_user_cgroups(user, script=True):
    LOG.debug("Creating cgroups sub-directories for user %s", user)
    # Get hierarchies and create cgroups sub-directories
    try:
        hierarchies = os.listdir(BASE_CGROUPS)
    except OSError as exc:
        if exc.errno == 2:
            raise CgroupsException("cgroups filesystem is not mounted on %s" % BASE_CGROUPS)

        raise

    LOG.debug("Hierarchies availables: %s", hierarchies)
    for hierarchy in hierarchies:
        user_cgroup = os.path.join(BASE_CGROUPS, hierarchy, user)
        if not os.path.exists(user_cgroup):
            try:
                os.mkdir(user_cgroup)
            except OSError as e:
                if e.errno == errno.EACCES:
                    if script:
                        raise CgroupsException("Permission denied, you don't have root privileges")
                    else:
                        raise CgroupsException("Permission denied. If you want to use cgroups without root"
                                               " priviliges, please execute first the 'user_cgroups' command"
                                               " (as root or sudo).")
                elif e.errno == errno.EEXIST:
                    pass
                else:
                    raise OSError(e)
            else:
                uid, gid = get_user_info(user)
                os.chown(user_cgroup, uid, gid)
    LOG.debug("cgroups sub-directories created for user %s", user)
