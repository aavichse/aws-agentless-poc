import os
import psutil
from common import logger

__author__ = 'ofri'

LOG = logger.get_logger(module_name=__name__)


class EnvironmentStatistics(object):
    def __init__(self):
        self._get_process_stats = lambda p: {'name': p.name(),
                                             'cmdline': p.cmdline(),
                                             'cpu_usage': p.cpu_percent(),
                                             'memory_usage': p.memory_percent()}
        self._current_process = psutil.Process(pid=os.getpid())

    @staticmethod
    def get_network_interfaces_params(nics):
        """
        :param nics: (optional) list of network interfaces names
        :return: A dictionary of NICs and their network statistics.
                If nics is None, it returns statistics for all NICs. Otherwise it returns the statistics of nics.
        """
        try:
            nic_counters = psutil.net_io_counters(pernic=True)
        except psutil.AccessDenied as e:
            LOG.warn('Failed to get network counters - %s', e)
            return {}
        if not nics:
            nics = nic_counters.keys()

        # noinspection PyProtectedMember
        return {_mongo_repair(key): nic_counters[key]._asdict() for key in nics if key in nic_counters}

    def get_processes_resources_usage(self):
        """
        :return: A dictionary of process names and their corresponding (cmdline, cpu usage and memory usage).
                If process_names is None, it returns stats for all processes.
                Otherwise it returns the stats of process_names.
        """
        processes = {}
        try:
            memory = psutil.virtual_memory()
            processes['current_process'] = {str(os.getpid()): self._get_process_stats(self._current_process)}
            processes['total'] = {'cpu_usage': psutil.cpu_percent(),
                                  'memory_usage': memory.percent,
                                  'cpu_count': psutil.cpu_count(),
                                  'cpu_count_without_logical': psutil.cpu_count(logical=False),
                                  'total_memory': memory.total}
        except psutil.AccessDenied:
            LOG.warn('Failed to get process statistics - Access Denied')
        except psutil.NoSuchProcess as exc:
            LOG.warn('Failed to get process statistics - %s', exc)
        return processes

    def get_environment_stats(self, nics=None):
        stats = {'network_interfaces': self.get_network_interfaces_params(nics),
                 'processes_resources': self.get_processes_resources_usage()}
        return stats

def _mongo_repair(key):
    return key.replace('.', '%2E').replace('$', '%24')
