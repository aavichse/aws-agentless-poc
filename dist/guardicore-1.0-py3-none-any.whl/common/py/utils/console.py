
from enum import Enum


class ConsoleColorStyle(Enum):
    # styles
    BOLD = ['\033[1m', '\033[22m']
    ITALIC = ['\033[3m', '\033[23m']
    UNDERLINE = ['\033[4m', '\033[24m']
    INVERSE = ['\033[7m', '\033[27m']
    # grayscale
    WHITE = ['\033[37m', '\033[39m']
    GREY = ['\033[90m', '\033[39m']
    BLACK = ['\033[30m', '\033[39m']
    # color
    BLUE = ['\033[34m', '\033[39m']
    CYAN = ['\033[36m', '\033[39m']
    GREEN = ['\033[32m', '\033[39m']
    MAGENTA = ['\033[35m', '\033[39m']
    RED = ['\033[31m', '\033[39m']
    YELLOW = ['\033[33m', '\033[39m']


def colorify(text, style_color_name):
    """Prefix and suffix text to render terminal color"""
    if isinstance(style_color_name, ConsoleColorStyle):
        pre_suf_list = style_color_name.value
    else:
        pre_suf_list = ConsoleColorStyle[style_color_name].value

    text = '{}{}{}'.format(pre_suf_list[0], text, pre_suf_list[1])
    return text