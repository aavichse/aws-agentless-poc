import struct
import attr
import socket

from common.logger import get_logger
from common.py.model.exceptions import GuardicoreException

LOG = get_logger(module_name=__name__)

# PROXY protocol v2 definitions
PROXY_V2_SIG = b"\x0D\x0A\x0D\x0A\x00\x0D\x0A\x51\x55\x49\x54\x0A"
PROXY_V2_VERSION_1 = 0x20
PROXY_V2_VERSION_2 = 0x21
PROXY_V2_TCPv4 = 0x11
PROXY_V2_TCPv6 = 0x21
PROXY_V2_HEADER_FORMAT = b"!%dsBBH" % (len(PROXY_V2_SIG), )
PROXY_V2_HEADER_LEN = struct.calcsize(PROXY_V2_HEADER_FORMAT)
PROXY_V2_TCPv4_ADDR_FORMAT = b"!LLHH"
PROXY_V2_TCPv4_ADDR_LEN = struct.calcsize(PROXY_V2_TCPv4_ADDR_FORMAT)

PROXY_V2_PP2_TLV_FORMAT = b"!BBB"
PROXY_V2_PP2_TLV_LEN = struct.calcsize(PROXY_V2_PP2_TLV_FORMAT)

PROXY_V2_PP2_TYPE_ALPN = 0x01
PROXY_V2_PP2_TYPE_AUTHORITY = 0x02
PROXY_V2_PP2_TYPE_CRC32C = 0x03
PROXY_V2_PP2_TYPE_NOOP = 0x04
PROXY_V2_PP2_TYPE_SSL = 0x20
PROXY_V2_PP2_SUBTYPE_SSL_VERSION = 0x21
PROXY_V2_PP2_SUBTYPE_SSL_CN = 0x22
PROXY_V2_PP2_SUBTYPE_SSL_CIPHER = 0x23
PROXY_V2_PP2_SUBTYPE_SSL_SIG_ALG = 0x24
PROXY_V2_PP2_SUBTYPE_SSL_KEY_ALG = 0x25
PROXY_V2_PP2_TYPE_NETNS = b"0x30"

PROXY_V2_PP2_TLV_SSL_FORMAT = b"!BL"
PROXY_V2_PP2_TLV_SSL_LEN = struct.calcsize(PROXY_V2_PP2_TLV_SSL_FORMAT)


@attr.s(slots=True, frozen=True)
class ProxyProtocolHeader(object):
    src_ip = attr.ib()
    dst_ip = attr.ib()
    src_port = attr.ib()
    dst_port = attr.ib()

    ssl_verified = attr.ib(default=False)
    ssl_cn_name = attr.ib(default=None)
    ssl_requested_sni = attr.ib(default="")

    def as_dict(self):
        return dict(src_ip=self.src_ip, dst_ip=self.dst_ip,
                    src_port=self.src_port, dst_port=self.dst_port)


class ProxyProtocolException(GuardicoreException):
    pass


# if this error raised - the content is not a proxy protocol - and its safe to continue
class NotProxyProtocol(ProxyProtocolException):
    pass


class ProxyProtocolParser(object):
    def __init__(self):
        self._proxy_info_buff = b""
        self._total_header_len = 0
        self._ssl_verified = False
        self._ssl_cn_name = None
        self._ssl_requested_sni = b""

    def parse(self, new_data):
        """
        Parse proxy protocol.

        :param new_data: data read from client connection
        :return: None in case data is yet incomplete, or ProxyProtocolHeader when parsing is done.
        """

        self._proxy_info_buff += new_data

        sig_bytes = self._proxy_info_buff[:len(PROXY_V2_SIG)]
        if not PROXY_V2_SIG.startswith(sig_bytes):
            raise NotProxyProtocol("invalid magic for PROXY protocol")

        # first header part not ready yet
        if len(self._proxy_info_buff) < PROXY_V2_HEADER_LEN:
            return None

        magic, version, family, header_len = struct.unpack(PROXY_V2_HEADER_FORMAT,
                                                           self._proxy_info_buff[:PROXY_V2_HEADER_LEN])
        self._total_header_len = PROXY_V2_HEADER_LEN + header_len

        if version not in (PROXY_V2_VERSION_1, PROXY_V2_VERSION_2):
            raise ProxyProtocolException("unsupported PROXY protocol version")

        elif family != PROXY_V2_TCPv4:
            raise ProxyProtocolException("unsupported PROXY protocol family")

        elif PROXY_V2_TCPv4_ADDR_LEN > header_len:
            raise ProxyProtocolException("invalid PROXY protocol address length")

        # full header not ready yet
        if len(self._proxy_info_buff) < PROXY_V2_HEADER_LEN + header_len:
            return None

        # read header
        addr_hdr = self._proxy_info_buff[PROXY_V2_HEADER_LEN:PROXY_V2_HEADER_LEN + PROXY_V2_TCPv4_ADDR_LEN]
        src_ip, dst_ip, src_port, dst_port = struct.unpack(PROXY_V2_TCPv4_ADDR_FORMAT, addr_hdr)

        more_headers = self._proxy_info_buff[PROXY_V2_HEADER_LEN + PROXY_V2_TCPv4_ADDR_LEN:PROXY_V2_HEADER_LEN + header_len]
        self._parse_extra_headers(more_headers)

        return ProxyProtocolHeader(
            src_ip=socket.inet_ntoa(struct.pack("!L", src_ip)),
            dst_ip=socket.inet_ntoa(struct.pack("!L", dst_ip)),
            src_port=src_port,
            dst_port=dst_port,
            ssl_verified=self._ssl_verified,
            ssl_cn_name=self._ssl_cn_name if not self._ssl_cn_name else self._ssl_cn_name.decode('utf-8'),
            ssl_requested_sni=self._ssl_requested_sni)

    def _parse_extra_headers(self, headers):
        while headers:
            htype, length_hi, length_lo = struct.unpack(PROXY_V2_PP2_TLV_FORMAT, headers[:PROXY_V2_PP2_TLV_LEN])
            length = (length_hi << 8) | length_lo
            value = headers[PROXY_V2_PP2_TLV_LEN:PROXY_V2_PP2_TLV_LEN + length]
            self._handle_extra_header(htype, value)
            headers = headers[PROXY_V2_PP2_TLV_LEN + length:]

    def _handle_extra_header(self, htype, value):
        if htype == PROXY_V2_PP2_TYPE_SSL:
            client, verify = struct.unpack(PROXY_V2_PP2_TLV_SSL_FORMAT, value[:PROXY_V2_PP2_TLV_SSL_LEN])
            self._ssl_verified = (verify == 0)
            self._parse_extra_headers(value[PROXY_V2_PP2_TLV_SSL_LEN:])
        elif htype == PROXY_V2_PP2_SUBTYPE_SSL_CN:
            self._ssl_cn_name = value
        elif htype == PROXY_V2_PP2_TYPE_AUTHORITY:
            self._ssl_requested_sni = value
        else:
            # other headers - which we ignore
            # for full list see https://www.haproxy.org/download/1.8/doc/proxy-protocol.txt
            pass

    def get_remain_data(self):
        return self._proxy_info_buff[self._total_header_len:]
