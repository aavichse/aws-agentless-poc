SETUP_CONFIGURATION_PATH = '/etc/guardicore/guardicore_setup.conf'
AGGREGATOR_DEFAULT_HOST_SSH_PORT = 22
