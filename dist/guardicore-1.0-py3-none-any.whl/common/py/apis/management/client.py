import base64
import calendar
import datetime
import functools
import logging
import random
import time
import uuid

from six.moves.urllib.parse import urljoin

from common.py.apis import (NEW_REST_API_BASE_URL, MANAGEMENT_REST_API_PORT, AUTOMATION_API_BASE_URL,
                            REST_API_BASE_URL_V4, REST_API_ORIGIN)
from common.py.apis.management.rest import RESTManagementAPI
from common.py.clouds import LabelingStrategy
from common.py.clouds.aws import AwsAuthenticationMethodDescriptions, AwsAuthenticationMethod
from common.py.clouds.inventory_api import AuthenticationScheme, DEFAULT_REPORT_EXPIRATION
from common.py.clouds.openstack import FullPortPullStrategy, DifferentialPortPullStrategy
from common.py.filter.policy import PolicyRuleType
from common.py.orchestration.orchestration_type import OrchestrationType

__author__ = 'Lior'

DEFAULT_VIEW_EXPLORE = 'Explore'


def datetime_to_timestamp(dt):
    """
    Convert a datetime object to timestamp in ms since epoch (which is the format
     used to query management).
    :param dt: datetime timestamp
    :return: dt as milliseconds since epoch
    """
    return int(calendar.timegm(dt.timetuple()) * 1000 + dt.microsecond / 1000)


def add_default_from_to_time(start_delta=datetime.timedelta(days=-30), end_delta=datetime.timedelta(days=30),
                             start_param_name='from_time', end_param_name='to_time'):
    def decorator(f):
        @functools.wraps(f)
        def decorated(self, *args, **kwargs):
            now = datetime.datetime.utcnow()
            filts = {start_param_name: now + start_delta,
                     end_param_name: now + end_delta}
            for filt, default_value in filts.items():
                if kwargs.get(filt) is None:
                    kwargs[filt] = default_value
                if isinstance(kwargs[filt], str):
                    continue
                kwargs[filt] = datetime_to_timestamp(kwargs[filt])

            return f(self, *args, **kwargs)

        return decorated

    return decorator


class SystemComponentApi(object):
    def __init__(self, client_api, base_resource):
        self.client_api = client_api
        self.base_resource_url = urljoin(NEW_REST_API_BASE_URL, base_resource)

    def _json_query(self, *args, **kwargs):
        return self.client_api._json_query(*args, **kwargs)

    def list(self, **filt):
        return self._json_query(self.base_resource_url,
                                params=dict(extended=True,
                                            **filt))

    def get(self, component_id):
        return self._json_query(self.base_resource_url + '/%s' % component_id)

    def get_configuration_schema(self, component_id, conf_view=None):
        return self._json_query(self.base_resource_url + '/%s/configuration/schema' % component_id,
                                params={'view': conf_view})

    def get_configuration(self, component_id, include_defaults=True, conf_view=None):
        return self._json_query(self.base_resource_url + '/%s/configuration' % component_id,
                                params={'include_defaults': include_defaults,
                                        'view': conf_view})

    def get_group_configuration(self, include_defaults=True, conf_view=None):
        return self._json_query(self.base_resource_url + '/configuration',
                                params={'include_defaults': include_defaults,
                                        'view': conf_view})

    def set_configuration(self, component_id, configuration, conf_view=None):
        self._json_query(self.base_resource_url + '/%s/configuration' % component_id,
                         method='PUT',
                         params={'view': conf_view},
                         data=configuration,
                         return_json=False)

    def set_group_configuration(self, configuration, conf_view=None):
        self._json_query(self.base_resource_url + '/configuration',
                         method='PUT',
                         params={'view': conf_view},
                         data=configuration,
                         return_json=False)

    def reset_configuration(self, component_id):
        self._json_query(self.base_resource_url,
                         method='POST',
                         data={'action': 'reset_configuration',
                               'component_ids': [component_id]},
                         return_json=False)

    def set_state(self, component_id, state):
        self._json_query(self.base_resource_url, method='POST',
                         data={'action': 'change_state',
                               'state': state,
                               'component_ids': [component_id]},
                         return_json=False)

    def is_task_running(self):
        status = self._json_query(self.base_resource_url + '/tasks')
        if status == {} or status['status'] is None:
            return False
        return status['status']['state'] != 'SUCCESS'

    def send_action_command(self, action, component_ids=None):
        self._json_query(self.base_resource_url,
                         method='POST',
                         params=dict(action=action),
                         data=dict(component_ids=component_ids) if component_ids is not None else dict(),
                         return_json=False)

    def stop(self, component_ids):
        """
        Stop non-agent components. Method has been retained for backwards compatibility
        """
        self.send_action_command(action='power_off', component_ids=component_ids)

    def start(self, component_ids):
        """
        Start non-agent components. Method has been retained for backwards compatibility
        """
        self.send_action_command(action='restart', component_ids=component_ids)

    def stop_agent(self, component_ids):
        """
        Stop agent components.
        """
        self.send_action_command(action='stop', component_ids=component_ids)

    def start_agent(self, component_ids):
        """
        Start agent components.
        """
        self.send_action_command(action='start', component_ids=component_ids)

    def restart(self, component_ids):
        """
        Restart non-agent components.
        """
        self.send_action_command(action='restart', component_ids=component_ids)

    def forget(self, component_ids):
        """
        Forget components.
        """
        self.send_action_command(action='remove_components', component_ids=component_ids)

    def remove_invalid_components(self):
        """
        Remove all components with `AgentMissing` flag
        """
        self.send_action_command(action='remove_invalid_components')


class ClientManagementAPI(object):
    def __init__(self, management_host, username=None, password=None, rest_auth_enabled=True, auto_reconnect=True,
                 port=MANAGEMENT_REST_API_PORT, ssl=True, two_factor_auth=False, auto_connect=True,
                 use_scripts_api=False, keep_last_response=False):
        """
        :param username: username to use with mgmt REST
        :param password: password to use with mgmt REST
        :param management_host: IP or host name ('localhost', NOT 'http://....')
        :param rest_auth_enabled: True to enable REST authentication (using username & password),
            False for unauthenticated access (must be supported by server).
        :param auto_reconnect: True to reconnect if needed
        :param auto_connect: True to connect on initialization
        :param port: use the selected port to connect to rest servers
        :param ssl: True to connect to REST servers using ssl.
        :param use_scripts_api: True to proxy all requests to ScriptRestServers instead of regular RestServers
        """
        self.restapi = RESTManagementAPI(management_host=management_host, username=username, password=password,
                                         rest_auth_enabled=rest_auth_enabled, auto_reconnect=auto_reconnect,
                                         port=port, ssl=ssl, two_factor_auth=two_factor_auth, auto_connect=auto_connect,
                                         use_scripts_api=use_scripts_api,
                                         keep_last_response=keep_last_response)

        self.logger = logging.getLogger('guardicore.ClientManagementAPI')

        self.aggregators = SystemComponentApi(self, 'aggregators')
        self.agent_aggregators = SystemComponentApi(self, 'agent_aggregators')
        self.collectors = SystemComponentApi(self, 'collectors')
        self.agents = SystemComponentApi(self, 'agents')
        self.honeypots = SystemComponentApi(self, 'honeypots')

    def logout(self):
        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'logout'),
                         method='POST',
                         return_json=False)

    @staticmethod
    def get_new_incident_id():
        return uuid.uuid4()  # For backwards compatibility with HPAPP API. We don't actually generate these on server

    def _json_query(self, *args, **kwargs):
        return self.restapi.json_query(*args, **kwargs)

    def _download_file(self, uri, download_dir_path, **kwargs):
        return self.restapi.download_file(uri, download_dir_path, **kwargs)

    # Utils
    def _filter_options(self, route, filter_name, filter_value=None, **filt):
        params = dict(filter_name=filter_name,
                      filter_value=filter_value or '')
        params.update(filt)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, '/'.join((route, 'filter-options'))),
                                params=params)

    def _filter_options_resolve(self, route, **filt):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, '/'.join((route, 'filter-options-resolve'))),
                                params=filt)

    # System
    def get_system_status(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system-status'))

    @add_default_from_to_time()
    def list_system_events(self, raw_result=False, **filt):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system-events'), params=filt)
        return raw if raw_result else raw['objects']

    def get_system_notifications(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system-notifications'))

    def num_of_system_events(self, **filt):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system-events'), params=filt)['total_count']

    def get_export_configuration_task_status(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'export_configuration_task_status'),
                                method='GET')

    def collected_data_cleanup(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'cleanup/collected-data'),
                                method='POST',
                                data={'confirm': True},
                                return_json=False)

    def orchestration_data_cleanup(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'cleanup/assets-and-policies'),
                                method='POST',
                                data={'confirm': True},
                                return_json=False)

    def system_cleanup(self):
        # TODO: remove that hack and simply clean all data
        # (devops scripts should be changed to use orchestration_data_cleanup instead)
        return self.orchestration_data_cleanup()
        # return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'cleanup/all'),
        #                         method='POST',
        #                         data={'confirm': True},
        #                         return_json=False)

    def purge_queue(self, queue_name=None):
        """
        Purge a given queue
        :param queue_name: the name of the queue to purge
        """
        if queue_name:
            return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'purge-queue'),
                                    method='POST',
                                    data={'name': queue_name},
                                    return_json=False)

    def get_system_configuration(self, conf_view=None, conf_group=None):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system-configuration'),
                                params=dict(view=conf_view,
                                            group=conf_group),
                                follow_redirects=True)

    def set_system_configuration(self, configuration_dict, conf_view=None, conf_group=None):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system-configuration'),
                                params=dict(view=conf_view,
                                            group=conf_group),
                                method='PUT',
                                data=configuration_dict,
                                return_json=False)

    def get_reputation_configuration(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'reputation'),
                                params=dict(view="reputation"),
                                method='GET')

    def set_reputation_configuration(self, configuration_dict):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'reputation'),
                                params=dict(view="reputation"),
                                method='PUT',
                                data=configuration_dict,
                                return_json=False)

    def set_segmentation_configuration(self, configuration_dict):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'segmentation'),
                                params=dict(view="segmentation"),
                                method='PUT',
                                data=configuration_dict,
                                return_json=False)

    def add_label_segmentation_rules(self, label_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/segmentation/%s' % label_id),
                                method='POST',
                                data=dict(action='segment', origin='EXPLORE_SEGMENTATION'),
                                return_json=False)

    def add_label_micro_segmentation_rules(self, label_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/segmentation/%s' % label_id),
                                method='POST',
                                data=dict(action='microsegment', origin='EXPLORE_MICRO_SEGMENTATION'),
                                return_json=False)

    def get_integration_configuration(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'integration'))

    def add_integration_configuration(self, configuration_dict):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'integration'),
                                method='POST',
                                data=configuration_dict,
                                return_json=True)

    def edit_integration_configuration(self, configuration_dict, integration_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'integration/' + integration_id),
                                method='PUT',
                                data=configuration_dict,
                                return_json=True)

    def delete_integration_configuration(self, integration_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'integration/' + integration_id),
                                method='DELETE', )

    def integration_test_connection(self, configuration_dict):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'integration/test-connection'),
                                method='POST',
                                data=configuration_dict,
                                return_json=True)

    def get_orchestration_configuration(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'orchestration'))

    def get_orchestration_revisions(self):
        resp = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'orchestration/revisions'),
                                method='GET')
        return resp

    def get_orchestration_sync_data(self, orchestration_ids):
        data = dict(orchestration_ids=orchestration_ids)
        resp = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'orchestration/basic-data'),
                                method='POST', data=data)
        return resp

    def get_configuration_revisions(self):
        resp = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'configuration/revisions'),
                                method='GET')
        return resp

    def get_configuration_sync_data(self, configuration_ids):
        data = dict(configuration_ids=configuration_ids)
        resp = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'configuration/basic-data'),
                                method='POST', data=data)
        return resp

    def delete_orchestration_configuration(self, orchestration_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'orchestration/' + orchestration_id),
                                method='DELETE', )

    def _aggregator_cluster_id(self):
        aggregators = [aggr for aggr in self.list_aggregators()['objects'] if not aggr['collector_type']]
        if aggregators:
            return aggregators[0]['cluster_id']

    def _orchestration_cluster_id(self, conf_dict):
        return conf_dict.get('cluster_id') or self._aggregator_cluster_id() or 'default'

    def set_orchestration_configuration(self, configuration_dict):
        orchestration_conf = {}
        if 'vSphere' in configuration_dict and isinstance(configuration_dict['vSphere'], dict):
            vsphere_conf = configuration_dict['vSphere']

            orchestration_conf['orchestration_type'] = OrchestrationType.VSPHERE.value
            orchestration_conf['name'] = vsphere_conf.get('name', '%s:%s' % (vsphere_conf['auth_host'],
                                                                             str(vsphere_conf['auth_port'])))
            orchestration_conf['cluster_id'] = self._orchestration_cluster_id(vsphere_conf)
            orchestration_conf['configuration'] = {'auth_host': vsphere_conf["auth_host"],
                                                   'admin_user': vsphere_conf['admin_user'],
                                                   'auth_port': vsphere_conf['auth_port'],
                                                   'admin_password': vsphere_conf["admin_password"],
                                                   'vsphere_clusters': vsphere_conf.get('vsphere_clusters', []),
                                                   'number_of_ignored_updates': vsphere_conf.get(
                                                       'number_of_ignored_updates', 10),
                                                   'labeling_strategy': vsphere_conf.get('labeling_strategy',
                                                                                         LabelingStrategy.Disabled.name),
                                                   'predefined_labels': vsphere_conf.get('predefined_labels', []),
                                                   'metadata_labels': vsphere_conf.get('metadata_labels', True),
                                                   'orchestration_full_report_interval':
                                                       vsphere_conf.get('orchestration_full_report_interval', 1800),
                                                   'use_vm_hostname': vsphere_conf.get('use_vm_hostname', False),
                                                   'prefer_agents_hostname': vsphere_conf.get(
                                                       'prefer_agents_hostname', False)
                                                   }

        elif 'Kubernetes' in configuration_dict and isinstance(configuration_dict['Kubernetes'], dict):
            kubernetes_conf = configuration_dict['Kubernetes']

            orchestration_conf['orchestration_type'] = OrchestrationType.KUBERNETES.value
            auth_port = kubernetes_conf.get('auth_port', 6443)
            orchestration_conf['name'] = kubernetes_conf.get('name', '%s:%d' % (kubernetes_conf['auth_host'],
                                                                                auth_port))
            orchestration_conf['cluster_id'] = self._orchestration_cluster_id(kubernetes_conf)
            orchestration_conf['configuration'] = {
                'auth_host': kubernetes_conf["auth_host"],
                'auth_port': auth_port,
                'validate_certificate': kubernetes_conf.get('validate_certificate', False),
                'service_account_token': kubernetes_conf.get('service_account_token'),
                'ca_cert_data': kubernetes_conf.get('ca_cert_data', []),
                'metadata_labels': kubernetes_conf.get('metadata_labels', True),
                'orchestration_full_report_interval': kubernetes_conf.get('orchestration_full_report_interval', 1800),
                'prefer_agents_hostname': kubernetes_conf.get('prefer_agents_hostname', False),
            }

        elif 'AWS' in configuration_dict and isinstance(configuration_dict['AWS'], dict):
            aws_conf = configuration_dict['AWS']

            orchestration_conf['orchestration_type'] = OrchestrationType.AWS.value
            orchestration_conf['name'] = aws_conf.get('name', 'aws-orch-%s' % aws_conf['secret_access_key'])
            orchestration_conf['cluster_id'] = self._orchestration_cluster_id(aws_conf)
            orchestration_conf['configuration'] = {
                'authentication_method': aws_conf.get(
                    'authentication_method',
                    AwsAuthenticationMethodDescriptions[AwsAuthenticationMethod.CustomerCredentials]),
                'access_key_id': aws_conf['access_key_id'],
                'secret_access_key': aws_conf['secret_access_key'],
                'region_name': aws_conf['region_name'],
                'role_arn': aws_conf.get('role_arn', None),
                'external_id': aws_conf.get('external_id', None),
                'enable_vpc_flow_logs': aws_conf.get('enable_vpc_flow_logs', None),
                'log_group_name': aws_conf.get('log_group_name', []),
                'prior_days_time_frame': aws_conf.get('prior_days_time_frame', 0),
                'interval_period': aws_conf.get('interval_period', 30),
                'number_of_log_groups_limit': aws_conf.get('number_of_log_groups_limit', 50),
                'number_of_streams_limit': aws_conf.get('number_of_streams_limit', 50),
                'stream_events_limit': aws_conf.get('stream_events_limit', 500),
                'interval_limit': aws_conf.get('interval_limit', 10),
                'socket_name': aws_conf.get('socket_name', '/var/run/aggregator/dp_visibility.sock'),
                'labeling_strategy': aws_conf.get('labeling_strategy', LabelingStrategy.Enabled.name),
                'predefined_labels': aws_conf.get('predefined_labels', []),
                'metadata_labels': aws_conf.get('metadata_labels', True),
                'orchestration_full_report_interval': aws_conf.get('orchestration_full_report_interval', 1800)
            }

        elif 'Azure' in configuration_dict and isinstance(configuration_dict['Azure'], dict):
            azure_conf = configuration_dict['Azure']

            orchestration_conf['orchestration_type'] = OrchestrationType.AZURE.value
            orchestration_conf['name'] = azure_conf.get('name', 'azure-orch-%s' % azure_conf['tenant_id'])
            orchestration_conf['cluster_id'] = self._orchestration_cluster_id(azure_conf)
            orchestration_conf['configuration'] = {'application_key': azure_conf['application_key'],
                                                   'application_id': azure_conf['application_id'],
                                                   'tenant_id': azure_conf['tenant_id'],
                                                   'subscriptions_list': azure_conf['subscriptions_list'],
                                                   'display_computer_name': azure_conf.get('display_computer_name',
                                                                                           False),
                                                   'full_cloud_discovery': azure_conf.get('full_cloud_discovery',
                                                                                          False),
                                                   'proxy_url': azure_conf.get('proxy_url'),
                                                   'fetch_scale_sets': azure_conf.get('fetch_scale_sets'),
                                                   'labeling_strategy': azure_conf.get('labeling_strategy',
                                                                                       LabelingStrategy.Enabled.name),
                                                   'predefined_labels': azure_conf.get('predefined_labels', []),
                                                   'metadata_labels': azure_conf.get('metadata_labels', True),
                                                   'orchestration_full_report_interval':
                                                       azure_conf.get('orchestration_full_report_interval', 1800)
                                                   }

        elif 'AzureADGraph' in configuration_dict and isinstance(configuration_dict['AzureADGraph'], dict):
            azure_ad_conf = configuration_dict['AzureADGraph']

            orchestration_conf['orchestration_type'] = OrchestrationType.AZURE_AD_GRAPH.value
            orchestration_conf['name'] = azure_ad_conf.get('name', 'azure-orch-%s' % azure_ad_conf['tenant_id'])
            orchestration_conf['cluster_id'] = self._orchestration_cluster_id(azure_ad_conf)
            orchestration_conf['configuration'] = {'application_id': azure_ad_conf['application_id'],
                                                   'application_key': azure_ad_conf['application_key'],
                                                   'tenant_id': azure_ad_conf['tenant_id'],
                                                   'orchestration_full_report_interval':
                                                       azure_ad_conf.get('orchestration_full_report_interval', 1800)}

        elif 'GCP' in configuration_dict and isinstance(configuration_dict['GCP'], dict):
            gcp_conf = configuration_dict['GCP']

            orchestration_conf['orchestration_type'] = OrchestrationType.GCP.value
            orchestration_conf['name'] = gcp_conf.get('name', 'gcp-orch-%s' % gcp_conf['name'])
            orchestration_conf['cluster_id'] = self._orchestration_cluster_id(gcp_conf)
            orchestration_conf['configuration'] = {'service_account': gcp_conf['service_account'],
                                                   'projects_list': gcp_conf['projects_list'],
                                                   'private_key': gcp_conf['private_key'],
                                                   'proxy_url': gcp_conf.get('proxy_url'),
                                                   'labeling_strategy': gcp_conf.get('labeling_strategy',
                                                                                     LabelingStrategy.Enabled.name),
                                                   'predefined_labels': gcp_conf.get('predefined_labels', []),
                                                   'metadata_labels': gcp_conf.get('metadata_labels', True),
                                                   'orchestration_full_report_interval':
                                                       gcp_conf.get('orchestration_full_report_interval', 1800)
                                                   }

        elif 'inventory_api' in configuration_dict and isinstance(configuration_dict['inventory_api'], dict):
            inventory_api_conf = configuration_dict['inventory_api']

            orchestration_conf['orchestration_type'] = OrchestrationType.INVENTORY_API.value
            orchestration_conf['name'] = inventory_api_conf.get('name', 'inventory-api-%d' % random.randint(1, 10000))
            orchestration_conf['cluster_id'] = self._orchestration_cluster_id(inventory_api_conf)
            orchestration_conf['configuration'] = {'rest_username': inventory_api_conf['rest_username'],
                                                   'rest_password': inventory_api_conf.get('rest_password', None),
                                                   'integration_token': inventory_api_conf.get('integration_token',
                                                                                               None),
                                                   'authentication_scheme': inventory_api_conf.get(
                                                       'authentication_scheme', AuthenticationScheme.UserPassword.name),
                                                   'allowed_incoming': inventory_api_conf.get('allowed_incoming', ""),
                                                   'report_expiration': inventory_api_conf.get('report_expiration',
                                                                                               DEFAULT_REPORT_EXPIRATION),
                                                   'overwrite_ips': inventory_api_conf.get('overwrite_ips', True),
                                                   'labeling_strategy': inventory_api_conf.get('labeling_strategy',
                                                                                               LabelingStrategy.Enabled.name),
                                                   'predefined_labels': inventory_api_conf.get('predefined_labels', []),
                                                   'metadata_labels': inventory_api_conf.get('metadata_labels', True),
                                                   'orchestration_full_report_interval':
                                                       inventory_api_conf.get('orchestration_full_report_interval',
                                                                              1800)
                                                   }

        elif 'active_directory' in configuration_dict and isinstance(configuration_dict['active_directory'], dict):
            active_directory_conf = configuration_dict['active_directory']

            orchestration_conf['orchestration_type'] = OrchestrationType.ACTIVE_DIRECTORY.value
            orchestration_conf['name'] = active_directory_conf['name']
            orchestration_conf['cluster_id'] = self._orchestration_cluster_id(active_directory_conf)
            orchestration_conf['configuration'] = {'login_username': active_directory_conf['application_key'],
                                                   'login_password': active_directory_conf['application_id'],
                                                   'base_dn': active_directory_conf.get('tenant_id'),
                                                   'use_ssl': active_directory_conf.get('use_ssl', True),
                                                   'servers': active_directory_conf['ldap_servers'],
                                                   'domain_name': active_directory_conf['domain_name'],
                                                   'orchestration_full_report_interval':
                                                       active_directory_conf.get('orchestration_full_report_interval',
                                                                                 1800)}

        elif 'Oracle' in configuration_dict and isinstance(configuration_dict['Oracle'], dict):
            oracle_conf = configuration_dict['Oracle']

            orchestration_conf['orchestration_type'] = OrchestrationType.ORACLE.value
            orchestration_conf['name'] = oracle_conf.get('name', 'oracle-orch-%s' % oracle_conf['user_ocid'])
            orchestration_conf['cluster_id'] = self._orchestration_cluster_id(oracle_conf)
            orchestration_conf['configuration'] = {'user_ocid': oracle_conf['user_ocid'],
                                                   'key_pair_fingerprint': oracle_conf['key_pair_fingerprint'],
                                                   'private_key': oracle_conf['private_key'],
                                                   'private_key_passphrase': oracle_conf.get('private_key_passphrase'),
                                                   'tenancy_ocid': oracle_conf['tenancy_ocid'],
                                                   'region': oracle_conf['region'],
                                                   'region_free_text': oracle_conf.get('region_free_text'),
                                                   'query_all_regions': oracle_conf.get('query_all_regions', False),
                                                   'proxy_url': oracle_conf.get('proxy_url'),
                                                   'labeling_strategy': oracle_conf.get('labeling_strategy',
                                                                                        LabelingStrategy.Enabled.name),
                                                   'predefined_labels': oracle_conf.get('predefined_labels', []),
                                                   'metadata_labels': oracle_conf.get('metadata_labels', True),
                                                   'orchestration_full_report_interval':
                                                       oracle_conf.get('orchestration_full_report_interval', 1800)}
        elif 'AS400' in configuration_dict and isinstance(configuration_dict['AS400'], dict):
            as400_conf = configuration_dict['AS400']
            default_advanced_config = {
                "maximum_number_events": 100000,
                "high_watermark_time_percent": 80,
                "low_watermark_time_percent": 20,
                "adaptive_jump_factor": 8,
                "ftp_block_size": 8192,
                "entries_in_read_chunk": 1000,
                "ftp_connection_reuse_time": 300,
                "ftp_connection_retries": "3",
                "log_retention": "4",
                "use_ftps": False
            }
            advanced_conf = as400_conf.get('advanced', {})
            default_advanced_config.update(advanced_conf)
            advanced_conf_list = [
                '{}:{}'.format(k, v) for k, v in default_advanced_config.items()
            ]
            # Don't use OrchestrationType.AS400, because OrchestrationType is code used in management. AS400
            # is only supported in v36, while test code is running from master, which causing some failures on PR-gate.
            orchestration_conf['orchestration_type'] = 'AS400'
            orchestration_conf['name'] = as400_conf.get('name', 'as400-orch')
            orchestration_conf['cluster_id'] = self._orchestration_cluster_id(as400_conf)
            orchestration_conf['configuration'] = {
                "lpar_agents_list": as400_conf.get('lpar_agents_list', []),
                "reveal_polling_period": as400_conf.get("reveal_polling_period", 60),
                "machine_details_polling_period": as400_conf.get("machine_details_polling_period", 60),
                "metadata_labels": as400_conf.get("metadata_labels", True),
                "orchestration_full_report_interval": as400_conf.get("orchestration_full_report_interval", 1800),
                "advanced": advanced_conf_list
            }

        elif 'Citrix' in configuration_dict and isinstance(configuration_dict['Citrix'], dict):
            citrix_conf = configuration_dict['Citrix']

            orchestration_conf['orchestration_type'] = OrchestrationType.CITRIX.value
            orchestration_conf['name'] = citrix_conf.get('name', 'citrix-orch-%s' % citrix_conf['user_ocid'])
            orchestration_conf['cluster_id'] = self._orchestration_cluster_id(citrix_conf)
            orchestration_conf['configuration'] = {'user': citrix_conf['user']
                                                   }

        if 'openstack' in configuration_dict and \
                isinstance(configuration_dict['openstack'], dict) and \
                'openstack_auth' not in configuration_dict['openstack']:
            openstack_conf = configuration_dict['openstack']

            orchestration_conf['orchestration_type'] = OrchestrationType.OPENSTACK.value
            orchestration_conf['name'] = openstack_conf.get('name',
                                                            '%s' % (openstack_conf['api_authentication_endpoint']))
            orchestration_conf['cluster_id'] = self._orchestration_cluster_id(openstack_conf)
            orchestration_conf['configuration'] = {'user': openstack_conf["user"],
                                                   'password': openstack_conf['password'],
                                                   'projects_list': openstack_conf['projects_list'],
                                                   'api_authentication_endpoint': openstack_conf[
                                                       'api_authentication_endpoint'],
                                                   'user_domain_name': openstack_conf.get('user_domain_name'),
                                                   'user_domain_id': openstack_conf.get('user_domain_id'),
                                                   'fetch_hosts': openstack_conf.get('fetch_hosts', True),
                                                   'fetch_users': openstack_conf.get('fetch_users', True),
                                                   'fetch_flavors': openstack_conf.get('fetch_flavors', True),
                                                   'fetch_images': openstack_conf.get('fetch_images', True),
                                                   'full_port_pull_strategy': openstack_conf.get(
                                                       'full_port_pull_strategy',
                                                       FullPortPullStrategy.AllAtOnce.name),
                                                   'differential_port_pull_strategy': openstack_conf.get(
                                                       'differential_port_pull_strategy',
                                                       DifferentialPortPullStrategy.AllAtOnce.name),
                                                   'ports_pull_bulk_size': openstack_conf.get('ports_pull_bulk_size',
                                                                                              0),
                                                   'interval_between_ports_pulls': openstack_conf.get(
                                                       'interval_between_ports_pulls', 0),
                                                   'servers_pull_bulk_size': openstack_conf.get(
                                                       'servers_pull_bulk_size', 0),
                                                   'interval_between_server_pulls': openstack_conf.get(
                                                       'interval_between_server_pulls', 0),
                                                   'orchestration_full_report_interval': openstack_conf[
                                                       'orchestration_full_report_interval'],
                                                   'keystone_version': openstack_conf.get('keystone_version', '3'),
                                                   'keystone_endpoint': openstack_conf.get('keystone_endpoint'),
                                                   'nova_version': openstack_conf.get('nova_version', '2.1'),
                                                   'nova_endpoint': openstack_conf.get('nova_endpoint'),
                                                   'neutron_endpoint': openstack_conf.get('neutron_endpoint'),
                                                   }

        elif 'as400' in configuration_dict and isinstance(configuration_dict['as400'], dict):
            as400_conf = configuration_dict['as400']

            orchestration_conf['orchestration_type'] = OrchestrationType.AS400.value
            orchestration_conf['name'] = as400_conf.get('name', 'as400-orch')
            orchestration_conf['cluster_id'] = self._orchestration_cluster_id(as400_conf)
            orchestration_conf['configuration'] = as400_conf.get('lpar_configuration')

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'orchestration'),
                                method='POST',
                                data=orchestration_conf,
                                return_json=True)

    def check_orchestration_connectivity(self, configuration_dict=None):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'orchestration/test-connection'),
                                method='POST',
                                data=configuration_dict or {},
                                return_json=True)

    def edit_orchestration_parameters(self, configuration_dict, orchestration_id):
        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'orchestration/' + orchestration_id),
                         method='PUT',
                         data=configuration_dict)

    def export_system_configuration(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system-configuration/export'),
                                return_json=False)

    def import_system_configuration(self, config_file):
        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system-configuration/import'),
                         method='PUT',
                         convert_data_to_json=False,
                         files=dict(file=open(config_file, 'rb')),
                         return_json=False)

    # only perform collection
    def collect_all_logs(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system-status/debug-logs-collect'), return_json=False)

    # query the collection status, before file is ready
    def all_logs_collection_status(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system-status/debug-logs-file-status'),
                                return_json=True)

    # fetch the collected logs file.
    def get_all_logs(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system-status/debug-logs-file'), return_json=False,
                                follow_redirects=True)

    # aggregator logs
    def get_debug_logs_async(self, component_type, component_id, rotated=True, timeout=180):
        self.get_debug_logs_async_post(component_type=component_type, component_id=component_id, rotated=rotated)
        start_time = time.time()
        end_time = time.time()
        while (end_time - start_time) < timeout:
            response = self.get_debug_logs_async_get(component_type=component_type, component_id=component_id)
            if b'{"found":false}' not in response:
                return response
            end_time = time.time()
        raise Exception('Operation "get-debug-logs-async" timed out')

    def get_debug_logs_async_post(self, component_type, component_id, rotated=True):
        url_suffix = '%s/%s/get-debug-logs-async' % (component_type, component_id)
        self._json_query(urljoin(NEW_REST_API_BASE_URL, url_suffix), method='POST', params={'rotated': rotated})

    def get_debug_logs_async_get(self, component_type, component_id):
        url_suffix = '%s/%s/get-debug-logs-async' % (component_type, component_id)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, url_suffix), method='GET', return_json=False,
                                follow_redirects=True)

    def get_aggregator_debug_logs_async(self, component_id, rotated=True):
        return self.get_debug_logs_async(component_type='agent_aggregators', component_id=component_id, rotated=rotated)

    def get_aggregator_debug_logs_async_get(self, component_id):
        return self.get_debug_logs_async_get(component_type='agent_aggregators', component_id=component_id)

    @add_default_from_to_time()
    def get_network_connections(self, raw_result=False, **kwargs):
        """
        :param raw_result: if True, will return the raw result including all pagination info
        :param kwargs:  request filters
        The Type filter name is connection_type.
        Optional values: redirected_to_hpvm/successful/failed
        :return:
        """
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'connections'), params=kwargs)
        return raw if raw_result else raw['objects']

    def pull_connections(self, raw_options, **kwargs):
        target_url = '%s?%s' % (urljoin(NEW_REST_API_BASE_URL, 'connections'), raw_options)
        return self._json_query(target_url, **kwargs)

    def pull_filter_options(self, raw_options, path):
        target_url = '%s?%s' % (urljoin(NEW_REST_API_BASE_URL, path),
                                raw_options)
        return self._json_query(target_url)

    @add_default_from_to_time()
    def get_agents_logs(self, raw_result=False, **kwargs):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agent-status/events'), params=kwargs)
        return raw if raw_result else raw['objects']

    @add_default_from_to_time()
    def get_reputation_log(self, raw_result=False, **kwargs):
        """
        :param raw_result: if True, will return the raw result including all pagination info
        :param kwargs:  request filters
        :return:
        """
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'reputation-log'), params=kwargs)
        return raw if raw_result else raw['objects']

    # System Users
    def list_system_users(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system/users'))

    def change_login_password(self, username, curr_password, password, password_confirm):
        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system/user/password'),
                         method='POST',
                         data={'username': username, 'curr_password': curr_password, 'password': password,
                               'password_confirm': password_confirm},
                         return_json=False)

    def update_user(self, username, overwrite='', email='', description='', password='', id='',
                    password_confirm='', action='update', two_factor_auth_enabled=False, can_access_passwords=False,
                    permission_scheme_ids=None):
        if permission_scheme_ids is None:
            permission_scheme_ids = []

        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system/user'),
                         method='POST',
                         data={'overwrite': overwrite, 'id': id, 'action': action, 'username': username,
                               'email': email, 'description': description,
                               'password': password, 'password_confirm': password_confirm,
                               'two_factor_auth_enabled': two_factor_auth_enabled,
                               'can_access_passwords': can_access_passwords,
                               'permission_scheme_ids': permission_scheme_ids},
                         return_json=False)

    def delete_user(self, username):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system/users'),
                                method='POST',
                                data={'username': username, "action": "delete", 'confirm': True},
                                return_json=False)

    def logout_user(self, username):
        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system/user'),
                         method='POST',
                         data={'username': username, "action": "logout", 'confirm': True},
                         return_json=False)

    def hide_user(self, username):
        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system/user'),
                         method='POST',
                         data={'username': username, "action": "hide", 'confirm': True},
                         return_json=False)

    # Enrichers
    def list_enrichers(self, group_name=None, name=None, only_configurable=None):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'enrichers'),
                                params={'group_name': group_name, 'name': name, 'only_configurable': only_configurable})

    def set_enrichers_state(self, is_enabled, group_name=None, name=None):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'enrichers'),
                                params={'group_name': group_name, 'name': name},
                                method='POST',
                                data=dict(enabled=is_enabled),
                                return_json=False)

    def get_enricher_group_configuration(self, group_name):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'enrichers/%s/configuration' % group_name))

    def set_enricher_group_configuration(self, group_name, configuration):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'enrichers/%s/configuration' % group_name),
                                method='PUT',
                                data=configuration,
                                return_json=False)

    def get_enricher_configuration(self, group_name, enricher_name):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'enrichers/%s/enrichers/%s/configuration' % (group_name,
                                                                                                            enricher_name)))

    def set_enricher_configuration(self, group_name, enricher_name, configuration):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'enrichers/%s/enrichers/%s/configuration' % (group_name,
                                                                                                            enricher_name)),
                                method='PUT',
                                data=configuration,
                                return_json=False)

    # Redirection events
    @add_default_from_to_time()
    def count_redirection_events(self, **filt):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'redirection-events'), params=filt)['total_count']

    @add_default_from_to_time()
    def list_redirection_events(self, raw_result=False, **filt):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'redirection-events'), params=filt)
        return raw if raw_result else raw['objects']

    def redirection_events_filter_options(self, filter_name, filter_value=None, **filt):
        return self._filter_options('redirection-events', filter_name, filter_value, **filt)

    def redirection_events_filter_options_resolve(self, **filt):
        return self._filter_options_resolve('redirection-events', **filt)

    def num_of_redirection_events(self, **filt):
        return self.count_redirection_events(**filt)

    # Honeypot events
    def list_honeypot_events(self, raw_result=False, **filt):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'honeypot-events'), params=filt)
        return raw if raw_result else raw['objects']

    def num_of_honeypot_events(self, **filt):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'honeypot-events'), params=filt)['total_count']

    # Incidents
    def get_incidents_graph(self, interval, samples, **filt):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/stats'),
                                params=dict(interval=interval,
                                            samples=samples,
                                            **filt))

    def get_incidents_stats(self, stats_type):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, '/'.join(('incidents', 'stats', stats_type))))

    @add_default_from_to_time()
    def list_incidents(self, raw_result=False, **filt):
        from_closed_time = filt.get('from_closed_time')
        to_closed_time = filt.get('to_closed_time')
        # same behavior as from/to time
        # rest api receives an int (timestamp)
        if from_closed_time:
            filt['from_closed_time'] = datetime_to_timestamp(from_closed_time)
        if to_closed_time:
            filt['to_closed_time'] = datetime_to_timestamp(to_closed_time)

        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents'), params=filt)
        return raw if raw_result else raw['objects']

    @add_default_from_to_time()
    def list_incidents_groups(self, raw_result=False, **filt):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents_groups'), params=filt)
        return raw if raw_result else raw['objects']

    def incidents_filter_options(self, filter_name, filter_value=None, **filt):
        return self._filter_options('incidents', filter_name, filter_value, **filt)

    def incidents_filter_options_resolve(self, **filt):
        return self._filter_options_resolve('incidents', **filt)

    def get_incident(self, incident_id, limit=None, full_dump=False, metadata=False, iocs=False, rules=False,
                     fetch_graph_data=False):
        if limit is None:
            if full_dump:
                return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/%s/dump' % (incident_id,)))
            elif metadata:
                return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/%s/metadata' % (incident_id,)))
            elif iocs:
                return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/%s/iocs' % (incident_id,)))
            elif rules:
                return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/%s/rules' % (incident_id,)))
            else:
                if fetch_graph_data:
                    return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/%s' % (incident_id,)),
                                            params=dict(fetch_graph_data=True))
                else:
                    return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/%s' % (incident_id,)))
        else:
            return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/%s?limit=%d' % (incident_id, limit)))

    @add_default_from_to_time()
    def num_of_incidents(self, **filt):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents'), params=filt)['total_count']

    def add_generic_incident(self, incident_config):
        return self._json_query(urljoin(AUTOMATION_API_BASE_URL, 'incidents'),
                                method='POST',
                                data=incident_config,
                                return_json=True)

    def add_generic_incident_bulk(self, incidents_config):
        return self._json_query(urljoin(AUTOMATION_API_BASE_URL, 'incidents/bulk/create'),
                                method='POST',
                                data=incidents_config,
                                return_json=True)

    def list_generic_incidents(self, raw_result=False, **filt):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'generic-incidents'), params=filt)
        return raw if raw_result else raw['objects']

    def get_generic_incident_by_id(self, incident_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'generic-incidents/%s' % incident_id))

    def get_permalink_by_id(self, **kwargs):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'permalink?'), params=kwargs)

    @add_default_from_to_time()
    def export_generic_incident_csv(self, **filt):
        result = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'generic-incidents/export?'),
                                  method='GET',
                                  params=filt)

        export_task_status_id = result['export_task_status_id']
        report_id = self._get_report_id(export_task_status_id)
        return self._download_report_file(report_id)

    def has_tag(self, incident_id, tag_name):
        """
        does incident have the given tag?
        """
        incident = self.get_incident(incident_id)
        tag_names = [tag['name'] for tag in incident['tags']]
        return tag_name in tag_names

    def add_user_tag(self, incident_id, tag_name):
        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/%s' % incident_id),
                         method='PUT',
                         params=dict(action='add_user_tag'),
                         data=dict(name=tag_name),
                         return_json=False)

    def remove_user_tag(self, incident_id, tag_name):
        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/%s' % incident_id),
                         method='PUT',
                         params=dict(action='remove_user_tag'),
                         data=dict(name=tag_name),
                         return_json=False)

    def list_incidents_solved_by_rules(self, incident_ids, rules, raw_result=False):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/solved-by-rules'),
                               method='POST',
                               data=dict(incident_ids=incident_ids,
                                         rules=rules))
        return raw if raw_result else raw['objects']

    def misclassify_incident(self, incident_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/%s' % incident_id),
                                method='PUT',
                                params=dict(action='misclassify'),
                                data=dict(id=incident_id),
                                return_json=False)

    def acknowledged_incident(self, incident_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/%s' % incident_id),
                                method='PUT',
                                params=dict(action='acknowledge'),
                                data=dict(id=incident_id),
                                return_json=False)

    def bulk_acknowledge_incidents(self, incident_ids):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/acknowledge'),
                                method='POST',
                                data=dict(incident_ids=incident_ids))

    # backwards compatibility with testing code - TODO remove me once testing fix their side!
    acknowledge_incidents = bulk_acknowledge_incidents

    def revert_acknowledged_incident(self, incident_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/%s' % incident_id),
                                method='PUT',
                                params=dict(action='revert_acknowledge'),
                                data=dict(id=incident_id),
                                return_json=False)

    def bulk_revert_acknowledged_incident(self, incident_ids):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/revert-acknowledge'),
                                method='POST',
                                data=dict(incident_ids=incident_ids))

    def bulk_update_fim_templates_by_incident(self, incident_ids):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/update-fim-templates'),
                                method='POST',
                                data=dict(incident_ids=incident_ids))

    def export_incident_as_pdf(self, incident_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/%s/pdf' % incident_id),
                                return_json=False, follow_redirects=True)

    def export_incident_as_html(self, incident_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/%s/html' % incident_id),
                                return_json=False, follow_redirects=True)

    def export_incident_as_tar(self, incident_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents/%s/export' % incident_id),
                                return_json=False, follow_redirects=True)

    def generate_repo_keys(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system/repo_keys'), method='POST',
                                data={'confirm': True})

    def _download_report_file(self, report_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'exported_csv_files/%s' % report_id),
                                return_json=False, follow_redirects=True)

    def _get_report_id(self, export_task_status_id, timeout=600):
        status = None
        start_time = time.time()
        curr_time = time.time()
        while curr_time - start_time <= timeout and \
                (status is None or status['state'] != 2):
            curr_time = time.time()
            status = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'export_csv_task_status'),
                                      params={'task_id': export_task_status_id},
                                      return_json=True)
            self.logger.debug('Export CSV Task Status: %s', status)
            if status['state'] != 2:
                time.sleep(1)
        if status['state'] != 2:
            error = "Export task operation for task id '{}' " \
                    "timed out after {} seconds".format(export_task_status_id, timeout)
            raise TimeoutError(error)
        return status['exported_csv_file_id']

    @add_default_from_to_time()
    def export_network_log(self, timeout=600, **kwargs):
        result = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'connections/export'),
                                  params=kwargs)
        self.logger.debug('Export Result: %s', result)
        export_task_status_id = result['export_task_status_id']
        report_id = self._get_report_id(export_task_status_id, timeout=timeout)
        return self._download_report_file(report_id)

    @add_default_from_to_time()
    def export_redirection_log(self, **kwargs):
        result = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'redirection-events/export'),
                                  params=kwargs)
        export_task_status_id = result['export_task_status_id']
        report_id = self._get_report_id(export_task_status_id)
        return self._download_report_file(report_id)

    @add_default_from_to_time()
    def export_reputation_log(self, **kwargs):
        result = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'reputation-log/export'),
                                  params=kwargs)
        export_task_status_id = result['export_task_status_id']
        report_id = self._get_report_id(export_task_status_id)
        return self._download_report_file(report_id)

    @add_default_from_to_time()
    def export_incident_groups_log(self, **kwargs):
        result = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'incidents_groups/export'),
                                  params=kwargs)
        export_task_status_id = result['export_task_status_id']
        report_id = self._get_report_id(export_task_status_id)
        return self._download_report_file(report_id)

    def export_assets_log(self):
        result = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'assets/export'))
        export_task_status_id = result['export_task_status_id']
        report_id = self._get_report_id(export_task_status_id)
        return self._download_report_file(report_id)

    # Incident Groups
    def get_group_from_incident(self, incident_id):
        incident = self.get_incident(incident_id, metadata=True)
        return incident['incident_group'][0]['gid']

    # Policies
    def _get_valid_rule(self, rule):
        """
        Gets a rule, validates it and fills its fields as needed by protocol.
        :return: Rule that has the following structure:
            {comment, source: {type: [TYPE], value}, destination: {type: [TYPE], value},
            policy_type: ['Ignore', 'Bypass', 'Inspect'],
            destination_ports, rule_id, status: ['Enabled', 'Disabled']}
        """
        for key in ('id', '_id', 'update_time'):
            if key in rule:
                del rule[key]
        if 'rule_id' not in rule:
            rule['rule_id'] = str(uuid.uuid4())
        if 'status' not in rule:
            rule['status'] = 'Enabled'
        for side in ('source', 'destination'):
            if side not in rule:
                rule[side] = {'type': 'Any', 'value': ''}
            assert 'value' in rule[side]
            assert 'type' in rule[side]
            assert rule[side]['type'] in ('VM', 'Network', 'IPNetwork', 'Any')
        assert 'policy_type' in rule and hasattr(PolicyRuleType, rule['policy_type'])
        return rule

    def set_policy(self, rules):
        """
        :param rules: A list of dictionaries of the following structure:
            {'source': {'type': [TYPE], 'value': [string]},
             'destination': {'type': [TYPE], 'value': [string]},
             'policy_type': ['Ignore', 'Bypass', 'Inspect'],
             'destination_ports': [a list of port numbers, with 0 for ARP]}

            * TYPE: one of 'VM', 'Network', 'IPNetwork', 'Any'
            * source and destinations are optional and defaulted to 'Any'
            * destination_ports is optional, and defaults to an empty list = ANY
        """
        valid_rules = [self._get_valid_rule(rule) for rule in rules]
        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'policy-rules'), method='POST',
                         data={'rules': valid_rules})

    def delete_policy(self):
        self.set_policy([])

    def get_policy(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'policy-rules'), method='GET')

    # Honeypots
    def list_honeypots(self, **filt):
        return self.honeypots.list(**filt)

    def get_honeypot(self, honeypot_id):
        return self.honeypots.get(honeypot_id)

    def get_honeypot_configuration(self, honeypot_id, include_defaults=True):
        return self.honeypots.get_configuration(honeypot_id, include_defaults)

    def set_honeypot_configuration(self, honeypot_id, configuration):
        self.honeypots.set_configuration(honeypot_id, configuration)

    def reset_honeypot_configuration(self, honeypot_id):
        self.honeypots.reset_configuration(honeypot_id)

    def set_honeypot_state(self, honeypot_id, state):
        self.honeypots.set_state(honeypot_id, state)

    def is_honeypot_task_running(self):
        return self.honeypots.is_task_running()

    def stop_honeypots(self, honeypot_ids):
        self.honeypots.stop(honeypot_ids)

    def start_honeypots(self, honeypot_ids):
        self.honeypots.start(honeypot_ids)

    def restart_honeypots(self, honeypot_ids):
        self.honeypots.restart(honeypot_ids)

    def patch_honeypots(self, patch_file_path):
        return self.honeypots.patch(patch_file_path)

    def get_file_content_by_id(self, honeypot_id, file_uuid):
        path = 'honeypots/%s/files/%s' % (honeypot_id, file_uuid)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, path), return_json=False,
                                follow_redirects=True)

    # Aggregator
    def flush_aggregators_cache(self, seen_connection_cache=True, seen_ip_cache=True,
                                sampling_cache=True, orchestration_cache=False, containers_cache=True):
        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'aggregators_cache/flush'),
                         method='POST',
                         data={'seen_connection_cache': seen_connection_cache,
                               'seen_ip_cache': seen_ip_cache,
                               'sampling_cache': sampling_cache,
                               'orchestration_cache': orchestration_cache,
                               'containers_cache': containers_cache},
                         return_json=False)

    def get_mitigation_and_iocs(self, mitigator_class):
        URL = 'mitigators/{}/configuration'.format(mitigator_class)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, URL),
                                method='GET')

    def set_mitigator_configuration(self, mitigator_class, new_configuration):
        URL = 'mitigators/{}/configuration'.format(mitigator_class)

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, URL),
                                method='PUT',
                                data=new_configuration,
                                return_json=False)

    # Collectors
    def list_collectors(self, **filt):
        return self.collectors.list(**filt)


    # Visibility
    @add_default_from_to_time()
    def list_network_visibility_events(self, raw_result=False, **filt):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/aggregated-connections-events'), params=filt)
        return raw if raw_result else raw['objects']

    def get_network_visibility_event(self, event_uuid):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL,
                                        'visibility/aggregated-connections-events/%s' % event_uuid))

    @staticmethod
    def _create_visibility_graph_body(start_time=None, end_time=None, offset=None, limit=None,
                                      apply_network_policy=False, saved_map_id=None,
                                      filters=None, group_by=None,
                                      open_vms=None, open_groups=None,
                                      open_subnets=None, open_internets=None,
                                      open_processes=None, add_policy_overlays=False):
        params = dict(apply_network_policy=apply_network_policy)
        if start_time is not None:
            params['start_time'] = start_time
        if end_time is not None:
            params['end_time'] = end_time
        if offset is not None:
            params['offset'] = offset
        if limit is not None:
            params['limit'] = limit
        if group_by is not None:
            params['group_by'] = group_by
        if saved_map_id is None:
            raise Exception("No saved map id")
        else:
            params['saved_map_id'] = saved_map_id

        body = dict(state={})
        if open_groups:
            for group_id in open_groups:
                body['state'][group_id] = dict(type='group', open=True)

        if open_vms:
            for vm_id in open_vms:
                body['state'][vm_id] = dict(type='vm', open=True)

        if open_subnets:
            for subnet_id in open_subnets:
                body['state'][subnet_id] = dict(type='subnet', open=True)

        if add_policy_overlays:
            body['overlays'] = dict(policy=dict())

        if open_internets:
            for internet_id in open_internets:
                body['state'][internet_id] = dict(type='internet', open=True)

        if open_processes:
            for process_id in open_processes:
                body['state'][process_id] = dict(type='process', open=True)

        if filters:
            body['filters'] = filters
        else:
            body['filters'] = {'include': {}, 'exclude': {}}

        return dict(params=params, data=body)

    @add_default_from_to_time(start_param_name='start_time', end_param_name='end_time')
    def list_network_visibility_flows(self, start_time=None, end_time=None, offset=None, limit=None,
                                      apply_network_policy=False,
                                      filters=None, group_by=None,
                                      open_vms=None, open_groups=None,
                                      open_subnets=None, open_internets=None,
                                      open_processes=None, saved_map_id=None,
                                      add_policy_overlays=False):

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/graph'),
                                method='POST',
                                **self._create_visibility_graph_body(start_time=start_time, end_time=end_time,
                                                                     offset=offset, limit=limit,
                                                                     saved_map_id=saved_map_id,
                                                                     apply_network_policy=apply_network_policy,
                                                                     filters=filters, group_by=group_by,
                                                                     open_vms=open_vms, open_groups=open_groups,
                                                                     open_subnets=open_subnets,
                                                                     open_internets=open_internets,
                                                                     open_processes=open_processes,
                                                                     add_policy_overlays=add_policy_overlays))

    @add_default_from_to_time(start_param_name='start_time', end_param_name='end_time')
    def get_item_data_from_graph(self, item, start_time=None, end_time=None, offset=None, limit=None,
                                 apply_network_policy=False,
                                 filters=None, group_by=None,
                                 open_vms=None, open_groups=None,
                                 open_subnets=None, open_internets=None,
                                 open_processes=None, saved_map_id=None):
        body = self._create_visibility_graph_body(start_time=start_time, end_time=end_time,
                                                  offset=offset, limit=limit,
                                                  apply_network_policy=apply_network_policy,
                                                  filters=filters, group_by=group_by,
                                                  open_vms=open_vms, open_groups=open_groups,
                                                  open_subnets=open_subnets,
                                                  open_internets=open_internets,
                                                  open_processes=open_processes,
                                                  saved_map_id=saved_map_id)
        body['item'] = item

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/preview-data'),
                                method='POST', data=body)

    @add_default_from_to_time()
    def list_visibility_policy_revisions(self, offset=0, limit=20, sort='', **filt):
        params = dict(offset=offset, limit=limit)
        if sort:
            params['sort'] = sort
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/revisions'),
                                params=params)

    def get_visibility_policy_revision_info(self, revision_number):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL,
                                        'visibility/policy/revision/{}'.format(revision_number)))

    def get_visibility_policy_revision_rules(self, revision_number, offset=0, limit=20, enrich_labels_only=False):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL,
                                        'visibility/policy/revision/{}/rules'.format(revision_number)),
                                params=dict(offset=offset,
                                            limit=limit,
                                            enrich_labels_only=enrich_labels_only))

    def get_visibility_policy_revision_label_groups(self, revision_number, offset=0, limit=20):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL,
                                        'visibility/policy/revision/{}/label-groups'.format(revision_number)),
                                params=dict(offset=offset,
                                            limit=limit))

    def get_visibility_policy_revision_user_groups(self, revision_number, offset=0, limit=20):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL,
                                        'visibility/policy/revision/{}/user-groups'.format(revision_number)),
                                params=dict(offset=offset,
                                            limit=limit))

    def compare_visibility_policy_revisions_metadata(self, base_revision, compare_revision):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/revisions/compare-revisions'),
                                params=dict(base_revision=base_revision,
                                            compare_revision=compare_revision))

    def compare_visibility_policy_revisions_rules(self, base_revision, compare_revision, offset=0, limit=20):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/revisions/compare-revisions/rules'),
                                params=dict(base_revision=base_revision,
                                            compare_revision=compare_revision,
                                            offset=offset,
                                            limit=limit))

    def compare_visibility_policy_revisions_label_groups(self, base_revision, compare_revision, offset=0, limit=20):
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/revisions/compare-revisions/label-groups'),
            params=dict(base_revision=base_revision,
                        compare_revision=compare_revision,
                        offset=offset,
                        limit=limit))

    def compare_visibility_policy_revisions_user_groups(self, base_revision, compare_revision, offset=0, limit=20):
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/revisions/compare-revisions/user-groups'),
            params=dict(base_revision=base_revision,
                        compare_revision=compare_revision,
                        offset=offset,
                        limit=limit))

    def list_visibility_policy_rules(self, section_position, offset=0, limit=20, **kwargs):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL,
                                        'visibility/policy/sections/{}/rules'.format(section_position)),
                                params=dict(offset=offset,
                                            limit=limit,
                                            **kwargs))

    def list_visibility_policy_rules_v4(self, offset=0, limit=20, **kwargs):
        return self._json_query(urljoin(AUTOMATION_API_BASE_URL, 'visibility/policy/rules'),
                                params=dict(offset=offset,
                                            limit=limit,
                                            **kwargs))

    def list_segmentation_rules(self, **kwargs):
        """
        Similar to "list_visibility_policy_rules", but uses REST API url for the new segmentation pages (added in v26)
        "list_visibility_policy_rules" still works, but with the previous API url
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL,
                                        'visibility/policy/rules'),
                                params=dict(**kwargs))

    def create_visibility_policy_rule(self, section_position, ports, port_ranges, source, destination, ip_protocols,
                                      comments, ruleset_id, action, exclude_ports=None, exclude_port_ranges=None,
                                      scope=None, icmp_matches=None, ruleset_name=None,
                                      network_profile=None, attributes=None):
        from common.py.events.visibility.enforcement_policy import NetworkProfile
        network_profile = network_profile or NetworkProfile.CORPORATE.name

        response = self._json_query(urljoin(NEW_REST_API_BASE_URL,
                                            'visibility/policy/sections/{}/rules'.format(section_position)),
                                    method='POST',
                                    data=dict(rule=dict(ports=ports,
                                                        port_ranges=port_ranges,
                                                        source=source,
                                                        destination=destination,
                                                        ip_protocols=ip_protocols,
                                                        comments=comments,
                                                        action=action,
                                                        ruleset_id=ruleset_id,
                                                        ruleset_name=ruleset_name or '',
                                                        exclude_ports=exclude_ports or [],
                                                        exclude_port_ranges=exclude_port_ranges or [],
                                                        icmp_matches=icmp_matches or [],
                                                        scope=scope,
                                                        creation_origin='SEGMENTATION_RULES',
                                                        last_updated_origin='SEGMENTATION_RULES',
                                                        network_profile=network_profile,
                                                        attributes=attributes or {})))

        return dict(rule=response['rules'][0])

    def create_visibility_policy_rules(self, section_position, rules):
        for rule in rules:
            rule['creation_origin'] = 'SEGMENTATION_RULES'
            rule['last_updated_origin'] = 'SEGMENTATION_RULES'

        response = self._json_query(urljoin(NEW_REST_API_BASE_URL,
                                            'visibility/policy/sections/{}/rules'.format(section_position)),
                                    method='POST',
                                    data=dict(rules=rules))
        return dict(rules=response['rules'])

    def visibility_policy_bulk_op(self,
                                  added_rules=[], modified_rules=[], deleted_rules=[], incident_ids=None):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules/bulk'),
                                method='POST',
                                data=dict(
                                    incident_ids=incident_ids,
                                    added=added_rules,
                                    modified=modified_rules,
                                    deleted=deleted_rules,
                                    origin='INCIDENTS'))

    def visibility_policy_bulk_delete(self, rule_ids=None):
        if rule_ids is None:
            rule_ids = []

        data = {
            'action': 'delete',
            'rule_ids': rule_ids
        }
        return self.visibility_policy_bulk_action(data)

    def bulk_policy_delete(self, ruleset):
        url = urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules-bulk/action?sections=OVERRIDE_ALLOW,'
                                             'OVERRIDE_ALERT,OVERRIDE_BLOCK,ALLOW,ALERT,BLOCK&ruleset=%s' % ruleset)
        return self._json_query(url, method='POST', data={'action': 'delete'})

    def visibility_policy_bulk_action(self, payload, filter_params=None):
        payload["origin"] = REST_API_ORIGIN

        url = urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules-bulk/action')
        return self._json_query(url, method='POST', data=payload, params=filter_params)

    def visibility_policy_label_bulk_actions(self, payload, filter_params=None):
        url = urljoin(NEW_REST_API_BASE_URL, 'visibility/labels/bulk')
        return self._json_query(url, method='POST', data=payload, params=filter_params)

    def visibility_policy_rules_bulk_replace_label(self, key, value, apply_to='both', negate_args=None, selected=None):
        data = dict()

        if negate_args:
            data['negate_args'] = negate_args

        if selected:
            data['rule_ids'] = selected

        data['apply_to'] = apply_to

        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules-bulk/labels/replace/{}/{}'.format(key, value)),
            method='POST',
            data=data)

    def visibility_policy_rules_bulk_remove_label(self, key, apply_to='both', negate_args=None, selected=None):
        data = dict()

        if negate_args:
            data['negate_args'] = negate_args

        if selected:
            data['rule_ids'] = selected

        data['apply_to'] = apply_to

        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules-bulk/labels/remove/{}'.format(key)),
            method='POST',
            data=data)

    def visibility_policy_rules_bulk_move_ruleset(self, ruleset, negate_args=None, selected=None):
        data = dict()

        if negate_args:
            data['negate_args'] = negate_args

        if selected:
            data['rule_ids'] = selected

        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules-bulk/ruleset/move/{}'.format(ruleset)),
            method='POST',
            data=data)

    def visibility_policy_rules_bulk_clone_to_ruleset(self, ruleset, negate_args=None, selected=None):
        data = dict()

        if negate_args:
            data['negate_args'] = negate_args

        if selected:
            data['rule_ids'] = selected

        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules-bulk/ruleset/clone/{}'.format(ruleset)),
            method='POST',
            data=data)

    def visibility_policy_rules_bulk_remove_processes(self, negate_args=None, selected=None):
        data = dict()

        if negate_args:
            data['negate_args'] = negate_args

        if selected:
            data['rule_ids'] = selected

        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules-bulk/processes/remove'),
            method='POST',
            data=data)

    def get_visibility_policy_rule(self, rule_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules/%s' % rule_id))

    def edit_visibility_policy_rule(self, rule_id, **kwargs):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules/%s' % rule_id),
                                method='PUT',
                                data=dict(kwargs, origin='SEGMENTATION_RULES'))

    def delete_visibility_policy_rule(self, rule_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules/%s' % rule_id),
                                method='POST',
                                data=dict(action='delete', origin='SEGMENTATION_RULES'))

    def undelete_visibility_policy_rule(self, rule_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules/%s' % rule_id),
                                method='POST',
                                data=dict(action='undelete', origin='SEGMENTATION_RULES'))

    def revert_visibility_policy_rule(self, rule_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules/%s' % rule_id),
                                method='POST',
                                data=dict(action='revert', origin='SEGMENTATION_RULES'))

    def enable_visibility_policy_rule(self, rule_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules/%s' % rule_id),
                                method='POST',
                                data=dict(action='enable', origin='SEGMENTATION_RULES'))

    def disable_visibility_policy_rule(self, rule_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules/%s' % rule_id),
                                method='POST',
                                data=dict(action='disable', origin='SEGMENTATION_RULES'))

    def list_suggested_allow_rules_for_incidents(self, incident_ids, raw_result=False):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules/suggest-by-incidents'),
                               method='POST',
                               data=dict(incident_ids=incident_ids))
        return raw if raw_result else raw['objects']

    def publish_visibility_policy(self, comments, ruleset=None, reset_hit_count=False, origin=REST_API_ORIGIN):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/revisions'),
                                method='POST',
                                data=dict(comments=comments, ruleset=ruleset, reset_hit_count=reset_hit_count,
                                          origin=origin))

    def discard_visibility_policy(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/revisions'),
                                method='DELETE')

    def revert_visibility_policy(self, revision_number, reset_hit_count=False, origin=REST_API_ORIGIN):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/revisions/revert'),
                                method='POST',
                                data=dict(revision_number=revision_number, reset_hit_count=reset_hit_count,
                                          origin=origin))

    def list_visibility_policy_rulesets(self, offset=0, limit=20):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rulesets'),
                                params=dict(offset=offset,
                                            limit=limit))

    def create_visibility_policy_ruleset(self, name, rules=None):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rulesets'),
                                method='POST',
                                data=dict(name=name,
                                          rules=rules))

    def get_visibility_policy_ruleset(self, ruleset_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rulesets/%s' % ruleset_id))

    def edit_visibility_policy_ruleset(self, ruleset_id, **kwargs):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rulesets/%s' % ruleset_id),
                                method='PUT',
                                data=dict(kwargs))

    def delete_visibility_policy_ruleset(self, ruleset_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rulesets/%s' % ruleset_id),
                                method='DELETE')

    def get_map_suggestions(self, saved_map_id, start_time, end_time, filters=None,
                            state=None, grouping="os_type", **kwargs):
        data = dict(saved_map_id=saved_map_id, start_time=start_time, end_time=end_time, filters=filters, state=state,
                    grouping=grouping,
                    **kwargs)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/map-suggestions'),
                                method='POST',
                                data=data)

    def get_map_suggestions_dismissed(self, saved_map_id, start_time, end_time, filters=None,
                                      state=None, grouping="os_type", **kwargs):
        data = dict(saved_map_id=saved_map_id, start_time=start_time, end_time=end_time, filters=filters, state=state,
                    grouping=grouping,
                    **kwargs)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/map-suggestions/dismissed'),
                                method='POST',
                                data=data)

    def get_map_suggestions_dismissed_all_maps(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/map-suggestions/dismissed/all-maps'),
                                method='GET')

    def delete_map_suggestions_dismissed(self, dismissed_id):
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, "visibility/policy/map-suggestions/dismissed/{}".format(dismissed_id)),
            method='DELETE')

    def dismiss_map_suggestions(self, suggestions):
        """
        ignore bulk of suggested rules by map suggestions. the rule will go to ignore suggestions list
        request example:
            {"suggestions": [{
                "source": {"labels": {"or_labels": [{"and_labels": ["6a4b4534-bc0b-4e59-8ce4-8d1d12c7b93a"]}]},
                                     "processes": ["/usr/local/bin/telegraf"]},
                "destination": {"subnets": ["172.16.0.0/12"]},
                "ports": [8086],
                "ip_protocols": ["TCP"],
                "ruleset": "MongoDB Segmentation Policies - os_type: Linux",
                "unique_flows": 6,
                "saved_map_id": "652b8534-49f4-4cb9-8add-20f43a8b047d"
                }],
            "rules_to_delete": []}
        """
        data = dict(suggestions=suggestions, rules_to_delete=[])
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/map-suggestions/bulk/dismiss'),
                                method='POST',
                                data=data)

    def delete_bulk_map_suggestions_dismissed(self, suggestions_ids, map_obj=None):
        """
        revert ignored (dissmissed) policy rules suggested by map suggestion
        request example:
        1. {"suggestions":["813ec4ff-1bfa-42b8-a690-9c5cf953b858","a1db262f-ccba-4b3f-82b2-5d326f0a02ea"]}
        2. {"suggestions": ["b18b9534-bf43-425c-9eff-2d29ba0dd7c2", "d9982b80-d4e3-4766-bc01-af71481b099d",
                 "11251d02-77d6-4734-b0b7-ea7806c68f87"],
                 "map": {
                        "state": {},
                        "saved_map_id": "652b8534-49f4-4cb9-8add-20f43a8b047d",
                        "filters": {},
                        "grouping": "os_type",
                        "end_time": "1678924799999",
                        "start_time": "1678272736820"},
            "all_maps": False}
        example #1 is same as clicking on 'revert all' in map policy suggestion page
        example #2 is same as clicking on 'revert all' in map ignore suggestion page, and it requires to pass map
         object that can be called by self.get_map(map_id)
        """
        data = {"suggestions": suggestions_ids,
                "all_maps": False}
        if map_obj:
            data.update({"map": map_obj})
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/map-suggestions/bulk/dismissed/delete'),
            method='POST',
            data=data)

    def map_suggestions_bulk_rule(self, rules):

        data = dict(dismissed_suggestions_to_delete=[], rules=rules)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/map-suggestions/bulk/rule'),
                                method='POST',
                                data=data)

    def map_suggestions_rule_undo(self, rule_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/map-suggestions/rule/undo'),
                                method='POST',
                                data={'rule_id': rule_id})

    def map_suggestions_rule_bulk_undo(self, rule_ids):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/map-suggestions/rule/undo'),
                                method='POST',
                                data={'rule_ids': rule_ids})

    def add_visibility_label(self, asset_ids, label_key, label_value):
        endpoint = 'assets/labels/{}/{}'.format(label_key, label_value)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, endpoint),
                                method='POST',
                                data=dict(vms=asset_ids,
                                          delete=False)
                                )

    def delete_visibility_label(self, asset_ids, label_key, label_value):
        endpoint = 'assets/labels/{}/{}'.format(label_key, label_value)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, endpoint),
                                method='POST',
                                data=dict(vms=asset_ids,
                                          delete=True)

                                )

    def add_dynamic_label(self, key, value, dynamic_field=None,
                          dynamic_criterion_operation=None, dynamic_argument=None):
        """
        Creates a dynamic label.
        For example:
            If we're creating a label a:b, for assets whose names begin with 'Attacker', then pass the following params:
            key - 'a'
            value - 'b'
            dynamic_field - 'name'
            dynamic_criterion_operation - LabelCriterionOperation.STARTSWITH
            dynamic_argument - 'Attacker'

        :param dynamic_field: Should be either 'name' or 'numeric_ip_addresses'
        :param dynamic_criterion_operation: Should be one of management.models.labels.LabelCriterionOperation
        :type dynamic_criterion_operation: LabelCriterionOperation
        :param dynamic_argument: The argument itself
        :return:
        """

        def has_dynamic_criteria():
            dynamic_params = [dynamic_field, dynamic_criterion_operation, dynamic_argument]

            if all(dynamic_params):
                return True
            if not any(dynamic_params):
                return False

            raise Exception('You must pass either none, or all of the above: dynamic_name ({}), '
                            'dynamic_criterion_operation ({}), dynamic_argument({})'.format(dynamic_field,
                                                                                            dynamic_criterion_operation,
                                                                                            dynamic_argument))

        endpoint = 'visibility/labels'
        criteria = []

        if has_dynamic_criteria():
            criteria_dict = {
                'field': dynamic_field,
                'op': dynamic_criterion_operation.name,
                'argument': dynamic_argument
            }
            criteria.append(criteria_dict)

        data = {
            'id': None,
            'key': key,
            'value': value,
            'criteria': criteria
        }

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, endpoint), method='POST', data=data)

    def add_dynamic_label_with_multiple_criteria(self, key, value, criteria_list=None):
        """
        Creates a dynamic label.
        For example:
            If we're creating a label a:b, for assets whose names begin with 'Attacker', then pass the following params:
            key - 'a'
            value - 'b'
            criteria_list = list of dicts:
                {dynamic_field - 'name'
                dynamic_criterion_operation - LabelCriterionOperation.STARTSWITH
                dynamic_argument - 'Attacker'}
        """

        endpoint = 'visibility/labels'

        data = {
            'id': None,
            'key': key,
            'value': value,
            'criteria': criteria_list
        }

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, endpoint), method='POST', data=data)

    def add_multiple_labels(self, labels):
        """
        Imports mass amount of labels.

        :param labels: list of label dictionaries.
        Example:
            {'key': 'Role',
            'value': 'External',
            'asset_ids': [id1, id2,...]}
        :return: True if at least one label/asset was modified. False otherwise
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/labels/bulk'),
                                method='POST',
                                data={'labels': labels, 'action': 'add'})

    def list_dynamic_labels(self, raw_result=False):
        """
        Returns a list of dicts. Each label looks like this:

        {
            '_id': '52907f0c-0f75-4c03-ab2c-80208be291a5',
            'criteria': [
                {
                    'argument': 'Attacker',
                    'case_sensitive': False,
                    'field': 'name',
                    'matching_vms': [
                        {
                            '_id': '7aaefe8d-7493-4783-80d0-d0a6901732d0',
                            'name': 'Attacker2'
                        },
                        {
                            '_id': 'eb862ab0-7f09-4777-8dfa-9e35e60d5cc5',
                            'name': 'Attacker1'
                        }
                    ],
                    'op': 'STARTSWITH'
                }
            ],
            'doc_version': 60,
            'id': '52907f0c-0f75-4c03-ab2c-80208be291a5',
            'key': 'LabelKey',
            'matched_assets_counter': 2,
            'source': 'User',
            'value': 'LabelValue'
        }
        """
        endpoint = 'visibility/labels?find_matches=true'
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, endpoint), method='GET')
        return raw if raw_result else raw['objects']

    def delete_dynamic_label_by_id(self, label_id):
        endpoint = 'visibility/labels/{}'.format(label_id)
        self._json_query(urljoin(NEW_REST_API_BASE_URL, endpoint), method='DELETE')

    def list_labels_dynamic_criteria(self, **filt):
        resp = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/labels/labels-dynamic-criteria'),
                                params=filt)
        return resp

    def get_label_revisions(self):
        resp = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/labels/labels-subnet-criteria'),
                                method='GET')
        return resp

    def get_label_sync_data(self, label_ids):
        data = dict(label_ids=label_ids, ranges_as_subnets=True)
        resp = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/labels/labels-subnet-criteria'),
                                method='POST', data=data)
        return resp

    def list_visibility_labels(self, **filt):
        resp = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/labels'), params=filt)
        for label in resp['objects']:
            label['criteria'] = label['dynamic_criteria'] + label['equal_criteria'] + label['implicit_criteria']
        return resp

    def list_labels_new_api(self, **filt):
        resp = self._json_query(urljoin(AUTOMATION_API_BASE_URL, 'labels'), params=filt)
        for label in resp['objects']:
            # equal_criteria will be taken when we execute Centra Cluster suite using a v42 env CS env
            label['criteria'] = label.get('dynamic_criteria') + label.get('static_criteria', label.get(
                'equal_criteria')) + label.get('implicit_criteria')
        return resp

    def get_auto_labeling_conf(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/labels/auto-labeling/configuration'),
                                method='GET')

    def set_auto_labeling_conf(self, conf):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/labels/auto-labeling/configuration'),
                                method='PUT', data=conf)

    def list_label_groups(self, **filt):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/label-groups'), params=filt)

    def create_label_group(self, key, value, include_labels, exclude_labels):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/label-groups'),
                                method='POST',
                                data=dict(label_group=dict(key=key,
                                                           value=value,
                                                           include_labels=include_labels,
                                                           exclude_labels=exclude_labels)))

    def labels_filter_options(self, filter_name, **filt):
        return self._filter_options('visibility/labels', filter_name=filter_name, **filt)

    def edit_label_by_id(self, label_id, body):
        endpoint = 'visibility/labels/{}'.format(label_id)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, endpoint),
                                method='PUT',
                                data=body)

    def update_label_group(self, label_group_id, label_group):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/label-groups/{}'.format(label_group_id)),
                                data=label_group,
                                method='PUT')

    def delete_label_group(self, label_group_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/label-groups/{}'.format(label_group_id)),
                                method='DELETE')

    def publish_label_groups_draft(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/label-groups'),
                                method='PUT')

    def discard_label_groups_draft(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/label-groups'),
                                method='DELETE')

    def get_visibility_policy_suggestions(self, suggest_rules=True, suggest_locks=True, flow_ids=None,
                                          start_time=None, end_time=None,
                                          filters=None, group_by=None,
                                          open_vms=None, open_groups=None,
                                          open_subnets=None, open_internets=None,
                                          action=None, section_position=None,
                                          ruleset_name=None, saved_map_id=None):

        params = self._create_visibility_graph_body(start_time=start_time, end_time=end_time,
                                                    filters=filters, group_by=group_by,
                                                    open_vms=open_vms, open_groups=open_groups,
                                                    open_subnets=open_subnets,
                                                    open_internets=open_internets, saved_map_id=saved_map_id)

        params['data']['origin'] = 'EXPLORE_SUGGESTIONS'

        if flow_ids:
            params['data']['flow_ids'] = flow_ids

        if ruleset_name:
            params['data']['ruleset_name'] = ruleset_name

        if action:
            params['data']['action'] = action

        if section_position:
            params['data']['section_position'] = section_position

        if not suggest_rules and not suggest_locks:
            return {}

        url = 'visibility/policy/suggestions'
        if not suggest_rules:
            url += '/locks'
        if not suggest_locks:
            url += '/rules'

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, url),
                                method='POST', **params)

    # Mitigation agents
    def monitor_udp_connection(self, monitor=True):
        answer = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'aggregators/configuration'),
                                  method='PUT',
                                  data={"mitigation_agent": {"network_visibility_plugin": {"monitor_udp": monitor}}},
                                  return_json=True)
        return answer

    def list_aggregators(self, **filt):
        return self.aggregators.list(**filt)

    def get_aggregator(self, aggregator_id):
        return self.aggregators.get(aggregator_id)

    def get_aggregator_configuration(self, aggregator_id, include_defaults=True):
        return self.aggregators.get_configuration(aggregator_id, include_defaults)

    def set_aggregator_configuration(self, aggregator_id, configuration):
        self.aggregators.set_configuration(aggregator_id, configuration)

    def reset_aggregator_configuration(self, aggregator_id):
        self.aggregators.reset_configuration(aggregator_id)

    def set_aggregator_state(self, aggregator_id, state):
        self.aggregators.set_state(aggregator_id, state)

    def is_aggregator_task_running(self):
        return self.aggregators.is_task_running()

    def stop_aggregators(self, aggregator_ids):
        self.aggregators.stop(aggregator_ids)

    def start_aggregators(self, aggregator_ids):
        self.aggregators.start(aggregator_ids)

    def restart_aggregators(self, aggregator_ids):
        self.aggregators.restart(aggregator_ids)

    def patch_aggregators(self, patch_file_path):
        return self.aggregators.patch(patch_file_path)

    def power_off_on_aggregators(self, operation):
        agents = []
        agents_json = self.list_aggregators()['objects']
        for agent in agents_json:
            agents.append(agent['component_id'])
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'aggregators'), method='POST',
                                data=dict(action=operation,
                                          component_ids=agents),
                                return_json=False)

    # Assets
    def list_assets(self, raw_result=False, **filt):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'assets'), params=filt)
        return raw if raw_result else raw['objects']

    def assets_filter_options(self, filter_name, filter_value=None, **filt):
        return self._filter_options('assets', filter_name, filter_value, **filt)

    def assets_filter_options_resolve(self, **filt):
        return self._filter_options_resolve('assets', **filt)

    def get_asset(self, vm_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'assets/%s' % (vm_id,)))

    def get_asset_actions_log(self, vm_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'assets/%s/actions' % (vm_id,)))

    def deactivate_assets(self, asset_ids):
        asset_ids = ','.join(asset_ids)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'assets/deactivate'),
                                method='POST',
                                data=dict(component_ids=asset_ids))

    def get_deactivation_verdict(self, asset_ids):
        asset_ids = ','.join(asset_ids)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'assets/deactivation-verdict'),
                                params=dict(component_ids=asset_ids))

    def set_comments_to_asset(self, vm_id, user_comment):
        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'assets/%s' % (vm_id,)),
                         method='PUT',
                         params=dict(action='set_comment'),
                         data=dict(user_comment=user_comment),
                         return_json=False)

    def list_assets_basic_data(self, asset_ids):
        data = dict(asset_ids=asset_ids)

        resp = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'assets/basic-data'), method='POST', data=data)
        return resp

    def list_asset_revisions(self):
        resp = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'assets/basic-data'), method='GET')
        return resp

    def create_asset(self, **filt):
        """
        This method using the new automation api '/api/v3.0/api/automation_api/v1/'

           Note: orchestration_obj_id, name, and nics must be provided
        """
        return self._json_query(urljoin(AUTOMATION_API_BASE_URL, 'assets/'), method='POST', **filt)

    def create_asset_bulk(self, **filt):
        """
        This method using the new automation api '/api/v3.0/api/automation_api/v1/'
        """
        results = self._json_query(urljoin(AUTOMATION_API_BASE_URL, 'assets/bulk'),
                                   method='POST',
                                   return_json=True, **filt)
        return results

    def edit_asset_by_id(self, asset_id, **filt):
        """
        This method using the new automation api '/api/v3.0/api/automation_api/v1/'
        """
        return self._json_query(urljoin(AUTOMATION_API_BASE_URL, 'assets/{}'.format(asset_id)), method='PUT', **filt)

    def edit_asset_bulk(self, **filt):
        """
        This method using the new automation api '/api/v3.0/api/automation_api/v1/'
        """
        return self._json_query(urljoin(AUTOMATION_API_BASE_URL, 'assets/bulk'), method='PUT', **filt)

    def get_asset_by_id(self, asset_id, **filt):
        """
        This method using the new automation api '/api/v3.0/api/automation_api/v1/'
        """
        return self._json_query(urljoin(AUTOMATION_API_BASE_URL, 'assets/{}'.format(asset_id)), **filt)

    def get_assets(self, raw_result=False, **filt):
        """
        This method using the new automation api '/api/v3.0/api/automation_api/v1/'
        """
        raw = self._json_query(urljoin(AUTOMATION_API_BASE_URL, 'assets'), params=filt)
        return raw if raw_result else raw['objects']

    def deactivate_asset_by_id(self, asset_id, **filt):
        """
        This method using the new automation api '/api/v3.0/api/automation_api/v1/'
        """
        return self._json_query(urljoin(AUTOMATION_API_BASE_URL, 'assets/{}'.format(asset_id)), method='DELETE', **filt)

    def deactivate_assets_bulk(self, **filt):
        """
        This method using the new automation api '/api/v3.0/api/automation_api/v1/'
        """
        return self._json_query(urljoin(AUTOMATION_API_BASE_URL, 'assets/bulk/deactivate'), method='POST', **filt)

    def get_assets_by_type(self, asset_type, status):
        """
        This method using the new automation api '/api/v4.0/'
        gets assets with a specified asset_type
        :param asset_type: one of 'undefined', 'workstation', 'k8s'
        :param status: one of 'on', 'off', 'deleted'
        :return: dict with a list of asset ids
        """
        url = urljoin(REST_API_BASE_URL_V4, 'assets/types')
        return self._json_query(url, params=dict(asset_type=asset_type, status=status), method='GET')

    def set_asset_types(self, asset_type, asset_ids):
        """
       This method using the new automation api '/api/v4.0/'
       Sets assets to a type
       :param asset_type: one of 'undefined', 'workstation', 'k8s'
       :param asset_ids: list of asset ids to set
       :return: dict with a list of asset ids
        """
        url = urljoin(REST_API_BASE_URL_V4, 'assets/type/set')
        return self._json_query(url, method='POST', params=dict(asset_type=asset_type), data=dict(asset_ids=asset_ids))

    def unset_asset_types(self, asset_ids):
        """
       This method using the new automation api '/api/v4.0/'
       Unsets assets' type
       :param asset_ids: list of asset ids to unset
       :return: dict with a list of asset ids
        """
        url = urljoin(REST_API_BASE_URL_V4, 'assets/type/unset')
        return self._json_query(url, method='POST', data=dict(asset_ids=asset_ids))

    # assets log
    def list_assets_log(self, **filt):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'assets-log'), params=filt)

    # audit log
    @add_default_from_to_time()
    def list_audit_log_entries(self, raw_result=False, **filt):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system/audit-log'), params=filt)
        return raw if raw_result else raw['objects']

    def num_of_audit_log_entries(self, **filt):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system/audit-log'), params=filt)['total_count']

    # hypervisors
    def list_hypervisors(self, raw_result=False, **filt):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'hypervisors'), params=filt)
        return raw if raw_result else raw['objects']

    # patches
    def list_patch_files(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system/update/patch-files'))

    def get_patch_file(self, patch_file_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system/update/patch-files/{}'.format(patch_file_id)))

    def delete_patch_file(self, patch_file_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system/update/patch-files/{}'.format(patch_file_id)),
                                method='DELETE',
                                return_json=False)

    def get_patch_logs(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'patch-logs'),
                                return_json=False)

    def get_latest_patch_status(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system/update/patch-runs'))

    def start_apply_patch(self, patch_file_id, component_types):
        """
        Applies a patch
        :param patch_file_id: the patch file to apply
        :param component_types: a list of components such as ['management','honeypot', 'aggregator', 'monicore']
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system/update/patch-runs'),
                                method='POST',
                                data=dict(patch_file_id=patch_file_id, component_types=component_types))

    def get_patch_status(self, patch_status_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system/update/patch-runs/{}'.format(patch_status_id)))

    # packages info
    def get_packages_info(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'packages-info'), method='GET')

    # blocked connections
    def list_blocked_connections(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'blocked_connections'))

    # ================================ DNS api-calls     ================================

    @add_default_from_to_time()
    def get_dns_requests(self, raw_result=False, **filt):
        """
        filter can be:
        requested_host_name - e.g. requested_host_name='www.google.com'
        client_ip - e.g. client_ip='172.17.0.3'
        empty_answer (boolean) - HostNotFound
        no_answer (boolean) - no answer from DNS servers
        from_time , to_time - for sorting
        """
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'labs/dns-requests'), params=filt)
        return raw if raw_result else raw['objects']

    def download_dns_list(self, list_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/dns-security/' + list_id),
                                method='GET',
                                return_json=False)

    # ============================= GUEST AGENT ============================================

    def list_agents(self, **filt):
        """
        :param filt: request filters
        The Module-Status's filter name is one out of 3 options: (according to the 3 radio buttons in the ui)
            module_status_deception
            module_status_enforcement
            module_status_reveal
        optional values: Active/Not Deployed/Enforcement disabled from management console
        :return: agents result list and metadata
        """
        return self.agents.list(**filt)

    def forget_missing_agents(self):
        return self.agents.remove_invalid_components()

    def start_agent(self, agent_id):
        self.agents.start_agent([agent_id])

    def stop_agent(self, agent_id):
        self.agents.stop_agent([agent_id])

    def get_version(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'version'))

    def set_agent_configuration(self, configuration):
        """
        :param configuration:
            {'component_ids':<list of ids>, 'enforcementagent':{'agent_monitor_mode':<bool>}}
        :return:
        """
        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-v2/configuration'),
                         method='PUT',
                         data=configuration)

    def put_configuration_schema(self, params, configuration, ignore_errors=True):
        """
        sends a put configuration schema request to the client
        @param params:
        @param configuration: configuration that will set on the agent, for example :
        {"enforcementagent":{"conn_request_size":90}, "negate_args":null,
        "component_ids":["AG-5b10af3d-1018-42b0-8d1d-5e3d1bc951fe"]}
        @param ignore_errors: Whether to ignore errors and return response as is
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-v2/configuration/schema'),
                                params=params, method='PUT', data=configuration, ignore_errors=ignore_errors)

    def set_agent_configuration_replace(self, params, configuration):
        """
        :param params: passed as part of the search arguments
        :param configuration: payload of the request
        :return:
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-v2/configuration/replace'),
                                params=params, method='PUT', data=configuration, ignore_errors=True)

    def send_agent_action(self, data, params):
        """
        :param data: payload of the request
        :param params: parameters passed at the request
        :return:
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents'),
                                method='POST', data=data, ignore_errors=True, params=params)

    def get_agent_configuration(self, component_id):
        """
        :param component_id:
            component_id
        :return:
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-v2/configuration'),
                                method='POST',
                                data={'component_ids': [component_id]},
                                return_json=True)

    def reset_agents_configuration(self, data, ignore_errors):
        """
        :param data: Payload that is sent in the request to reset the agent's configuration, for example:
        {"negate_args":null,"component_ids":["AG-77820e9f-8eeb-4106-83f3-f8f890ab41b5"]}, where the components_ids
        value is the components ids of the agents configuration to reset
        :param ignore_errors: Whether to ignore errors and return response as is
        :return:
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-v2/configuration/reset'), method='POST',
                                data=data, ignore_errors=ignore_errors)

    def reset_agents_configuration_dry_run(self, component_ids):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-v2/configuration/reset/dry-run'), method='POST',
                                data=dict(component_ids=component_ids))

    def get_agent_policy(self, asset_id):
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'assets/{}/policy'.format(asset_id)),
            return_json=True, follow_redirects=True)

    def forget_agents(self, agent_ids):
        return self.agents.forget(component_ids=agent_ids)

    @staticmethod
    def _update_replace_bypass_proxy_parameters(systems, bypass_proxy=False):
        if bypass_proxy:
            bypass_proxy_curl_bypass_proxy_value = " --noproxy '{ip_no_port}'"
            bypass_proxy_wget_bypass_proxy_value = " --no-proxy"
            bypass_proxy_bypass_proxy_arg_windows_value = "/bypass-proxy"
            bypass_proxy_export_bypass_proxy_arg_value = "export GC_PROXY_NO_PROXY=\"{ip_no_port}\""
            bypass_proxy_export_bypass_proxy_mac_value = "export GC_PROXY_NO_PROXY=\"{ip_no_port}\""
        else:
            bypass_proxy_curl_bypass_proxy_value = ""
            bypass_proxy_wget_bypass_proxy_value = ""
            bypass_proxy_bypass_proxy_arg_windows_value = ""
            bypass_proxy_export_bypass_proxy_arg_value = ""
            bypass_proxy_export_bypass_proxy_mac_value = ""

        # replacing bypass proxy, must run before replacing the IP
        for system in systems:
            system["online_command"] = system["online_command"].replace("{curl-bypass-proxy}",
                                                                        bypass_proxy_curl_bypass_proxy_value)
            system["online_command"] = system["online_command"].replace("{wget-bypass-proxy}",
                                                                        bypass_proxy_wget_bypass_proxy_value)
            system["online_command"] = system["online_command"].replace("{bypass-proxy-arg-windows}",
                                                                        bypass_proxy_bypass_proxy_arg_windows_value)
            system["online_command"] = system["online_command"].replace("{export-bypass-proxy-variable}",
                                                                        bypass_proxy_export_bypass_proxy_arg_value)
            system["online_command"] = system["online_command"].replace("{export-bypass-proxy-variable-mac}",
                                                                        bypass_proxy_export_bypass_proxy_mac_value)
            system["offline_command"] = system["offline_command"].replace("{curl-bypass-proxy}",
                                                                          bypass_proxy_curl_bypass_proxy_value)
            system["offline_command"] = system["offline_command"].replace("{wget-bypass-proxy}",
                                                                          bypass_proxy_wget_bypass_proxy_value)
            system["offline_command"] = system["offline_command"].replace("{bypass-proxy-arg-windows}",
                                                                          bypass_proxy_bypass_proxy_arg_windows_value)
            system["offline_command"] = system["offline_command"].replace("{export-bypass-proxy-variable}",
                                                                          bypass_proxy_export_bypass_proxy_arg_value)
            system["offline_command"] = system["offline_command"].replace("{export-bypass-proxy-variable-mac}",
                                                                          bypass_proxy_export_bypass_proxy_mac_value)

    def get_agents_installation_instruction(self, format_ip=True, installation_profile=None, agent_type=None, bypass_proxy=False):
        systems = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-installation/operating-systems'))[
            'operating_systems']

        self._update_replace_bypass_proxy_parameters(systems, bypass_proxy)

        if format_ip:
            ip = \
                self._json_query(
                    urljoin(NEW_REST_API_BASE_URL, 'agent_aggregators/selectbox-options?limit=40&offset=0'))[
                    0]["ip_address"]
            for system in systems:
                system["online_command"] = system["online_command"].replace("{ip}", ip)
                system["online_command"] = system["online_command"].replace("{ip_no_port}", ip)

                system['offline_command'] = system['offline_command'].replace("{ip}", ip)
                system['offline_command'] = system['offline_command'].replace("{ip_no_port}", ip)

        installation_profile = installation_profile if installation_profile is not None else "default"
        if not agent_type:
            agent_type = ""
        for system in systems:
            try:
                system["online_command"] = system["online_command"].replace("{profile_name}",
                                                                            installation_profile).replace(
                    "{agent_type}", agent_type)
                system["offline_command"] = system["offline_command"].replace("{profile_name}",
                                                                              installation_profile).replace(
                    "{agent_type}", agent_type)
            # Not all operating systems have offline_command value
            except KeyError:
                continue

        return systems

    # ============================= AGENT INSTALLATION PROFILES ===================================

    def get_installation_profile(self, profile_name):
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'agents-installation/profile/{}'.format(profile_name)),
            method='GET',
            params=dict(name=profile_name)
        )

    def get_installation_profile_instance_sync(self, params={}):
        """
        get data is relevant in order for an instance to sync the cluster manager,
        for example objects of profile, or revisions of the object in the collection, can be expanded for future needs
        @param params: used for indication on whether all profile data is required
        @return: either response contains objects field, or a response contains installation_profiles_revisions field
        """
        resp = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-installation/instance_sync'),
                                method='GET',
                                params=params)
        return resp

    def update_installation_profile(self, profile_data):
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'agents-installation/profile/{}'.format(profile_data['name'])),
            method='PUT',
            data=profile_data
        )

    def delete_installation_profile(self, profile_name):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-installation/profile/{}'.format(profile_name)),
                                method='DELETE')

    def get_installation_profiles(self, sort_string):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-installation/profiles'), method='GET',
                                params=dict(sort=sort_string))

    def create_installation_profile(self, profile_data):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-installation/profiles'), method='POST',
                                data=profile_data)

    def get_installation_profile_full_oslo_configuration(self, profile_name, view):
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'agents-installation/profile/{}/configuration'.format(profile_name)),
            method='GET',
            params=dict(sort=view)
        )

    def get_installation_profiles_schema(self, view):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-installation/profiles/schema'),
                                method='GET', params=dict(sort=view))

    def get_installation_profiles_schema_base(self, view):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-installation/profiles/schema/base'),
                                method='GET', params=dict(sort=view))

    # ============================= AGENTS BULK LABELING =====================================

    def agents_bulk_label_set(self, key, value, negate_args=None, selected=None):
        # Note: negate_args and selected are mutually exclusive - the endpoint will fail if both are passed in
        data = dict()

        if negate_args:
            data['negate_args'] = negate_args

        if selected:
            data['selected'] = selected

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/bulk-label/set/{}/{}'.format(key, value)),
                                method='POST',
                                data=data)

    def agents_bulk_label_remove(self, key, negate_args=None, selected=None):
        # Note: negate_args and selected are mutually exclusive - the endpoint will fail if both are passed in
        data = dict()

        if negate_args:
            data['negate_args'] = negate_args

        if selected:
            data['selected'] = selected

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/bulk-label/remove/{}'.format(key)),
                                method='POST',
                                data=data)

    # ============================= REMOTE AGENT DIAGNOSTICS ===============================

    def get_agents_diagnostics(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-v2/diagnostics'))

    def start_agents_diagnostics(self, agents, verbose=False, log_size=0, agent_logs=True, agent_server_logs=True,
                                 certificate_details=True, agent_local_config=True, server_details=True,
                                 rotated_logs=True):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-v2/diagnostics'), method="POST",
                                data=dict(agents=agents, verbose=verbose, log_size=log_size, agent_logs=agent_logs,
                                          agent_server_logs=agent_server_logs, certificate_details=certificate_details,
                                          agent_local_config=agent_local_config, server_details=server_details,
                                          rotated_logs=rotated_logs))

    def download_agents_diagnostics(self, diagnostic_id, agent_id=None):
        data = dict(diagnostic_id=diagnostic_id)
        if agent_id:
            data['agent_id'] = agent_id
        uri = 'agents-v2/diagnostics/download?diagnostic_id={}'.format(diagnostic_id)
        if agent_id:
            uri += "&agent_id={}".format(agent_id)

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, uri), return_json=False, follow_redirects=True)

    def download_agents_diagnostics_file(self, download_dir_path, diagnostic_id, agent_id=None):
        uri = 'agents-v2/diagnostics/download?diagnostic_id={}'.format(diagnostic_id)
        if agent_id:
            uri += "&agent_id={}".format(agent_id)

        params = {'follow_redirects': True}
        return self._download_file(urljoin(NEW_REST_API_BASE_URL, uri), download_dir_path, **params)

    def abort_agents_diagnostics(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-v2/diagnostics/abort'))

    # ============================= REMOTE AGENTS UPGRADE ============================================

    def get_agents_bundle_info(self, component_ids):
        if isinstance(component_ids, list):
            component_ids = ','.join(component_ids)

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/upgrade'),
                                params={'component_ids': component_ids})

    def trigger_agent_upgrades_job(self,
                                   action,
                                   description,
                                   component_ids,
                                   bundles_version='',
                                   selected_profile=None):

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/upgrades'),
                                method='POST',
                                data={'action': action,
                                      'component_ids': component_ids,
                                      'description': description,
                                      'bundles_version': bundles_version,
                                      "selectedProfile": selected_profile})

    def get_agent_upgrades_job(self, upgrade_job_id='latest'):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/upgrades/%s' % upgrade_job_id))

    def abort_agent_upgrades_job(self, path):
        target_url = '%s' % (urljoin(NEW_REST_API_BASE_URL, path))
        return self._json_query(target_url,
                                method='POST',
                                data={'action': 'abort'})

    def get_all_agent_upgrade_jobs(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/upgrades'))

    # ====================================== AGENTS QUERY ============================================

    def run_new_agent_query(self, query, agent_filter, export_csv_file=False):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query'),
                                method='POST',
                                data={'action': 'run',
                                      'query': query,
                                      'filter': agent_filter,
                                      'export_csv_file': export_csv_file
                                      }
                                )

    def get_latest_agent_query_status(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/latest'))

    def get_agent_query_status(self, query_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/%s' % query_id))

    def agent_query_preview_selection(self, filters):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query'),
                                method='POST',
                                data={'action': 'preview_selection',
                                      'filter': filters})

    def agent_query_get_os_filter_options(self, limit=20, offset=0):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/filter-options'),
                                params={'filter_name': 'os',
                                        'filter_value': '',
                                        'limit': limit,
                                        'offset': offset})

    def agent_query_get_labels_filter_options(self, filter_value, limit=20, offset=0):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/filter-options'),
                                params={'filter_name': 'labels',
                                        'filter_value': filter_value,
                                        'limit': limit,
                                        'offset': offset})

    def get_agent_query_results(self, query_id, limit=20, offset=0):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/%s/results' % query_id),
                                params={'limit': limit,
                                        'offset': offset})

    def export_agent_query_results(self, query_id):
        result = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/%s/export' % query_id))
        export_task_status_id = result['export_task_status_id']
        report_id = self._get_report_id(export_task_status_id)
        return self._download_report_file(report_id)

    def export_agent_query_errors(self, query_id):
        result = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/%s/errors/export' % query_id))
        export_task_status_id = result['export_task_status_id']
        report_id = self._get_report_id(export_task_status_id)
        return self._download_report_file(report_id)

    def agent_query_preview_labeling(self, query_id, key, value):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/%s/label' % query_id),
                                method='POST',
                                data={'action': 'preview_agents_to_label',
                                      'label_key': key,
                                      'label_value': value})

    def agent_query_label_agents_by_query_results(self, query_id, key, value):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/%s/label' % query_id),
                                method='POST',
                                data={'action': 'add_to_label',
                                      'label_key': key,
                                      'label_value': value})

    def export_agent_query_log(self):
        result = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/history/export'))
        export_task_status_id = result['export_task_status_id']
        report_id = self._get_report_id(export_task_status_id)
        return self._download_report_file(report_id)

    # ============================= SCHEDULED QUERY ============================================

    def insight_schedule_query(self, query, filters, name, interval_sec, enabled,
                               target_label_key, target_label_value, remove_label_on_empty, alert_on_nonempty_result):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/scheduled'),
                                method='POST',
                                data={'name': name,
                                      'query': query,
                                      'filter': filters,
                                      'interval_sec': interval_sec,
                                      'enabled': enabled,
                                      'target_label_key': target_label_key,
                                      'target_label_value': target_label_value,
                                      'remove_label_on_empty': remove_label_on_empty,
                                      'alert_on_nonempty_result': alert_on_nonempty_result})

    def insight_update_scheduled_query(self,
                                       scheduled_query_id, name=None, interval_sec=None, enabled=None,
                                       query=None, filters=None,
                                       target_label_key=None, target_label_value=None, remove_label_on_empty=None):
        update_data = {key: value for key, value in {'name': name,
                                                     'interval_sec': interval_sec,
                                                     'enabled': enabled,
                                                     'target_label_key': target_label_key,
                                                     'target_label_value': target_label_value,
                                                     'query': query,
                                                     'remove_label_on_empty': remove_label_on_empty}.items()
                       if value is not None}

        if filters is not None:
            update_data['filter.os'] = filters.get('os')
            update_data['filter.labels'] = filters.get('label')

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/scheduled/%s' % scheduled_query_id),
                                method='PATCH',
                                data=update_data)

    def insight_delete_scheduled_query(self, scheduled_query_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/scheduled/%s' % scheduled_query_id),
                                method='DELETE')

    @staticmethod
    def _get_scheduled_queries_filter(name_filter=None, enabled_filter=None, status_filter=None,
                                      user_filter=None, text_filter=None):
        filters = ['%s=%s' % (key, value) for key, value in {'name': name_filter,
                                                             'enabled': enabled_filter,
                                                             'status': status_filter,
                                                             'user': user_filter,
                                                             'gc_filter': text_filter}.items()
                   if value is not None]

        return '&'.join(filters)

    def insight_bulk_enable_scheduled_queries(self, name_filter=None, enabled_filter=None, status_filter=None,
                                              user_filter=None, text_filter=None):
        filters = self._get_scheduled_queries_filter(name_filter, enabled_filter, status_filter,
                                                     user_filter, text_filter)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/scheduled/bulk/enable?%s' % filters),
                                method='POST')

    def insight_bulk_disable_scheduled_queries(self, name_filter=None, enabled_filter=None, status_filter=None,
                                               user_filter=None, text_filter=None):
        filters = self._get_scheduled_queries_filter(name_filter, enabled_filter, status_filter,
                                                     user_filter, text_filter)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/scheduled/bulk/disable?%s' % filters),
                                method='POST')

    def insight_bulk_delete_scheduled_queries(self, name_filter=None, enabled_filter=None, status_filter=None,
                                              user_filter=None, text_filter=None):
        filters = self._get_scheduled_queries_filter(name_filter, enabled_filter, status_filter,
                                                     user_filter, text_filter)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/scheduled/bulk/delete?%s' % filters),
                                method='POST')

    def insight_get_scheduled_queries(self, name_filter=None, enabled_filter=None, status_filter=None,
                                      user_filter=None, text_filter=None):
        filters = self._get_scheduled_queries_filter(name_filter, enabled_filter, status_filter,
                                                     user_filter, text_filter)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/query/scheduled?%s' % filters),
                                method='GET')

    # ============================= STORAGE ============================================

    def get_storage_data(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'storage-overview'))

    def get_storage_timeout(self, **filt):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'storage-overview/reveal/days-to-freed-space'),
                                params=filt)

    def set_storage_watermark(self, watermark):
        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'storage-overview/set-watermark'),
                         method='PUT',
                         data=watermark)

    # ============================= USER DIRECTORIES ============================================

    def add_user_directory(self, directory_type, name, **kwargs):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'user-directories'),
                                method='POST',
                                data=dict(action='add', directory_type=directory_type, name=name, **kwargs))

    def list_user_directories(self, raw_result=False):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'user-directories'))
        return raw if raw_result else raw['objects']

    def delete_user_directory(self, type, name):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'user-directories'),
                                method='DELETE',
                                params=dict(directory_type=type, domain_name=name),
                                return_json=False)

    def get_groups_from_domain(self, domain_id, search_term=""):
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'visibility/user-groups/validate/%s/%s' % (domain_id, search_term)))

    def download_saml_cert(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'user-directories/download-saml-cert'),
                                method='GET', convert_data_to_json=False, return_json=False)

    # ================================= FIM TEMPLATES ============================================

    def list_fim_templates(self, raw_result=False, **filt):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'fim/templates'), params=filt)
        return raw if raw_result else raw['objects']

    def create_fim_template(self, title, files, hash_type=None, enabled=True,
                            affected_asset_ids=None, affected_label_ids=None, description=None):
        if affected_asset_ids is None:
            affected_asset_ids = []
        if affected_label_ids is None:
            affected_label_ids = []
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'fim/templates'),
                                method='POST',
                                data=dict(templates=[dict(title=title, files=files, hash_type=hash_type,
                                                          affected_asset_ids=affected_asset_ids,
                                                          affected_label_ids=affected_label_ids,
                                                          enabled=enabled,
                                                          description=description)]))

    def edit_fim_template(self, template_id, title, files, hash_type=None, enabled=True,
                          affected_asset_ids=None, affected_label_ids=None, description=None):
        if affected_asset_ids is None:
            affected_asset_ids = []
        if affected_label_ids is None:
            affected_label_ids = []
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'fim/templates/%s' % template_id),
                                method='PUT',
                                data=dict(title=title, files=files, hash_type=hash_type,
                                          affected_asset_ids=affected_asset_ids,
                                          affected_label_ids=affected_label_ids,
                                          enabled=enabled,
                                          description=description))

    def delete_fim_template(self, template_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'fim/templates/%s' % template_id),
                                method='POST',
                                data=dict(action='delete'))

    def fim_discard_changes(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'fim/revisions'), method='DELETE')

    def publish_fim_templates(self, comments=None):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'fim/revisions/publish'),
                                method='POST',
                                data=dict(comments=comments))

    def list_stale_hashes(self, interval_days, raw_result=False):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'fim/stale-hashes'),
                               params=dict(interval_days=interval_days))
        return raw if raw_result else raw['objects']

    def delete_stale_hashes(self, hash_tuples, confirm=False):
        # hash tuple is list of {template_id: X, path: X, hash: X}
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'fim/stale-hashes'),
                                method='POST',
                                data=dict(action='delete', hash_tuples=hash_tuples, confirm=confirm))

    # ================================= FIM LOG =================================================

    @add_default_from_to_time()
    def get_fim_log(self, raw_result=False, **filt):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'fim/log'), params=filt)
        return raw if raw_result else raw['objects']

    # ================================= LABELS LOG =================================================

    @add_default_from_to_time()
    def get_labels_log(self, raw_result=False, **filt):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'labels-log'), params=filt)
        return raw if raw_result else raw['objects']

    # ================================= SAVED MAPS ==============================================
    @staticmethod
    def _build_map_resource(api_base_url):
        """Build Saved Maps url."""
        resource_map = {
            NEW_REST_API_BASE_URL: 'visibility/saved-maps',
            REST_API_BASE_URL_V4: 'saved-maps'
        }
        if api_base_url not in resource_map:
            raise ValueError("Not supported Api base url: %s" % api_base_url)

        return urljoin(api_base_url, resource_map[api_base_url])

    def list_saved_maps(self, api_base_url=NEW_REST_API_BASE_URL, raw_result=False, **filters):
        """Return the list of Saved Maps."""
        resource = self._build_map_resource(api_base_url)
        raw = self._json_query(resource, params=filters)
        return raw if raw_result else raw['objects']

    def create_saved_map(self, end_time_filter, start_time_filter, filters, map_type=0, scope=None, name=None,
                         time_resolution=False, include_flow_hit_count=False, include_incident_marks=False,
                         export_archive=False, email_on_progress=False, api_base_url=NEW_REST_API_BASE_URL):
        """
        Create Saved Map.
        # map_type: 0 - PUBLIC, 1 - PRIVATE, 2 - INCIDENT
        # filters: {include: {}, exclude: {}}
        """
        data = dict(name=name,
                    map_type=map_type,
                    filters=filters,
                    start_time_filter=start_time_filter,
                    end_time_filter=end_time_filter,
                    time_resolution=time_resolution,
                    include_flow_hit_count=include_flow_hit_count,
                    include_incident_marks=include_incident_marks,
                    email_on_progress=email_on_progress)

        if scope:
            data['scope'] = scope
        if export_archive:
            data['export_archive'] = export_archive

        resource = self._build_map_resource(api_base_url)
        return self._json_query(resource, method='POST', data=data)

    def get_saved_map(self, saved_map_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/saved-maps/%s' % saved_map_id),
                                params={'saved_map_id': saved_map_id},
                                method='GET',
                                return_json=True)

    def download_saved_map(self, saved_map_id, download_dir_path):
        return self._download_file(urljoin(NEW_REST_API_BASE_URL, 'visibility/saved-maps/download'),
                                   download_dir_path,
                                   params={'saved_map_id': saved_map_id})

    def delete_saved_map(self, saved_map_id, api_base_url=NEW_REST_API_BASE_URL):
        """Delete Saved Map with given identifier."""
        resource = self._build_map_resource(api_base_url)
        return self._json_query("%s/%s" % (resource, saved_map_id), method='DELETE')

    def cancel_saved_map(self, saved_map_id, api_base_url=NEW_REST_API_BASE_URL):
        """Cancel Saved Map with given identifier."""
        resource = self._build_map_resource(api_base_url)
        return self._json_query("%s/%s/cancel" % (resource, saved_map_id), method='POST')

    def get_last_active_scheduled_map(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/saved-maps/scheduled-maps/latest'))

    # ================================= Inventory Sync ==============================================

    def upstream_sync_inventory(self, inventory_type, max_inventories, mc_instance_id):
        return self.restapi.get_compressed_streamed_data(
            urljoin(NEW_REST_API_BASE_URL, 'inventory_upstream'),
            params=dict(inventory_type=inventory_type, max_inventories=max_inventories, mc_instance_id=mc_instance_id))

    def confirm_upstream_inventory_synced(self, inventory_ids, inventory_type, mc_instance_id):
        data = dict(inventory_ids=inventory_ids,
                    inventory_type=inventory_type)
        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'inventory_upstream'),
                         method='POST',
                         data=data,
                         params=dict(mc_instance_id=mc_instance_id),
                         return_json=False)

    def trigger_upstream_sync_inventory(self, inventory_type, mc_instance_id, seen_after=None, inventory_ids=None):
        data = dict(inventory_type=inventory_type)

        if seen_after is not None:
            data['seen_after'] = datetime_to_timestamp(seen_after)

        if inventory_ids is not None:
            data['inventory_ids'] = inventory_ids

        self._json_query(urljoin(NEW_REST_API_BASE_URL, 'inventory_upstream/manual_sync'),
                         method='POST',
                         data=data,
                         params=dict(mc_instance_id=mc_instance_id),
                         return_json=False)

    def report_cross_instance_reveal(self, events, mc_instance_id):
        """
        Report connection events to centra instance via Connections API.
        It is used to:
            1. Report cross instance incoming NetworkEvents to cluster manager
            2. Report events from manager to instance that potentially can match it.
               manager gets events from instances (1).
        """
        self._json_query(urljoin(REST_API_BASE_URL_V4,
                                 'provider/connections/bulk'),
                         method='POST',
                         data=events,
                         params=dict(mc_instance_id=mc_instance_id),
                         return_json=False)

    # ====================================== RBAC ===============================================

    def list_permission_schemes(self, raw_result=False, **filt):
        raw = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'rbac/user-permission-schemes'), params=filt)
        return raw if raw_result else raw['objects']

    def create_permission_scheme(self, title, role_ids, scoping_data=None, default_view=DEFAULT_VIEW_EXPLORE,
                                 description=None, user_directory_groups=None, view_neighboring_assets=None,
                                 limited_to_non_override_rules=False, labels=None, permissions_to_revoke=None):
        # scoping_data: {scoping_key: x, selected_ids: [id_1, ids_2,...]
        #                scoping_key is from rbac_scoping.yaml
        if user_directory_groups is None:
            user_directory_groups = []

        data_dict = dict(title=title, description=description,
                         role_ids=role_ids,
                         labels=labels,
                         default_view=default_view,
                         user_directory_groups=user_directory_groups,
                         view_neighboring_assets=view_neighboring_assets,
                         limited_to_non_override_rules=limited_to_non_override_rules)

        if scoping_data is not None:
            data_dict['scoping_data'] = scoping_data

        if permissions_to_revoke is not None:
            data_dict['permissions_to_revoke'] = permissions_to_revoke

        if view_neighboring_assets is not None:
            data_dict['view_neighboring_assets'] = view_neighboring_assets

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'rbac/user-permission-schemes'),
                                method='POST',
                                data=dict(user_permission_schemes=[data_dict]))

    def delete_permission_scheme(self, permission_scheme_id):
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'rbac/user-permission-schemes/%s' % permission_scheme_id),
            method='POST',
            data=dict(action='delete'))

    def edit_permission_scheme(self, permission_scheme_id, title, role_ids, scoping_data=None,
                               default_view=DEFAULT_VIEW_EXPLORE, description=None, user_directory_groups=None,
                               view_neighboring_assets=None, labels=None, permissions_to_revoke=None):
        if user_directory_groups is None:
            user_directory_groups = []

        data_dict = dict(title=title, description=description,
                         role_ids=role_ids,
                         labels=labels,
                         default_view=default_view,
                         user_directory_groups=user_directory_groups)

        if scoping_data is not None:
            data_dict['scoping_data'] = scoping_data

        if permissions_to_revoke is not None:
            data_dict['permissions_to_revoke'] = permissions_to_revoke

        if view_neighboring_assets is not None:
            data_dict['view_neighboring_assets'] = view_neighboring_assets

        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'rbac/user-permission-schemes/%s' % permission_scheme_id),
            method='PUT',
            data=data_dict)

    # ================================= IoC Blacklist ============================================

    def set_ioc_blacklist(self, type, items):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'blacklist'),
                                params=dict(type=type),
                                method='POST',
                                data={'{}'.format(type): items})

    def clear_all_ioc_blacklist(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'blacklist'),
                                method='DELETE')

    # ================================= Cluster Health ===========================================

    def get_cluster_health(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'cluster/health'))

    # =================================== User Groups ============================================

    def get_user_groups(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/user-groups'))['objects']

    def get_user_group_sync_data(self, user_group_ids):
        data = dict(user_group_ids=user_group_ids)
        resp = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/user-groups/basic-data'),
                                method='POST', data=data)
        return resp

    def get_user_group_revisions(self):
        resp = self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/user-groups/revisions'),
                                method='GET')
        return resp

    def add_user_group(self, title, orchestrations_groups):
        """
        :param title: user group title
        :param orchestrations_groups: [
                                        {
                                           orchestration_id: <orchestration id in mongo>,
                                           groups: [<group id>, <group id>, ...]
                                        }
                                     ]
        :return: user group
        """
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'visibility/user-groups'),
            method='POST',
            data=dict(title=title, orchestrations_groups=orchestrations_groups))

    def edit_user_group(self, user_group_id, title, orchestrations_groups):
        """
        update user group with new groups for AD orchestrations and remove AD orchestrations that are with None
        :param user_group_id: user group id
        :param title: user group title
        :param orchestrations_groups: [
                                        {
                                           orchestration_id: <orchestration id in mongo>,
                                           groups: [<group id>, <group id>, ...]
                                        },
                                        {
                                           orchestration_id: <orchestration id in mongo>,
                                           groups: None  # to delete the orchestration
                                        }
                                     ]
        :return: user group
        """
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'visibility/user-groups/%s' % user_group_id),
            method='PUT',
            data=dict(title=title, orchestrations_groups=orchestrations_groups))

    def delete_user_group(self, user_group_id):
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'visibility/user-groups/%s' % user_group_id),
            method='DELETE')

    def publish_user_groups(self):
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'visibility/user-groups/revisions'), method='POST')

    def discard_user_groups(self):
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'visibility/user-groups/revisions'), method='DELETE')

    def set_agent_admin_lock(self, component_ids, admin_lock_state, admin_lock_password=None, ignore_errors=False):
        """
        :param component_ids: List of agents ids.
        :param admin_lock_state: The desired admin lock state, from type AdminLockState.
        :param admin_lock_password: The desired admin lock password, could be None.
        :param ignore_errors: Whether to ignore errors and return response as is
        :return:
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-v2/admin-lock'), method='POST',
                                ignore_errors=ignore_errors,
                                data=dict(component_ids=component_ids,
                                          state=admin_lock_state.name,
                                          password=admin_lock_password))

    def set_agent_enforcement_mode(self, component_ids, enforcement_mode, ignore_errors=False):
        """
        Set agent's enforcement mode
        :param component_ids: List of agents ids.
        :param enforcement_mode: The desired enforcement mode enum, from type EnforcementMode.
        an example of a possible enforcement_mode enum declaration is:
            class EnforcementMode(IntEnum):
                Unset = 0
                RevealOnly = 1
                Monitoring = 2
                Enforcing = 3
                Unused4 = 4
                MetricsOnly = 5

        :param ignore_errors: Whether to ignore errors and return response as is
        :return:
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-v2/enforcement-state'), method='POST',
                                data=dict(state=enforcement_mode.name, component_ids=component_ids),
                                ignore_errors=ignore_errors)

    # ====================================== Workflow ============================================

    def get_label_suggestions(self, sort, limit):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'workflow/label-suggestions'), method='GET',
                                params=dict(sort=sort, limit=limit))

    def create_label_suggestion(self, variable_id, label_key, label_value, asset_ids, api_version):
        data = dict(
            variable_id=variable_id,
            label_key=label_key,
            label_value=label_value,
            asset_ids=asset_ids,
            api_version=api_version,
        )

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'workflow/label-suggestions'), method='POST',
                                data=data)

    def delete_label_suggestions(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'workflow/label-suggestions'), method='DELETE')

    def get_project_templates(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'workflow/project-templates'), method='GET')

    def create_project_template(self, project_name, icon_url, project_version, api_version, template_configuration,
                                user_configuration_defaults, hashtags, variables, project_suggestion_format,
                                project_title_format, project_creation_format, rules, default_map, author):
        data = dict(
            project_name=project_name,
            icon_url=icon_url,
            project_version=project_version,
            api_version=api_version,
            template_configuration=template_configuration,
            user_configuration_defaults=user_configuration_defaults,
            hashtags=hashtags,
            variables=variables,
            project_suggestion_format=project_suggestion_format,
            project_title_format=project_title_format,
            project_creation_format=project_creation_format,
            rules=rules,
            default_map=default_map,
            author=author,
        )

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'workflow/project-template'), method='POST',
                                data=data)

    def delete_project_template(self, project_template_id):
        url = 'workflow/project-template/{project_template_id}'.format(project_template_id=project_template_id)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, url), method='DELETE')

    def create_project_prioritization(self, template_id, variable_values, priority):
        data = dict(
            template_id=template_id,
            variable_values=variable_values,
            priority=priority,
        )

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'workflow/project-prioritization'), method='POST',
                                data=data)

    def delete_project_prioritizations(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'workflow/project-prioritizations'), method='DELETE')

    def get_project_suggestions(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'workflow/project-suggestions'), method='GET')

    def generate_project_violations_map(self, project_id, **kwargs):
        """
        Request URL: https://87.thin.env/api/v3.0/workflow/generate-project-violations-map
            data: {origin: "SEGMENTATION_RULES", project_id: "26ec2d3b-9f62-4a8b-9613-b6ea214f0e1d"}
        Response: {"saved_map_permalink_id":"57129191-a070-4cbe-a8f4-00df5d4433b9"}
        """
        data = dict(origin="SEGMENTATION_RULES", project_id=project_id, **kwargs)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'workflow/generate-project-violations-map'),
                                method='POST', data=data)

    def list_project_violations_maps(self, related_project_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/saved-maps'),
                                params=dict(sort='-last_access_time', state='READY',
                                            related_project_id__is=related_project_id),
                                method='GET',
                                return_json=True)

    def create_project(self, project_name, project_template_id, api_version, rulesets, assigned_variables,
                       include_process_level, remove_allowed_flows, prefer_individual_items,
                       some_rules_failed_validation, map_start_time_filter=None, map_end_time_filter=None):

        data = dict(
            project_name=project_name,
            project_template_id=project_template_id,
            api_version=api_version,
            rulesets=rulesets,
            assigned_variables=assigned_variables,
            include_process_level=include_process_level,
            remove_allowed_flows=remove_allowed_flows,
            prefer_individual_items=prefer_individual_items,
            some_rules_failed_validation=some_rules_failed_validation,
        )

        if map_end_time_filter is not None and map_start_time_filter is not None:
            data['map_start_time_filter'] = map_start_time_filter
            data['map_end_time_filter'] = map_end_time_filter

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'workflow/project'), method='POST',
                                data=data)

    def get_projects(self, offset=0, limit=20, sort='-last_update_time'):
        params = dict(offset=offset, limit=limit, sort=sort)

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'workflow/projects'), method='GET',
                                params=params)

    def delete_project(self, project_id):
        url = 'workflow/project/{project_id}'.format(project_id=project_id)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, url), method='DELETE')

    def get_project(self, project_id):
        url = 'workflow/project/{project_id}'.format(project_id=project_id)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, url), method='GET')

    def scroll_daily_connections(self, index_day, fields=None, filters=None, **kwargs):
        data = dict(index_day=index_day,
                    fields=fields,
                    filters=filters,
                    **kwargs)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'daily_connections/scroll'),
                                method='POST',
                                data=data)

    def clear_daily_connections_scrolls(self, scroll_ids):
        data = dict(scroll_ids=scroll_ids)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'daily_connections/scroll'),
                                method='DELETE',
                                data=data)

    # ----------------------------- Agent SDK --------------------------------------------------------------------

    def get_agent_sdk_task_result(self, task_id, command_type):
        return self._json_query('agent_sdk/{}/{}'.format(command_type, task_id), method='GET')

    def run_agent_sdk_command(self, command):
        data = dict(command=command)
        return self._json_query('agent_sdk/command', method='POST', data=data)

    def run_agent_sdk_agent_command(self, command, agents, params=None, params_by_agent=None):
        data = dict(command=command,
                    agents=agents,
                    params=(params if params else {}),
                    params_by_agent=(params_by_agent if params_by_agent else {}))
        return self._json_query('agent_sdk/agent_command', method='POST', data=data)

    def run_agent_sdk_osquery(self, command, agents, query=None, params=None, params_by_agent=None):
        data = dict(command=command,
                    agents=agents,
                    query=query,
                    params=(params if params else {}),
                    params_by_agent=params_by_agent if params_by_agent else {})
        return self._json_query('agent_sdk/osquery', method='POST', data=data)

    # dashboard
    def get_dashboard_data(self, dashboard_id="security-dashboard", time_frame="DAY"):
        DASHBOARD_DATA_URL = urljoin(NEW_REST_API_BASE_URL, 'dashboards/dashboard/{}/data'.format(dashboard_id))
        return self._json_query(DASHBOARD_DATA_URL, method='GET', params=dict(time_frame=time_frame))

    # ----------------------------- Agent KO Upgrade ------------------------------------------------------------
    def get_latest_agent_ko_upgrade_job(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/ko-upgrade'), method='GET')

    # upgrade_only_missing_ko - will only be used when feature flag enabled
    def create_agent_ko_upgrade_job(self, component_ids, action='create', upgrade_only_missing_ko=False):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/ko-upgrade'), method='POST',
                                data=dict(action=action, component_ids=component_ids,
                                          upgrade_only_missing_ko=upgrade_only_missing_ko))

    def abort_agent_ko_upgrade_job(self, action='abort'):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/ko-upgrade'), method='POST',
                                data=dict(action=action))

    # ----- DNS Security -----
    # Automation API Endpoints
    DNS_SECURITY_ENDPOINT = 'dns_security'

    def list_dns_lists(self, **filt):
        return self._json_query(urljoin(AUTOMATION_API_BASE_URL, self.DNS_SECURITY_ENDPOINT),
                                params=filt,
                                return_json=True,
                                method='GET')['objects']

    def add_dns_list(self, list_config, header=None):
        return self._json_query(urljoin(AUTOMATION_API_BASE_URL, self.DNS_SECURITY_ENDPOINT),
                                method='POST',
                                return_json=True,
                                data=list_config,
                                user_headers=header)

    def add_dns_list_bulk(self, bulk_dns_lists):
        return self._json_query(urljoin(AUTOMATION_API_BASE_URL, '{endpoint}/bulk'.format(
            endpoint=self.DNS_SECURITY_ENDPOINT)),
                                method='POST',
                                return_json=True,
                                data=bulk_dns_lists)

    def modify_dns_list(self, list_id, update_dict):
        return self._json_query(urljoin(AUTOMATION_API_BASE_URL, '{endpoint}/{list_id}'.format(
            endpoint=self.DNS_SECURITY_ENDPOINT, list_id=list_id)),
                                method='PATCH',
                                data=update_dict,
                                return_json=True)

    def delete_dns_list(self, list_id):
        return self._json_query(urljoin(AUTOMATION_API_BASE_URL, '{endpoint}/{list_id}'.format(
            endpoint=self.DNS_SECURITY_ENDPOINT, list_id=list_id)),
                                return_json=True,
                                method='DELETE')

    def delete_dns_lists_bulk(self, ids, header=None):
        return self._json_query(urljoin(AUTOMATION_API_BASE_URL, '{endpoint}/bulk?ids={ids}').format(
            endpoint=self.DNS_SECURITY_ENDPOINT, ids=','.join(ids)),
            return_json=True,
            method='DELETE',
            user_headers=header)

    def export_labels_abort(self):
        """
        Abort the currently running export labels task
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'export-labels/abort'), method='PUT', return_json=True)

    def export_labels_check(self, key=None, value=None, origin=None, text_search=None):
        """
        Check if labels export is possible
        :param key: label key filters
        :param value: label value filters
        :param origin: label origin filters
        :param text_search: free text filter
        """
        params = dict()
        if key:
            params.update(key=key)
        if value:
            params.update(value=value)
        if origin:
            params.update(origin=origin)
        if text_search:
            params.update(text_search=text_search)

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'export-labels/check'), method='GET', return_json=True,
                                params=params)

    def export_labels(self, key=None, value=None, origin=None, text_search=None, unlabeled_assets=False):
        """
        Start an export labels task
        :param key: label key filters
        :param value: label value filters
        :param origin: label origin filters
        :param text_search: free text filter
        :param unlabeled_assets: whether to export the unlabeled assets sheet as well
        """
        params = dict()
        if key:
            params.update(key=key)
        if value:
            params.update(value=value)
        if origin:
            params.update(origin=origin)
        if text_search:
            params.update(text_search=text_search)
        if unlabeled_assets:
            params.update(unlabeled_assets=unlabeled_assets)

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'export-labels'), method='GET', return_json=True,
                                params=params)

    def export_labels_download(self):
        """
        Download the exported excel file
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'export-labels/download'),
                                method='GET', return_json=False, follow_redirects=True)

    def export_labels_status(self):
        """
        Check the status of the export task
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'export-labels/status'), method='GET', return_json=True)

    def import_labels(self, filename, file):
        """
        Imports labels from file
        """

        files = {
            'file': (filename, file),
            'filename': (None, filename),
        }

        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'import-job/labels'),
                                method='POST', files=files, return_json=False)

    def import_labels_check(self):
        """
        Checks import labels process
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'import-job/labels/check'),
                                method='GET', return_json=True)


    def import_labels_status(self):

        """
        Checks import labels status
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'import-job/labels/status'),
                                method='GET', return_json=True)

    def import_labels_download_error_report(self):

        """
        Downloads import labels error report
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'import-job/labels/download-error-report'),
                                method='GET', return_json=False, follow_redirects=True)

    def remove_ai_label(self, suggestion_id, dry_run=False):
        """
        Remove the association of the assets to the label of the suggestion
        :param suggestion_id: the id of the suggestion
        :param dry_run: True to check which suggestions will be unlabeled
        :return: the suggestion that was unlabeled and the suggestions that can be updated
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL,
                                        'visibility/ai-labels/{suggestion_id}/remove'.format(
                                            suggestion_id=suggestion_id, dry_run=dry_run)),
                                method='PUT', return_json=True)

    def get_k8s_cluster(self, **kwargs):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'k8s_clusters'),
                                method='GET',
                                return_json=True,
                                params=kwargs)

    def delete_k8s_cluster(self, cluster_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'k8s_clusters/' + cluster_id),
                                method='DELETE')

    def set_k8s_cluster_configuration(self, cluster_id, configuration):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'k8s_clusters/configuration/' + cluster_id),
                                method='POST',
                                data={'configuration': configuration},
                                return_json=False)

    # ----- Multi Cluster -----
    def sync_agents_configuration(self, agents_configuration):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'migrate-agent-config'), data=agents_configuration,
                                method='PUT')

    def trigger_agent_migration(self, target_centra, target_aggregator, agent_ids):
        migration_data = dict(target_centra=target_centra, target_aggregator=target_aggregator, agent_ids=agent_ids)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-migrate'), data=migration_data, method='POST')

    def get_agent_migration_job_status(self, job_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents-migrate'),
                                params={'job_id': job_id}, method='GET')

    def get_member_status(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'cluster/members/status'),
                                method='GET', return_json=True)

    def get_instance_configuration(self, group, option):
        params = dict(group=group, option=option)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'cluster/configuration-sync'),
                                params=params)

    def set_instance_configuration(self, group, option, value):
        data = dict(group=group, option=option, value=value)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'cluster/configuration-sync'),
                                method='POST', data=data)

    def run_dns_feed_task(self):
        """
        Run the feeder task immediately for dns security feeds
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/dns-security/feed'),
                                method='POST',
                                return_json=True,
                                params={})

    def get_dns_security_feed_status(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/dns-security/feed/status'),
                                method='GET',
                                return_json=True,
                                params={})

    def get_inventory_changes(self, cluster_member_id, revision, entity_types):

        params = dict(member_id=cluster_member_id, revision=revision, entity_types=entity_types)
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'cluster/data-sync'),
                                method='GET',
                                params=params)

    def trigger_manual_sync(self, params):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'cluster/data-sync'), data=params, method='POST')

    def get_members(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'cluster/members'),
                                method='GET', return_json=True)

    def get_cluster_status(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'cluster/status'),
                                method='GET', return_json=True)

    def get_off_corp_configuration(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system-configurations/off_corp'),
                                method='GET',
                                params={})

    def change_global_off_corporate_config(self, **kwargs):
        """
        options are:
            'enable_off_corporate_policy'
            'corporate_detection_method'
            'internal_domain'
            'resolution_addresses'
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system-configuration'),
                                method='PUT',
                                return_json=True,
                                params={'view': 'system'},
                                data={'endpoints': kwargs})

    def get_traffic_encryption_configuration(self):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system-status'),
                                method='GET',
                                params={}).get('feature_flags', {}).get('traffic_encryption', {})

    def change_global_traffic_encryption_config(self, **kwargs):
        """
        options are:
            'method': 'PSK' / 'PKI'
        """
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'system-configuration'),
                                method='PUT',
                                return_json=True,
                                params={'view': 'system'},
                                data={'traffic_encryption': kwargs})

    def get_dr_mapping_conf(self, username, password):
        user_headers = dict(Authorization='Basic {}'.format(base64.standard_b64encode(
            '{}:{}'.format(username, password).encode()).decode()))
        return self._json_query(urljoin("dr_config/", 'components_config.json'),
                                method='GET',
                                authenticate=False,
                                user_headers=user_headers)

    def dr_healthcheck(self):
        return self._json_query('dr-healthcheck',
                                method='GET',
                                authenticate=False)

    def reset_hit_counters(self, rules_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules-bulk/hit-count/reset'),
                                method='POST',
                                data=dict(ids=rules_id))

    def get_cloud_apps(self, raw_result=False):
        """
        Get all available cloudapps in Management
        """
        raw = self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'cloud_apps'), method='GET'
        )
        return raw if raw_result is True else raw['objects']

    def remove_cloudapps_bulk(self, cloudapp_ids):
        """
        Bulk remove cloudapps from Management
        """
        cloudapps_data = {
            'action': 'remove_components',
            'component_ids': cloudapp_ids
        }
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'cloud_apps'),
            method='POST', data=cloudapps_data
        )

    def assign_agents_to_worksite(self, agent_component_ids, worksite_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'agents/assign'),
                                method='POST',
                                data=dict(to='worksite',
                                          selected=worksite_id,
                                          component_ids=agent_component_ids))

    def assign_assets_to_worksite(self, asset_ids, worksite_id):
        return self._json_query(urljoin(NEW_REST_API_BASE_URL, 'assets/assign'),
                                method='POST',
                                data=dict(to='worksite',
                                          selected=worksite_id,
                                          asset_ids=asset_ids))

    def create_worksite(self, name, comment=None):
        return self._json_query(urljoin(REST_API_BASE_URL_V4, 'worksites'),
                                method='POST',
                                data=dict(name=name,
                                          comment=comment))

    def delete_worksites(self, worksite_ids):
        return self._json_query(urljoin(REST_API_BASE_URL_V4, 'worksites/delete_worksites'),
                                method='POST',
                                data=dict(component_ids=worksite_ids,
                                          negate_args=None))

    def get_worksites(self, raw_result=False, **filt):
        raw = self._json_query(urljoin(REST_API_BASE_URL_V4, 'worksites'),
                               method='GET',
                               params=filt)
        return raw if raw_result else raw['objects']

    def update_worksite(self, worksite_id, comment):
        return self._json_query(urljoin(REST_API_BASE_URL_V4, 'worksites'),
                                method='PUT',
                                data=dict(id=worksite_id, comment=comment))

    def bulk_assign_rules_to_worksite_v3(self, rule_ids, worksite_id, **filt):
        return self._json_query(
            urljoin(NEW_REST_API_BASE_URL, 'visibility/policy/rules-bulk/worksite/move/%s' % worksite_id),
            method='POST',
            data=dict(ids=rule_ids, negate_args={'filters': filt}))

    # ================================= Bloodhund ============================================

    @property
    def bloodhound_base_url(self):
        return urljoin(REST_API_BASE_URL_V4, 'bloodhound/')

    def bloodhound_get_configured_domains(self):
        return self._json_query(urljoin(self.bloodhound_base_url, 'configured_domains'),
                                method='GET')

    def bloodhound_get_scan_status(self):
        return self._json_query(urljoin(self.bloodhound_base_url, 'scan'),
                                method='GET')

    def bloodhound_run_scan(self, target, **kwargs):
        return self._json_query(urljoin(self.bloodhound_base_url, 'scan'),
                                method='POST', data=dict(kwargs, target=target))

    def bloodhound_stop_scan(self):
        return self._json_query(urljoin(self.bloodhound_base_url, 'scan'),
                                method='DELETE')

    def bloodhound_get_history(self, max_results=None):
        params = {}
        if max_results is not None:
            params['max_results'] = max_results
        return self._json_query(urljoin(self.bloodhound_base_url, 'history'),
                                method='GET', params=params)

    def bloodhound_get_gcp_configuration(self):
        return self._json_query(urljoin(self.bloodhound_base_url, 'gcp_configuration'),
                                method='GET')

    def bloodhound_set_gcp_configuration(self, bucket_name, service_account_dict):
        return self._json_query(urljoin(self.bloodhound_base_url, 'gcp_configuration'),
                                method='PUT', data=dict(service_account_dict, bucket_name=bucket_name))
