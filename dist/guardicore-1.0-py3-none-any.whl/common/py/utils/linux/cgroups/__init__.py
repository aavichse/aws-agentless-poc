#! /usr/bin/env python
# -*- coding:utf-8 -*-

BASE_CGROUPS = '/sys/fs/cgroup'


class CgroupsException(Exception):
    pass
