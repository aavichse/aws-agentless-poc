import copy
from enum import Enum

from common.py.utils.config import cfg
from common.py.utils.config.cfg import StrChoicesOpt
from common.py.utils.config.copyable_config_opt import CopyableConfig
from common.py.utils.config.oslo_config.cfg import MultiOpt
from common.py.utils.config.oslo_config.types import String, Boolean, Integer, Float, IPAddress, IPNetwork, List, \
    MultiString
from common.py.utils.config.types import Port, Severity, ChoicesString, Structure

__author__ = 'Amit'

# converts oslo option type to jsonschema property type
BASIC_OPT_TYPE_TO_JSONSCHEMA_TYPE = {String: 'string',
                                     Boolean: 'boolean',
                                     Integer: 'integer',
                                     Port: 'integer',
                                     Float: 'number',
                                     Severity: 'string',
                                     IPAddress: 'string',
                                     IPNetwork: 'string',
                                     ChoicesString: 'string',
                                     }

RE_IPv4_ADDRESS = '(1?\\d\\d?|2[0-4]\\d|25[0-5])\\.(1?\\d\\d?|2[0-4]\\d|25[0-5])\\.(1?\\d\\d?|2[0-4]\\d|25[0-5])\\.(1?\\d\\d?|2[0-4]\\d|25[0-5])'
RE_IPv4_SUBNET = r'(\/([0-9]|[1-2][0-9]|3[0-2])){0,1}'
RE_IPv6_ADDRESS = '((?:[0-9A-Fa-f]{1,4}))((?::[0-9A-Fa-f]{1,4}))*::((?:[0-9A-Fa-f]{1,4}))((?::[0-9A-Fa-f]{1,4}))*|((?:[0-9A-Fa-f]{1,4}))((?::[0-9A-Fa-f]{1,4})){7}'
RE_IPv6_SUBNET = r'(\/(1[0-2][0-8]|\\d?\\d)){0,1}'

BASIC_OPT_TYPE_TO_JSONSCHEMA_PATTERN = {
    IPAddress: '(^%s$)|(^%s$)' % (RE_IPv4_ADDRESS, RE_IPv6_ADDRESS),
    IPNetwork: '(^%s%s$)|(^%s%s$)' % (RE_IPv4_ADDRESS, RE_IPv4_SUBNET, RE_IPv6_ADDRESS, RE_IPv6_SUBNET)
}

COMPLEX_OPT_TYPE_TO_JSONSCHEMA_TYPE = {List: 'array',
                                       MultiOpt: 'array',
                                       MultiString: 'array'}


# TODO: support MultiString, Dict


class StructType(dict):
    """ Used as a cover for structure types inplace of dict which might be interpreted as a group of opts """

    def __repr__(self):
        return "%s%s" % (self.__class__.__name__, super(StructType, self).__repr__())


def get_jsonschema_opt_type(opt):
    """
    Convert oslo opt type to jsonschema opt type.
    :param opt: oslo opt
    :return: dict describing the jsonschema object type of the option
    """
    def recursive_convert_oslo_opt_type(oslo_opt_type):
        """
        Recursively convert oslo configuration type to jsonschema object type definition.
        Complex types such as Lists are recursively converted.
        """
        oslo_opt_meta_type = type(oslo_opt_type)
        if oslo_opt_meta_type in BASIC_OPT_TYPE_TO_JSONSCHEMA_TYPE:
            opt_properties_dict = dict(type=BASIC_OPT_TYPE_TO_JSONSCHEMA_TYPE[oslo_opt_meta_type])

            if oslo_opt_meta_type in BASIC_OPT_TYPE_TO_JSONSCHEMA_PATTERN:
                opt_properties_dict['pattern'] = BASIC_OPT_TYPE_TO_JSONSCHEMA_PATTERN[oslo_opt_meta_type]
            if issubclass(oslo_opt_meta_type, ChoicesString):
                if oslo_opt_type.choices_dict is not None:
                    opt_properties_dict['enum'] = list(oslo_opt_type.choices_dict.values())
            if issubclass(oslo_opt_meta_type, String):
                if oslo_opt_type.choices is not None:
                    opt_properties_dict['enum'] = oslo_opt_type.choices
            if issubclass(oslo_opt_meta_type, Integer):
                if oslo_opt_type.min is not None:
                    opt_properties_dict['minimum'] = oslo_opt_type.min
                if oslo_opt_type.max is not None:
                    opt_properties_dict['maximum'] = oslo_opt_type.max

            return opt_properties_dict

        elif oslo_opt_meta_type in COMPLEX_OPT_TYPE_TO_JSONSCHEMA_TYPE:
            opt_properties_dict = dict(type=COMPLEX_OPT_TYPE_TO_JSONSCHEMA_TYPE[oslo_opt_meta_type])

            if oslo_opt_meta_type is List:
                opt_properties_dict['items'] = recursive_convert_oslo_opt_type(oslo_opt_type.item_type)

            return opt_properties_dict

        elif oslo_opt_meta_type is Structure:
            properties_dict = build_group_properties_dict(oslo_opt_type.conf, oslo_opt_type.conf)
            return _to_jsonschema_object(properties_dict)

        else:
            return None

    return recursive_convert_oslo_opt_type(opt.type)


def get_jsonschema_opt_value(oslo_opt_value):
    def recursive_convert_oslo_opt_value(opt_value):
        if isinstance(opt_value, list):
            return [recursive_convert_oslo_opt_value(value) for value in opt_value]

        elif isinstance(opt_value, (dict, CopyableConfig)):
            return {key: recursive_convert_oslo_opt_value(value) for key, value in opt_value.items()}

        elif isinstance(opt_value, Enum):
            return opt_value.name

        return opt_value

    return recursive_convert_oslo_opt_value(oslo_opt_value)


def opt_to_jsonschema_property(opt, opt_value, conversion_hooks, opt_name, override_defaults=True):
    """
    Convert an oslo opt to a jsonschema property.
    :param opt: opt object
    :param opt_value: opt value
    :param conversion_hooks: see oslo_to_jsonschema_object
    :param opt_name: full option name
    :return: opt properties dict
    """
    opt_properties_dict = get_jsonschema_opt_type(opt)
    if opt_properties_dict is None:
        return None

    if not opt.secret:
        if isinstance(opt_value, Enum):
            opt_value = opt_value.name
        elif isinstance(opt, StrChoicesOpt):
            # Get the value's key (the key should be presented in the UI, while the value is an actual enum's name)
            for k, v in opt.type.choices_dict.items():
                if v == opt_value:
                    opt_value = k
                    break
        if override_defaults:
            opt_properties_dict['default'] = get_jsonschema_opt_value(opt_value)  # use current value as default
        else:
            opt_properties_dict['default'] = opt.default
    else:
        opt_properties_dict['secret'] = True
        if opt_value is not None and len(opt_value):
            opt_properties_dict['has_value'] = True

    if not opt.required:
        opt_properties_dict['type'] = [opt_properties_dict['type'], 'null']

    opt_properties_dict['title'] = opt.name.replace('_', ' ')
    opt_properties_dict['description'] = opt.help if opt.help is not None else ''
    opt_properties_dict['conf_key'] = opt_name
    opt_properties_dict['hidden'] = getattr(opt, 'hidden', False)
    opt_properties_dict['restart'] = getattr(opt, 'restart', False)
    opt_properties_dict['rebuild'] = getattr(opt, 'rebuild', False)
    opt_properties_dict['multi_line_text'] = getattr(opt, 'multi_line_text', False)
    opt_properties_dict['custom_warning'] = getattr(opt, 'custom_warning', '')

    if conversion_hooks is not None:
        for hook in conversion_hooks:
            hook(opt, opt_properties_dict)

    return opt_properties_dict


def build_group_properties_dict(group, group_attr, filter_opts=None,
                                conversion_hooks=None, group_name=None, override_defaults=True):
    """
    build a jsonschema properties dict for a OptGroup object
    :param group: OptGroup object to convert
    :param group_attr: GroupAttr object wrapping the given group and conf
    :param filter_opts: if not None, only group options in filter_opt are added
    :param conversion_hooks: see oslo_to_jsonschema_object
    :param group_name: optional group name
    :return: jsonschema properties dict
    """
    group_properties_dict = {}

    for opt_key, opt_value in group._opts.items():
        opt = opt_value['opt']

        if filter_opts is not None and opt_key not in filter_opts:
            continue

        opt_properties_dict = opt_to_jsonschema_property(opt, group_attr[opt_key], conversion_hooks,
                                                         opt_name=('.'.join((group_name, opt_key))
                                                                   if group_name is not None else opt_key),
                                                         override_defaults=override_defaults)
        if opt_properties_dict is not None:
            group_properties_dict[opt_key] = opt_properties_dict

    return group_properties_dict


def oslo_to_jsonschema_object(conf, filter_opts=None, conversion_hooks=None, title=None, conf_name=None,
                              override_defaults=True, groups_additional_data=None):
    """
    Convert an oslo configuration object to jsonschema object properties dict.
    :param override_defaults:
    :param conf: oslo configuration
    :param filter_opts: if not None, only group options in filter_opt are added
    :param conversion_hooks: optional list of hook functions which are applied on the converted oslo
     config items just before storing them as jsonschema object properties. Each function operates on a
     (oslo_opt_obj, jsonschema_properties_dict) pair, and can change the jsonschema_properties_dict by adding
      properties to it.
    :param conf_name: optional sub-configuration name
    :param groups_additional_data: add additional data to groups {mode: warn, disable}
    :return: jsonschema object definition
    """
    properties_dict = {}

    for group_key, group in conf._groups.items():
        if filter_opts is not None and group_key not in filter_opts:
            continue

        group_properties_dict = build_group_properties_dict(group, conf[group_key],
                                                            filter_opts=(filter_opts[group_key]
                                                                         if filter_opts is not None else None),
                                                            conversion_hooks=conversion_hooks,
                                                            group_name=('.'.join((conf_name, group_key))
                                                                        if conf_name is not None else group_key),
                                                            override_defaults=override_defaults)

        if group_properties_dict:
            properties_dict[group_key] = _to_jsonschema_object(group_properties_dict,
                                                               title=group_key.replace('_', ' '),
                                                               group_additional_data=(groups_additional_data[group_key]
                                                                                      if groups_additional_data is not None and
                                                                                         group_key in groups_additional_data
                                                                                      else None))

    for opt_key, opt_value in conf._opts.items():
        opt = opt_value['opt']

        if filter_opts is not None and ('' not in filter_opts or opt_key not in filter_opts['']):
            continue

        opt_properties_dict = opt_to_jsonschema_property(opt, conf[opt_key], conversion_hooks,
                                                         opt_name=('.'.join((conf_name, opt_key))
                                                                   if conf_name is not None else opt_key),
                                                         override_defaults=override_defaults)
        if opt_properties_dict is not None:
            properties_dict[opt_key] = opt_properties_dict

    return _to_jsonschema_object(properties_dict, title=title)


def oslo_to_jsonvalues_object(conf):
    jsonvalues = {}
    for group_key, group in conf._groups.items():
        jsonvalues[group_key] = {}
        group_properties_dict = build_group_properties_dict(group, conf[group_key])
        for property, value in group_properties_dict.items():
            jsonvalues[group_key][property] = value['default']

    return jsonvalues


def oslo_group_to_jsonvalues_object(conf, group_key):
    """
    Convert oslo group to a dict with the jsonvalues
    :param conf: oslo configuration
    :param group_key: group's name
    """
    group = conf._groups[group_key]
    group_properties_dict = build_group_properties_dict(group, conf[group_key])
    jsonvalues = _rec_oslo_properties_to_jsonvalues_object(group_properties_dict)

    return jsonvalues


def _rec_oslo_properties_to_jsonvalues_object(properties):
    """
    recursively go over the properties and fetch the structure and default values
    :param properties: jsonschema properties dict to iterate over
    """
    jsonvalues = {}

    for property, value in properties.items():
        if value.get('properties'):
            jsonvalues[property] = _rec_oslo_properties_to_jsonvalues_object(value['properties'])
        else:
            jsonvalues[property] = value['default']

    return jsonvalues


def oslo_hierarchy_to_jsonschema_object(conf_hierarchy, filter_opts=None, conversion_hooks=None,
                                        override_defaults=True):
    """
    Convert a hierarchy of oslo configuration objects to jsonschema object properties dict.
    :param override_defaults:
    :param conf_hierarchy: oslo configuration hierarchy, as a dict mapping configuration key to
     oslo configuration object (one-level hierarchy only)
    :param filter_opts: if not None, only group options in filter_opt are added
    :param conversion_hooks: see oslo_to_jsonschema_object
    :return: jsonschema object definition
    """
    properties_dict = {conf_key: oslo_to_jsonschema_object(conf,
                                                           filter_opts=(filter_opts[conf_key]
                                                                        if filter_opts is not None else None),
                                                           conversion_hooks=conversion_hooks,
                                                           title=conf_key.replace('_', ' '),
                                                           conf_name=conf_key,
                                                           override_defaults=override_defaults)
                       for conf_key, conf in conf_hierarchy.items()
                       if filter_opts is None or conf_key in filter_opts}
    return _to_jsonschema_object(properties_dict)


def _to_jsonschema_object(properties_dict, title=None, group_additional_data=None):
    """
    Create a jsonschema object definition with the given properties dict.
    :param properties_dict: defines the object property set
    :param group_additional_data: see oslo_to_jsonschema_object
    :return: jsonschema object definition
    """
    jsonschema_obj = dict(type='object',
                          properties=properties_dict,
                          additionalProperties=False)
    if title is not None:
        jsonschema_obj['title'] = title

    if group_additional_data is not None:
        for key, value in group_additional_data.items():
            jsonschema_obj[key] = value

    return jsonschema_obj


def get_empty_jsonschema_object():
    """
    Generate an empty jsonschema object.
    :return: jsonschema object definition
    """
    return _to_jsonschema_object({})


def get_jsonschema_config(jsonschema_object, title=None, display_name=None):
    """
    Generate a complete jsonschema configuration for the configuration object
    :param jsonschema_object: defines the configuration object
    :param title: schema title
    :param display_name: schema display name
    :return: jsonschema object definition for the configuration
    """
    schema = copy.deepcopy(jsonschema_object)
    schema['$schema'] = 'http://json-schema.org/draft-04/schema#'
    if title is not None:
        schema['title'] = title
    if display_name is not None:
        schema['display_name'] = display_name
    return schema


def get_jsonschema_obj_defaults(jsonschema_obj):
    """
    Given a jsonschema object definition, extract and return a dict of default properties (name -> default value)
    :param jsonschema_obj: jsonschema object definition
    :return: properties dict
    """

    def jsonschema_obj_to_dict(jsonschema_obj):
        result = {}
        for key, val in jsonschema_obj['properties'].items():
            if val['type'] == 'object':
                result[key] = jsonschema_obj_to_dict(val)
            else:
                result[key] = val.get('default')

        return result

    return jsonschema_obj_to_dict(jsonschema_obj)


def get_property_dict(jsonschema_obj, property_key):
    """
    Get the property dict of the property given by property_key out of the jsonschema object.
    :param jsonschema_obj: jsonschema object
    :param property_key: property key hierarchy, separated by dots.
    :return: property dict, or None if property was not fount
    """
    for k in property_key.split('.'):
        jsonschema_obj = jsonschema_obj.get('properties', {}).get(k)
        if jsonschema_obj is None:
            return None

    return jsonschema_obj


def prepare_full_schema(source_jsonshcema):
    """
    Set sequential ordering and title on properties
    :param source_jsonshcema: jsonschema to apply the sequential ordering on
    """

    def rec_prepare_full_schema(current_node):
        """
        Recursively set sequential ordering and title on properties
        :param current_node: current node in the recursion stack
        """
        properties = current_node.get('properties', {})
        keys = properties.keys()

        for index, value in enumerate(sorted(keys)):
            properties[value]['order'] = index
            properties[value]['title'] = value.replace('_', ' ').capitalize()

            if properties[value].get('type') == 'object' and 'properties' in properties[value]:
                rec_prepare_full_schema(properties[value])

    rec_prepare_full_schema(source_jsonshcema)

    return source_jsonshcema


def transform_jsonschema(source_jsonshcema, transform):
    """
    Transform one jsonschema object to another.
    :param source_jsonshcema: transformed jsonschema
    :param transform: transformation specifications
    :return: new jsonschema object
    """

    def rec_transform_jsonschema(transform):
        """
        Recursively use transform to create a new jsonschema.
        :param transform: transformer
        :return: resulting (sub-)jsonschema.
        """
        if 'source_key' in transform:
            source_property = get_property_dict(source_jsonshcema, transform['source_key'])
            if source_property is None:
                return None

            result = copy.deepcopy(source_property) if source_property is not None else {}
            result['conf_key'] = transform['source_key']

        else:
            properties_dict = {}
            for i, item in enumerate(transform.get('items', [])):
                if 'depends_on' in item:
                    depends_on_dict = get_property_dict(source_jsonshcema, item['depends_on'])
                    if depends_on_dict is not None and not depends_on_dict.get('default', True):
                        continue
                if 'hide_by_global_config' in item:
                    group, option = item['hide_by_global_config'].split('.')
                    if _should_hide(group, option):
                        continue

                item_properties_dict = rec_transform_jsonschema(item)
                if item_properties_dict is not None:
                    item_properties_dict['order'] = i
                    properties_dict[item['key']] = item_properties_dict
                if 'key' in transform:  # Single-level configurations use the root namespace instead of groups
                    group_properties_dict = get_property_dict(source_jsonshcema, transform['key'])
                    if group_properties_dict is not None and 'mode' in group_properties_dict:
                        transform['mode'] = group_properties_dict['mode']

            result = _to_jsonschema_object(properties_dict)

        if 'title' in transform:
            result['title'] = transform['title']
        if 'description' in transform:
            result['description'] = transform['description']
        if 'readonly' in transform:
            result['readonly'] = transform['readonly']
        if 'hidden' in transform:
            result['hidden'] = transform['hidden']
        if 'mode' in transform:
            result['mode'] = transform['mode']

        return result

    return rec_transform_jsonschema(transform)


def _should_hide(group, option):
    """
    hide the configuration if the cfg option is false or non-existent
    """
    try:
        if not cfg.CONF[group][option]:
            return True
    except KeyError:
        return True
    return False


def transform_jsonschema_list(source_jsonshcema, transform):
    """
    Transform one jsonschema object to another.
    :param source_jsonshcema: transformed jsonschema
    :param transform: transformation specifications
    :return: new jsonschema object
    """
    joined_schema = {item['key']: transform_jsonschema(source_jsonshcema, item) for item in transform.get('items', [])}
    return dict(type='object', properties=joined_schema)


def transform_configuration_to_schema(transformed_jsonschema, conf):
    """
    Given an original configuration dict and transformation instructions in transformed_jsonschema,
    returned a transformed configuration.
    :param transformed_jsonschema: transformation instructions, given as a transformed jsonschema
    :param conf: original config
    :return: transformed config
    """
    transformed_conf = {}

    def recursive_transform_configuration_to_schema(transformed_subschema,
                                                    transformed_subconf):
        for property_name, property_dict in transformed_subschema['properties'].items():
            if 'conf_key' in property_dict:
                conf_key_hierarchy = property_dict['conf_key'].split('.')
                conf_value = conf
                for subkey in conf_key_hierarchy[:-1]:
                    conf_value = conf_value.get(subkey, {})

                if conf_key_hierarchy[-1] in conf_value:
                    transformed_subconf[property_name] = conf_value[conf_key_hierarchy[-1]]
            else:
                transformed_subconf[property_name] = {}
                recursive_transform_configuration_to_schema(property_dict,
                                                            transformed_subconf[property_name])

    recursive_transform_configuration_to_schema(transformed_jsonschema, transformed_conf)
    return transformed_conf


def revert_transformed_configuration(transformed_jsonschema, transformed_conf):
    """
    Given a transformed configuration which matches a transformed jsonschema, revert it back
    to the original schema structure.
    :param transformed_jsonschema: transformed jsonschema
    :param transformed_conf: transformed configuration
    :return: reverted configuration

    Note:
        Let j1 a jsonschema, c1 a config such that validate(c1, j1), F is a jsonschema transformer for j1.
        Let j2 = transform_jsonschema(j1, F), and c2 a config such that validate(c2, f2)
        Then:
         1. validate(transform_configuration_to_schema(j2, c1), j2) should pass
         2. validate(revert_transformed_configuration(j2, c2), j1) should also pass
    """
    reverted_conf = {}

    def recursive_revert_transformed_configuration(transformed_subschema,
                                                   transformed_subconf):
        for k, v in transformed_subconf.items():
            obj_property = transformed_subschema['properties'][k]
            if 'conf_key' in obj_property:
                conf_key_hierarchy = obj_property['conf_key'].split('.')
                target_slot = reverted_conf
                for subkey in conf_key_hierarchy[:-1]:
                    target_slot = target_slot.setdefault(subkey, {})

                if 'object' in obj_property['type']:  # This is a Structure
                    v = StructType(v)

                target_slot[conf_key_hierarchy[-1]] = v
            else:
                assert obj_property['type'] == 'object'
                assert isinstance(v, dict)
                recursive_revert_transformed_configuration(obj_property, v)

    recursive_revert_transformed_configuration(transformed_jsonschema, transformed_conf)
    return reverted_conf


def intersect_jsonschema_config(jsonschema_obj, conf):
    intersected_conf = {}

    def recursive_intersect_jsonschema_config(subschema,
                                              subconf):
        if not subschema:
            return

        assert subschema['type'] == 'object'

        for k, obj_property in subschema['properties'].items():
            if k not in subconf:
                continue
            if 'conf_key' in obj_property:
                conf_key_hierarchy = obj_property['conf_key'].split('.')
                target_slot = intersected_conf
                for subkey in conf_key_hierarchy[:-1]:
                    target_slot = target_slot.setdefault(subkey, {})

                target_slot[conf_key_hierarchy[-1]] = subconf[conf_key_hierarchy[-1]]
            else:
                assert obj_property['type'] == 'object'
                assert isinstance(obj_property, dict)
                recursive_intersect_jsonschema_config(obj_property, subconf[k])

    recursive_intersect_jsonschema_config(jsonschema_obj, conf)
    return intersected_conf


def all_same(items, exclude_keys=None):
    if exclude_keys is None:
        exclude_keys = []

    def compare_items(x, y):
        if isinstance(x, dict) and isinstance(y, dict):
            for key in x:
                if key in exclude_keys:
                    continue
                if key not in y or x[key] != y[key]:
                    return False
            return True
        return x == y
    return all(compare_items(x, items[0]) for x in items)


def intersect_jsonschemas(*schemas):
    def recursive_intersect_obj_properties(objects):
        if not objects:
            return get_empty_jsonschema_object()

        assert all([obj['type'] == 'object' for obj in objects])

        intersection_properties = {}
        common_property_names = set.intersection(*[set(obj['properties'].keys()) for obj in objects])
        for property_name in common_property_names:
            property_objs = [obj['properties'][property_name] for obj in objects]
            property_obj_types = [property_obj['type'] for property_obj in property_objs]
            if not all_same(property_obj_types):
                continue

            property_obj_type = property_obj_types[0]
            if property_obj_type == 'object':
                intersection_properties[property_name] = recursive_intersect_obj_properties(property_objs)
            else:
                if all_same(property_objs):
                    intersection_properties[property_name] = property_objs[0]

        joint_object = _to_jsonschema_object(intersection_properties)
        # add title, description, etc, if they are identical across all objects
        joint_object.update({k: v for k, v in objects[0].items()
                             if k not in joint_object and set(o[k] for o in objects) == {v}})
        return joint_object

    return recursive_intersect_obj_properties(schemas)


def union_jsonschemas(*schemas):
    def recursive_union_obj_properties(objects):
        if not objects:
            return get_empty_jsonschema_object()

        assert all([obj['type'] == 'object' for obj in objects])

        union_properties = {}
        joint_property_names = set.union(*[set(obj['properties'].keys()) for obj in objects])
        for property_name in joint_property_names:
            property_objs = [obj['properties'][property_name] for obj in objects if property_name in obj['properties']]
            property_obj_types = [property_obj['type'] for property_obj in property_objs if 'type' in property_obj]
            if not all_same(property_obj_types) or not property_obj_types:
                continue

            property_obj_type = property_obj_types[0]
            if property_obj_type == 'object':
                union_properties[property_name] = recursive_union_obj_properties(property_objs)
            else:
                if all_same(property_objs, exclude_keys=['default']):
                    union_properties[property_name] = property_objs[0]

        joint_object = _to_jsonschema_object(union_properties)
        # add title, description, etc, if they are identical across all objects
        joint_object.update({k: v for k, v in objects[0].items()
                             if k not in joint_object and set(o[k] for o in objects) == {v}})
        return joint_object

    return recursive_union_obj_properties(schemas)


def update_jsonschema_config_conf_keys(jsonschema_obj):
    def recursive_jsonschema_config_conf_key_update(jsonschema_obj, conf_key_path=None):
        if 'properties' not in jsonschema_obj:
            return
        for property_name, property_dict in jsonschema_obj['properties'].items():
            if 'conf_key' in property_dict:
                update_conf_key = conf_key_path if conf_key_path is None else '.'.join((conf_key_path, property_name))
                property_dict['conf_key'] = update_conf_key
            else:
                new_conf_key_path = property_name if conf_key_path is None else '.'.join((conf_key_path, property_name))
                recursive_jsonschema_config_conf_key_update(property_dict, new_conf_key_path)

    recursive_jsonschema_config_conf_key_update(jsonschema_obj)
