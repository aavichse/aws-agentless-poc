

class BPFFilter(object):
    def get_filter(self):
        """
        Build the bpf filter that fits the following expression.
        :return: The bpf filter
        :rtype: str.
        """
        raise NotImplementedError()

    def __and__(self, other):
        return BpfFilterBinaryOperation(filter1=self,
                                        filter2=other,
                                        operand="and")

    def __rand__(self, other):
        return self.__and__(other)

    def __or__(self, other):
        return BpfFilterBinaryOperation(filter1=self,
                                        filter2=other,
                                        operand="or")

    def __ror__(self, other):
        return self.__or__(other)

    def __invert__(self):
        return BpfFilterNot(self)

    def __str__(self):
        return "%s" % self.get_filter()

    def __repr__(self):
        return "<bpf filter - %s >" % self


class BPF(BPFFilter):
    def __init__(self, bpf_string):
        super(BPF)
        self.bpf_string = bpf_string

    def __add__(self, other):
        return BpfFilterBinaryOperation(filter1=self, filter2=other, operand='+')

    def __radd__(self, other):
        return BpfFilterBinaryOperation(filter1=other, filter2=self, operand='+')

    def __eq__(self, other):
        return BpfFilterBinaryOperation(filter1=self, filter2=other, operand="=")

    def __mul__(self, other):
        return BpfFilterBinaryOperation(filter1=self, filter2=other, operand="*")

    def __rmul__(self, other):
        return BpfFilterBinaryOperation(filter1=other, filter2=self, operand="*")

    def get_filter(self):
        return self.bpf_string


class BpfFilterBinaryOperation(BPF):
    def __init__(self, filter1, filter2, operand):
        self.filter1 = filter1
        self.filter2 = filter2
        self.operand = operand

    def get_filter(self):
        return "(%s) %s (%s)" % (self.filter1, self.operand, self.filter2)


class BpfFilterNot(BPFFilter):
    def __init__(self, filter_):
        self.filter_ = filter_

    def get_filter(self):
        return "not (%s)" % self.filter_


class EmptyBpf(object):
    def get_filter(self):
        return ''

    def __and__(self, other):
        return other

    def __or__(self, other):
        return other

    def __invert__(self):
        raise NotImplementedError("Can't invert empty expression")

    def __nonzero__(self):
        return False


class StaticBpfFilter(BPFFilter):
    EXPRESSION = None

    def get_filter(self):
        return self.EXPRESSION


class Tcp(StaticBpfFilter):
    EXPRESSION = 'tcp'


class Udp(StaticBpfFilter):
    EXPRESSION = 'udp'


class Arp(StaticBpfFilter):
    EXPRESSION = 'arp'


class Ip(StaticBpfFilter):
    EXPRESSION = 'ip'


class TCPFlag(BPFFilter):
    FLAG = None

    def get_filter(self):
        return Tcp() & ("tcp[tcpflags] & %s != 0" % self.FLAG)


class Syn(TCPFlag):
    FLAG = "tcp-syn"


class Fin(TCPFlag):
    FLAG = "tcp-fin"


class Rst(TCPFlag):
    FLAG = "tcp-rst"


class Ack(TCPFlag):
    FLAG = "tcp-ack"


DNS_PORT = 53


class DnsRequest(BPFFilter):

    def get_filter(self):
        return Udp() & DstPort(DNS_PORT)


class DnsResponse(BPFFilter):
    def get_filter(self):
        return Udp() & SrcPort(DNS_PORT)


class Host(BPFFilter):
    def __init__(self, host):
        self.host = host

    def get_filter(self):
        return "host %s" % self.host


class SrcHost(Host):
    def get_filter(self):
        return "src host %s" % self.host


class DstHost(Host):
    def get_filter(self):
        return "dst host %s" % self.host


class Mac(BPFFilter):
    def __init__(self, mac_address):
        self.mac_address = mac_address

    def get_filter(self):
        return "ether host %s" % self.mac_address


class SrcMac(Mac):
    def get_filter(self):
        return "ether src host %s" % self.mac_address


class DstMac(Mac):
    def get_filter(self):
        return "ether dst host %s" % self.mac_address


class Port(BPFFilter):
    def __init__(self, port):
        self.port = port

    def get_filter(self):
        return "port %s" % self.port


class SrcPort(Port):
    def get_filter(self):
        return "src port %s" % self.port


class DstPort(Port):
    def get_filter(self):
        return "dst port %s" % self.port


class FilterList(BPFFilter):
    SingleFilter = None

    def __init__(self, args):
        self.args = args

    def get_filter(self):
        return " or ".join("(%s)" % self.SingleFilter(arg)
                           for arg in self.args)


class PortsList(FilterList):
    SingleFilter = Port


class SrcPortsList(FilterList):
    SingleFilter = SrcPort


class DstPortList(FilterList):
    SingleFilter = DstPort


class Ether(BPFFilter):
    """
    Compare value from the packet against given value.
    There are two equivalent ways to use this class,
    directly be instantiate it with all the parameters - or
    by perform the requested comparison of the instantiated object.
    """
    _ALLOWED_SIZES = (1, 2, 4)
    _ALLOWED_COMPARISON_TYPE = ("=", "!=", "<", ">", "<=", ">=")

    def __init__(self, offset, size, comparable=None, comparison_type="="):
        """
        :param offset: The starting offset in the packet.
        :param size: The size of the value to compare in bytes.
        :param comparable: The value to compare the bytes to.
        :param comparison_type: The type of comparison to perform.
        :return:
        """
        if size not in self._ALLOWED_SIZES:
            raise ValueError("unsupported size. (allowed sizes are %s)")
        if comparison_type not in self._ALLOWED_COMPARISON_TYPE:
            raise ValueError("Illegal comparison %s" % comparison_type)
        self.offset = offset
        self.size = size
        self.comparable = comparable
        self.comparison_type = comparison_type

    def get_filter(self):
        if self.comparable is None:
            raise RuntimeError("Missing comparable.")
        return "ether[{offset}:{size}] {comparison_type} {comparable}".format(
            offset=self.offset,
            size=self.size,
            comparable=self.comparable,
            comparison_type=self.comparison_type,
        )

    def _fill_ether_values(self, comparable, comparison_type):
        if self.comparable is not None:
            raise RuntimeError("Comparable already set.")

        self.comparable = comparable
        self.comparison_type = comparison_type
        return self

    def __eq__(self, other):
        return self._fill_ether_values(other, "=")

    def __ne__(self, other):
        return self._fill_ether_values(other, "!=")

    def __le__(self, other):
        return self._fill_ether_values(other, "<=")

    def __ge__(self, other):
        return self._fill_ether_values(other, ">=")

    def __lt__(self, other):
        return self._fill_ether_values(other, "<")

    def __gt__(self, other):
        return self._fill_ether_values(other, ">")


def ip_session(src_ip, dst_ip, directed=False, ip_only=True):
    """
    Filer entire ip session.
    :param src_ip: The source Ip.
    :param dst_ip: The destination Ip.
    :param directed: False to Filter packet in both direction, True to filter only
        from the source to the destination.
    :param ip_only: Filter only ip packets (Don't include arps, for instance).
    :return: BpfFilter
    """
    result = EmptyBpf()

    if ip_only:
        result &= Ip()

    if directed:
        return result & (SrcHost(src_ip) & DstHost(dst_ip))
    else:
        return result & (Host(src_ip) & Host(dst_ip))


def port_session(src_port, dst_port, directed=False):
    if directed:
        return SrcPort(src_port) & DstPort(dst_port)
    else:
        return Port(src_port) & Port(dst_port)


def tcp_session(src_ip, dst_ip, src_port, dst_port, directed=False):
    """
    Filter tcp session.
    :param src_ip: Src host.
    :param dst_ip: Dest host.
    :param src_port: Src port.
    :param dst_port: Dst port.
    :param directed: True to catch only catch the directed side of the session.
    """
    return (Tcp() &
            (ip_session(src_ip=src_ip, dst_ip=dst_ip, directed=directed, ip_only=False) &
             port_session(src_port=src_port, dst_port=dst_port, directed=directed)))


def udp_session(src_ip, dst_ip, src_port, dst_port, directed=False):
    """
    Filter udp session.
    :param src_ip: Src host.
    :param dst_ip: Dest host.
    :param src_port: Src port.
    :param dst_port: Dst port.
    :param directed: True to catch only the directed side of the session.
    """
    return (Udp() &
            (ip_session(src_ip=src_ip, dst_ip=dst_ip, directed=directed, ip_only=False) &
             port_session(src_port=src_port, dst_port=dst_port, directed=directed)))


def ethernet_session(src_mac, dst_mac, directed=False):
    """
    Filer entire ethernet session.
    :param src_mac: The source mac address.
    :param dst_mac: The destination mac address.
    :param directed: Filter packet in both direction, or only from the source to
        the destination.
    :return: BpfFilter
    """
    if directed:
        return SrcMac(src_mac) & DstMac(dst_mac)
    else:
        return Mac(src_mac) & Mac(dst_mac)
