import os
import subprocess
from common.logger import get_logger

LOG = get_logger(module_name=__name__)
IPTABLES_SAVE_FILE = "/etc/iptables/rules.v4"


class IPTables(object):
    IPTABLES_BIN = "/sbin/iptables"
    EXCEPTION_ON_FAILURE = False
    Popen = subprocess.Popen
    
    @staticmethod
    def run_iptables(command):
        iptables_cmd = [IPTables.IPTABLES_BIN] + command.split()
        iptables_process = IPTables.Popen(iptables_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        stdout, unused_stderr = iptables_process.communicate()
        
        exit_code = iptables_process.wait()
        if 0 != exit_code:
            if IPTables.EXCEPTION_ON_FAILURE:
                raise subprocess.CalledProcessError(returncode=exit_code, cmd=iptables_cmd, output=stdout)
            
            LOG.warn("iptables call '%s' returned exit code %d (output = %r)", command, exit_code, stdout)
            return False
        
        return True

    @staticmethod
    def add_chain(table="filter", chain=None):
        assert chain
        params = {
            "table": table,
            "chain": chain,
        }
        return IPTables.run_iptables("-t %(table)s -N %(chain)s" % params)

    @staticmethod
    def delete_chain(table="filter", chain=None):
        assert chain
        params = {
            "table": table,
            "chain": chain,
        }
        return IPTables.run_iptables("-t %(table)s -X %(chain)s" % params)

    @staticmethod
    def set_policy(table="filter", chain="INPUT", policy="ACCEPT"):
        params = {
            "table": table,
            "chain": chain,
            "policy": policy
        }
        return IPTables.run_iptables("-t %(table)s -P %(chain)s %(policy)s" % params)

    @staticmethod
    def flush(table="filter", chain="INPUT"):
        params = {
            "table": table,
            "chain": chain,
        }
        return IPTables.run_iptables("-t %(table)s -F %(chain)s" % params)

    @staticmethod
    def append(table="filter", chain="INPUT", matches=None, action="ACCEPT"):
        if not matches:
            matches = []
        params = {
            "table": table,
            "chain": chain,
            "params": " ".join(matches),
            "action": action,
        }
        return IPTables.run_iptables("-t %(table)s -A %(chain)s %(params)s -j %(action)s" % params)

    @staticmethod
    def check(table="filter", chain="INPUT", matches=None, action="ACCEPT"):
        if not matches:
            matches = []
        params = {
            "table": table,
            "chain": chain,
            "params": " ".join(matches),
            "action": action,
        }
        return IPTables.run_iptables("-t %(table)s -C %(chain)s %(params)s -j %(action)s" % params)

    @staticmethod
    def insert(table="filter", chain="INPUT", index=1, matches=None, action="ACCEPT"):
        if not matches:
            matches = []
        params = {
            "table": table,
            "chain": chain,
            "params": " ".join(matches),
            "index": index,
            "action": action,
        }
        return IPTables.run_iptables("-t %(table)s -I %(chain)s %(index)d %(params)s -j %(action)s" % params)

    @staticmethod
    def delete(table="filter", chain="INPUT", index=1):
        params = {
            "table": table,
            "chain": chain,
            "index": index,
        }
        return IPTables.run_iptables("-t %(table)s -D %(chain)s %(index)d" % params)

    @staticmethod
    def delete_rule_by_specifications(table="filter", chain="INPUT", matches=None, action="ACCEPT"):
        if not matches:
            matches = []
        params = {
            "table": table,
            "chain": chain,
            "params": " ".join(matches),
            "action": action,
        }
        return IPTables.run_iptables("-t %(table)s -D %(chain)s %(params)s -j %(action)s" % params)

    @staticmethod
    def physdev_out(name):
        return ["-m physdev --physdev-out %s" % (name, )]
    
    @staticmethod
    def physdev_in(name):
        return ["-m physdev --physdev-in %s" % (name, )]
    
    @staticmethod
    def dev_in(name):
        return ["-i %s" % (name, )]
    
    @staticmethod
    def dev_out(name):
        return ["-o %s" % (name, )]
    
    @staticmethod
    def syn_flag():
        return ["-p tcp --syn"]

    @staticmethod
    def rst_flag():
        return ["-p tcp --tcp-flags SYN,RST SYN,RST"]

    @staticmethod
    def make_current_config_persistent(output_file=IPTABLES_SAVE_FILE):
        iptables_dir = os.path.dirname(output_file)
        if not os.path.exists(iptables_dir):
            os.makedirs(iptables_dir)

        try:
            subprocess.check_call("iptables-save > {}".format(output_file), shell=True)
        except subprocess.CalledProcessError as exc:
            LOG.warning("Error saving iptables configuration with command '%s' (error %d)", exc.cmd, exc.returncode)
            return False

        return True
