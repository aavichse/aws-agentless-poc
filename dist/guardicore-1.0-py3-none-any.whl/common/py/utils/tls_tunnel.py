#!/usr/bin/python

from __future__ import print_function
import os
import sys
import socket
import select
import logging
from urllib.parse import urlparse
import threading


logging.basicConfig(format="%(asctime)s [%(levelname)s] %(module)s.%(funcName)s.%(lineno)d: %(message)s",
                    level=logging.DEBUG)


class SocketProxyThread(threading.Thread):
    NEXT_ID = 1
    CHUNK_SIZE = 1024

    def __init__(self, proxy_host, proxy_port, client_sock, server_addr, server_port):
        self.thread_id = SocketProxyThread.NEXT_ID
        SocketProxyThread.NEXT_ID += 1

        super(SocketProxyThread, self).__init__(name='proxy-%d' % (self.thread_id, ))

        self.proxy_host = proxy_host
        self.proxy_port = proxy_port
        self.server_addr = server_addr
        self.server_port = server_port
        self.client_sock = client_sock
        self.proxy_sock = None

    def _connect_proxy(self):
        proxy_sock = socket.create_connection((self.proxy_host, self.proxy_port))
        proxy_sock.sendall("CONNECT %(server_addr)s:%(server_port)d HTTP/1.1\r\n"
                           "Host: %(server_addr)s:%(server_port)d\r\n"
                           "User-Agent: Guardicore Proxy\r\n"
                           "Proxy-Connection: Keep-Alive\r\n\r\n" % dict(server_addr=self.server_addr,
                                                                         server_port=self.server_port))
        logging.debug("[%d] Sent CONNECT request through proxy %s:%d to %s:%d", self.thread_id, self.proxy_host,
                      self.proxy_port, self.server_addr, self.server_port)

        header = ""
        while not header.endswith("\r\n\r\n") and not header.endswith("\n\n"):
            new_data = proxy_sock.recv(1)
            if not new_data:
                logging.warn("[%d] disconnection during CONNECT", self.thread_id)
                return None
            header += new_data

        logging.debug("CONNECT reply: %s", header.rstrip("\r\n"))

        return proxy_sock

    def _proxy_data(self, src_sock, dst_sock):
        data = src_sock.recv(SocketProxyThread.CHUNK_SIZE)
        if not data:
            logging.warn("[%d] No data from socket", self.thread_id)
            return False

        dst_sock.sendall(data)
        return True

    def run(self):
        logging.debug("New connection thread [%d]", self.thread_id)

        try:
            self.proxy_sock = self._connect_proxy()
            if not self.proxy_sock:
                return

            while True:
                rlist, _, _ = select.select([self.proxy_sock, self.client_sock], [], [])
                if self.proxy_sock in rlist and \
                        not self._proxy_data(src_sock=self.proxy_sock, dst_sock=self.client_sock):
                    logging.debug("[%d] Connection closed by proxy side", self.thread_id)
                    break
                if self.client_sock in rlist and \
                        not self._proxy_data(src_sock=self.client_sock, dst_sock=self.proxy_sock):
                    logging.debug("[%d] Connection closed by client side", self.thread_id)
                    break
        except socket.error as exc:
            logging.error("Socket error in thread [%d]: %s", self.thread_id, exc)
        finally:
            logging.debug("Closed connection of thread [%d]", self.thread_id)
            self.client_sock.close()
            if self.proxy_sock:
                self.proxy_sock.close()


def main():
    if 4 != len(sys.argv):
        print("Invalid usage")
        print("%s <listen addr:port> <proxy url> <server addr:port>" % (os.path.basename(sys.argv[0]) ,))
        return 1

    listen_addr, proxy_url, server_addr = sys.argv[1:]

    try:
        listen_addr, listen_port = listen_addr.split(":")
        listen_port = int(listen_port)
        server_addr, server_port = server_addr.split(":")
        server_port = int(server_port)
        proxy_host, proxy_port = urlparse.urlparse(proxy_url).netloc.split(":")
        proxy_port = int(proxy_port)
    except:
        print("Invalid usage")
        print("%s <listen addr:port> <proxy url>" % (os.path.basename(sys.argv[0]),))
        return 1

    threads = []

    logging.info("Proxy configuration: %s:%d", proxy_host, proxy_port)
    logging.info("Server configuration: %s:%d", server_addr, server_port)

    logging.debug("Trying to bind server address on %s:%d", listen_addr, listen_port)

    # create server socket
    srv_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP)

    try:
        srv_sock.bind((listen_addr, listen_port))
        srv_sock.listen(10)

        logging.info("Listened on server address: %s:%d", listen_addr, listen_port)

        while True:
            client_sock, client_addr = srv_sock.accept()
            logging.info("New incoming connection: %s", client_addr)

            new_thread = SocketProxyThread(proxy_host=proxy_host, proxy_port=proxy_port, client_sock=client_sock,
                                           server_addr=server_addr, server_port=server_port)
            new_thread.setDaemon(True)
            new_thread.start()
            threads.append(new_thread)
    finally:
        srv_sock.close()
        del srv_sock

    return 0


if __name__ == '__main__':
    sys.exit(main())
