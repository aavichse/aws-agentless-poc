'''
Created on Jul 17, 2014

@author: itamar
'''


class GuardicoreException(Exception):
    def __init__(self, err_msg, *args):
        Exception.__init__(self, err_msg % args)


class ExceptionTimeout(GuardicoreException):
    """class ExceptionTimeout(Exception)
    
    Timeout occurred while executing command.
    """

    def __init__(self, timeout, err_msg, *args):
        GuardicoreException.__init__(self, "Timeout (%2.2f seconds) occurred during execution: %s", timeout,
                                     err_msg % args)


class DriverLoadError(GuardicoreException):
    def __init__(self, driver_name, driver_type_name, msg, *args):
        GuardicoreException.__init__(self, "Error while loading %s driver in %s: %s", driver_type_name, driver_name,
                                     msg % args)


class MissingConfigException(GuardicoreException):
    def __init__(self, key_name, err_msg=None):
        err_msg = "" if not err_msg else " (%s)" % (err_msg,)

        GuardicoreException.__init__(self, "Configuration for '%s' is missing %s" % (key_name, err_msg))


class CorruptedConfigException(GuardicoreException):
    def __init__(self, config_files, err_msg):
        super(CorruptedConfigException, self).__init__("Error reading configuration file(s) %s: %s", config_files,
                                                       err_msg)


class MissingConfigValuesException(GuardicoreException):
    def __init__(self, key_name, missing_subkeys, err_msg=None):
        err_msg = "" if not err_msg else " (%s)" % (err_msg,)

        GuardicoreException.__init__(self,
                                     "Configuration for subkeys %s of '%s' is missing %s" % (
                                         ','.join(["'%s'" % s for s in missing_subkeys]),
                                         key_name, err_msg))


class InvalidConfigException(GuardicoreException):
    def __init__(self, key_name, invalid_key_value, err_msg=None, *args):
        err_msg = "" if not err_msg else " (%s)" % (err_msg % args,)

        GuardicoreException.__init__(self, "Invalid configuration value for '%s': %s%s", key_name, invalid_key_value,
                                     err_msg)


class CriticalConfigException(GuardicoreException):
    pass


class HostErrorException(GuardicoreException):
    def __init__(self, err_msg, *args):
        GuardicoreException.__init__(self, "Error with host (config/info retrieval): %s", err_msg % args)


class OvsCmdException(GuardicoreException):
    pass


class EnvironmentSetupException(GuardicoreException):
    def __init__(self, err_msg, *args):
        GuardicoreException.__init__(self, "Error during environment setup: %s", err_msg % args)


class SnapshotException(GuardicoreException):
    def __init__(self, err_msg, *args):
        GuardicoreException.__init__(self, "Error setting up snapshot: %s", err_msg % args)


class IpTablesApplyException(GuardicoreException):
    def __init__(self, err_msg, *args):
        GuardicoreException.__init__(self, "Error during applying iptables command: %s", err_msg % args)


class NotSupportedDPState(GuardicoreException):
    def __init__(self):
        GuardicoreException.__init__(self, "Invalid state was set")


class NotSupportedVMType(GuardicoreException):
    pass


class BridgingOperationCanceled(GuardicoreException):
    pass


class InvalidPacketError(GuardicoreException):
    pass


class InvalidIPError(GuardicoreException):
    pass


class InvalidUpdateFileError(GuardicoreException):
    def __init__(self, err_msg, *args):
        GuardicoreException.__init__(self, "Error during update: %s", err_msg % args)


class ManagementConnectivityError(EnvironmentSetupException):
    def __init__(self, mgmt_cls, management_hosts, exc=None):
        super(ManagementConnectivityError, self).__init__("Error connecting to management server (class=%s, hosts=%s, "
                                                          "exc=%r). This might be a result of a connectivity issue or "
                                                          "some problem with the remote server. Please contact "
                                                          "support if the issue persists.", mgmt_cls, management_hosts,
                                                          exc)

        self.mgmt_cls = mgmt_cls
        self.management_hosts = management_hosts


class FeatureUnavailableException(GuardicoreException):
    def __init__(self, feature_name):
        super(GuardicoreException, self).__init__("%s is not enabled", feature_name)
        self.feature_name = feature_name


class InvalidParamException(GuardicoreException):
    def __init__(self, param_name, invalid_value, valid_options=None):
        msg = "'{}' is not a valid option for the '{}' parameter.".format(invalid_value, param_name)
        if valid_options:
            msg = msg + ' Valid options are ' + ','.join(valid_options)

        super(GuardicoreException, self).__init__(msg)

        self.param_name = param_name
        self.invalid_value = invalid_value
        self.valid_options = valid_options


class InvalidQueryParamException(InvalidParamException):
    def __init__(self, param_name, invalid_value, valid_options=None):
        super(InvalidQueryParamException, self).__init__(param_name, invalid_value, valid_options)


class MissingParamException(GuardicoreException):
    def __init__(self, param_name):
        super(GuardicoreException, self).__init__("'%s' parameter is missing", param_name)
        self.param_name = param_name


class MissingCASFile(GuardicoreException):
    pass


class CloudAppConnectionException(GuardicoreException):
    pass


class CloudAppClusterException(GuardicoreException):
    pass


class CloudAppDuplicateException(GuardicoreException):
    pass


class CloudAppValidationException(GuardicoreException):
    pass
