__author__ = 'Izi'

import collections


class MultipleIdenticalKeysLifoDict(collections.MutableMapping):
    """A dictionary supporting multiple identical keys.
    Only the last value is returned when accessing a key. Popping the key permits access to the previous value.
    """

    def __init__(self):
        super(MultipleIdenticalKeysLifoDict, self).__init__()
        self._dict = {}
        self._items_count = 0

    def __getitem__(self, key):
        return self._dict[key][-1]

    def __setitem__(self, key, value):
        self._dict.setdefault(key, []).append(value)
        self._items_count += 1

    def __delitem__(self, key):
        self._dict[key].pop(-1)
        if len(self._dict[key]) == 0:
            self._dict.pop(key)
        self._items_count -= 1

    def __iter__(self):
        for key in self._dict:
            yield key

    def __len__(self):
        return self._items_count

    def __repr__(self):
        return repr(self._dict)