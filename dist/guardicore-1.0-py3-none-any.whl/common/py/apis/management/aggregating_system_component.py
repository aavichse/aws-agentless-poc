from common.logger import get_logger
from common.py.apis import RPCExchange, RPCMessage, AggregatorType, ComponentType, IntegrationType
from common.py.apis.management import UNKNOWN_API_VERSION
from common.py.apis.management.system_component import SystemComponentManagementAPI
from common.py.model.aggregator import AggregatorTypes
from common.py.utils.config.to_jsonschema import intersect_jsonschema_config
from common.py.utils.dictutils import recursive_update_dict
from common.py.model.collection_setup_configuration import SetupConfiguration

__author__ = 'Eddie'

LOG = get_logger(module_name=__name__)


def get_external_fqdn_addresses():
    external_fqdn_addresses = []
    try:
        setup_config = SetupConfiguration(load=True)
        external_fqdn_addresses = setup_config.get('external_fqdn_addresses', [])
    except:
        LOG.exception("Failure while reading setup configuration file")
    finally:
        return external_fqdn_addresses


class AggregatorBaseComponentManagementAPI(SystemComponentManagementAPI):
    COMPONENT_TYPE = None  #: overridden by subclasses
    AGENTS_COMPONENT_TYPE = None  #: overridden by subclasses
    COMPONENT_BASE_URI = None  #: overridden by subclasses

    def __init__(self, component_id, management_hosts, agent_id,
                 component_details=None, version=UNKNOWN_API_VERSION,
                 anonymous=False, configuration_schema=None, aggregator_configuration_schema=None, error_callback=None,
                 attempt_reconnect_on_error=False, transport_type='eventlet', cluster_id=None,
                 aggregator_type=AggregatorType.COLLECTOR, aggregator_features=None, collector_type=None,
                 recv_agent_updates=False, **kwargs):
        if component_details is None:
            component_details = {}

        self.aggregator_component_id = ComponentType.AGGREGATOR.prefix + agent_id
        self.agent_id = agent_id
        component_details.update(dict(agent_id=agent_id,
                                      aggregator_configuration_schema=aggregator_configuration_schema,
                                      aggregator_type=aggregator_type,
                                      aggregator_features=aggregator_features or [],
                                      collector_type=collector_type))

        if cluster_id is not None:
            component_details['cluster_id'] = cluster_id

        component_details["external_fqdn_addresses"] = get_external_fqdn_addresses()

        # FIXME: The naming here very confusing. error_callback in ints original sense is deprecated.
        kwargs['read_loop_error_callback'] = error_callback

        # we use this extra routing key to filter whos getting agent configuration updates
        if recv_agent_updates:
            kwargs['extra_routing_keys'].append('agent_conf_updates')

        super(AggregatorBaseComponentManagementAPI, self).__init__(component_id=component_id,
                                                                   management_hosts=management_hosts,
                                                                   version=version,
                                                                   anonymous=anonymous,
                                                                   transport_type=transport_type,
                                                                   attempt_reconnect_on_error=attempt_reconnect_on_error,
                                                                   component_details=component_details,
                                                                   configuration_schema=configuration_schema,
                                                                   **kwargs)
        self.agents_details = {}

    def get_configuration_anonymously(self, component_type=None):
        if component_type is None:
            component_type = self.COMPONENT_TYPE
        aggregator_id = self.component_details.get('aggregator_id', None)
        if aggregator_id is None:
            aggregator_id = self.component_details.get('agent_id', None)
            assert aggregator_id is not None, "Couldn't find nither 'aggregator_id' nor 'agent_id'"

        component_id = component_type.prefix + aggregator_id
        return self.rabbitapi.call_management_rpc(RPCMessage.Control.COMPONENT_GET_CONFIGURATION_RPC_FUNC_NAME,
                                                  component_id=component_id,
                                                  component_type=component_type,
                                                  component_details=None,
                                                  component_status=None,
                                                  anonymous=True,
                                                  blocking=True)

    def _extract_component_configuration(self, source_configuration):
        configuration = {}
        recursive_update_dict(configuration, source_configuration['group'])
        recursive_update_dict(configuration, source_configuration['components'].get(self.component_id, {}))

        if self.COMPONENT_TYPE == ComponentType.AGGREGATOR:
            for component_type in (ComponentType.DATAPATH, ComponentType.MITIGATION_AGENT):
                configuration[component_type.normal] = self.get_configuration_anonymously(component_type=component_type)

        configuration[self.COMPONENT_TYPE.normal] = intersect_jsonschema_config(
            self.component_details['configuration_schema'],
            configuration.get(self.COMPONENT_TYPE.normal, {}))

        return configuration

    def get_configuration(self):
        conf = super(AggregatorBaseComponentManagementAPI, self).get_configuration()
        if self.COMPONENT_TYPE == ComponentType.AGGREGATOR:
            for component_type in (ComponentType.DATAPATH, ComponentType.MITIGATION_AGENT):
                component_conf = self.get_configuration_anonymously(component_type=component_type)
                conf.update(component_conf)
        else:
            conf.update(self.get_aggregator_configuration())

        return conf

    def add_flush_aggregator_cache_callback(self, callback_func):
        """
        Calls callback_func that should semantically cause flushing of all aggregator's cache
        callback_func should be of type:
            callback_func(seen_connection_cache, seen_ip_cache, sampling_cache, orchestration_cache)
        :param callback_func: this will be called once the appropriate message is received.
        """

        if self.__class__.COMPONENT_TYPE not in (ComponentType.AGGREGATOR, ComponentType.DATAPATH):
            LOG.warn("'add_flush_aggregator_cache_callback' is not applicable for '%s'",
                     self.__class__.COMPONENT_TYPE.normal)

        def _cb_wrapper(msg):
            return callback_func(seen_connection_cache=msg.get('seen_connection_cache', True),
                                 seen_ip_cache=msg.get('seen_ip_cache', True),
                                 sampling_cache=msg.get('sampling_cache', True),
                                 orchestration_cache=msg.get('orchestration_cache', False),
                                 containers_cache=msg.get('containers_cache', False),
                                 )

        self.rabbitapi.add_callback(RPCMessage.Aggregator.AGGREGATOR_FLUSH_CACHE, _cb_wrapper)

    def list_all_aggregators(self, cluster_id=None, extended=True):
        return self.rabbitapi.call_management_rpc(RPCMessage.Aggregator.AGGREGATOR_LIST_ALL_AGGREGATORS_RPC_FUNC_NAME,
                                                  cluster_id=cluster_id, extended=extended, blocking=True)

    def list_all_honeypots(self, cluster_id_list=None):
        return self.rabbitapi.call_management_rpc(RPCMessage.Aggregator.AGGREGATOR_LIST_ALL_HONEYPOTS_RPC_FUNC_NAME,
                                                  cluster_id_list=cluster_id_list,
                                                  blocking=True)

    def add_notify_honeypots_list_changed_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.Aggregator.AGGREGATOR_NOTIFY_HONEYPOTS_LIST_CHANGE,
                                    lambda message: callback_func())

    def send_alive_agents(self, agents=None):
        if agents is None:
            agents = []

        new_json_agents = []
        for agent_details in agents:
            json_agent = agent_details.to_dict()
            if json_agent.get('module_details') is None:
                json_agent['module_details'] = {}
            json_agent['module_details']['aggregator_component_id'] = self.aggregator_component_id
            assert agent_details.module_type == self.AGENTS_COMPONENT_TYPE
            new_json_agents.append(json_agent)
            self.agents_details[json_agent['agent_id']] = json_agent['module_details']
        self.rabbitapi.call_management_rpc(RPCMessage.Aggregator.AGGREGATOR_REPORT_AGENTS_ALIVE_RPC_FUNC_NAME,
                                           exchange=RPCExchange.AGENT_EVENT_EXCHANGE_NAME,
                                           agents=new_json_agents,
                                           aggregator_component_id=self.aggregator_component_id)

    def get_aggregator_configuration(self):
        return self.rabbitapi.call_management_rpc(RPCMessage.Aggregator.AGGREGATOR_GET_CONFIGURATION,
                                                  aggregator_component_id=self.aggregator_component_id,
                                                  blocking=True)

    def aggregator_get_agent_monitoring_configuration(self):
        return self.rabbitapi.call_management_rpc(
            RPCMessage.Aggregator.AGGREGATOR_GET_AGENT_MONITORING_CONFIGURATION_RPC_FUNC_NAME, blocking=True)

    def add_agent_config_update_callback(self, callback_func):
        return self.rabbitapi.add_agent_config_update_callback(callback_func)

    def report_agents_config_update_results(self, update_results):
        return self.rabbitapi.report_agents_config_update_results(update_results)

    def get_agents_configuration(self, *agent_types):
        return self.rabbitapi.get_agents_configuration(*agent_types)

    def get_installation_profiles(self):
        installation_profiles = self.rabbitapi.call_management_rpc(
            rpc_func_name=RPCMessage.Aggregator.AGGREGATOR_GET_INSTALLATION_PROFILES_CONFIGURATION_RPC_FUNC_NAME,
            routing_key=RPCMessage.Aggregator.AGGREGATOR_GET_INSTALLATION_PROFILES_CONFIGURATION_RPC_FUNC_NAME,
            exchange=RPCExchange.AGENT_EVENT_EXCHANGE_NAME,
            blocking=True,
        )
        return installation_profiles

    def add_installation_profiles_update_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.Agent.INSTALLATION_PROFILES_CONFIGURATION_UPDATE_MESSAGE_TYPE,
                                    lambda message: callback_func(message['installation_profiles_configuration']))

    def get_datacenter_inventory_snapshot(self):
        """
        Get the current datacenter inventory snapshot.
        :return: current DC inventory snapshot, as a DatacenterInventorySnapshot instance.
        """
        snapshot = self.rabbitapi.call_management_rpc(
            RPCMessage.DatacenterInventory.GET_DC_INVENTORY_SNAPSHOT_RPC_FUNC_NAME,
            blocking=True,
            exchange=RPCExchange.DC_INVENTORY_EXCHANGE_NAME)
        return snapshot

    def add_datacenter_inventory_update_callback(self, callback_func, initial_call=True):
        """
        Register a callback to be called whenever the datacenter inventory is updated.
        :param callback_func: callback function. Expected to receive a single argument for the DC inventory snapshot,
            as an DatacenterInventorySnapshot instance.
        :param initial_call: should the callback be called after registration with the current snapshot?
        """

        self.rabbitapi.add_callback(
            RPCMessage.DatacenterInventory.DC_INVENTORY_UPDATE_MESSAGE_TYPE,
            lambda message: callback_func(message['dc_inventory_snapshot']),
            initial_call=initial_call,
            initial_call_func=lambda: callback_func(self.get_datacenter_inventory_snapshot()))

    def add_integration_config_change_callback(self, callback_func, initial_call=False):
        """
        the callback method should have arguments:
        correlation_id - result should contain that id to return (used by us)
        credentials: the initial eaa cloud credentials
        """

        integration_type = None
        if initial_call:
            integration_type = {  # Request integration configs from mgmt based on collector type
                AggregatorTypes.CloudCollector.value.short_name: IntegrationType.Cloud,
                AggregatorTypes.PFCollector.value.short_name: IntegrationType.PACKETFENCE
            }[self.component_details["collector_type"]]

        self.rabbitapi.add_callback(
            message_type=RPCMessage.Integrations.NOTIFY_CONFIGS,
            callback_func=lambda message: callback_func(
                integration_configs=message['integration_info'],
                integration_type=message['integration_type']
            ),
            initial_call=initial_call,
            initial_call_func=lambda: callback_func(integration_type=integration_type,
                                                    integration_configs=self.get_integration_config(integration_type))
        )

    def get_integration_config(self, integration_type):
        return self.rabbitapi.call_management_rpc(
            rpc_func_name=RPCMessage.Integrations.GET_CONFIGS,
            integration_type=integration_type,
            blocking=True
        )

    def update_cloud_health(self, health_information, version_info):
        component_id = health_information['component-id'] if health_information else version_info['component_id']
        return self.rabbitapi.call_management_rpc(
            RPCMessage.CloudApp.CLOUD_APP_UPDATE_HEALTH,
            external_cloud_app_id=component_id,
            details=health_information,
            version_info=version_info
        )

    def add_cloud_service_config_change_callback(self, callback_func):
        """
        cloud app service configuration is supported only through mgmt cli (does not have UI)
        """
        self.rabbitapi.add_callback(RPCMessage.CloudApp.CLOUD_APP_NOTIFY_SERVICE_CONFIG,
                                    lambda message: callback_func(
                                        service_configs=message['service_configuration']))

    def get_cloud_service_config(self, cloud_app_id):
        return self.rabbitapi.call_management_rpc(RPCMessage.CloudApp.CLOUD_APP_GET_SERVICE_CONFIG,
                                                  external_cloud_app_id=cloud_app_id,
                                                  blocking=True)

    def set_cloud_service_config_opts(self, cloud_app_id, opts):
        return self.rabbitapi.call_management_rpc(RPCMessage.CloudApp.CLOUD_APP_REGISTER_SERVICE_CONFIG_OPTS,
                                                  external_cloud_app_id=cloud_app_id,
                                                  configuration_schema=opts)

    def update_cloud_flags(self, cloud_app_id, flags):
        return self.rabbitapi.call_management_rpc(RPCMessage.CloudApp.CLOUD_APP_UPDATE_FLAGS,
                                                  external_cloud_app_id=cloud_app_id,
                                                  flags=flags)

    def get_all_policies(self):
        return self.rabbitapi.call_management_rpc(RPCMessage.Datapath.DATAPATH_GET_POLICIES_RPC_FUNC_NAME,
                                                  blocking=True)

    def add_policy_update_callback(self, callback_func, initial_call=True):
        self.rabbitapi.add_callback(RPCMessage.Datapath.DATAPATH_POLICY_CHANGE_MESSAGE_TYPE,
                                    lambda message: callback_func(message['policies']),
                                    initial_call=initial_call,
                                    initial_call_func=lambda: callback_func(self.get_all_policies()))

    def send_agent_upgrade_reports(self, upgrades_status):
        self.rabbitapi.call_management_rpc(RPCMessage.Aggregator.AGGREGATOR_REPORT_AGENT_UPGRADES_RPC_FUNC_NAME,
                                           routing_key=RPCMessage.Aggregator.AGGREGATOR_REPORT_AGENT_UPGRADES_RPC_FUNC_NAME,
                                           exchange=RPCExchange.AGENT_EVENT_EXCHANGE_NAME,
                                           upgrades_status=upgrades_status)

    def send_agent_migration_reports(self, agents_migration_reports):
        self.rabbitapi.call_management_rpc(RPCMessage.Aggregator.AGGREGATOR_REPORT_AGENT_MIGRATION_RPC_FUNC_NAME,
                                           exchange=RPCExchange.AGENT_EVENT_EXCHANGE_NAME,
                                           agent_reports=agents_migration_reports)

    def send_connected_controller_agents(self, job_id, agents_uuids):
        self.rabbitapi.call_management_rpc(RPCMessage.ControllerServer.CONTROLLER_SERVER_CONNECTED_AGENTS,
                                           exchange=RPCExchange.AGENT_EVENT_EXCHANGE_NAME,
                                           job_id=job_id,
                                           aggregator_id=self.aggregator_component_id,
                                           agent_ids=agents_uuids)

    def send_agent_ko_upgrade_reports(self, ko_upgrades_status):
        self.rabbitapi.call_management_rpc(RPCMessage.Aggregator.AGGREGATOR_REPORT_AGENT_KO_UPGRADES_RPC_FUNC_NAME,
                                           routing_key=RPCMessage.Aggregator.AGGREGATOR_REPORT_AGENT_KO_UPGRADES_RPC_FUNC_NAME,
                                           exchange=RPCExchange.AGENT_EVENT_EXCHANGE_NAME,
                                           ko_upgrades_status=ko_upgrades_status)
