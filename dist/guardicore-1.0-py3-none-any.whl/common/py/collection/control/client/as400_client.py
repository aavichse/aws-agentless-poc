from common.py.collection.control.client import AggregatorControlClient
from common.py.collection.control.model import build_ctrl_sock_path
from prettytable import PrettyTable
from aggregator.services.orchestration.as400.agent.enforcement_agent import as400_supported_features


class AS400ControlClient(AggregatorControlClient):
    def __init__(self, orchestration_id, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.path = build_ctrl_sock_path(self.component_name, special_id=orchestration_id)
        self.quoted_path = self.path.replace("/", "%2F")

    def get_lpar_rules(self, lpar, format_json=False):
        if not format_json:
            rules = self.call("/as400/lpar/" + lpar + "/rules")
        else:
            rules = self.call("/as400/lpar/" + lpar + "/rulesj")
        return rules

    def load_rules(self, lpar):
        return self.call("/as400/lpar/" + lpar + "/load-rules")

    def get_lpar_rules_mapping(self, lpar):
        return self.call("/as400/lpar/" + lpar + "/rules-mapping")

    def send_command(self, lpar, command):
        return self.call("/as400/lpar/" + lpar + "/command/" + command)

    def get_enf_data(self, lpar):
        return self.call("/as400/lpar/" + lpar + "/enf_data")

    def get_enf_mode(self, lpar):
        return self.call("/as400/lpar/" + lpar + "/enf_mode")
