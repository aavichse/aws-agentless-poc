import sys

from common.py.apis.palo_alto.pan.xapi import PanXapi, PanXapiError
from common.py.apis.palo_alto.panxapi import print_response, get_result_json
from common.py.utils.gc_statsd import STATSD
from common.logger import get_logger


LIST_DEVICES_QUERY = "<show><devices><connected></connected></devices></show>"
IP_ACTION_QUERY = '<uid-message><version>1.0</version><type>update</type><payload><{action}>'\
                  '<entry ip="{ip}"> <tag><member>{tag}</member></tag></entry></{action}></payload></uid-message>'

# we are unsure of the different vsys names. in our env it was always vsys1, but is configurable.
VSYS_DEFAULT_NAME = 'vsys1'
LOGGER = get_logger()


class PaloAltoAPIException(Exception):
    def __init__(self, err_msg, *args):
        Exception.__init__(self, err_msg % args)


class PaloAltoAPI(object):
    """
    this is the Guardicore written api, which uses the panxapi which uses the "pan" library.
    """

    def __init__(self, username=None, password=None, hostname=None, port=443, vsys=VSYS_DEFAULT_NAME,
                 register_to_all_pan_firewalls=True, list_of_firewall_serials=None):
        """

        :param username: username to connect to Panorama
        :param password: password to connect to Panorama
        :param hostname: Panorama's hostname
        :param vsys: name of the vsys. default - "vsys1"
        :param register_to_all_pan_firewalls: whether we should list the devices and register IPs to all of them
        (override list_of_firewall_serials)
        :param list_of_firewall_serials: whether registering IPs should be perform for subset of the Panorama's firewalls.
        """

        if username is None or password is None or hostname is None:
            raise PaloAltoAPIException("Error: Incorrect arguments. Make sure correct username, password and hostname are provided.")

        self.username = username
        self.password = password
        self.hostname = hostname
        self.port = port
        self.vsys = vsys
        self.register_to_all_pan_firewalls = register_to_all_pan_firewalls
        self.list_of_firewall_serials = list_of_firewall_serials
        self.print_options = {'print_xml': True, 'print_result': True, 'print_json': True, 'print_python': True, 'print_text': True}

    def _list_device_serials(self, xapi):
        xapi.op(cmd=LIST_DEVICES_QUERY, vsys=self.vsys)
        serials = []
        result = get_result_json(xapi)
        for entry in result['response']['result']['devices']['entry']:
            serials.append(entry['serial'])

        return serials

    @classmethod
    def register_ip_from_config(cls, config, ip, tag, timeout=None, asset_id=None):
        pan_hostname = config.paloalto.hostname
        pan_port     = config.paloalto.port
        pan_username = config.paloalto.username
        pan_password = config.paloalto.password
        pan_vsys = config.paloalto.vsys
        register_to_all_pan_firewalls = config.paloalto.register_to_all_pan_firewalls
        list_of_firewall_serials = config.paloalto.list_of_firewall_serials

        palo_alto_api = PaloAltoAPI(username=pan_username,
                                    password=pan_password,
                                    hostname=pan_hostname,
                                    port=pan_port,
                                    vsys=pan_vsys,
                                    register_to_all_pan_firewalls=register_to_all_pan_firewalls,
                                    list_of_firewall_serials=list_of_firewall_serials)

        return palo_alto_api._register_ip(ip=ip, tag=tag, timeout=timeout, asset_id=asset_id)

    def _register_ip(self, ip, tag, timeout=None, asset_id=None):
        try:
            xapi = PanXapi(api_username=self.username,
                           api_password=self.password,
                           hostname=self.hostname,
                           port=self.port)

            if self.register_to_all_pan_firewalls:
                device_serials = self._list_device_serials(xapi)
            else:
                device_serials = self.list_of_firewall_serials

            for serial in device_serials:
                xapi.user_id(cmd=IP_ACTION_QUERY.format(ip=ip, tag=tag, action='register'),
                             vsys=self.vsys,
                             target=serial,
                             timeout=timeout)

                LOGGER.info("registered IP: %r , tag: %r to %r, serial: %r with timeout: %r",
                            ip, tag, self.vsys, serial, timeout)

                STATSD.incr(metric='paloalto.registered_ip.success', tags=dict(ip=ip))

            return device_serials

        except PanXapiError as msg:
            STATSD.incr(metric='paloalto.registered_ip.failure', tags=dict(ip=ip, msg=str(msg)))
            raise PaloAltoAPIException("Failed reporting IP: %s tag: %s - %s",
                                       ip, tag, str(msg))

    def unregister_all(self, all_entries):
        try:
            xapi = PanXapi(api_username=self.username,
                           api_password=self.password,
                           hostname=self.hostname,
                           port=self.port)

            LOGGER.info("clear all (%d) reported IPs", len(all_entries))
            for entry in all_entries:
                ip = entry['ip']
                tag = entry['tag']
                serials = entry['fw_serials']

                for serial in serials:
                    xapi.user_id(cmd=IP_ACTION_QUERY.format(ip=ip, tag=tag, action='unregister'),
                                 vsys=self.vsys,
                                 target=serial)

        except PanXapiError as msg:
            raise PaloAltoAPIException("Failed unregistering IPs - %s", str(msg))

    def show(self):
        xapi = PanXapi(api_username=self.username,
                       api_password=self.password,
                       hostname=self.hostname,
                       port=self.port)
        xapi.show()
        print_response(xapi, self.print_options)

    def test_connection(self, timeout=None):
        """
        testing the credentials - should throw an exception if failed.
        :return:
        """

        try:
            LOGGER.info("performing test connection to hostname: %r:, port: %r, username: %r, password: %r",
                        self.hostname, self.port, self.username, self.password[0] + '*' * len(self.password[1:-1]))
            xapi = PanXapi(api_username=self.username,
                           api_password=self.password,
                           hostname=self.hostname,
                           port=self.port,
                           timeout=timeout)
            self._list_device_serials(xapi=xapi)
        except Exception as e:
            raise PaloAltoAPIException("Failed connection test - %s", str(e))

    def clean_ips(self, ips, tag):
        """
        This method is used by UTs - if a UT fails, an IP might be remained registered.
        this method cleans all the IPs at the beginning of the UT using the "testing" tag.
        :param ips:
        :param tag:
        :return:
        """
        try:
            LOGGER.info("cleaning IPs: %r, with tag: %r", ips, tag)
            xapi = PanXapi(api_username=self.username,
                           api_password=self.password,
                           hostname=self.hostname,
                           port=self.port)
            all_serials = self._list_device_serials(xapi=xapi)
            for ip in ips:
                for serial in all_serials:
                    LOGGER.debug("trying to clean ip: %r from serial: %r", ip, serial)
                    xapi.user_id(cmd=IP_ACTION_QUERY.format(ip=ip, tag=tag, action='unregister'),
                                 vsys=self.vsys,
                                 target=serial)
        except Exception as e:
            raise PaloAltoAPIException("Failed connection test - %s", str(e))


if __name__ == '__main__':
    username, password, hostname, port = sys.argv[1:5]
    palo_alto_api = PaloAltoAPI(username=username, password=password, hostname=hostname, port=port)
    palo_alto_api.show()
