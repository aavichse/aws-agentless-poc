import time
import attr
import eventlet
from abc import abstractmethod
from eventlet.event import Event
from eventlet.timeout import Timeout

from common.logger import get_logger
from common.py.model.exceptions import GuardicoreException
from common.service import ServiceState, Service
from common.py.utils.eventlet import spawn_wait_named, spawn_named
from common.py.utils.profiling import TimeIt

LOG = get_logger(module_name=__name__)


@attr.s
class JobInfo(object):
    spawn = attr.ib()
    func = attr.ib()
    name = attr.ib()
    id = attr.ib(default=None)
    cleanup_timeout = attr.ib(default=None)


class JobStopException(GuardicoreException):
    pass


class ComponentService(Service):
    JOB_CLEANUP_TIMEOUT = 1.0
    EMPTY_JOB = JobInfo(spawn=None, func=None, name=None)

    def __init__(self, name):
        super(ComponentService, self).__init__()
        self.name = name

        self._state_change_event = Event()
        self._jobs = {}
        self._periodicals = {}

    def initialize(self):
        super(ComponentService, self).initialize()

    def verify(self):
        super(ComponentService, self).verify()

    def start(self):
        super(ComponentService, self).start()

    def cleanup(self):
        super(ComponentService, self).cleanup()

        for periodical_info in self._periodicals.values():
            periodical_info['force_event'].send()

        with TimeIt(title="Component service '%s' cleanup" % (self.name, ), timeout=1.0):
            for job in list(self._jobs.values()):
                self._stop_job(job)

    def _on_state_change_event(self):
        super(ComponentService, self)._on_state_change_event()

        if self._state_change_event.has_result():
            self._state_change_event.reset()
        self._state_change_event.send(self._state)

    def wait_until_state_change(self, starting_state=None):
        if starting_state is not None and (self.get_state() == starting_state):
            return True

        if self._state_change_event.has_result():
            self._state_change_event.reset()

        try:
            self._state_change_event.wait()
            return True
        except JobStopException:
            return True
        except Timeout:
            raise
        except Exception:
            LOG.exception("Error waiting for service %s state change", self)

        return False

    def _safe_sleep(self, timeout, state=ServiceState.Started):
        """_safe_sleep(timeout, state=ServiceState.Started)

        Sleep for 'timeout' seconds or until service state changes.
        """

        if state != self._state:
            return False

        try:
            with Timeout(timeout):
                self.wait_until_state_change()
        except Timeout:
            pass

        return self.get_state() == state

    def wait_all(self, cleanup=False):
        """wait_all(cleanup=False)

        Wait for all jobs to complete. If 'cleanup' is True, timeout on the job wait for as much as
        the job cleanup_timeout says. Otherwise, wait forever until the job ends.
        """

        for job in list(self._jobs.values()):
            timeout = job.cleanup_timeout if cleanup else None
            self._wait_job(job, timeout=timeout)

    def _run_job(self, name, func, stop_on_error=True, stop_on_exit=False, cleanup_timeout=JOB_CLEANUP_TIMEOUT,
                 *args, **kwargs):

        LOG.debug("Starting new service job named '%s' under service '%s' with function '%s'",
                  name, self.name, func.__name__)

        spawn = spawn_wait_named(name=name, func=lambda *x, **y: self.__run_job(*x, **y)[1], job_func=func,
                                 job_name=name, stop_on_error=stop_on_error, stop_on_exit=stop_on_exit, *args, **kwargs)
        job = JobInfo(spawn=spawn, id=id(spawn), name=name, func=func, cleanup_timeout=cleanup_timeout)
        self._jobs[job.name] = job
        return job

    def list_periodicals(self):
        return self._periodicals.values()

    def get_periodical_by_name(self, name):
        return self._periodicals.get(name, None)

    def list_jobs(self):
        return self._jobs.values()

    @staticmethod
    def wait_next_periodical_run(periodical_info, timeout=None, force_now=True):
        periodical_info['notify_next_run'] = Event()

        if force_now:
            periodical_info['force_event'].send()

        try:
            if timeout is None:
                return periodical_info['notify_next_run'].wait()
            else:
                with Timeout(timeout):
                    return periodical_info['notify_next_run'].wait()
        finally:
            periodical_info['notify_next_run'] = None

    @staticmethod
    def run_periodical_now(periodical_info):
        assert isinstance(periodical_info, dict) and 'func' in periodical_info
        kwargs = {key: value for key, value in periodical_info.get('kwargs', dict()).items()
                  if key not in {'job_debug'}}
        return periodical_info['func'](*periodical_info.get('args', tuple()),
                                       **kwargs)

    def __periodical_runner(self, period_func, get_time_period, job_name, stop_on_error=True,
                            *args, **kwargs):
        periodical_info = {'name': job_name,
                           'args': tuple(args),
                           'kwargs': kwargs.copy(),
                           'last_run_time': None,
                           'get_time_period': get_time_period,
                           'func': period_func,
                           'executions': 0,
                           'notify_next_run': None,
                           'force_event': Event()}
        self._periodicals[job_name] = periodical_info

        try:
            while ServiceState.Started == self.get_state():
                try:
                    with Timeout(get_time_period()):
                        periodical_info['force_event'].wait()
                except Timeout:
                    pass
                except JobStopException:
                    LOG.debug("Job %s has been stopped for service: %s", job_name, self.name)
                    break
                finally:
                    if periodical_info['force_event'].has_result():
                        periodical_info['force_event'].reset()

                if job_name not in self._jobs:
                    LOG.debug("Job %s has been stopped for service: %s", job_name, self.name)
                    break
                elif ServiceState.Started != self.get_state():
                    break

                success, ret = self.__run_job(job_func=period_func, stop_on_error=stop_on_error, stop_on_exit=False,
                                              job_name=job_name, *args, **kwargs)
                periodical_info['executions'] += 1
                if periodical_info['notify_next_run']:
                    periodical_info['notify_next_run'].send((success, ret))

                if not success:
                    if stop_on_error:
                        LOG.warning("Breaking out of periodical job '%s' in service '%s' after an error occurred",
                                    job_name, self.name)
                        break
                    else:
                        LOG.debug("Ignoring error in job '%s' of service '%s'", job_name, self.name)

                periodical_info['last_run_time'] = time.time()
        except Exception:
            LOG.exception("Exception in periodical job %r:", period_func)
            self._job_failed(job_name=job_name, stop_on_error=stop_on_error)
            raise
        finally:
            self._periodicals.pop(job_name, None)
            LOG.info("Periodical job %r exited", period_func)

    def __run_job(self, job_func, stop_on_error=True, stop_on_exit=False, job_name=None, job_debug=True,
                  *args, **kwargs):
        try:
            if job_debug:
                LOG.debug("Run job [%s]: %s", job_name, job_func)
            ret = job_func(*args, **kwargs)
        except JobStopException:
            return False, None
        except Exception:
            LOG.exception("Error while running function '%s'", getattr(job_func, 'func_name', str(job_func)))
            self._job_failed(job_name=job_name, stop_on_error=stop_on_error)
            # NOTE: If we reach here and stop on error wasn't called, lets continue.
            return False, None
        finally:
            if job_debug:
                LOG.debug("Job [%s] %s exited", job_name, job_func)

        if stop_on_exit and self.get_state() != ServiceState.Stopped:
            LOG.exception("Job exited when it shouldn't while running function '%s'",
                          getattr(job_func, 'func_name', str(job_func)))
            self._job_failed(job_name=job_name, stop_on_error=stop_on_error)
            return False, ret

        return True, ret

    def _run_periodical(self, func, time_period, stop_on_error=True, spawn_name=None,
                        cleanup_timeout=JOB_CLEANUP_TIMEOUT, *args, **kwargs):
        """
        Runs a function periodically.
        Use only after the service is started (self.get_state() == ServiceState.Started), otherwise the periodical
        stops immediately.
        """
        if time_period is None:
            raise ValueError("_run_periodical needs time_period")

        get_time_period = lambda: time_period
        spawn_name = spawn_name or func.__name__
        LOG.debug("Starting new periodical service callback named '%s' under service '%s' with time period %s",
                  spawn_name, self.name, time_period)

        # placeholder for the actual job
        self._jobs[spawn_name] = self.EMPTY_JOB

        spawn = spawn_named(name=spawn_name, func=self.__periodical_runner, period_func=func,
                            job_name=spawn_name, get_time_period=get_time_period, stop_on_error=stop_on_error,
                            *args, **kwargs)
        job = JobInfo(spawn=spawn, id=id(spawn), name=spawn_name, func=func, cleanup_timeout=cleanup_timeout)

        LOG.debug("Periodic job [id: %d, %s] is %r", job.id, spawn_name, func)
        self._jobs[spawn_name] = job
        return job

    def _stop_job(self, job, cleanup_timeout=None):
        if cleanup_timeout is None:
            cleanup_timeout = job.cleanup_timeout
        self._wait_job(job, timeout=cleanup_timeout)

    def _wait_job(self, job, timeout=None, kill=False):
        LOG.debug("Wait for job: '%s' [job id: %d, timeout=%r]", job.name, job.id, timeout)
        if not job.spawn or job.spawn.dead:
            LOG.debug("Job '%s' already dead", job.name)
            self.__remove_job(job_name=job.name)
            return

        elif kill or (timeout == 0):
            self.__kill_job(job)
            LOG.debug("job is killed: '%s' [job id: %d]", job.name, job.id)
            self.__remove_job(job_name=job.name)
            return

        try:
            if timeout is None:
                job.spawn.wait()
            elif timeout > 0:
                eventlet.with_timeout(seconds=timeout,
                                      function=job.spawn.wait)
        except eventlet.timeout.Timeout:
            if timeout:
                LOG.warning("Timeout (%2.2f seconds) during wait job: '%s' [job id: %d]", timeout, job.name, job.id)
            self.__kill_job(job)
        except (SystemExit, KeyboardInterrupt):
            LOG.info("Service wait interrupted")
            raise
        except Exception:
            LOG.exception("Job Exit with exception. (continue) '%s' [job id: %d]", job.name, job.id)
        finally:
            LOG.debug("job is done: '%s' [job id: %d]", job.name, job.id)

        self.__remove_job(job_name=job.name)

    @staticmethod
    def __kill_job(job):
        if not job.spawn or job.spawn.dead:
            return

        try:

            job.spawn.kill(JobStopException("Job was stopped"))
        except (JobStopException, SystemExit):
            pass

    def __remove_job(self, job_name):
        if job_name in self._jobs:
            LOG.debug("Remove job %s for service %s", job_name, self.name)
            del self._jobs[job_name]
        else:
            LOG.debug("Job %s not found for service:%s", job_name, self.name)

    @abstractmethod
    def _job_failed(self, job_name, stop_on_error):
        LOG.warning("Failed to run service %s job %s", self.name, job_name)
