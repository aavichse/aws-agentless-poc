from collections import namedtuple


DnsAddressDetails = namedtuple("DnsAddressDetails", ('address_name', 'address_type', 'address_class'))
DnsAddressInfo = namedtuple("DnsAddressInfo", ('response_sender_ip', 'new_addresses', 'answer_types', 'answer_ttls'))


class TransactionAddressInfoCollection(object):
    """
    simple class (practically struct) for holding all the information of one transaction as seen from
    the received packets
    """
    __slots__ = ["transaction_id", "src_ip", "query", "dns_arrival_time",
                 "answers_infos", "unknown_address_responders", "dst_ips"]

    def __init__(self, transaction_id=None, src_ip=None, query=None, dns_arrival_time=None):
        # The transaction id
        self.transaction_id = transaction_id
        # The src ip - the ip who sent the request
        self.src_ip = src_ip
        # The information of the request (should be a DnsAddressDetails)
        self.query = query
        # time the packet was captured(and NOT when this object was created)
        self.dns_arrival_time = dns_arrival_time
        # Information on the answers - (should be a list of DnsAddressInfo)
        self.answers_infos = []
        # List of ips that responded with failed response
        self.unknown_address_responders = []
        # List of ips of the destination servers (used to check what respond packets have not arrived)
        self.dst_ips = []

    def to_dict(self):
        # useful before sending via rabbit
        return {"transaction_id": self.transaction_id,
                "src_ip": self.src_ip,
                "query": self.query,
                "answers_infos": self.answers_infos,
                "unknown_addresses": self.unknown_address_responders,
                "dst_ips": self.dst_ips,
                "dns_arrival_time": self.dns_arrival_time}

    @classmethod
    def from_dict(cls, attributes_dict):
        new_obj = TransactionAddressInfoCollection(transaction_id=attributes_dict["transaction_id"],
                                                   src_ip=attributes_dict["src_ip"],
                                                   query=DnsAddressDetails(*attributes_dict["query"]),
                                                   dns_arrival_time=attributes_dict["dns_arrival_time"])
        new_obj.dst_ips = attributes_dict["dst_ips"]
        # named tuples are transmitted to lists when they are jsoned
        new_obj.answers_infos = []
        for answers_info in attributes_dict["answers_infos"]:
            new_obj.answers_infos.append(DnsAddressInfo(*answers_info))
        new_obj.unknown_address_responders = attributes_dict["unknown_addresses"]
        return new_obj
