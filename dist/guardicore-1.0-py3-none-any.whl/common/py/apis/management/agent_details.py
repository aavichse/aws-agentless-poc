from enum import IntEnum

import attr
from common.py.apis import AgentComponentType
from common.py.events.agent import AgentStatusFlagType
from common.py.events.mitigation.machine_details import AgentInstallationMode
from common.py.events.visibility.enforcement_policy import EnforcementPolicyDerivationType
from common.py.models.events import AgentEventSeverity
from common.py.utils.attr_base import AttrBase

__author__ = 'Amit'


class StatusFlagSeverity(IntEnum):
    INFORMATION = 0
    WARNING = 10
    ERROR = 20


class StatusFlagRaisedBy(IntEnum):
    AGGREGATOR = 0
    MANAGEMENT = 1
    COLLECTOR = 2


def get_agent_event_severity_for_agent_flag_severity(flag_severity):
    """
    Convert between status flag severity and agent event severity.
    """
    agent_status_flag_severity_to_agent_event_severity = {
        StatusFlagSeverity.INFORMATION: AgentEventSeverity.INFO,
        StatusFlagSeverity.WARNING: AgentEventSeverity.WARNING,
        StatusFlagSeverity.ERROR: AgentEventSeverity.ERROR
    }

    return agent_status_flag_severity_to_agent_event_severity.get(flag_severity, AgentEventSeverity.DEBUG)


class AgentModuleState(IntEnum):
    NOT_INSTALLED = 0
    DISABLED = 1
    INSTALLED = 2


class AgentModuleStatus(IntEnum):
    UNKNOWN = 0
    INITIALIZING = 1
    RUNNING = 2
    STOPPED = 3
    ERROR = 4
    STOPPING = 5
    ASSETSHUTDOWN = 6


class AgentStatus(IntEnum):
    ONLINE = 0
    OFFLINE = 1


class AgentType(IntEnum):
    ENDPOINT = 0  # Akamai Zero Trust Client (EAA)
    WORKLOAD = 1

    @classmethod
    def installation_mode_to_agent_type(cls, installation_mode):
        if installation_mode == AgentInstallationMode.AZTC.value:
            return cls.ENDPOINT
        elif installation_mode == AgentInstallationMode.DEFAULT.value:
            return cls.WORKLOAD


class AdminLockState(IntEnum):
    UNLOCKED = 0
    LOCKED = 1
    UNSET = 2

    def is_effective_value(self):
        return self in [self.UNLOCKED, self.LOCKED]


class ConfigurationOverrideStatus(IntEnum):
    APPLIED = 0
    OUTDATED = 1
    PARTIAL = 2
    PENDING = 3


DEFAULT_INSTALLATION_PROFILE_NAME = 'default'


@attr.s
class StatusFlagDetails(AttrBase):
    pass


@attr.s(frozen=True)
class PolicyDerivationIssue(AttrBase):
    name = attr.ib(type=str, default=None)
    description = attr.ib(type=str, default=None)
    rules_count = attr.ib(type=str, default=None)
    rules = attr.ib(type=list, default=[])

    @classmethod
    def from_dict(cls, data):
        return cls(**data)


@attr.s(frozen=True)
class PolicyFlagDetails(StatusFlagDetails):
    agent_policy_revision = attr.ib(type=str, default=None)
    latest_policy_revision = attr.ib(type=str, default=None)
    agent_dc_inventory_revision = attr.ib(type=str, default=None)
    latest_dc_inventory_revision = attr.ib(type=str, default=None)
    reasons = attr.ib(type=list, default=[])


@attr.s(frozen=True)
class StatusFlags(AttrBase):
    description = attr.ib(type=str, default='')
    severity = attr.ib(type=StatusFlagSeverity, default=StatusFlagSeverity.INFORMATION,
                       converter=StatusFlagSeverity)
    details = attr.ib(type=dict, default=attr.Factory(dict))
    raised_by = attr.ib(type=StatusFlagRaisedBy, default=StatusFlagRaisedBy.AGGREGATOR, converter=StatusFlagRaisedBy)

    @classmethod
    def from_dict(cls, data):
        return cls(**data)


def convert_flags(raw_flags):
    flags = {}
    for flag_type, flag_data in raw_flags.items():
        if not isinstance(flag_data, StatusFlags):
            flag_data = StatusFlags.from_dict(flag_data) if flag_data else None
        flags[AgentStatusFlagType(int(flag_type))] = flag_data
    return flags


@attr.s(frozen=True)
class ModuleStatus(AttrBase):
    state = attr.ib(type=AgentModuleState, converter=AgentModuleState)
    status = attr.ib(type=AgentModuleStatus, converter=AgentModuleStatus)
    flags = attr.ib(default=attr.Factory(dict),             # type: {AgentStatusFlagType: StatusFlags}
                    converter=convert_flags)
    dump_present = attr.ib(type=bool, default=False)

    @classmethod
    def from_dict(cls, data):
        return cls(**data)


def convert_enum_or_none(enum_type):
    def convert_func(enum_value):
        if enum_value is None:
            return None

        return enum_type(enum_value)

    return convert_func


def convert_features(raw_features):
    return [int(feature) for feature in raw_features]


@attr.s(frozen=True)
class ModuleDetails(AttrBase):
    aggregator_component_id = attr.ib(default=None, type=str)
    policy_revision = attr.ib(default=None, type=str)
    dc_inventory_revision = attr.ib(default=None, type=str)
    policy_derivation_type = attr.ib(default=EnforcementPolicyDerivationType.Layer4,
                                     type=EnforcementPolicyDerivationType, converter=EnforcementPolicyDerivationType)
    full_path_enforcement = attr.ib(default=False)
    implicit_rules = attr.ib(default=[])  # not used anymore
    not_rules_support = attr.ib(default=False)
    domain_name = attr.ib(default=None, type=str)
    user_groups_support = attr.ib(default=False)
    dns_enforcement_support = attr.ib(default=False)
    ipv6_enforcement_support = attr.ib(default=False)
    supported_features = attr.ib(default=attr.Factory(list), converter=convert_features)
    adminlock_override = attr.ib(type=AdminLockState, default=AdminLockState.UNSET)
    adminlock_effective_state = attr.ib(type=AdminLockState, default=AdminLockState.UNSET)
    dns_security_support = attr.ib(default=False)
    win_service_support = attr.ib(default=False)
    access_internal_status = attr.ib(type=str, default="UNKNOWN")

    @classmethod
    def from_dict(cls, data):
        return cls(**data)


def convert_modules_status(raw_modules_status):
    return {AgentComponentType(int(module_type)): module_status if isinstance(module_status, ModuleStatus) else ModuleStatus.from_dict(module_status)
            for module_type, module_status in raw_modules_status.items()}


def convert_module_details(raw_module_details):
    if raw_module_details is None:
        raw_module_details = {}

    if isinstance(raw_module_details, ModuleDetails):
        return raw_module_details

    return ModuleDetails.from_dict(raw_module_details)


@attr.s()
class AgentDetails(AttrBase):
    agent_id = attr.ib(type=str)
    module_type = attr.ib(type=AgentComponentType, converter=AgentComponentType)
    module_details = attr.ib(default=attr.Factory(dict),
                             type=ModuleDetails, converter=convert_module_details)
    flags = attr.ib(default=attr.Factory(dict),             # type: {AgentStatusFlagType: StatusFlags}
                    converter=convert_flags)
    modules_status = attr.ib(default=attr.Factory(dict),    # type: {AgentComponentType: ModuleStatus}
                             converter=convert_modules_status)
    installation_profile = attr.ib(type=str, default=None)
    agent_bundle_version = attr.ib(type=str, default=None)
    agent_bundles_status = attr.ib(type=dict, default=attr.Factory(dict))
    agent_start_time = attr.ib(type=int, default=None)

    @classmethod
    def from_dict(cls, data):
        return cls(**data)


class AgentUpgradeStatus(IntEnum):
    PENDING = 1
    IN_PROGRESS = 2
    SUCCESS = 3
    FAILURE = 4
    TIMEOUT = 5
    SKIPPED = 6
    ABORTED = 7

    @classmethod
    def get_finished_statuses(cls):
        return [
            AgentUpgradeStatus.SUCCESS,
            AgentUpgradeStatus.FAILURE,
            AgentUpgradeStatus.TIMEOUT,
            AgentUpgradeStatus.SKIPPED,
            AgentUpgradeStatus.ABORTED,
            ]

    @property
    def is_finished_status(self):
        return self in self.get_finished_statuses()
