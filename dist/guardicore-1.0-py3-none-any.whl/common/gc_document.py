from mongoengine import IntField, Document, DynamicDocument


class GCDocument(Document):
    meta = {
        'abstract': True,
        'auto_create_index': False,
        'indexes': ['doc_version']
    }

    # this should be NOT required or default
    doc_version = IntField()

    @classmethod
    def get_collection(cls):
        return cls._get_collection()

    @classmethod
    def get_collection_name(cls):
        return cls._get_collection_name()

    @classmethod
    def clear_collection(cls):
        cls.get_collection().drop()
        cls.ensure_indexes()


class GCDynamicDocument(DynamicDocument):
    meta = {
        'abstract': True,
        'auto_create_index': False,
        'indexes': ['doc_version']
    }

    # this should be NOT required or default
    doc_version = IntField()

    @classmethod
    def get_collection(cls):
        return cls._get_collection()

    @classmethod
    def get_collection_name(cls):
        return cls._get_collection_name()

    @classmethod
    def clear_collection(cls):
        cls.get_collection().drop()
        cls.ensure_indexes()
