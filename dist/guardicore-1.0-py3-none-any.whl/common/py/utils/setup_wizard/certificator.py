
__author__ = 'Uri'

import os
import sys

BASE_PATH = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
if __name__ == "__main__":
    sys.path.insert(0, BASE_PATH)

import six
import logging
import argparse
from OpenSSL import crypto
from common import get_guardicore_storage_root
from common.py.utils.linux.ip_lib import IPWrapper
from common.py.utils.linux.general import get_hostname
from common.py.model.certificates import DEPLOYMENT_SERVER_SNI_NAME, REVEAL_SERVER_SNI_NAME, DECEPTION_SERVER_SNI_NAME, \
    ENFORCEMENT_SERVER_SNI_NAME, DETECTION_SERVER_SNI_NAME, CONTROLLER_SERVER_SNI_NAME, ENFORCEMENT_GRPC_SERVER_SNI_NAME


TLS_FOLDER_PATH = os.path.join(get_guardicore_storage_root(), 'storage', 'certs', 'tls')
MITIGATION_CAS_CHAIN_FILE_PATH = os.path.join(TLS_FOLDER_PATH, 'mitigation_cas_chain.pem')
CA_DIR = os.path.join(TLS_FOLDER_PATH, 'mitigation_ca')

logging.basicConfig(format="%(asctime)s [%(levelname)s] %(module)s.%(funcName)s.%(lineno)d: %(message)s")

GUARDICORE_CA_FILE = os.path.join(TLS_FOLDER_PATH, 'guardicore_ca.pem')
MITIGATION_CA_CERT_FILE_NAME = os.path.join(CA_DIR, "cert.pem")
MITIGATION_CA_KEY_FILE_NAME = os.path.join(CA_DIR, "key.pem")

DEF_SERVER_CERT_SIGN_ALGO = "sha256"
SERVER_CERT_SIGN_OPTIONS = ["sha1", "sha256"]
DEF_RSA_KEY_SIZE = 2048


def create_chain_file(guardicore_ca_cert_file, aggregator_intermediate_cert_file,
                      aggregator_cas_chain_file):
    if not os.path.isfile(guardicore_ca_cert_file):
        logging.error("Can't find the Guardicore root-CA public certificate file: %s", guardicore_ca_cert_file)
        return False
    elif not os.path.isfile(aggregator_intermediate_cert_file):
        logging.error("Can't find the aggregator intermediate-CA certificate file: %s",
                      aggregator_intermediate_cert_file)
        return False

    if not os.path.isdir(os.path.dirname(aggregator_cas_chain_file)):
        os.makedirs(os.path.dirname(aggregator_cas_chain_file))

    try:
        with open(aggregator_intermediate_cert_file) as mitigation_ca_cert_file_obj, \
                open(guardicore_ca_cert_file) as guardicore_ca_file_obj, \
                open(aggregator_cas_chain_file, "w") as mitigation_cas_chain_file_obj:
            mitigation_cas_chain_file_obj.write(mitigation_ca_cert_file_obj.read())
            mitigation_cas_chain_file_obj.write(guardicore_ca_file_obj.read())
    except IOError as exc:
        logging.error("Failed reading/writing PEM files for creating the chain certificate: %s", exc)
        return False

    logging.debug("Created chain file in '%s'", aggregator_cas_chain_file)

    return True


def get_current_ip_list():
    guests_ips = []
    for device in IPWrapper(root_helper="sudo").get_devices(exclude_loopback=True):
        for ip_addr in device.addr.list():
            if 4 == ip_addr['ip_version']:
                guests_ips.append(ip_addr['cidr'].split("/")[0])
    return guests_ips


def _create_certificate_internal(dst_dir, ca_cert, ca_key, pkey, req, x509_extensions, cert_sign_method,
                                 not_before_nof_days, is_final_dest, cert_name_suffix):
    # Here comes the actual certificate
    cert = crypto.X509()
    cert.set_version(2)
    cert.set_serial_number(1000)
    cert.gmtime_adj_notBefore(not_before_nof_days * (-1) * 24 * 3600)
    cert.gmtime_adj_notAfter(2 * 365 * 24 * 60 * 60)
    cert.set_issuer(ca_cert.get_subject())
    cert.set_subject(req.get_subject())
    cert.set_pubkey(req.get_pubkey())
    cert.add_extensions(x509_extensions)
    cert.sign(ca_key, cert_sign_method)

    pem_cert = crypto.dump_certificate(crypto.FILETYPE_PEM, cert)
    pem_pkey = crypto.dump_privatekey(crypto.FILETYPE_PEM, pkey)

    def _get_pem_path(name, signed_method_suffix=True):
        cert_name = name
        if cert_name_suffix:
            cert_name = "%s.%s" % (name, cert_name_suffix)

        if signed_method_suffix:
            return os.path.join(dst_dir, "%s.pem.%s" % (cert_name, cert_sign_method))
        return os.path.join(dst_dir, "%s.pem" % (cert_name,))

    with open(_get_pem_path("cert"), "wb") as pem_cert_file:
        pem_cert_file.write(pem_cert)
    logging.debug("Generated certificate file: %s", _get_pem_path("cert"))

    with open(_get_pem_path("key"), "wb") as pem_key_file:
        pem_key_file.write(pem_pkey)
    logging.debug("Generated key file: %s", _get_pem_path("key"))

    with open(_get_pem_path("crt"), "wb") as crt_key_file:
        crt_key_file.write(pem_cert + pem_pkey)
    logging.debug("Generated combined crt file (certificate + key): %s", _get_pem_path("crt"))

    if is_final_dest:
        for name in ("cert", "key", "crt"):
            symlink_path = _get_pem_path(name, signed_method_suffix=False)
            if os.path.exists(symlink_path):
                logging.debug("Remove previous symlink %s", symlink_path)
                os.unlink(symlink_path)

            logging.debug("Create certificate symlink at path: %s", symlink_path)
            os.symlink(_get_pem_path(name), symlink_path)


def create_certificate(ca_cert_file_name, ca_key_file_name, dst_dir, guests_ips, alternative_dns_names,
                       not_before_nof_days, cert_sign_methods=None, rsa_key_size=DEF_RSA_KEY_SIZE,
                       cert_name_suffix=""):
    if not cert_sign_methods:
        cert_sign_methods = SERVER_CERT_SIGN_OPTIONS[:]

    with open(ca_cert_file_name, "r") as mitigation_ca_cert_file_obj:
        ca_cert_pem = mitigation_ca_cert_file_obj.read()
    ca_cert = crypto.load_certificate(crypto.FILETYPE_PEM, ca_cert_pem)

    with open(ca_key_file_name, "r") as mitigation_ca_key_file_obj:
        ca_key_pem = mitigation_ca_key_file_obj.read()
    ca_key = crypto.load_privatekey(crypto.FILETYPE_PEM, ca_key_pem)

    guests_ips = guests_ips or []
    try:
        guests_ips += get_current_ip_list()
    except Exception as exc:
        logging.warning("Failed reading interface IPs for this machine: %s", exc)
    logging.debug("Using guest IP's: %s", guests_ips)

    if not alternative_dns_names:
        alternative_dns_names = []
    logging.debug("Using alternative DNS names: %s", alternative_dns_names)

    if not os.path.isdir(dst_dir):
        os.mkdir(dst_dir)
        logging.info("Created destination directory %s", dst_dir)
    else:
        logging.debug("Destination directory already exists %s", dst_dir)

    pkey = crypto.PKey()
    pkey.generate_key(crypto.TYPE_RSA, rsa_key_size)
    req = crypto.X509Req()
    subject = req.get_subject()
    subject.CN = get_hostname()
    subject.countryName = "IL"
    subject.O = "guardicore"
    req.set_pubkey(pkey)
    alternative_names = ["DNS.{}: {}".format(index, name)
                         for index, name in enumerate(set(alternative_dns_names))]
    alternative_names += ["IP:{}".format(ip) for ip in set(guests_ips)]
    base_constraints = ([
        crypto.X509Extension(six.b("keyUsage"), False, six.b("Digital Signature, Non Repudiation, Key Encipherment")),
        crypto.X509Extension(six.b("basicConstraints"), True, six.b("CA:FALSE")),
        crypto.X509Extension(six.b("subjectAltName"), False, ",".join(alternative_names).encode("utf-8")),
    ])
    x509_extensions = base_constraints
    req.add_extensions(x509_extensions)
    req.sign(pkey, "sha256")

    for cert_sign_method in cert_sign_methods:
        _create_certificate_internal(dst_dir=dst_dir, ca_cert=ca_cert, ca_key=ca_key, pkey=pkey, req=req,
                                     x509_extensions=x509_extensions, cert_sign_method=cert_sign_method,
                                     not_before_nof_days=not_before_nof_days,
                                     is_final_dest=(cert_sign_method == DEF_SERVER_CERT_SIGN_ALGO),
                                     cert_name_suffix=cert_name_suffix)

    return True


def certificator(dst_dir, guests_ips, alternative_dns_names, not_before_nof_days=0,
                 guardicore_ca_file=GUARDICORE_CA_FILE,
                 aggregator_intermediate_cert_file=MITIGATION_CA_CERT_FILE_NAME,
                 aggregator_intermediate_key_file=MITIGATION_CA_KEY_FILE_NAME,
                 aggregator_cas_chain_file=MITIGATION_CAS_CHAIN_FILE_PATH,
                 cert_sign_methods=None,
                 cert_name_suffix="",
                 create_intermediate=True):

    logging.debug("Guardicore CA file: %s", guardicore_ca_file)
    logging.debug("Mitigation CA certificate file: %s", aggregator_intermediate_cert_file)
    logging.debug("Mitigation CA key file: %s", aggregator_intermediate_key_file)

    if create_intermediate and \
            not create_chain_file(guardicore_ca_file, aggregator_intermediate_cert_file=aggregator_intermediate_cert_file,
                                  aggregator_cas_chain_file=aggregator_cas_chain_file):
        return False

    return create_certificate(ca_cert_file_name=aggregator_intermediate_cert_file,
                              ca_key_file_name=aggregator_intermediate_key_file, dst_dir=dst_dir, guests_ips=guests_ips,
                              alternative_dns_names=alternative_dns_names, not_before_nof_days=not_before_nof_days,
                              cert_sign_methods=cert_sign_methods,
                              cert_name_suffix=cert_name_suffix)


def main():
    parser = argparse.ArgumentParser(description='Certificator')
    parser.add_argument("-g", "--guests_ips", default=[], type=str, nargs='+',
                        help="Guests ip addresses (space as delimiter)")
    parser.add_argument("-s", "--alternative-dns-names", type=str, nargs='+',
                        help="alternative DNS names (space as delimiter)",
                        default=[DEPLOYMENT_SERVER_SNI_NAME, REVEAL_SERVER_SNI_NAME, DECEPTION_SERVER_SNI_NAME,
                                 ENFORCEMENT_SERVER_SNI_NAME, DETECTION_SERVER_SNI_NAME, CONTROLLER_SERVER_SNI_NAME,
                                 ENFORCEMENT_GRPC_SERVER_SNI_NAME])
    parser.add_argument("-d", "--destination-directory", default=os.path.join(TLS_FOLDER_PATH, "aggregator"),
                        type=str, help="the directory path that the certificate will be located")
    parser.add_argument("-m", "--cert-sign-methods", default=[], choices=SERVER_CERT_SIGN_OPTIONS,
                        type=str, nargs='+', help="methods to use for signing certificates")
    parser.add_argument("-v", "--verbose", action='store_true', default=False,
                        help="print verbose logging for the 'certificator' tool")
    parser.add_argument("-b", "--certificate-valid-before", type=int, default=0,
                        help="the certificate field notBefore will be set to the specified number of days "
                             "before the current time")
    parser.add_argument("-a", "--guardicore-ca-file", type=str, default=GUARDICORE_CA_FILE,
                        help="The Guardicore root-CA public certificate which originally signed the intermediate-CA")
    parser.add_argument("-i", "--aggregator-intermediate-ca-cert-file", type=str, default=MITIGATION_CA_CERT_FILE_NAME,
                        help="The Aggregator intermediate-CA certificate file")
    parser.add_argument("-k", "--aggregator-intermediate-ca-key-file", type=str, default=MITIGATION_CA_KEY_FILE_NAME,
                        help="The Aggregator intermediate-CA key file")
    parser.add_argument("-c", "--aggregator-intermediate-ca-chain-file", type=str,
                        default=MITIGATION_CAS_CHAIN_FILE_PATH,
                        help="The Aggregator intermediate-CA certificate chain output file")
    parser.add_argument("-n", "--cert-name-suffix", type=str,
                        default="",
                        help="extra name to append certificate file")
    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    else:
        logging.getLogger().setLevel(logging.INFO)

    if not certificator(dst_dir=args.destination_directory,
                        guests_ips=args.guests_ips,
                        alternative_dns_names=args.alternative_dns_names,
                        not_before_nof_days=args.certificate_valid_before,
                        guardicore_ca_file=args.guardicore_ca_file,
                        aggregator_intermediate_cert_file=args.aggregator_intermediate_ca_cert_file,
                        aggregator_intermediate_key_file=args.aggregator_intermediate_ca_key_file,
                        aggregator_cas_chain_file=args.aggregator_intermediate_ca_chain_file,
                        cert_sign_methods=args.cert_sign_methods,
                        cert_name_suffix=args.cert_name_suffix):
        logging.error("failed!")
        return 1

    logging.info("done!")
    return 0


if __name__ == "__main__":
    sys.exit(main())
