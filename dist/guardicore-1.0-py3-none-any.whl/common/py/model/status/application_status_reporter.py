from eventlet.semaphore import Semaphore

from common.component_service import ComponentService
from common.py.network.unix_queue import NetSingleDictTransport
from common.py.network.comm_strategy import JsonCommunicationStrategy
from common.py.model.monicore import MONICORE_STATUS_SOCK
from common.py.model.status import APPLICATION_STATUS_KEY, APPLICATION_NAME_KEY
from common.py.model.status.application_lifecycle import ApplicationLifecyclePhase
from common.py.model.status.application_status import ApplicationStatus
from common.py.utils.config import cfg
from common.logger import get_logger

LOG = get_logger(module_name=__name__)

STATUS_REPORTING_OPTS = [
    cfg.IntOpt('status-report-interval', default=30,
               help="Application status report interval to monicore in seconds"),
]

cfg.CONF.register_opts(STATUS_REPORTING_OPTS, group='status')


class ApplicationStatusReporter(ComponentService):
    def __init__(self, app):
        super(ApplicationStatusReporter, self).__init__(name='app-status-reporter')

        self._app = app
        self._monicore_app_name = self._app.get_monicore_app_name()
        self._last_app_status = None
        self._lock = Semaphore(value=1)

    def verify(self):
        pass

    def start(self):
        super(ApplicationStatusReporter, self).start()

        # send initial report on startup
        self.send_status_updates()
        # send reports periodically
        self._run_periodical(func=self.send_status_updates, time_period=cfg.CONF.status.status_report_interval,
                             stop_on_error=False, spawn_name='status_reporter_updates')

    def send_status_updates(self):
        with self._lock:
            if not self._app.app_status:
                app_status = ApplicationStatus(lifecycle_phase=ApplicationLifecyclePhase.FAILED, services_status={
                    'status-reporter': 'Application status has not been initialized'}).to_dict()
            else:
                app_status = self._app.app_status.to_dict()

            if self._status_changed(app_status):
                LOG.info("Application status changed %s", app_status)
            app_status[APPLICATION_NAME_KEY] = self._monicore_app_name

            try:
                NetSingleDictTransport.send_dict(path=MONICORE_STATUS_SOCK, data=app_status,
                                                 communication_strategy=JsonCommunicationStrategy,
                                                 response_expected=False, timeout=30)
                self._last_app_status = app_status
            except:
                LOG.exception("Failed to send status report %s", app_status)

    def _status_changed(self, app_status):
        return not self._last_app_status or \
               self._last_app_status.get(APPLICATION_STATUS_KEY) != app_status.get(APPLICATION_STATUS_KEY)
