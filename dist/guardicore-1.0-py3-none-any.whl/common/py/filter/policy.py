from enum import IntEnum

from netaddr.ip import IPNetwork

from common import logger
from common.py.model.exceptions import GuardicoreException

__author__ = 'Eddie'

LOG = logger.get_logger(module_name=__name__)


class PolicyRuleType(IntEnum):
    Inspect = 1
    Bypass = 2
    Ignore = 3


class BasicPolicy(object):
    __slots__ = ["policy_id"]

    def __init__(self, policy_id):
        self.policy_id = policy_id

    def check(self, matches):
        if matches:
            return True
        return False


class Policy(BasicPolicy):
    __slots__ = ["policy_type", "service_type", "src_ip_net", "dst_ip_net"]

    def __init__(self, policy_id, policy_type, service_type=None,
                 src_ip_net=None, dst_ip_net=None):
        super(Policy, self).__init__(policy_id)
        self.policy_type = policy_type
        self.service_type = service_type or []
        self.dst_ip_net = []
        self.src_ip_net = []

        if src_ip_net is not None:
            for ip in src_ip_net:
                self.src_ip_net.append(IPNetwork(ip))

        if dst_ip_net is not None:
            for ip in dst_ip_net:
                self.dst_ip_net.append(IPNetwork(ip))

    @classmethod
    def from_json(cls, json_policy):
        return Policy(policy_id=json_policy['policy_id'],
                      policy_type=PolicyRuleType[json_policy['policy_type']],
                      service_type=json_policy.get('service_type'),
                      src_ip_net=json_policy.get('src_ip_net'),
                      dst_ip_net=json_policy.get('dst_ip_net'))

    def check(self, packet_data):
        """
        Compare IPNetwork in src_ip_net[] and dst_ip_net[] to packet_data IPs
          Note that src_ip_net and dst_ip_net will always have 1 element in them
        Compare each Port in service_type[] to packet_data port
        :type packet_data: PacketInspectionData
        """

        # Check Policy is in correct format
        if len(self.src_ip_net) > 1:
            raise GuardicoreException("Invalid Policy - received multiple Source IP's")

        if len(self.dst_ip_net) > 1:
            raise GuardicoreException("Invalid Policy - received multiple Destination IP's")

        if packet_data.src_ip_addr is not None and self.src_ip_net and \
                packet_data.src_ip_addr not in self.src_ip_net[0]:
            return False

        if packet_data.dst_ip_addr is not None and self.dst_ip_net and \
                packet_data.dst_ip_addr not in self.dst_ip_net[0]:
            return False

        if self.service_type and packet_data.service_type not in self.service_type:
            return False

        return True

    def __repr__(self):
        return "Policy(policy_id=%s, policy_type=%s, service_type=%s, src_ip_net=%s, dst_ip_net=%s)" % \
               (self.policy_id, self.policy_type, self.service_type,
                self.src_ip_net, self.dst_ip_net)
