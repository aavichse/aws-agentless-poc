"""
NOTE:
Any change in this file should be copied to: honeypot/hp_vm/dsm/linux_dsm/sources/pam_python/xauth
"""

from collections import Hashable


class ReversibleEnum(object):
    @classmethod
    def reverse_dict(cls):
        if getattr(cls, '_rdict', None) is None:
            cls._rdict = {v: k for k, v in cls.__dict__.items()
                          if isinstance(v, Hashable) and not isinstance(v, classmethod) and not hasattr(ReversibleEnum, k)}
        return cls._rdict

    @classmethod
    def reverse(cls, value, default='<Unknown %(class_name)s (%(value)d)>'):
        # Return the value's name, or "<Unknown MyEnum (123)>"
        return cls.reverse_dict().get(value, cls._format_default(value, default))

    @classmethod
    def reverse_flags(cls, value, default='<Unknown %(class_name)s (0x%(value)x)>'):
        return ([k for v, k in cls.reverse_dict().items() if v != 0 and (value & v) == v] or
                [cls._format_default(value, default)])

    @classmethod
    def _format_default(cls, value, default):
        return default % {'class_name': cls.__name__, 'value': value}
