__author__ = 'ofri'


class StatisticsException(Exception):
    pass