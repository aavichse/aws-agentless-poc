import os


def is_runtime_saas():
    saas = os.environ.get('SAAS')
    return saas is not None


def get_namespace_name():
    namespace = os.environ.get('NAMESPACE_NAME', "no_namespace")
    return namespace