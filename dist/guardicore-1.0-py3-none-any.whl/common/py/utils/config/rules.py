import re

from enum import IntEnum
from common.py.models.events import EventSeverity
from common.py.events.honeypot import FsEntityType, FileChangeOperation, FileDeleteOperation, FileReadOperation, \
    FileExecuteOperation, FileCreateOperation, FileRenameOperation, FileHardlinkOperation, FileTruncateOperation, \
    FilePermissionChangeOperation, FileOwnerChangeOperation, OperationType, ReportFileOperation
from common.py.utils.config import types, cfg
from common.py.utils.config.types import Structure, six

__author__ = 'shelef'


RULES_OPT_NAME = 'rules'  # opt name for rules to pass to HPVM
REGISTRY_RULES_GROUP_NAME = 'WindowsRegistryReportPlugin'

IGNORE_OPT_NAME = 'ignore_list'
LINUX_FS_GROUP_NAME = 'LinuxFSReportPlugin'


class Hive(IntEnum):
    MACHINE = 1
    USER = 2
    A = 3


class MatchTypes(IntEnum):
    Normal = 0
    CaseSensitive = 1
    RegularExpression = 2


def build_match(path, match_type):
    if match_type is MatchTypes.RegularExpression:
        if path.startswith("(?i)"):
            regex = path.replace("(?i)", "(?i)^", 1) + "$"
        else:
            regex = "^" + path + "$"

    elif match_type is MatchTypes.CaseSensitive:
        regex = "^" + re.escape(path) + "$"

    elif match_type is MatchTypes.Normal:
        regex = "(?i)^" + re.escape(path) + "$"

    else:
        raise ValueError('Invalid match type: %s' % match_type)

    return re.compile(regex)


CLASS_TO_OPERATION = {
    FileChangeOperation: "write",
    FileDeleteOperation: "delete",
    FileReadOperation: "read",
    FileExecuteOperation: "execute",
    FileCreateOperation: "create",
    FileRenameOperation: "rename",
    FileHardlinkOperation: "hardlink",
    FileTruncateOperation: "truncate",
    FilePermissionChangeOperation: "chmod",
    FileOwnerChangeOperation: "chown",
    ReportFileOperation: "report"
    }

FILE_RULE_STRUCTURE = Structure([cfg.Opt('name', type=types.String(),
                                         help="Rule name"),
                                 cfg.Opt('path', type=types.String(), required=True,
                                         help="Path to match"),
                                 cfg.Opt('type',
                                         type=types.String(choices=[MatchTypes.Normal.name,
                                                                    MatchTypes.CaseSensitive.name,
                                                                    MatchTypes.RegularExpression.name]),
                                         required=True, default=MatchTypes.RegularExpression.name,
                                         help="Type of match to perform on path"),
                                 cfg.Opt('entity_types',
                                         type=types.List(item_type=types.String(choices=[FsEntityType.File.name,
                                                                                         FsEntityType.Directory.name,
                                                                                         FsEntityType.SymLink.name]),
                                                         bounds=True),
                                         default=[FsEntityType.File.name]),
                                 cfg.Opt('process', type=types.String(), help="Process RegEx"),
                                 cfg.Opt('priority', type=types.Integer(min=0), default=500,
                                         help="Rule application priority (0 is highest)"),
                                 cfg.Opt('operations',
                                         type=types.List(item_type=types.String(choices=list(CLASS_TO_OPERATION.values())),
                                                         bounds=True), default=[]),
                                 cfg.SeverityOpt(default=EventSeverity.Low.name,
                                                 help="Severity of this rule")])


class FileRule(object):
    def __init__(self, path=None, type=MatchTypes.RegularExpression.name, process=None, entity_types=None,
                 operations=None, priority=0, name="", severity=EventSeverity.Low):
        self._priority = priority
        self.name = name
        self.severity = severity
        self._path = build_match(path, getattr(MatchTypes, type)) if path is not None else None
        self._process = build_match(process, MatchTypes.RegularExpression) if process is not None else None
        self._entity_types = entity_types
        self._operations = operations

    def matches(self, entity_type=None, path=None, process=None, operation=None):
        if any([self._entity_types and entity_type not in self._entity_types,
                self._operations and operation not in self._operations,
                self._path and not self._path.match(six.text_type(path)),
                self._process and not self._process.match(six.text_type(process))]):
            return False
        return True

    def __eq__(self, other):
        return self._priority == other._priority

    def __lt__(self, other):
        return self._priority < other._priority

    def __hash__(self):
        return hash((self._priority, self._path, self._process, self._entity_types, self._operations))

    def __repr__(self):
        return "FileRule(path=%r, process=%r, entity_types=%r, operations=%r, priority=%r, name=%r)" % \
               (self._path, self._process, self._entity_types, self._operations, self._priority, self.name)


class FileRuleSet(object):
    def __init__(self, ruleset):
        assert isinstance(ruleset, list)

        self._ruleset = ruleset
        self._ruleset.sort()

    def matches(self, entity_type=None, path=None, process=None, operation=None):
        for rule in self._ruleset:
            if rule.matches(entity_type=entity_type, path=path, process=process, operation=operation):
                return rule

        return None

    def __repr__(self):
        return "FileRuleSet(%s)" % ", ".join(map(repr, self._ruleset))

    @classmethod
    def from_config(cls, config):
        return cls([FileRule(**rule) for rule in config])


COMMAND_RULE_STRUCTURE = Structure([cfg.Opt('name', type=types.String()),
                                    cfg.Opt('commands', type=types.String()),
                                    cfg.Opt('arguments', type=types.String()),
                                    cfg.SeverityOpt(default=EventSeverity.Low.name, help="Severity of this rule")])


class CommandRule(object):
    def __init__(self, commands=None, arguments=None, name="", severity=EventSeverity.Low):
        self.name = name
        self._commands = build_match(commands, MatchTypes.RegularExpression) if commands else None
        self._arguments = build_match(arguments, MatchTypes.RegularExpression) if arguments else None
        self.severity = severity

    def matches(self, command=None, arguments=None):
        if isinstance(arguments, (list, tuple)):
            arguments = " ".join(arguments)

        if any([self._commands and not self._commands.match(six.text_type(command)),
                self._arguments and not self._arguments.match(six.text_type(arguments))]):
            return False
        return True

    def __hash__(self):
        return hash((self._commands, self._arguments))

    def __repr__(self):
        return "%s(commands=%r, arguments=%r, name=%r)" % (self.__class__.__name__,
                                                           self._commands.pattern if self._commands else None,
                                                           self._arguments.pattern if self._arguments else None,
                                                           self.name)


class CommandRuleSet(object):
    def __init__(self, ruleset):
        assert isinstance(ruleset, list)

        self._ruleset = ruleset

    def matches(self, command=None, arguments=None):
        for rule in self._ruleset:
            if rule.matches(command=command, arguments=arguments):
                return rule

        return None

    def __repr__(self):
        return "%s(%s)" % (self.__class__.__name__, ", ".join(map(repr, self._ruleset)))

    @classmethod
    def from_config(cls, config):
        return cls([CommandRule(**rule) for rule in config])


def find_matching_rule_name(rules, ids):
    """ helper method to get suspicious mask name from list of rules given matching rule ids of a registry event """
    for rule in rules:
        if rule.rule_id in ids:
            return rule.name


REGISTRY_MASK_STRUCTURE = Structure([cfg.Opt('rule_id', type=types.Integer(), required=True),
                                     cfg.Opt('name', type=types.String(), help="Registry rule name"),
                                     cfg.Opt('reg_path', type=types.String(), help="Regex of registry path to mask"),
                                     cfg.Opt('hives',
                                             type=types.List(item_type=types.String(choices=[
                                                 Hive.MACHINE.name,
                                                 Hive.USER.name
                                             ]), bounds=True), help="Registry hives masked by this rule"),
                                     cfg.Opt('process', type=types.String(),
                                             help="Regex of process paths masked by this rule"),
                                     cfg.Opt('access_types',
                                             type=types.List(item_type=types.String(choices=[
                                                 OperationType.Access.name,
                                                 OperationType.Create.name,
                                                 OperationType.Change.name,
                                                 OperationType.Delete.name
                                             ]), bounds=True), help="Operations masked by this rule")])


class RegistryRule(object):
    def __init__(self, rule_id, name=None, reg_path=None, hives=None, process=None, access_types=None):
        self.rule_id = rule_id
        self.name = name

        self._reg_path = build_match('(?i)' + reg_path, MatchTypes.RegularExpression) if reg_path is not None else None
        self._process = build_match(process, MatchTypes.RegularExpression) if process is not None else None
        self._access_types = map(OperationType.__getitem__, access_types) if access_types is not None else None
        self._hives = map(Hive.__getitem__, hives) if hives is not None else None

    def matches(self, hive=None, access_type=None, reg_path=None, process=None):
        if any([self._hives and hive not in self._hives,
                self._access_types and access_type not in self._access_types,
                self._reg_path and not self._reg_path.match(six.text_type(reg_path)),
                self._process and not self._process.match(six.text_type(process))]):
            return False
        return True

    def __repr__(self):
        return "%s(rule_id=%r, name=%r, reg_path=%r, hives=%r, process=%r, access_types=%r)" % \
               (self.__class__.__name__, self.rule_id, self.name, self._reg_path.pattern if self._reg_path else None,
                self._hives, self._process if self._process else None, self._access_types)


class RegistryRuleSet(object):
    def __init__(self, ruleset):
        assert isinstance(ruleset, list)

        self._ruleset = ruleset

    def matches(self, hive=None, access_type=None, reg_path=None, process=None):
        for rule in self._ruleset:
            if rule.matches(hive, access_type, reg_path, process):
                return rule

        return None

    def __repr__(self):
        return "%s(%s)" % (self.__class__.__name__, ", ".join(map(repr, self._ruleset)))

    @classmethod
    def from_config(cls, config):
        return cls([RegistryRule(**rule) for rule in config])


DNS_RULE_STRUCTURE = Structure([cfg.Opt('name', type=types.String()),
                                cfg.Opt('domain_name', type=types.String()),
                                cfg.Opt('process', type=types.String(),
                                        help="Regex of process paths masked by this rule"),
                                cfg.SeverityOpt(default=EventSeverity.Low.name, help="Severity of this rule")])


class DomainRule(object):
    def __init__(self, domain_name=None, process=None, name="", severity=EventSeverity.Low):
        self.name = name
        self._domain_name = build_match('(?i)' + domain_name, MatchTypes.RegularExpression) if domain_name else None
        self._process = build_match('(?i)' + process, MatchTypes.RegularExpression) if process else None
        # The severity is not used automatically. one can actively set the incident's severity according to this one.
        self.severity = severity

    def matches(self, domain_name=None, process=None):
        if any([self._domain_name and not self._domain_name.match(six.text_type(domain_name)),
                self._process and not self._process.match(six.text_type(process))]):
            return False
        return True

    def __hash__(self):
        return hash((self._domain_name, self._process))

    def __repr__(self):
        return "%s(domain_name=%r, process=%r, name=%r)" % (self.__class__.__name__,
                                                            self._domain_name.pattern if self._domain_name else None,
                                                            self._process.pattern if self._process else None,
                                                            self.name)


class DomainRuleSet(object):
    def __init__(self, ruleset):
        assert isinstance(ruleset, list)

        self._ruleset = ruleset

    def matches(self, domain_name=None, process=None):
        for rule in self._ruleset:
            if rule.matches(domain_name=domain_name, process=process):
                return rule

        return None

    def __repr__(self):
        return "%s(%s)" % (self.__class__.__name__, ", ".join(map(repr, self._ruleset)))

    @classmethod
    def from_config(cls, config):
        return cls([DomainRule(**rule) for rule in config])
