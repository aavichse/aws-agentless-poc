import os
from urllib import parse as urlparse
from common.logger import get_logger

# Proxy protocol -> Environment env variable
from common.py.model.exceptions import GuardicoreException

PROXY_PROTOCOL_MAPPING = {'http': 'http_proxy',
                          'https': 'https_proxy'}

LOGGER = get_logger()


class ProxyUnsupportedType(GuardicoreException):
    def __init__(self, proxy_url):
        super(ProxyUnsupportedType, self).__init__("Proxy type is not supported for URL {}".format(proxy_url))


class HttpProxyEnvironment(object):
    def __init__(self, proxy_url):
        self.proxy_url = proxy_url
        self.saved_proxy_env_vars = {}

    def __enter__(self):
        if not self.proxy_url or self.saved_proxy_env_vars:
            return

        if not HttpProxyEnvironment.is_proxy_url(self.proxy_url):
            raise ProxyUnsupportedType(self.proxy_url)

        if '=' in self.proxy_url:
            # proxy_url example: https_proxy=http://proxyhost:3128
            proxy_env_var, proxy_url = self.proxy_url.split('=', 1)
            proxy_env_var = proxy_env_var.lower()
            if proxy_env_var not in PROXY_PROTOCOL_MAPPING.values():
                raise ProxyUnsupportedType(proxy_url)
        else:
            # proxy_url example: https://proxyhost:3128
            proxy_protocol = self.proxy_url.lower().split(':', 1)[0]
            proxy_env_var = PROXY_PROTOCOL_MAPPING[proxy_protocol]
            proxy_url = self.proxy_url

        self._saved_predefined_proxy(proxy_env_var)
        os.environ[proxy_env_var] = proxy_url

        LOGGER.info('Using proxy {} with URL: {}'.format(proxy_env_var, proxy_url))

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._restore_predefined_proxy()

    def _saved_predefined_proxy(self, proxy_env_var):
        self.saved_proxy_env_vars[proxy_env_var] = None
        for cur_proxy_env_var in PROXY_PROTOCOL_MAPPING.values():
            existing_proxy_url = os.environ.get(cur_proxy_env_var)
            if existing_proxy_url:
                self.saved_proxy_env_vars[cur_proxy_env_var] = existing_proxy_url

        if any(self.saved_proxy_env_vars.values()):
            LOGGER.warning('Existing proxy detected, saving existing proxy configuration: {}'.format(self.saved_proxy_env_vars))

    def _restore_predefined_proxy(self):
        if not self.proxy_url:
            return

        LOGGER.info('Restoring existing proxy configuration: {}', self.saved_proxy_env_vars)
        for cur_proxy_env_var, proxy_url in self.saved_proxy_env_vars.items():
            if proxy_url:
                os.environ[cur_proxy_env_var] = proxy_url
            else:
                os.environ.pop(cur_proxy_env_var, None)
        self.saved_proxy_env_vars.clear()

    @staticmethod
    def is_proxy_url(url):
        if not url:
            return True

        if '=' in url:
            proxy_env_var, url = url.lower().split('=', 1)
            if proxy_env_var not in PROXY_PROTOCOL_MAPPING.values():
                raise ProxyUnsupportedType(url)

        token = urlparse.urlparse(url)
        min_attributes = ('scheme', 'netloc')
        if not all([getattr(token, attr) for attr in min_attributes]):
            return False

        if token.scheme not in PROXY_PROTOCOL_MAPPING:
            return False

        return True
