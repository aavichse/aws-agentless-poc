'''
Created on Oct 5, 2014

@author: itamar
'''

from common.py.model.system import OperatingSystem


class VmInfo(object):
    def __init__(self, name, os_type=None):
        if os_type is None:
            os_type = OperatingSystem.Unknown

        assert isinstance(os_type, OperatingSystem), \
            "Invalid type for os_type: %r" % (type(os_type), )

        self.name = name
        self.os_type = os_type
