__author__ = 'Eddie'

import subprocess


class IPRoute2(object):
    IP_BIN = "/sbin/ip"

    @staticmethod
    def link_add_veth(peer1, peer2):
        subprocess.call(("%s link add %s type veth peer name %s" % (IPRoute2.IP_BIN, peer1, peer2)).split())

    @staticmethod
    def link_add_dummy(dummy):
        subprocess.call(("%s link add %s type dummy" % (IPRoute2.IP_BIN, dummy)).split())

    @staticmethod
    def link_set(iface, options):
        subprocess.call(("%s link set %s" % (IPRoute2.IP_BIN, options)).split())

    @staticmethod
    def link_set_name(src, dst):
        subprocess.call(("%s link set %s name %s" % (IPRoute2.IP_BIN, src, dst)).split())

    @staticmethod
    def link_set_down(iface):
        subprocess.call(("%s link set %s down" % (IPRoute2.IP_BIN, iface)).split())

    @staticmethod
    def link_set_up(iface):
        subprocess.call(("%s link set %s up" % (IPRoute2.IP_BIN, iface)).split())

    @staticmethod
    def link_del(iface):
        subprocess.call(("%s link del %s" % (IPRoute2.IP_BIN, iface)).split())
