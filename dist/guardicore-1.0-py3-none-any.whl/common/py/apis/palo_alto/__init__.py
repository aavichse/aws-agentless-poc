from common.py.utils.config import cfg
from common.py.utils.config.types import Port

paloalto_opts = [
    cfg.StrOpt('hostname',
               default='',
               required=True),
    cfg.Opt('port',
            type=Port(),
            default=443,
            required=True),
    cfg.StrOpt('username',
               default='admin',
               required=True),
    cfg.StrOpt('password',
               default='',
               secret=True,
               required=True),
    cfg.StrOpt('vsys',
               default='vsys1',
               help='Firewall\'s vsys name must be sent in the API request. vsys1 is the default name.',
               required=True),
    cfg.BoolOpt('register_to_all_pan_firewalls',
                default=True,
                required=True,
                help='Report to all listed firewalls - ignores the firewalls list'),
    cfg.ListOpt('list_of_firewall_serials', default=[],
                help="List of firewall serials for IP registration"),
]

cfg.CONF.register_opts(paloalto_opts, "paloalto")
