from enum import IntEnum

from common.py.utils.config import cfg
from common.py.utils.config.oslo_config import types
from common.py.orchestration.consts import ORCHESTRATION_LABEL_KEY_TRANSLATION_SEPARATOR

__author__ = 'Lior'


class LabelingStrategy(IntEnum):
    Enabled = 0  # All tags will be added as orchestration labels
    Disabled = 1  # All tags will be ignored
    Predefined = 2  # Add only predefined list of tags as orchestration labels


common_opts = [
    cfg.BoolOpt('metadata_labels', help="Enable creation of metadata orchestration labels", default=True),
    cfg.IntOpt('orchestration_full_report_interval', help="Interval in which to run a full report (in seconds)",
               default=1800),
    cfg.BoolOpt('prefer_agents_hostname', help="Use agents hostname for asset", default=False),
    cfg.Opt('amplification_factor', type=types.Integer(min=1, max=6), default=1,
            help="Amplification factor,creates modified data(ip/mac/vm...) till size of assets is equal to "
                 "number of assets that multiplied by factor, default=1 means no amplification at all)")
]

label_opts = [
    cfg.StrOpt('labeling_strategy', help="Provisioning of orchestration tags into asset labels",
               default=LabelingStrategy.Disabled.name, choices=list(LabelingStrategy.__members__.keys())),
    cfg.Opt('predefined_labels', default=[], type=types.List(item_type=types.String(quotes=True), bounds=True),
            help="List of label keys to load from orchestration when labeling strategy is set to predefined. "
                 "Use '/*' at the end to search for prefix (ex: use 'gc_/*' to load all keys that start with 'gc_')"),
    cfg.Opt('label_key_translation', default=[], type=types.List(item_type=types.String(quotes=True), bounds=True),
            help='A list of label keys to translate on import; '
                 'each origin label key should be followed by {0} and the target label key.\n'
                 'For example, "OrchestrationAppName{0}App"'.format(ORCHESTRATION_LABEL_KEY_TRANSLATION_SEPARATOR)),
]
