from common.py.utils.config.oslo_config import cfg, types

DEFAULT_FASTPATH_SERVER_PORT = 8500


DP_OPTS = (
    cfg.IntOpt('fastpath_server_port', default=DEFAULT_FASTPATH_SERVER_PORT),

    # Installed hotplug
    cfg.Opt('tcp_service_ports', type=types.List(item_type=types.Integer(min=1, max=65535)),
            default=[21, 22, 80, 445, 3389, 135, 139, 3306, 1433, 5985, 5986]),

    # Redirect flows
    cfg.IntOpt('redirect_flow_idle_timeout', default=60),
    cfg.IntOpt('redirect_flow_hard_timeout', default=1200),

    # cleanup cycles period
    cfg.IntOpt('logic_cache_cleanup_period', default=60),
    cfg.IntOpt('network_event_aggregation_period', default=600),

    cfg.BoolOpt('enable-connection-sampling', default=True),
)
