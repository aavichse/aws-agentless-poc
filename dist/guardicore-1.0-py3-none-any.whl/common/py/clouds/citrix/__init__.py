from common.py.utils.config import cfg
from common.py.clouds import common_opts, label_opts
from common.py.utils.config.oslo_config import types
from common.py.utils.config.types import Structure

AGGREGATOR_IP_PARAMETER = '(aggregator_ip)'

SINGLE_ADC_STRUCTURE = Structure([cfg.StrOpt('appliance_name', help='appliance name', required=True),
                                  cfg.StrOpt('address',
                                             help='Citrix ADC IP address and NITRO API port, '
                                                  'separated by \':\' (default :443)'),
                                  cfg.StrOpt('user', help='User name for NITRO API'),
                                  cfg.StrOpt('password', secret=True, help='Password for NITRO API')
                                  ],
                                 name='single_citrix_struct')

citrix_opts = [
                  cfg.Opt(name='citrix_adc_list',
                          type=types.List(item_type=SINGLE_ADC_STRUCTURE, bounds=True),
                          default=[]),
                  cfg.IntOpt('session_timeout', default=600, help='Citrix ADC session timeout')
              ] + common_opts

CITRIX_OPT_STRUCTURE = Structure(citrix_opts)


def register_opts():
    cfg.CONF.register_opt(cfg.Opt(name='citrix_configuration', type=CITRIX_OPT_STRUCTURE), group="orchestration")
