from enum import IntEnum


class EnforcementFeatures(IntEnum):
    IPv4 = 1
    TCP = 2
    UDP = 3
    IPv6 = 4
    Layer7Policy = 5
    Layer4Policy = 6
    FullImagePath = 7
    IPBitmap = 8
    NotFlagParsing = 9
    NotFlagEnforcement = 10
    ShortIP = 11
    DcInventoryRevision = 12
    DNSEnforcement = 13
    Groups = 14
    LightRevisionUpdate = 15
    EnforcementMode = 16
    DriverLog = 17
    WindowsFirewallMode = 18
    ICMP = 19
    ContEnforcement = 20
    ProtocolList = 21
    IPv6V31 = 22
    IPv6Enforcement = 23
    IPv6ImplicitRules = 24
    PolicyIndex = 25
    IPv6CidrParseFix = 26
    Roaming = 27
    LidRemoval = 28
    DNSSecurity = 29
    CalicoEnforcement = 30
    MetricsOnly = 31
    WinServices = 32
    KthreadEnforcement = 33
    DNSSecurityCompact = 34
    DriverLogConfSplit = 35
    OffCorporatePolicy = 36
    FastLabelPolicy = 37
    K8sNodeEnforcement = 38
    UserGroups = 39
    OffCorporateMultiIPs = 40
    TrafficEncryption = 41
    UnifiedAgent = 42
    K8sNodeOperatingMode = 43
