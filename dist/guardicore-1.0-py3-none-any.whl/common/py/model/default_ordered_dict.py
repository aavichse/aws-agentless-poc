from collections import OrderedDict
#from aggregator.services.datapath.model.gc_cextensions import OrderedDefaultDict as DefaultOrderedDict

__author__ = 'Eddie'


class DefaultOrderedDict(OrderedDict):
    def __init__(self, default_factory=None, *args, **kwargs):
        if (default_factory is not None and
                not callable(default_factory)):
            raise TypeError('first argument must be callable')
        super(DefaultOrderedDict, self).__init__(*args, **kwargs)
        self.default_factory = default_factory

    def pop_to_start(self, key):
        # python 3 pop to start
        self.move_to_end(key, last=False)

    def __missing__(self, key):
        if self.default_factory is None:
            raise KeyError(key)
        self[key] = value = self.default_factory()
        return value

    def __reduce__(self):
        if self.default_factory is None:
            args = tuple()
        else:
            args = self.default_factory,
        return type(self), args, None, None, self.items()

    def __repr__(self, **kwargs):
        return 'DefaultOrderedDict(%s, %s)' % (self.default_factory,
                                               super(DefaultOrderedDict, self).__repr__(**kwargs))
