from common.py.collection.control.client import AggregatorControlClient


class AggregatorComponentControlClient(AggregatorControlClient):
    def get_configuration_schema(self, **kwargs):
        return self.call_with_reconnect("/component/config-schema", **kwargs)

    def get_aggregator_configuration_schema(self, **kwargs):
        return self.call_with_reconnect("/component/aggr-config-schema", **kwargs)

    def get_configuration(self, **kwargs):
        return self.call_with_reconnect("/component/config", **kwargs)

    def set_configuration(self, new_configuration, **kwargs):
        return self.call_with_reconnect("/component/config", method="POST", json=new_configuration, **kwargs)

    def set_system_configuration(self, new_configuration, **kwargs):
        return self.call_with_reconnect("/component/set_system_configuration", method="POST",
                                        json=new_configuration, **kwargs)

    def get_component_status(self, overall=False, **kwargs):
        return self.call_with_reconnect("/status?overall=%s" % str(overall).lower(), method="GET", **kwargs)

    def get_component_debug_level(self, **kwargs):
        return self.call_with_reconnect("/component/debug_log", method="GET", **kwargs)
        
    def set_component_debug_level(self, debug=True, **kwargs):
        return self.call_with_reconnect("/component/debug_log", method="POST", json={'debug': debug}, **kwargs)

    def flush_aggregator_cache(self, seen_connection_cache=True, seen_ip_cache=True, sampling_cache=True,
                               orchestration_cache=False, containers_cache=True, **kwargs):
        return self.call_with_reconnect("/component/aggregator_cache/flush",
                                        json={'seen_connection_cache': seen_connection_cache,
                                              'seen_ip_cache': seen_ip_cache,
                                              'sampling_cache': sampling_cache,
                                              'orchestration_cache': orchestration_cache,
                                              'containers_cache': containers_cache},
                                        method="POST", **kwargs)

