from functools import wraps

import gevent
from gevent.hub import Hub

from common import logger
from common.py.model.exceptions import GuardicoreException

LOG = logger.get_logger(module_name=__name__)
JOIN_REFRESH_INTERVAL = 10
KILL_TIMEOUT = 10

Hub.NOT_ERROR = tuple(list(Hub.NOT_ERROR) + [KeyboardInterrupt])


def ignore_exceptions(func, title):
    @wraps(func)
    def wrapped_func(*wrapped_args, **wrapped_kwargs):
        try:
            func(*wrapped_args, **wrapped_kwargs)
        except Exception as exc:
            LOG.exception("Exception %r in %s spawn", exc, title)

    return wrapped_func


def cyclic_handler(func, cycle_sleep, *args, **kwargs):
    while True:
        try:
            func(*args, **kwargs)
        except Exception as exc:
            LOG.exception("Got exception in spawn: %r", exc)
            raise
        if cycle_sleep:
            gevent.sleep(cycle_sleep)


class FuncHandler(object):
    def __init__(self, func, *args, **kwargs):
        self.func = func
        self.args = args
        self.kwargs = kwargs

    def convert_to_args(self):
        return [self.func] + list(self.args)


def timeout_wrapper(timeout, func, *args, **kwargs):
    with gevent.Timeout(timeout):
        func(*args, **kwargs)


class EventDispatcher(object):
    def __init__(self):
        super(EventDispatcher, self).__init__()  # We do this for multiple inheritance
        self._spawn_titles = dict()

    def handler_with_cleanup(self, title, func, *args, **kwargs):
        try:
            func(*args, **kwargs)
        except Exception as exc:
            LOG.exception(exc)
            raise
        finally:
            self._spawn_titles.pop(title, None)

    def add_handler(self, title, func, *args, **kwargs):
        if title in self._spawn_titles:
            return
        handler = FuncHandler(func, *args, **kwargs)
        cleanup_args = [title] + handler.convert_to_args()
        spawn = gevent.spawn(self.handler_with_cleanup, *cleanup_args, **handler.kwargs)
        self._spawn_titles[title] = spawn

    def add_handler_with_timeout(self, title, timeout, func, *args, **kwargs):
        if title in self._spawn_titles:
            LOG.debug('Cannot add handler - title: {}, _spawn_titles: {}'.format(title, timeout))
            return
        handler = FuncHandler(func, *args, **kwargs)
        timeout_arg_list = [title, timeout_wrapper, timeout] + handler.convert_to_args()
        spawn = gevent.spawn(self.handler_with_cleanup, *timeout_arg_list, **handler.kwargs)
        self._spawn_titles[title] = spawn

    def add_cyclic_handler_no_sleep_ignore_exceptions(self, title, func, *args, **kwargs):
        return self.add_cyclic_handler_no_sleep(title, ignore_exceptions(func, title), *args, **kwargs)

    def add_cyclic_handler_no_sleep(self, title, func, *args, **kwargs):
        """add_cyclic_handler_no_sleep(func, *args)

        Add the callback function func to the cyclic events called by the
        event handler. The callback is called upon again and again with no
        timeout interval between them. args are passed to the callback.
        """

        if title in self._spawn_titles:
            return
        handler = FuncHandler(func, *args)
        spawn = gevent.spawn(cyclic_handler, handler.func, 0, *handler.args, **kwargs)
        self._spawn_titles[title] = spawn

    def add_cyclic_handler_ignore_exceptions(self, title, func, cycle, *args, **kwargs):
        return self.add_cyclic_handler(title, ignore_exceptions(func, title), cycle, *args, **kwargs)

    def add_cyclic_handler(self, title, func, cycle, *args, **kwargs):
        """add_cyclic_handler(func, cycle, *args)

        Add the callback function func to the cyclic events called by the
        event handler. The callback is called upon every time span 'cycle' and
        args are passed to the callback.
        """
        if title in self._spawn_titles:
            return
        handler = FuncHandler(cyclic_handler, func, cycle, *args, **kwargs)
        spawn = gevent.spawn(handler.func, *handler.args, **kwargs)
        self._spawn_titles[title] = spawn

    def stop_handler(self, title, block=False):
        """stop_handler(handler)

        Remove a handler from the handlers handled by the event dispatched.
        """
        spawn = self._spawn_titles.pop(title, None)
        if spawn:
            LOG.debug("Try to kill (%s) spawn (blocking)", title)
            spawn.kill(block=block)
            LOG.debug("Just killed (%s) spawn", title)

    def add_greenlet(self, title, greenlet):
        self._spawn_titles[title] = greenlet

    def start(self):
        """start()

        Start looping over events and dispatch them one by one.
        """

        if not self._spawn_titles:
            raise GuardicoreException("No events found to start event loop")

        LOG.info("Dispatcher was started, waiting on events")
        while True:
            waiting_on = len(self._spawn_titles)
            done = gevent.joinall(self._spawn_titles.viewvalues(), raise_error=True, timeout=JOIN_REFRESH_INTERVAL)
            if len(done) == waiting_on:
                LOG.info("Done waiting for all %d greenlets", waiting_on)
                break

    def stop(self, block=False, exception=None):
        """stop(block=False)

        Kill all gevent spawns. if block is True, wait for the spawns to finish
        before returning.
        :param block:
        :param exception:
        """

        if exception is None:
            exception = []

        spawns_down = 0
        spawns_count = 0

        # LOG.debug("Stopping all greenlet events:")
        for title in self._spawn_titles.keys():
            if title in exception:
                continue
            spawns_count += 1

            try:
                # we check again because another greenlet might have changed the dict in another context
                if title in self._spawn_titles:
                    spawn = self._spawn_titles.pop(title)
                    spawn.kill(block=block, timeout=KILL_TIMEOUT)
                    LOG.debug("Just killed (%s) spawn", title)
                    spawns_down += 1
            except:
                LOG.debug("Failed to kill %s spawn", title)

        LOG.debug("Killed %d events out of %d, skipped %d", spawns_down, spawns_count, len(self._spawn_titles))
