from common.py.utils.drivers import DriversUtil
from common.py.utils.config import cfg

__author__ = 'Itamar'

default_opts = [
    cfg.StrOpt('non_persistent_config_driver',
               default='common.py.configuration.a.NonPersistentConfigInterface',
               help="Driver for the non-persistent configuration"), ]

cfg.CONF.register_opts(default_opts, "default")


class ConfigInterface(object):
    def __init__(self):
        self._change_listeners = {}

    def listen_for_changes(self, name, callback):
        if not callable(callback):
            raise TypeError("Callback must be callable")

        if "." not in name:
            name = "general." + name

        if not name in self._change_listeners:
            self._change_listeners[name] = []

        self._change_listeners[name].append(callback)

    def _call_config_change_listener(self, config_name, config_new_value):
        try:
            config_old_value = self.get_config_record(config_name)
        except:
            config_old_value = None

        for callback in self._change_listeners[config_name]:
            if config_old_value == config_new_value:
                continue

            try:
                callback(config_name, config_old_value, config_new_value)
            except:
                pass

    def write_config_records(self, **kwargs):
        for config in kwargs:
            if config in self._change_listeners:
                self._call_config_change_listener(config, kwargs[config])

    def write_state_record(self, state):
        config = "state"
        if config in self._change_listeners:
            self._call_config_change_listener(config, state)

    def read_config_records(self):
        raise NotImplementedError()

    def get_config_record(self, name):
        raise NotImplementedError()

    def __getattr__(self, item):
        return self.get_config_record(item)

    def read_state_record(self):
        raise NotImplementedError()


class NonPersistentConfigurationFactory(object):
    """NonPersistentConfigurationFactory()

    Per-iteration configuration (configuration read from the management server).
    """

    config = None

    @staticmethod
    def get_config(**kwargs):
        if not NonPersistentConfigurationFactory.config:
            NonPersistentConfigurationFactory.config = \
                DriversUtil.load_driver(cfg.CONF.default.non_persistent_config_driver,
                                        "non-persistent config",
                                        expected_class=ConfigInterface,
                                        **kwargs)

        return NonPersistentConfigurationFactory.config
