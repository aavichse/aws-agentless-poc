__author__ = 'Izi'


DC_PREFIX = "DC="


class DummyLock(object):
    def __init__(self, value=None):
        pass

    def __call__(self, *args, **kwargs):
        timeout = kwargs.get('timeout', None)
        return self

    def __enter__(self):
        return True

    def __exit__(self, exc_type, exc_val, exc_tb):
        return True


def is_with_domain_name(object_name):
    return '@' in object_name


def split_user_and_domain_name(object_name):
    return tuple(object_name.split('@', 1))


def domain_name_to_dn(domain_name):
    return ",".join(['{}{}'.format(DC_PREFIX, part) for part in domain_name.split('.')])


def domain_name_from_dn(dn):
    return '.'.join(part[len(DC_PREFIX):] for part in dn.split(',')
                    if part.startswith(DC_PREFIX))


def is_sub_domain_of(sub_domain_name, domain_name):
    return '.{}'.format(sub_domain_name).lower().endswith('.{}'.format(domain_name).lower())


def is_same_domain(first_domain_name, second_domain_name):
    return first_domain_name.lower() == second_domain_name.lower()


def get_user_name_with_domain(username, domain_name):
    if is_with_domain_name(username):
        _, user_domain_name = split_user_and_domain_name(username)
        if not is_sub_domain_of(user_domain_name, domain_name):
            return
        return username
    else:
        return u'{}@{}'.format(username, domain_name)
