from enum import IntEnum


class AuthenticationScheme(IntEnum):
    UserPassword = 1
    IntegrationToken = 2
    UserPasswordAndIntegrationToken = 3
