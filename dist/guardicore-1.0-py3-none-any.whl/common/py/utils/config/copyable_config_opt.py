import itertools
from common.py.utils.config.oslo_config.cfg import ConfigOpts
from common.py.utils.encoding.json.json_convert import encode_objects, decode_objects


class CopyableConfig(ConfigOpts):
    DEFAULT_CLI_OPT_NAMES = ('config_file', 'config_dir', 'json_config_file')

    def to_dict(self):
        return {k: getattr(self, k) for k in self.keys() if k not in self.DEFAULT_CLI_OPT_NAMES}

    def to_json(self):
        # Ignore the default cli opts which are added on setup
        cli_opts = [encode_objects(opt) for opt in self._cli_opts if opt['opt'].name.replace("-", "_") not in self.DEFAULT_CLI_OPT_NAMES]

        if bool(self._config_opts):
            call_args = dict(args=self._args,
                             project=self.project,
                             prog=self.prog,
                             version=self.version,
                             usage=self.usage,
                             default_config_files=self.default_config_files,
                             validate_default_values=self._validate_default_values)
            call_args = encode_objects(call_args)
            set_attrs = {k: encode_objects(getattr(self, k)) for k in self.keys()}
        else:
            set_attrs = call_args = None

        return {'cli_opts': cli_opts, 'call_args': call_args, 'set_attrs': set_attrs}

    @classmethod
    def from_json(cls, json_data):
        new = cls()

        if json_data['cli_opts']:
            for cli_opt in json_data['cli_opts']:
                new.register_cli_opt(decode_objects(cli_opt['opt']), cli_opt['group'])

        if json_data['call_args']:
            new(**decode_objects(json_data['call_args']))

        if json_data['set_attrs']:
            for k, v in json_data['set_attrs'].items():
                setattr(new, k, decode_objects(v))
        return new

    def __repr__(self):
        """ for jsonschema purpose - view as a dict """
        return repr(dict((k, getattr(self, k)) for k in self.keys()
                         if k not in self.DEFAULT_CLI_OPT_NAMES))

    def __reduce__(self):
        # Ignore the default cli opts which are added on setup
        cli_opts = [opt for opt in self._cli_opts if opt['opt'].name.replace("-", "_") not in self.DEFAULT_CLI_OPT_NAMES]

        if bool(self._config_opts):
            call_args = dict(args=self._args,
                             project=self.project,
                             prog=self.prog,
                             version=self.version,
                             usage=self.usage,
                             default_config_files=self.default_config_files,
                             validate_default_values=self._validate_default_values)
            set_attrs = {k: getattr(self, k) for k in self.keys()}
        else:
            set_attrs = call_args = None

        return self.__class__, (), (cli_opts, call_args, set_attrs)

    def __setstate__(self, state):
        cli_opts, call_args, set_attrs = state

        if cli_opts:
            for cli_opt in cli_opts:
                self.register_cli_opt(cli_opt['opt'], cli_opt['group'])

        if call_args:
            self(**call_args)

        if set_attrs:
            for k, v in set_attrs.items():
                setattr(self, k, v)

    def __contains__(self, key):
        return (key not in self.DEFAULT_CLI_OPT_NAMES and key in self._opts) or key in self._groups

    def __iter__(self):
        for key in itertools.chain([k for k in self._opts.keys() if k not in self.DEFAULT_CLI_OPT_NAMES],
                                   self._groups.keys()):
            if key not in self.DEFAULT_CLI_OPT_NAMES:
                yield key

    def __len__(self):
        return len([k for k in self._opts if k not in self.DEFAULT_CLI_OPT_NAMES]) + len(self._groups)