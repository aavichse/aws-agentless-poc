import six
import string
import time
import requests
import datetime
import posixpath
from enum import IntEnum

try:
    import gevent

    do_sleep = gevent.sleep
except ImportError:
    do_sleep = time.sleep
from pyVmomi import vim, Version as pyVmomi_version
from pyVim.connect import SmartConnect, vmodl
from common import logger
from common.py.utils.config import cfg
from common.py.clouds.vsphere import pchelper
from common.py.clouds.vsphere.utils import reconnect_function
from common.py.model.exceptions import MissingConfigValuesException
from requests.exceptions import ConnectionError

requests.packages.urllib3.disable_warnings()

__author__ = 'Eddi'

LOG = logger.get_logger(module_name=__name__)

# vsphere magic, don't ask
CPU_USAGE_PERCENTAGE_COUNTER_ID = 3
CPU_USAGE_MGHZ_COUNTER_ID = 6
NETWORK_UTILIZATION_COUNTER_ID = 143

DEFAULT_VMWARE_TOOLS_START_TIMEOUT = 1500

GC_VM_GROUP_NAME_TEMPLATE = "guardicore-vm-group-for-{host_name}"
GC_HOST_GROUP_NAME_TEMPLATE = "guardicore-host-group-{host_name}"
GC_DRS_RULE_NAME_TEMPLATE = "guardicore-rule-for-{host_name}"
GC_SPAN_PORTGROUP_PREFIX = 'GC-Span'


class VSphereEntity(IntEnum):
    Vm = 1
    Folder = 2


class VSphereException(Exception):
    def __init__(self, err_msg, *args):
        Exception.__init__(self, err_msg % args)


class VSphereTaskFailed(VSphereException):
    def __init__(self, job_name, error):
        super(VSphereTaskFailed, self).__init__("vSphere Task %s failed with error %s" % (job_name, error))


# an exception we should should try and reconnect after
class VSphereReconnectException(VSphereException):
    pass


class ClonedVmNotFoundException(VSphereException):
    pass


reconnect_on_fault = reconnect_function((vim.MethodFault, VSphereReconnectException,),
                                        reconnect=True)


class VSphereClient(object):
    """
    Wrapper for Vsphere
    """

    @classmethod
    def from_configuration(cls, conf=None):
        if conf is None:
            conf = cfg.CONF

        missing_config_keys = [key for key, value in conf.vsphere_auth.items() if value is None]
        if missing_config_keys:
            raise MissingConfigValuesException('vsphere_auth',
                                               missing_config_keys)

        return cls(admin_user=conf.vsphere_auth.admin_user,
                   admin_password=conf.vsphere_auth.admin_password,
                   auth_host=conf.vsphere_auth.auth_host,
                   auth_port=conf.vsphere_auth.auth_port,
                   number_of_ignored_updates=conf.number_of_ignored_updates)

    def __init__(self, admin_user, admin_password, auth_host, auth_port=443, number_of_ignored_updates=10):
        self.admin_user = admin_user
        self.admin_password = admin_password
        self.auth_host = auth_host
        self.auth_port = auth_port
        self.vsphere_api_version = ''
        self.number_of_ignored_updates = number_of_ignored_updates

        self._vsphere_connection = None
        self._vsphere_content = None
        self._perfManager = None

    def set_configuration(self, admin_user, admin_password, auth_host, auth_port=443, number_of_ignored_updates=10):
        self.admin_user = admin_user
        self.admin_password = admin_password
        self.auth_host = auth_host
        self.auth_port = auth_port
        self.number_of_ignored_updates = number_of_ignored_updates

    def __repr__(self):
        return "<VSphereClient host='%s:%d' [%s] user='%s' password='%s'>" % \
               (self.auth_host, self.auth_port,
                "On" if self._vsphere_connection is not None else "Off",
                self.admin_user, "*" * len(self.admin_password))

    def __del__(self):
        self.close()

    def connect(self, reconnect=False, insecure=True):
        """
        Create new authenticated VSphere client
        """
        if self._vsphere_connection is None or reconnect:
            LOG.info('Connecting to vSphere server on %s:%s', self.auth_host, self.auth_port)

            kwargs = {'host': self.auth_host, 'port': self.auth_port,
                      'user': self.admin_user, 'pwd': self.admin_password}
            vmomi_versions = sorted(pyVmomi_version.versionMap.keys())
            LOG.debug("PyVmomi versions: %s", vmomi_versions)

            if insecure and ("vim25/6.5" in vmomi_versions or "vim25/6.0" in vmomi_versions):
                try:
                    import ssl
                    kwargs['sslContext'] = ssl._create_unverified_context()
                except (ImportError, AttributeError):
                    # on python older than 2.7.9 ssl does not have this function
                    pass

            if "vim25/6.5" in vmomi_versions:
                kwargs['connectionPoolTimeout'] = 7200

            try:
                self._vsphere_connection = SmartConnect(**kwargs)
                self._vsphere_content = self._vsphere_connection.RetrieveContent()
                self.vsphere_api_version = self._vsphere_connection.content.about.apiVersion
                self._perf_manager = self._vsphere_content.perfManager
                LOG.debug("Succesfully reconnected vsphere client - connection: %s, content: %s",
                          self._vsphere_connection, self._vsphere_content)
            except (ConnectionError, vim.fault.InvalidLogin) as exc:
                raise VSphereException("Failed connecting to %s:%s using user %s: %s", self.auth_host, self.auth_port,
                                       self.admin_user, getattr(exc, 'msg', str(exc)))

    def close(self):
        if self._vsphere_connection:
            del self._vsphere_connection
            self._vsphere_connection = None

    def get_product_about(self):
        if self._vsphere_content:
            return self._vsphere_content.about
        return None

    def get_vsphere_content(self):
        return self._vsphere_content

    def create_property_collector(self):
        if self._vsphere_content:
            return self._vsphere_content.propertyCollector.CreatePropertyCollector()
        return None

    @property
    @reconnect_on_fault
    def session_key(self):
        """
        :return: The current session key. A unique identifier of the current connection.
        """
        if self._vsphere_content is not None and self._vsphere_connection is not None:
            # perform simple operation to check connectivity.
            self._vsphere_connection.CurrentTime()
            if not self._vsphere_content.sessionManager.currentSession:
                raise VSphereReconnectException("Can't get session key, session might be off")
            return self._vsphere_content.sessionManager.currentSession.key

    def get_events_manager(self):
        if self._vsphere_content is None:
            return None
        return self._vsphere_content.eventManager

    @reconnect_on_fault
    def find_vm_by_uuid(self, vm_uuid):
        """
        The method find single virtual machine (If exists) by given vm uuid.
        Note that the uuid expected in this method is the vm instanceUuid as opposed to
        the vm bios uuid.
        The instance uuid suppose to be more global uuid in the sense that it represents the vm
        together with its management server (vCenter/Host) and by that can uniquely represent the vm
        in environment contain multi vsphere vcenter instances.

        :param vm_uuid: The instance uuid of the vm to query.
        :return: vim.VirtualMachine
        """
        return self._vsphere_content.searchIndex.FindByUuid(datacenter=None,
                                                            uuid=vm_uuid,
                                                            vmSearch=True,
                                                            instanceUuid=True)

    def create_folder(self, datacenter, folder_path):
        """create_folder(datacenter, folder_path)

        Create a virtual folder under a given datacenter. The folder object is returned. In the case
        folder already exists, the existing object is returned.
        """

        if isinstance(datacenter, vim.Datacenter):
            datacenter_obj = datacenter
        else:
            datacenter_obj = self._get_obj(vim_type=[vim.Datacenter], name=datacenter)

        root_folder = datacenter_obj.vmFolder
        for path in folder_path.split(posixpath.sep):
            try:
                root_folder = root_folder.CreateFolder(path)
            except vim.DuplicateName as exc:
                root_folder = exc.object
        return root_folder

    def change_dir_permission(self, dir_entity, principal, role_id, group=False, propagate=False):
        LOG.debug("set dir %s permission", dir_entity.name)
        if not isinstance(dir_entity, vim.Folder):
            raise ValueError('Error: Dir Entity is not type of vim.Folder')

        perm = vim.AuthorizationManager.Permission(
            entity=dir_entity,
            group=group,
            principal=principal,
            propagate=propagate,
            roleId=role_id)

        auth_manager = self._vsphere_content.authorizationManager
        auth_manager.SetEntityPermissions(dir_entity, [perm])

    def walk_datacenter(self, datacenter, walk_cb, folder=None):
        if isinstance(datacenter, vim.Datacenter):
            datacenter_obj = datacenter
        else:
            datacenter_obj = self._get_obj(vim_type=[vim.Datacenter], name=datacenter)
            if not datacenter_obj:
                LOG.warn("Datacenter '%s' isn't found", datacenter)
                return False

        if not folder:
            root = datacenter_obj.vmFolder
        else:
            root = self.get_folder_by_path(folder_path=folder.strip(posixpath.sep),
                                           datacenter=datacenter)
            if not root:
                LOG.warn("Folder '%s' isn't found", folder)
                return False

        def _walk_folder(parent_folder, path="/"):
            for child_entity in parent_folder.childEntity:
                if isinstance(child_entity, vim.Folder):
                    entity_type = VSphereEntity.Folder
                    _walk_folder(child_entity, path=posixpath.join(path, child_entity.name))
                elif isinstance(child_entity, vim.VirtualMachine):
                    entity_type = VSphereEntity.Vm
                else:
                    continue

                walk_cb(path, child_entity, entity_type)

        _walk_folder(root)

    def get_walk_datacenter(self, datacenter, walk_cb, folder=None, case_sensitive=False):
        if not folder:
            datacenter_obj = self._get_obj(vim_type=[vim.Datacenter], name=datacenter)
            if not datacenter_obj:
                LOG.warn("Datacenter '%s' isn't found", datacenter)
                return False
            root = datacenter_obj.vmFolder
        else:
            root = self.get_folder_by_path(folder_path=folder.strip(posixpath.sep),
                                           datacenter=datacenter,
                                           case_sensitive=case_sensitive)
            if not root:
                LOG.warn("Folder '%s' isn't found", folder)
                return False

        def _walk_folder(parent_folder, path="/"):
            list_child_entities = []
            for child_entity in parent_folder.childEntity:
                if isinstance(child_entity, vim.Folder):
                    entity_type = VSphereEntity.Folder
                    _walk_folder(child_entity, path=posixpath.join(path, child_entity.name))
                elif isinstance(child_entity, vim.VirtualMachine):
                    entity_type = VSphereEntity.Vm
                else:
                    continue

                list_child_entities.append(walk_cb(path, child_entity, entity_type))
            return list_child_entities

        return _walk_folder(root)

    @reconnect_on_fault
    def get_vm_by_datastore_path(self, datacenter, vmx_path):
        return self._vsphere_content.searchIndex.FindByDatastorePath(datacenter=datacenter,
                                                                     path=vmx_path)

    @reconnect_on_fault
    def get_vm_commited_storage(self, vm, refresh=True):
        if refresh:
            LOG.debug("Refresh storage view for vm %r", vm.name)
            vm.RefreshStorageInfo()

        LOG.debug("VM storage: %r", vm.summary.storage)
        return vm.summary.storage.committed

    @reconnect_on_fault
    def get_all_vms_by_ip(self, ip_address):
        """
        The method find all the virtual machine (If exists) by given ip address.
        Note that this method relies on vmware tools meaning it only finds vms with running vmware tools
        installation.
        :param ip_address: The ip address to query
        :return: set of vim.VirtualMachine
        """
        # We return set instead of the ManagedObjectReference[] since we saw
        # cases that it returned duplicate instance of the same vm. Currently
        # __hash__ and __eq__ of  pyVmomi.VmomiSupport.ManagedObject works as expected
        # and fast, but if this thing changes we might consider doing it different.
        return set(self._vsphere_content.searchIndex.FindAllByIp(datacenter=None,
                                                                 ip=ip_address,
                                                                 vmSearch=True))

    @reconnect_on_fault
    def _list_objects(self, object_type, folder=None):
        if folder is None:
            folder = self._vsphere_content.rootFolder

        objview = self._vsphere_content.viewManager.CreateContainerView(folder,
                                                                        [object_type],
                                                                        True)

        objects = objview.view
        objview.Destroy()
        return objects

    @reconnect_on_fault
    def _get_obj(self, vim_type, name):
        """
         Get the vsphere object associated with a given text name
         :param vim_type: List of pyVmomi types.
         :type vim_type: vim.*
         :param name: The name of the desired object.
         :type name: str.
        """
        obj = None
        container = self._vsphere_content.viewManager.CreateContainerView(self._vsphere_content.rootFolder, vim_type,
                                                                          True)
        for item in container.view:
            if item.name == name:
                obj = item
                break
        if obj is None:
            LOG.debug("Could not find %s ", name)

        return obj

    def get_obj(self, vim_type, name):
        return self._get_obj(vim_type, name)

    def get_cluster_by_name(self, cluster_name):
        return self.get_obj([vim.ClusterComputeResource], cluster_name)

    def get_resource_pool_by_name(self, resource_pool_name):
        return self.get_obj([vim.ResourcePool], resource_pool_name)

    def get_vm_moid_by_uuid(self, vm_uuid):
        """
        Get the vm moid, for given vm vc-uuid.
        :param vm_uuid: The vm instance vc uuid.
        :return: The vm's moid.
        """
        vm = self.find_vm_by_uuid(vm_uuid)
        if vm is None:
            raise VSphereException("Failed to fetch vm_uuid:%s from vSphere" % vm_uuid)
        return vm._GetMoId()

    def get_network_name(self, vm_uuid, nic_idx):
        """
        Get the network name that connected to the nic at given index, for given vm.
        :param vm_uuid: The vm instance uuid.
        :param nic_idx: The index of the nic.
        :return: The name of the network.
        """
        vm = self.find_vm_by_uuid(vm_uuid)
        if vm is None:
            raise VSphereException("Failed to fetch vm_uuid:%s from vSphere" % vm_uuid)

        network_devices = []
        for device in vm.config.hardware.device:
            if isinstance(device, vim.VirtualEthernetCard):
                LOG.debug("Found Ethernet device (dev key: %s,  mac address: %s)" % (device.key, device.macAddress))
                network_devices.append(device)

        if nic_idx < 0 or nic_idx >= len(network_devices):
            raise VSphereException("nic_idx:%d is out of range, found only %d devices" % (nic_idx,
                                                                                          len(network_devices)))

        chosen_network_device_info = network_devices[nic_idx]
        network_id = self.get_network_name_from_network_hardware_device(chosen_network_device_info)

        # to which nic on the machine we chose (and see what its actual index)
        LOG.debug("For vm %s and nic index %s - "
                  "found network %s " % (vm_uuid, nic_idx, network_id))
        return network_id

    def get_network_name_from_network_hardware_device(self, network_device):
        """
        Return the network which the specified network device is connected to.
        Note the we use different Network identifiers for different network types.
        For networks connected to VSS (Vmware standard switch - also called HostPortGroup) we use the name.
        For networks connected to DVS we use the portgroupkey.

        :param network_device: The network device.
        :type network_device: vim.VirtualEthernetCard.
        :return: The network identifier if found. None if not.
        """
        if isinstance(network_device.backing, vim.VirtualEthernetCardNetworkBackingInfo):
            return network_device.backing.deviceName

        elif isinstance(network_device.backing, vim.VirtualEthernetCardDistributedVirtualPortBackingInfo):
            network_moid = network_device.backing.port.portgroupKey
            network = self.get_network(network_moid)
            if network:
                return network.name
            return network_moid

        LOG.debug("NIC has unknown backing: %s" % (network_device))
        return None

    def list_networks(self):
        return self._list_objects(vim.Network)

    def update_vm_nic_network(self, dst_vm, nic_to_be_replaced, dst_nic):
        """
        change a network interface for the given vm
        :param dst_vm: vm object for the vm you want to change nic for
        :param nic_to_be_replaced: the name of the nic you want to change
        :param dst_nic: the name of the nic you want to change to.
        :return:
        """
        assert isinstance(dst_vm, vim.VirtualMachine), ""

        devices = []
        new_nic_object = self.get_obj([vim.Network], dst_nic)
        if not new_nic_object:
            raise VSphereException("Cannot find %s network" % dst_nic)

        old_nic_object = self.get_obj([vim.Network], nic_to_be_replaced)
        if not old_nic_object:
            raise VSphereException("Cannot find %s network" % nic_to_be_replaced)

        nic_portgroup_key = old_nic_object.key

        nicspec = None
        for dev in dst_vm.config.hardware.device:
            if "Network" in dev.deviceInfo.label:
                if dev.backing.port.portgroupKey == nic_portgroup_key:
                    nicspec = vim.vm.device.VirtualDeviceSpec()
                    nicspec.device = dev
                    nicspec.operation = vim.vm.device.VirtualDeviceSpec.Operation.edit

                    dvs_port_connection = vim.dvs.PortConnection()
                    dvs_port_connection.portgroupKey = new_nic_object.key
                    dvs_port_connection.switchUuid = new_nic_object.config.distributedVirtualSwitch.uuid
                    nicspec.device.backing = vim.vm.device.VirtualEthernetCard.DistributedVirtualPortBackingInfo()
                    nicspec.device.backing.port = dvs_port_connection
                    break

        if nicspec is None:
            raise VSphereException("Cannot find nic with the key: %s" % nic_portgroup_key)
        else:
            devices.append(nicspec)
            vmconf = vim.vm.ConfigSpec(deviceChange=devices)
            error_msg = "Cannot change nics to %s" % dst_vm.name
            self.wait_for_task(dst_vm.ReconfigVM_Task(vmconf), error_msg)

    def _get_cluster_to_configure_drs(self, host):
        """
        Get for given host the cluster in which DRS rules should be defined.
        :param host: The host to get the cluster for.
        :type host: vim.HostSystem
        :return: The cluster in which we can configure DRS rules on
        :rtype: vim.ClusterComputeResource
        """
        if not isinstance(host.parent, vim.ClusterComputeResource):
            LOG.info("Host %s not managed under cluster" % host.name)
            return None

        cluster = host.parent
        LOG.debug("Host %s found under cluster %s" % (host.name, cluster.name))

        if not cluster.configuration.drsConfig.enabled:
            LOG.info("Drs not enabled on the cluster")
            return None

        return cluster

    def configure_drs_rule_keep_vm_on_host(self, vm, host):
        """
        Configure DRS (distributed resource scheduling) rule to keep the given vm
        on the given host.
        :param vm: The vm to keep.
        :param host: The host to keep this vm on.
        """
        cluster = self._get_cluster_to_configure_drs(host)
        if cluster is None:
            return

        self.clean_drs_rules(host)

        # The names to use.
        vm_group_name = GC_VM_GROUP_NAME_TEMPLATE.format(host_name=host.name)
        host_group_name = GC_HOST_GROUP_NAME_TEMPLATE.format(host_name=host.name)
        drs_rule_name = GC_DRS_RULE_NAME_TEMPLATE.format(host_name=host.name)

        cluster_config_spec_ex = vim.ClusterConfigSpecEx()

        # Create vm group contain the vm
        vm_cluster_group_spec = vim.ClusterGroupSpec()
        vm_cluster_group_spec.operation = vim.ArrayUpdateOperation.add
        cluster_vm_group = vim.ClusterVmGroup()
        cluster_vm_group.name = vm_group_name
        cluster_vm_group.vm.append(vm)
        vm_cluster_group_spec.info = cluster_vm_group
        cluster_config_spec_ex.groupSpec.append(vm_cluster_group_spec)

        # Create host group contain the host
        host_cluster_group_spec = vim.ClusterGroupSpec()
        host_cluster_group_spec.operation = vim.ArrayUpdateOperation.add
        cluster_host_group = vim.ClusterHostGroup()
        cluster_host_group.name = host_group_name
        cluster_host_group.host.append(host)
        host_cluster_group_spec.info = cluster_host_group
        cluster_config_spec_ex.groupSpec.append(host_cluster_group_spec)

        # Create rule for keeping the new vm group on the new host group
        cluster_rule_spec = vim.ClusterRuleSpec()
        cluster_rule_spec.operation = vim.ArrayUpdateOperation.add

        cluster_rule_info = vim.ClusterVmHostRuleInfo()
        cluster_rule_info.name = drs_rule_name
        cluster_rule_info.enabled = True
        cluster_rule_info.mandatory = True
        cluster_rule_info.vmGroupName = vm_group_name
        cluster_rule_info.affineHostGroupName = host_group_name

        cluster_rule_spec.info = cluster_rule_info

        cluster_config_spec_ex.rulesSpec.append(cluster_rule_spec)
        task = cluster.ReconfigureComputeResource_Task(cluster_config_spec_ex, modify=True)
        self.wait_for_task(task=task,
                           action_name='AddDrsRules: {}'.format(vm._moId))

    def create_vm_keep_together_rule(self, vms, rule_name, cluster):
        """
        Creating VM's rule of type 'keep together' in specific cluster.

        """

        rule = vim.cluster.AffinityRuleSpec(vm=vms, enabled=True, mandatory=True, name=rule_name)
        ruleSpec = vim.cluster.RuleSpec(info=rule, operation=vim.option.ArrayUpdateSpec.Operation.add)
        configSpec = vim.cluster.ConfigSpecEx(rulesSpec=[ruleSpec])
        task = cluster.ReconfigureEx(configSpec, modify=True)
        LOG.info("Adding rule called : %s for the following vms %s" % (rule_name, [vm.name for vm in vms]))
        self.wait_for_task(task=task, action_name='adding rule')

    def vm_keep_together_rule_add_vm(self, vm_add, rule_name, cluster):
        """
        Add VM to the existing cluster rule, or create a new VM keep together rule with the specified VM.
        """
        for rule in cluster.configurationEx.rule:
            if rule.name == rule_name:
                rule.vm.append(vm_add)
                cluster_rule_spec = vim.ClusterRuleSpec(info=rule, operation=vim.option.ArrayUpdateSpec.Operation.edit)
                cluster_config_spec_ex = vim.ClusterConfigSpecEx(rulesSpec=[cluster_rule_spec])
                task = cluster.ReconfigureComputeResource_Task(cluster_config_spec_ex, modify=True)
                self.wait_for_task(task=task, action_name='updating rule')
                return True

        self.create_vm_keep_together_rule([vm_add], rule_name, cluster)

    def remove_vms_rule(self, rule_name, cluster):
        """
        Remove VM's rule from specific cluster.

        :return: Return True if VM's rule deleted, otherwise False.
        """

        cluster_config_spec_ex = vim.ClusterConfigSpecEx()
        for rule in cluster.configurationEx.rule:
            if rule.name == rule_name:
                LOG.info("Found vms rule %s to delete" % rule_name)
                cluster_rule_spec = vim.ClusterRuleSpec()
                cluster_rule_spec.operation = vim.ArrayUpdateOperation.remove
                cluster_rule_spec.removeKey = rule.key
                cluster_config_spec_ex.rulesSpec.append(cluster_rule_spec)
                task = cluster.ReconfigureComputeResource_Task(cluster_config_spec_ex, modify=True)
                self.wait_for_task(task=task,
                                   action_name='Remove vms rule %s' % rule_name)
                return True
        return False

    @staticmethod
    def is_vms_rule_exists(rule_name, cluster):
        """
        Checking if VM's rule exists by rule name.

        """

        for rule in cluster.configurationEx.rule:
            if rule.name == rule_name:
                return True
        return False

    def clean_drs_rules(self, host):
        """
        Remove all previous guardicore drs rules leftovers.
        :param host: The host to clean the DRS rules for.
        """
        cluster = self._get_cluster_to_configure_drs(host)
        if cluster is None:
            return None

        vm_group_name = GC_VM_GROUP_NAME_TEMPLATE.format(host_name=host.name)
        host_group_name = GC_HOST_GROUP_NAME_TEMPLATE.format(host_name=host.name)
        drs_rule_name = GC_DRS_RULE_NAME_TEMPLATE.format(host_name=host.name)

        found_leftovers = False
        cluster_config_spec_ex = vim.ClusterConfigSpecEx()

        for group in cluster.configurationEx.group:
            if group.name in (vm_group_name, host_group_name):
                group_spec = vim.ClusterGroupSpec()
                group_spec.operation = vim.ArrayUpdateOperation.remove
                group_spec.removeKey = group.name
                cluster_config_spec_ex.groupSpec.append(group_spec)
                LOG.info("Found leftover drs group %s" % group.name)
                found_leftovers = True

        for rule in cluster.configurationEx.rule:
            if rule.name == drs_rule_name:
                cluster_rule_spec = vim.ClusterRuleSpec()
                cluster_rule_spec.operation = vim.ArrayUpdateOperation.remove
                cluster_rule_spec.removeKey = rule.key
                cluster_config_spec_ex.rulesSpec.append(cluster_rule_spec)
                LOG.info("Found leftover drs rule %s" % rule.name)
                found_leftovers = True

        if found_leftovers:
            LOG.info("Clean DRS leftovers")
            task = cluster.ReconfigureComputeResource_Task(cluster_config_spec_ex, modify=True)
            self.wait_for_task(task=task,
                               action_name='CleanDrsRules: {}'.format(host._moId))

    def configure_vm_auto_start(self, vm, host):
        """
        Configure our vms to start automaticly after ESX boot.
        :param vm: The virutal Machine to add to the autostart.
        :param host: The host to power the machine on.
        """
        host_auto_start_manager_spec = vim.HostAutoStartManagerConfig()

        auto_start_power_info = vim.AutoStartPowerInfo()
        auto_start_power_info.key = vm
        auto_start_power_info.startAction = "powerOn"
        auto_start_power_info.startOrder = -1
        auto_start_power_info.startDelay = -1
        auto_start_power_info.stopDelay = -1
        auto_start_power_info.stopAction = "systemDefault"
        auto_start_power_info.waitForHeartbeat = vim.AutoStartWaitHeartbeatSetting.systemDefault
        # We use the system's default power on delay.

        host_auto_start_manager_spec.powerInfo.append(auto_start_power_info)
        host.configManager.autoStartManager.ReconfigureAutostart(host_auto_start_manager_spec)

    def get_network_name_by_mac(self, vm_uuid, mac_address):
        """
        Get the network name that connected to the nic with the given mac, for given vm.
        :param vm_uuid: The vm instance uuid.
        :param mac_address: The nic mac address.
        :return: The name of the network.
        """
        vm = self.find_vm_by_uuid(vm_uuid)
        if vm is None:
            raise VSphereException("Failed to fetch vm_uuid:%s from vSphere" % vm_uuid)

        network_device = None
        for device in vm.config.hardware.device:
            if isinstance(device, vim.VirtualEthernetCard) and device.macAddress == mac_address:
                LOG.debug("Found Ethernet device (dev key: %s,  mac address: %s)" % (device.key, device.macAddress))
                network_device = device

        if network_device is None:
            LOG.warn("NIC with mac %s not found for vm %s (%s)" % (mac_address, vm_uuid, vm.name))
            return

        network_id = self.get_network_name_from_network_hardware_device(network_device)

        # to which nic on the machine we chose (and see what its actual index)
        LOG.debug("For vm %s and mac %s - "
                  "found network %s " % (vm_uuid, mac_address, network_id))
        return network_id

    def list_vms(self, parent=None):
        """
        :type parent: : vim.Folder
        :return: list
        """
        return self._list_objects(vim.VirtualMachine, folder=parent)

    def list_hosts(self, cluster_name=None, datacenter_name=None):
        if cluster_name:
            cluster = self._get_obj([vim.ClusterComputeResource], cluster_name)
            if not cluster:
                LOG.warn("No cluster named '%s'", cluster_name)
                return []

            return cluster.host

        elif datacenter_name:
            datacenter = self.get_datacenter_by_name(datacenter_name=datacenter_name)
            return self._list_objects(vim.HostSystem, folder=datacenter.hostFolder)
        else:
            return self._list_objects(vim.HostSystem)

    def list_datastores(self, cluster_name=None):
        if cluster_name:
            cluster = self._get_obj([vim.ClusterComputeResource], cluster_name)
            if not cluster:
                LOG.warn("No cluster named '%s'", cluster_name)
                return []

            return cluster.datastore
        else:
            return self._list_objects(vim.Datastore)

    def list_datacenters(self):
        return self._list_objects(vim.Datacenter)

    def list_clusters(self):
        return self._list_objects(vim.ClusterComputeResource)

    def get_folder_by_path(self, folder_path, datacenter, case_sensitive=False, log_errors=True):
        if not case_sensitive:
            folder_path = folder_path.lower()

        if isinstance(datacenter, six.string_types):
            datacenter_obj = self._get_obj(vim_type=[vim.Datacenter], name=datacenter)
        else:
            datacenter_obj = datacenter

        root_folder = datacenter_obj.vmFolder
        for path in folder_path.split(posixpath.sep):
            next_root_folder = None
            for child_entity in root_folder.childEntity:
                if not isinstance(child_entity, vim.Folder):
                    continue

                if (case_sensitive and (path == child_entity.name)) or \
                        (not case_sensitive and (path == child_entity.name.lower())):
                    next_root_folder = child_entity
                    break

            if not next_root_folder:
                if log_errors:
                    LOG.warn("Couldn't find folder by path '%s' ('%s' not found)", folder_path, path)
                return None
            root_folder = next_root_folder

        return root_folder

    def retry_missing_object(exc):
        return isinstance(exc, vmodl.fault.ManagedObjectNotFound)

    def get_vm_by_path(self, path):
        LOG.debug("Getting the vm with the path %s", path)
        if path.startswith("/"):
            path = path[1:]
        split_path = path.split(posixpath.sep)
        LOG.debug("The split path (%s) is split by %s", split_path, posixpath.sep)
        vm_name = split_path[-1]
        LOG.debug("The vm name is %s", vm_name)
        base_folder = split_path[0]
        LOG.debug("The vm's base folder is %s", base_folder)
        parent_folder_object = self.get_folder_by_name(base_folder)
        # get a list containing only the folders without the first parent folder and vm name.
        removed_vm_name_path = path.split(posixpath.sep)[1:]
        removed_base_and_vm_path = removed_vm_name_path[:-1]
        LOG.debug("The path without the base folder and vm %s", removed_base_and_vm_path)
        for folder in removed_base_and_vm_path:
            if type(parent_folder_object) == vim.Folder:
                parent_folder_object = self._get_folder_child_object(parent_folder_object, folder)

        return self._get_folder_child_object(parent_folder_object, vm_name)

    def get_vm_by_name(self, name):
        return self.get_obj([vim.VirtualMachine], name)

    def get_folder_by_name(self, name):
        return self.get_obj([vim.Folder], name)

    def _get_folder_child_object(self, folder_obj, child_name):
        if type(folder_obj) == vim.Folder:
            for entity in folder_obj.childEntity:
                if entity.name == child_name:
                    return entity
        else:
            raise VSphereException("The object given is not vim.Folder.")
        raise VSphereException("Could not find the child object for %s", child_name)

    @reconnect_on_fault
    def move_vm_to_folder(self, vm, datacenter, folder_path, block=False):
        destination_folder = self.create_folder(datacenter, folder_path)
        task = destination_folder.MoveInto([vm])
        if block:
            self.wait_for_task(task=task,
                               action_name='MoveVM: {}, DataCenter: {}, FolderPath: {}'.format(vm._moId, datacenter,
                                                                                               folder_path))

    @reconnect_on_fault
    def take_snapshot_vm(self, vm, snapshot_name, description, dump_memory=False, quiesce=False, block=False):
        task = vm.CreateSnapshot(snapshot_name, description, dump_memory, quiesce)
        if block:
            self.wait_for_task(task=task,
                               action_name='CreateSnapshot: {}, SnapshotName:{}'.format(vm.name, snapshot_name))

    @reconnect_on_fault
    def take_snapshot(self, vm_moid, snapshot_name, description, dump_memory=False, quiesce=False, block=False):
        vm = self.get_vm(vm_moid=vm_moid)
        return self.take_snapshot_vm(vm, snapshot_name,
                                     description,
                                     dump_memory=dump_memory,
                                     quiesce=quiesce,
                                     block=block)

    @reconnect_on_fault
    def remove_snapshot(self, vm, snapshot_name):
        snapshots = vm.snapshot.rootSnapshotList
        for snapshot in snapshots:
            if snapshot.name == snapshot_name:
                LOG.info('Snapshot %s found on the VM, removing it...', snapshot_name)
                snap_obj = snapshot.snapshot
                self.wait_for_task(task=snap_obj.RemoveSnapshot_Task(True),
                                   action_name='Removing snapshot {}'.format(snapshot_name))
                return
        LOG.warning('No snapshot %s found for the VM', snapshot_name)

    @reconnect_on_fault
    def restart_vm(self, vm_moid, block=False, shutdown=False):
        self.stop_vm(vm_moid=vm_moid, block=True, shutdown=shutdown)
        return self.start_vm(vm_moid=vm_moid, block=block)

    @reconnect_on_fault
    def stop_vm(self, vm_moid, block=False, shutdown=False):
        vm = self.get_vm(vm_moid=vm_moid)
        if self.is_vm_powered_off(vm):
            return

        if shutdown:
            try:
                vm.ShutdownGuest()
                # Allow the guest VM to shutdown cleanly since ShutdownGuest() command returns
                # immediately and does not wait for the guest operating system to complete the operation
                time.sleep(5)
            except Exception as e:
                LOG.debug("Failed to shutdown VM %s %s", vm.name, e)

        task = vm.PowerOff()
        if block:
            self.wait_for_task(task=task, action_name='StopVM: {}'.format(vm_moid))

    @reconnect_on_fault
    def start_vm(self, vm_moid, block=False):
        vm = self.get_vm(vm_moid=vm_moid)
        task = vm.PowerOn()
        if block:
            self.wait_for_task(task=task, action_name='StartVM: {}'.format(vm_moid))
        else:
            return task

    @reconnect_on_fault
    def suspend_vm(self, vm_moid, block=False):
        vm = self.get_vm(vm_moid=vm_moid)
        task = vm.Suspend()
        if block:
            self.wait_for_task(task=task, action_name='SuspendVM: {}'.format(vm_moid))

    @reconnect_on_fault
    def terminate_vm(self, vm_moid, block=False):
        vm = self.get_vm(vm_moid=vm_moid)
        task = vm.Terminate()
        if block:
            self.wait_for_task(task=task, action_name='TerminateVM: {}'.format(vm_moid))

    @reconnect_on_fault
    def destroy_vm(self, vm_moid, block=False):
        vm = self.get_vm(vm_moid=vm_moid)
        task = vm.Destroy()
        if block:
            self.wait_for_task(task=task, action_name='DestroyVM: {}'.format(vm_moid))

    @reconnect_on_fault
    def is_vm_powered_off(self, vm):
        return vm.runtime.powerState == vim.VirtualMachinePowerState.poweredOff

    @reconnect_on_fault
    def disconnect_network_cards(self, vm_moid, block=False):
        vm = self.get_vm(vm_moid=vm_moid)
        virtual_nic_devices = [dev for dev in vm.config.hardware.device if
                               isinstance(dev, vim.vm.device.VirtualEthernetCard)]
        if not virtual_nic_devices:
            LOG.warn("Coudln't find network cards on %s to disconnect", vm.name)
            return
        dev_changes = []
        for dev in virtual_nic_devices:
            virtual_nic_spec = vim.vm.device.VirtualDeviceSpec()
            virtual_nic_spec.operation = vim.vm.device.VirtualDeviceSpec.Operation.edit
            virtual_nic_spec.device = dev
            virtual_nic_spec.device.connectable.connected = False
            dev_changes.append(virtual_nic_spec)

        spec = vim.vm.ConfigSpec()
        spec.deviceChange = dev_changes
        task = vm.ReconfigVM_Task(spec=spec)
        if block:
            self.wait_for_task(task=task, action_name='ReconfigVM_Task: {}'.format(vm_moid))

    def list_resource_pools(self):
        return self._list_objects(vim.ResourcePool)

    def get_vm_full_path(self, vm):
        """
        Get virtual machine full path.
        :param vm: vim.VirtualMachine
        :return: The vm full path.
        :rtype: str.
        """
        path_suffix = vm.name
        current = vm.parent

        # Note that we don't consider neither the last folder when we building
        # the path nor path parts that are not folder (like Datacenter)
        # we do so since the last folder before the end always named "vm/"
        while current and isinstance(current.parent, vim.Folder):
            path_suffix = posixpath.join(current.name, path_suffix)
            current = current.parent

        return path_suffix

    def get_host_network_utilization_stats(self, host_moid, interval):
        """
        :param host_moid: host moid
        :param interval: query interval, in datetime.timedelta object
        :return: dict of {timestamp: <datetime_timestamp>, interval: <sample_interval>, value: <value>}
            which contains host network utilization statistics. Values represent average KBps during the
            sample interval.
        """
        metric_id = vim.PerformanceManager.MetricId(counterId=NETWORK_UTILIZATION_COUNTER_ID, instance="*")
        end_time = datetime.datetime.utcnow()
        start_time = end_time - interval
        host = vim.HostSystem(host_moid)
        query = vim.PerformanceManager.QuerySpec(maxSample=1, entity=host, metricId=[metric_id],
                                                 startTime=start_time, endTime=end_time)
        LOG.info('Collecting performance data for host %s on interval %s - start', host_moid, interval)
        performance_result = self._perf_manager.QueryPerf(querySpec=[query])
        if not performance_result:
            return []

        performance_result = performance_result[0]
        samples = performance_result.sampleInfo
        if not samples:
            return []

        result = [dict(timestamp=sample_info.timestamp, interval=sample_info.interval, value=value)
                  for sample_info, value in zip(samples, performance_result.value[0].value)]
        LOG.info('Collecting performance data for host %s on interval %s - end', host_moid, interval)
        return result

    def query_counter_id_info(self, counter_ids):
        """query_counter_id_info(self, counter_ids)

        counter_ids is an array of integer counter IDs.
        """

        return vim.PerformanceManager.QueryPerfCounter(self._perf_manager, counterId=counter_ids)

    def get_host_perf_stats(self, host, interval=10):
        metric_id = vim.PerformanceManager.MetricId(counterId=CPU_USAGE_PERCENTAGE_COUNTER_ID, instance="*")
        end_time = datetime.datetime.utcnow()
        start_time = end_time - datetime.timedelta(seconds=interval)
        query = vim.PerformanceManager.QuerySpec(maxSample=1, entity=host, metricId=[metric_id],
                                                 startTime=start_time, endTime=end_time)
        LOG.info('Collecting performance data for host %s on interval %s - start', host.name, interval)
        performance_result = self._perf_manager.QueryPerf(querySpec=[query])

        if not performance_result:
            return []

        performance_result = performance_result[0]
        samples = performance_result.sampleInfo
        if not samples:
            return []

        result = [dict(timestamp=sample_info.timestamp, interval=sample_info.interval, value=value)
                  for sample_info, value in zip(samples, performance_result.value[0].value)]
        LOG.info('Collecting performance data for host %s on interval %s - end', host.name, interval)
        return result

    # -----------------------------------------
    # Property-Collector based API (used for deployment)
    #  TODO: consider using only this API
    # -----------------------------------------
    @reconnect_on_fault
    def _get_objects(self, object_type, properties):
        view = pchelper.get_container_view(self._vsphere_connection,
                                           obj_type=[object_type])
        objects = pchelper.collect_properties(self._vsphere_connection,
                                              view_ref=view,
                                              obj_type=object_type,
                                              path_set=properties,
                                              include_mors=True)
        for obj in objects:
            obj['moid'] = obj['obj']._moId
            del obj['obj']

        return objects

    def collect_mac_addresses(self):
        result = {}
        vms_with_nics = self._get_objects(object_type=vim.VirtualMachine, properties=['guest.net'])
        for vm in vms_with_nics:
            # find out all nics for this VM
            nics = vm['guest.net']
            # group them all under the VM's ESX id
            vm_macs = [nic.macAddress for nic in nics]
            result[vm['moid']] = vm_macs
        return result

    def collect_hosts(self):
        return self._get_objects(object_type=vim.HostSystem,
                                 properties=['name',
                                             'summary.runtime.inMaintenanceMode',
                                             'summary.runtime.connectionState',
                                             'summary.runtime.powerState',
                                             'summary.runtime.standbyMode'])

    def collect_vms(self):
        vms = self._get_objects(object_type=vim.VirtualMachine,
                                properties=['name', 'parent'])

        for vm in vms:
            if 'parent' not in vm:
                LOG.warn("VM %s has no parent", vm['name'])
                continue
            vm['parent'] = vm['parent']._moId

        return vms

    def collect_templates(self):
        vms = self._get_objects(object_type=vim.VirtualMachine,
                                properties=['name', 'parent', 'config.template',
                                            'summary.storage.committed', 'summary.storage.uncommitted',
                                            'summary.config.product.vendor', 'summary.config.product.name',
                                            'summary.config.product.fullVersion'])

        for vm in vms:
            if 'parent' not in vm:
                LOG.warn("VM %s has no parent", vm['name'])
                continue
            vm['parent'] = vm['parent']._moId

        return [vm for vm in vms if vm.get('config.template')]

    def collect_networks(self):
        networks = self._get_objects(object_type=vim.Network,
                                     properties=['name', 'host'])
        for network in networks:
            network['hosts'] = [host._moId for host in network['host']]
            del network['host']

        return networks

    def collect_datastores(self):
        datastores = self._get_objects(object_type=vim.Datastore,
                                       properties=['name', 'host', 'summary.capacity', 'summary.freeSpace'])
        for ds in datastores:
            ds['hosts'] = [datastore_host_mount.key._moId for datastore_host_mount in ds['host']]
            del ds['host']

        datastores.sort(key=lambda ds: ds['summary.freeSpace'], reverse=True)
        return datastores

    def collect_folders(self):
        folders = self._get_objects(vim.Folder,
                                    properties=['name', 'parent'])
        for folder in folders:
            folder['parent'] = folder['parent']._moId
            folder['children'] = []
            folder['is_root'] = False

        # collect children of all folders
        folders_by_moid = {folder['moid']: folder for folder in folders}
        for folder in folders:
            if folder['parent'] in folders_by_moid:
                folders_by_moid[folder['parent']]['children'].append(folder)

        # mark root folders
        root_folders = [folder for folder in folders
                        if folder['parent'] not in folders_by_moid]
        for root_folder in root_folders:
            root_folder['is_root'] = True

        # build folders fullpaths, BFS style
        folders_queue = root_folders[:]
        while folders_queue:
            folder = folders_queue.pop(0)
            if folder['is_root']:
                folder['fullpath'] = ''
            else:
                folder['fullpath'] = posixpath.join(folders_by_moid[folder['parent']]['fullpath'],
                                                    folder['name'])

            folders_queue.extend(folder['children'])

        return folders

    def collect_datacenters(self):
        return self._get_objects(vim.Datacenter,
                                 properties=['name'])

    def collect_dvswitches(self):
        dvswitches = self._get_objects(vim.VmwareDistributedVirtualSwitch,
                                       properties=['name', 'config.host', 'portgroup'])
        for dvswitch in dvswitches:
            dvswitch['hosts'] = [host.config.host._moId for host in dvswitch['config.host']]
            del dvswitch['config.host']

        return dvswitches

    @reconnect_on_fault
    def _get_obj_by_moid(self, obj_type, moid):
        obj = obj_type(moid)
        obj._stub = self._vsphere_connection._stub
        return obj

    def find_by_name(self, target_name, list_object_method):
        result = list(filter(lambda obj: obj.name == target_name, list_object_method()))
        if 0 == len(result):
            LOG.debug("Couldn't find any '%s'", target_name)
            return None
        elif len(result) > 1:
            LOG.warning("Found more than one (%d) of '%s'", len(result), target_name)
            return None
        return result[0]

    def get_vm(self, vm_moid):
        """
        Get VM by moid.
        """
        return self._get_obj_by_moid(vim.VirtualMachine, vm_moid)

    def get_host(self, host_moid):
        """
        Get host by moid.
        """
        return self._get_obj_by_moid(vim.HostSystem, host_moid)

    def get_host_by_name(self, host_name):
        """
        Get host by name.
        """
        return self.get_obj([vim.HostSystem], host_name)

    def get_datacenter_by_name(self, datacenter_name):
        """
        Get center by name.
        """
        return self.get_obj([vim.Datacenter], datacenter_name)

    def get_network_by_name(self, network_name):
        """
        Get network by name.
        """
        return self.get_obj([vim.Network], network_name)

    def get_datastore(self, datastore_moid):
        """
        Get datastore by moid.
        """
        return self._get_obj_by_moid(vim.Datastore, datastore_moid)

    def get_folder(self, folder_moid):
        """
        Get folder by moid.
        """
        return self._get_obj_by_moid(vim.Folder, folder_moid)

    def get_network(self, network_moid):
        if network_moid.startswith("dvportgroup-"):
            return self._get_obj_by_moid(vim.dvs.DistributedVirtualPortgroup, network_moid)
        else:
            return self._get_obj_by_moid(vim.Network, network_moid)

    def get_dvswitch(self, dvswitch_moid):
        return self._get_obj_by_moid(vim.VmwareDistributedVirtualSwitch, dvswitch_moid)

    def get_dvswitch_by_name(self, switch_name="dvSwitch"):
        try:
            return self.find_by_name(switch_name, lambda: self._list_objects(vim.DistributedVirtualSwitch))
        except:
            return None

    def get_datastore_by_name(self, datastore_name):
        return self.find_by_name(datastore_name, lambda: self._list_objects(vim.Datastore))

    def get_vswitch_by_name(self, host_name, switch_name):
        host = self.get_host_by_name(host_name)
        for vswitch in host.configManager.networkSystem.networkConfig.vswitch:
            if switch_name == vswitch.name:
                return vswitch
        return None

    def get_vss_portgroup_by_name(self, host_name, portgroup_name, switch_name=None):
        host = self.get_host_by_name(host_name)
        port_group_found = False
        if switch_name:
            for portgroup in host.configManager.networkSystem.networkConfig.portgroup:
                if portgroup_name == portgroup.spec.name:
                    if switch_name == portgroup.spec.vswitchName:
                        port_group_found = True
            if not port_group_found:
                LOG.error("Portgroup '%s' doesn't exist in switch '%s'", portgroup_name, switch_name)
                return None

        for net in self.list_networks():
            if isinstance(net, vim.Network) and not \
                    isinstance(net, vim.DistributedVirtualPortgroup) and not \
                    isinstance(net, vim.OpaqueNetwork):
                if net.name == portgroup_name and host in net.host:
                    return net
        LOG.error("Failed finding vss portgourp '%s' on host '%s", portgroup_name, host_name)
        return None

    def get_dv_switch(self, dv_switch_name):
        return self.get_obj([vim.DistributedVirtualSwitch], dv_switch_name)

    def create_new_port_group(self, port_group_name, dv_switch_name, vlan_id=None,
                              allow_promiscuous=False,
                              forged_transmits=False,
                              mac_changes=False,
                              trunk=False,
                              trunk_start_vlan=1,
                              trunk_end_vlan=4094,
                              uplink_ports=None,
                              num_ports=128
                              ):

        dvs = self.get_dv_switch(dv_switch_name)

        dvport_config = vim.DVPortgroupConfigSpec()
        dvport_config.autoExpand = True
        dvport_config.configVersion = '3'
        dvport_config.type = 'earlyBinding'
        dvport_config.name = port_group_name
        dvport_config.numPorts = num_ports

        dvport_config.defaultPortConfig = vim.VMwareDVSPortSetting()
        if trunk:
            dvport_config.defaultPortConfig.vlan = vim.VmwareDistributedVirtualSwitchTrunkVlanSpec()
            vlan_range = vim.NumericRange()
            vlan_range.start = trunk_start_vlan
            vlan_range.end = trunk_end_vlan
            dvport_config.defaultPortConfig.vlan.vlanId = [vlan_range]
        else:
            if vlan_id is not None:
                dvport_config.defaultPortConfig.vlan = vim.VmwareDistributedVirtualSwitchVlanIdSpec()
                dvport_config.defaultPortConfig.vlan.vlanId = vlan_id

        dvport_config.defaultPortConfig.securityPolicy = vim.DVSSecurityPolicy()
        dvport_config.defaultPortConfig.securityPolicy.allowPromiscuous = vim.BoolPolicy()
        dvport_config.defaultPortConfig.securityPolicy.allowPromiscuous.value = allow_promiscuous
        dvport_config.defaultPortConfig.securityPolicy.forgedTransmits = vim.BoolPolicy()
        dvport_config.defaultPortConfig.securityPolicy.forgedTransmits.value = forged_transmits
        dvport_config.defaultPortConfig.securityPolicy.macChanges = vim.BoolPolicy()
        dvport_config.defaultPortConfig.securityPolicy.macChanges.value = mac_changes
        dvport_config.defaultPortConfig.uplinkTeamingPolicy = vim.VmwareUplinkPortTeamingPolicy()
        dvport_config.defaultPortConfig.uplinkTeamingPolicy.failureCriteria = vim.DVSFailureCriteria()
        dvport_config.defaultPortConfig.uplinkTeamingPolicy.notifySwitches = vim.BoolPolicy()
        dvport_config.defaultPortConfig.uplinkTeamingPolicy.notifySwitches.value = True

        dvport_config.defaultPortConfig.uplinkTeamingPolicy.reversePolicy = vim.BoolPolicy()
        dvport_config.defaultPortConfig.uplinkTeamingPolicy.reversePolicy.value = True
        dvport_config.defaultPortConfig.uplinkTeamingPolicy.rollingOrder = vim.BoolPolicy()
        dvport_config.defaultPortConfig.uplinkTeamingPolicy.rollingOrder.value = False
        dvport_config.defaultPortConfig.uplinkTeamingPolicy.uplinkPortOrder = vim.VMwareUplinkPortOrderPolicy()
        dvport_config.defaultPortConfig.uplinkTeamingPolicy.uplinkPortOrder.activeUplinkPort = uplink_ports
        dvport_config.defaultPortConfig.uplinkTeamingPolicy.uplinkPortOrder.standbyUplinkPort = []

        task_ref = dvs.AddDVPortgroup_Task([dvport_config])
        self.wait_for_task(task_ref, "create portGroup %s" % port_group_name)

        LOG.info("%s portgtoup was successfully created" % port_group_name)

    @reconnect_on_fault
    def _get_vm_creds(self, vm, username, password):
        tools_status = vm.guest.toolsStatus
        if (tools_status == vim.vm.GuestInfo.ToolsStatus.toolsNotInstalled or
                tools_status == vim.vm.GuestInfo.ToolsStatus.toolsNotRunning):
            raise VSphereException(
                "VMwareTools is either not running or not installed. "
                "Rerun the script after verifying that VMwareTools is running")
        return vim.vm.guest.NamePasswordAuthentication(username=username, password=password)

    @reconnect_on_fault
    def path_exists(self, vm, username, password, remote_file_path):
        """
        Check if a file or directory exist on the vm.
        :param vm:
        :param username:
        :param password:
        :param remote_file_path:
        :return:
        """
        creds = self._get_vm_creds(vm=vm, username=username, password=password)
        try:
            path_info = self._vsphere_content.guestOperationsManager.fileManager. \
                ListFilesInGuest(vm, creds, remote_file_path)
            return True if path_info and path_info.files else False
        except vim.fault.FileFault:
            return False

    @reconnect_on_fault
    def get_file(self, vm, username, password, remote_file_path):
        """
        Returns a string with remote_file_path contents on vm.
        This assumes the file is small enough to fit in memory!
        :param vm:
        :param username:
        :param password:
        :param remote_file_path:
        :return:
        """
        creds = self._get_vm_creds(vm=vm, username=username, password=password)
        file_info = self._vsphere_content.guestOperationsManager.fileManager. \
            InitiateFileTransferFromGuest(vm, creds, remote_file_path)

        resp = requests.get(file_info.url, verify=False)
        if not resp.status_code == 200:
            raise VSphereException("Error while downloading file")
        return resp.text

    @reconnect_on_fault
    def send_file(self, vm, username, password, file_obj, remote_file_path, file_content=None):
        creds = self._get_vm_creds(vm=vm, username=username, password=password)
        file_content = file_content if file_content else file_obj.read()

        file_attribute = vim.vm.guest.FileManager.FileAttributes()
        url = self._vsphere_content.guestOperationsManager.fileManager. \
            InitiateFileTransferToGuest(vm, creds, remote_file_path,
                                        file_attribute,
                                        len(file_content), True)
        resp = requests.put(url, data=file_content, verify=False)
        if not resp.status_code == 200:
            raise VSphereException("Error while uploading file")

    # no @reconnect_on_fault - don't try to reconnect if creds are not OK!
    def check_credentials(self, vm, username, password):
        LOG.info("Checking credentials for user %s on vm %s",
                 username, vm.name)
        creds = self._get_vm_creds(vm=vm, username=username, password=password)
        pm = self._vsphere_content.guestOperationsManager.processManager
        pm.ListProcessesInGuest(vm, creds)  # will raise vim.fault.InvalidGuestLogin if credentials are wrong

    @reconnect_on_fault
    def run_command(self, vm, username, password, command, arguments,
                    wait_for_return_value=True, process_exit_timeout=None, env_variables=None, sleep_between_intervals=1):
        self.wait_for_vmware_tools_to_run(vm)
        LOG.info("Running command '%s %s' on vm %s using user %s",
                 command, arguments, vm.name, username)
        creds = self._get_vm_creds(vm=vm, username=username, password=password)
        pm = self._vsphere_content.guestOperationsManager.processManager
        LOG.info("Process manager for running command is %s" % str(pm))
        spec = dict()
        if env_variables is not None:
            spec['envVariables'] = ["{}={}".format(key, value) for (key, value) in env_variables.items()]
        ps = vim.vm.guest.ProcessManager.ProgramSpec(
            programPath=command,
            arguments=arguments,
            **spec)
        LOG.info("Command process running %s" % str(ps))
        pid = pm.StartProgramInGuest(vm, creds, ps)
        LOG.info("Command running process id is %s" % str(pid))
        if not wait_for_return_value:
            return pid

        return self.wait_for_process(vm, username, password, pid, process_exit_timeout, sleep_between_intervals)

    @reconnect_on_fault
    def wait_for_process(self, vm, username, password, pid, process_exit_timeout=None, sleep_between_intervals=1):

        LOG.info("Waiting for process with pid %s on vm %s with the timeout %s to finish",
                 pid, vm.name, str(process_exit_timeout))

        creds = self._get_vm_creds(vm=vm, username=username, password=password)
        start_time = time.time()
        while process_exit_timeout is None or time.time() - start_time < process_exit_timeout:
            pm = self._vsphere_content.guestOperationsManager.processManager
            LOG.info("Process manager for running command is %s" % str(pm))
            process_list = pm.ListProcessesInGuest(vm, creds, [pid])
            if len(process_list) != 1:
                raise VSphereException("Process {} not found in process list on VM {}".format(pid, vm))
            if process_list[0].exitCode is not None:
                LOG.info('Process with pid %s on vm %s completed successfully, result: %s', pid, vm.name,
                         process_list[0].exitCode)
                return process_list[0].exitCode
            else:
                LOG.info('Process with pid %s on vm %s command result is None', pid, vm.name)
            do_sleep(sleep_between_intervals)

        raise VSphereException("Process execution timed out")

    @reconnect_on_fault
    def linked_clone(self, template_vm, snapshot_name, datastore, host, networks, new_vm_name, dest_folder,
                     should_turn_on=True, cpu_count=None, mem_size_mb=None, annotation=None, disk_size_gb=None):
        return self.clone(template_vm, datastore, host, networks, new_vm_name, dest_folder,
                          linked_clone=True, linked_clone_snapshot_name=snapshot_name,
                          should_turn_on=should_turn_on, cpu_count=cpu_count, mem_size_mb=mem_size_mb,
                          annotation=annotation, disk_size_gb=disk_size_gb)

    @reconnect_on_fault
    def clone(self, template_vm, datastore, host, networks, new_vm_name, dest_folder,
              linked_clone=False, linked_clone_snapshot_name=None, cpu_limit=-1, should_turn_on=True,
              cpu_count=None, cpu_reservation_mhz_per_core=None,
              mem_size_mb=None, mem_reservation_percent=None,
              disk_size_gb=None,
              use_e1000_nic=False,
              resource_pool=None,
              annotation=None):
        # Relocation spec
        relospec = vim.vm.RelocateSpec()
        if linked_clone:
            relospec.diskMoveType = 'createNewChildDiskBacking'

        relospec.pool = resource_pool if resource_pool else host.parent.resourcePool
        relospec.datastore = datastore
        relospec.host = host

        devices = []

        # don't clone nic devices from template if we specify networks
        if networks:
            for device in template_vm.config.hardware.device:
                if hasattr(device, 'addressType'):
                    # this is a VirtualEthernetCard, so we'll delete it
                    nic = vim.vm.device.VirtualDeviceSpec()
                    nic.operation = vim.vm.device.VirtualDeviceSpec.Operation.remove
                    nic.device = device
                    devices.append(nic)

            # create a Network device for each network
            for index, network in enumerate(networks):
                devices.append(self.create_nic(network, index, use_e1000_nic=use_e1000_nic))

        if disk_size_gb:
            for device in template_vm.config.hardware.device:

                if isinstance(device, vim.vm.device.VirtualDisk):
                    vdc = vim.vm.device.VirtualDeviceSpec()
                    LOG.info("changing disk size to %s", disk_size_gb)
                    device.capacityInBytes = disk_size_gb * 1024 * 1024 * 1024
                    device.capacityInKB = disk_size_gb * 1024 * 1024
                    vdc.device = device
                    vdc.operation = vim.vm.device.VirtualDeviceSpec.Operation.edit
                    devices.append(vdc)
                    break # TODO what would happen if we have multiple disks?

        # VM config spec
        vmconf = vim.vm.ConfigSpec()
        vmconf.cpuHotAddEnabled = True
        vmconf.memoryHotAddEnabled = True
        vmconf.deviceChange = devices
        vmconf.cpuAllocation = template_vm.config.cpuAllocation
        vmconf.cpuAllocation.limit = cpu_limit
        vmconf.annotation = annotation
        if cpu_count is not None:
            vmconf.numCPUs = cpu_count
            if cpu_reservation_mhz_per_core is not None:
                vmconf.cpuAllocation.reservation = int(round(cpu_reservation_mhz_per_core * cpu_count))
        if mem_size_mb is not None:
            vmconf.memoryMB = mem_size_mb
            if mem_reservation_percent is not None:
                reservation_mb = int(round(mem_size_mb * mem_reservation_percent / 100))
                vmconf.memoryAllocation = vim.ResourceAllocationInfo(reservation=reservation_mb)

        # Clone spec
        clonespec = vim.vm.CloneSpec()
        clonespec.location = relospec
        clonespec.powerOn = should_turn_on
        clonespec.template = False
        clonespec.config = vmconf
        if linked_clone:
            if not hasattr(template_vm.snapshot, "rootSnapshotList"):
                raise VSphereException("The given vm \"%s\" does not have any snapshots" % template_vm.name)
            if linked_clone_snapshot_name is None:
                raise VSphereException("No snapshot name specified")
            snapshots = template_vm.snapshot.rootSnapshotList
            found_snapshots = []
            for snapshot_obj in snapshots:
                found_snapshots += self._check_all_children_snapshots(snapshot_obj, linked_clone_snapshot_name)
            if len(found_snapshots) == 0:
                raise VSphereException(
                    "The machine \"%s\" does not have the snapshot \"%s\"" % (template_vm.name,
                                                                              linked_clone_snapshot_name))
            elif len(found_snapshots) > 1:
                raise VSphereException(
                    "The machine \"%s\" has more than 1 snapshot with the name \"%s\"" % (
                        template_vm.name, linked_clone_snapshot_name))
            else:
                snapshot_inner_snapshot_memory_obj = found_snapshots[0].snapshot
            clonespec.snapshot = snapshot_inner_snapshot_memory_obj

        # fire the clone task
        task = template_vm.Clone(folder=dest_folder, name=new_vm_name, spec=clonespec)
        return task

    @reconnect_on_fault
    def deploy_vm_from_template(self, template_vm, datastore, host, networks, new_vm_name, dest_folder,
                                cpu_limit=-1, should_turn_on=True,
                                cpu_count=None, cpu_reservation_mhz_per_core=None,
                                mem_size_mb=None, mem_reservation_percent=None,
                                linked_clone=False, linked_clone_snapshot_name=None, use_e1000_nic=False,
                                resource_pool=None, annotation=None, disk_size_gb=None):
        # Relocation spec
        relospec = vim.vm.RelocateSpec()
        relospec.datastore = datastore
        relospec.host = host
        relospec.pool = resource_pool if resource_pool else host.parent.resourcePool

        return self.clone(template_vm, datastore, host, networks, new_vm_name, dest_folder,
                          linked_clone=linked_clone, linked_clone_snapshot_name=linked_clone_snapshot_name,
                          cpu_limit=cpu_limit, should_turn_on=should_turn_on,
                          cpu_count=cpu_count, cpu_reservation_mhz_per_core=cpu_reservation_mhz_per_core,
                          mem_size_mb=mem_size_mb, mem_reservation_percent=mem_reservation_percent,
                          use_e1000_nic=use_e1000_nic, resource_pool=resource_pool,
                          annotation=annotation, disk_size_gb=disk_size_gb)

    @reconnect_on_fault
    def convert_vm_to_template(self, vm):
        try:
            vm.MarkAsTemplate()
        except Exception as exc:
            raise VSphereException("Failed converting VM %s (%s) to template: %s" % (vm.name, vm, exc))


    @reconnect_on_fault
    def wait_for_task(self, task, action_name, hide_result=False, update_status_callback=None):
        if update_status_callback is None:
            def dummy_callback(task):
                pass

            update_status_callback = dummy_callback

        LOG.info('Waiting for %s to complete.', action_name)

        last_state = (None, None)
        while task.info.state in [vim.TaskInfo.State.running, vim.TaskInfo.State.queued]:
            if task.info.state == "canceled":
                try:
                    task.CancelTask()
                except Exception as exc:
                    LOG.warn("Error canceling task '%s': %s", action_name, exc)

                LOG.warn('%s was canceled!', action_name)
                return None

            elif last_state != (task.info.state, task.info.progress):
                LOG.debug("Task '%s' state: %s (progress: %s%%)", action_name, task.info.state, task.info.progress or 0)
                last_state = (task.info.state, task.info.progress)

                try:
                    update_status_callback(task)
                except Exception:
                    LOG.exception("Error while calling %s task update status callback", action_name)

            do_sleep(1)

        if task.info.state == vim.TaskInfo.State.success:
            if task.info.result is not None and not hide_result:
                LOG.info('%s completed successfully, result: %s', action_name, task.info.result)
            else:
                LOG.info('%s completed successfully.', action_name)

            try:
                update_status_callback(task)
            except Exception:
                LOG.exception("Error while calling %s task update status callback", action_name)
        else:
            LOG.error('%s did not complete successfully: %s', action_name, task.info.error)
            raise VSphereTaskFailed(action_name, task.info.error)

        # may not always be applicable, but can't hurt.
        return task

    @reconnect_on_fault
    def wait_for_vmware_tools_to_run(self, vm, wait_timeout=DEFAULT_VMWARE_TOOLS_START_TIMEOUT, fast=False):
        LOG.info("Waiting for VMWare Tools service to start on vm %s", vm.name)

        start_time = time.time()
        while time.time() - start_time < wait_timeout:
            tools_status = vm.guest.toolsStatus
            if tools_status in [vim.vm.GuestInfo.ToolsStatus.toolsOk, vim.vm.GuestInfo.ToolsStatus.toolsOld]:
                LOG.info("VMWare tools installed and running on vm %s with version %s", vm.name, vm.guest.toolsVersion)
                if not fast:  # Some services might not yet be up.
                    do_sleep(30)
                return
            else:
                LOG.debug("VMWare tools still not running on VM or is not installed (%s)", tools_status)
                do_sleep(1)

        raise VSphereException("VMWare tools did not start on time on vm %s", vm.name)

    @reconnect_on_fault
    def wait_for_vm_to_report_ip(self, vm, timeout=None, interval=10, network=None):
        LOG.info("Waiting for vm %s to report its IP", vm.name)
        start_time = time.time()
        while timeout is None or time.time() - start_time < timeout:
            vm_ip = self.get_vm_ips(vm, network=network)
            if vm_ip:
                LOG.info("vm %s ip is %s" % (vm.name, str(vm_ip)))
                return vm_ip
            time.sleep(interval)

        raise VSphereException("wait for vm to report ip timed out")

    @reconnect_on_fault
    def create_subfolder(self, parent_folder, subfolder_name):
        return parent_folder.CreateFolder(subfolder_name)

    @reconnect_on_fault
    def get_vm_ips(self, vm, network=None, ipv6=False, ipv4=True):
        ips = []
        for nic in vm.guest.net:
            if (not network or (network == nic.network)) and nic.ipConfig:
                for ip_addr in nic.ipConfig.ipAddress:
                    if (ipv6 and (":" in ip_addr.ipAddress)) or (ipv4 and ("." in ip_addr.ipAddress)):
                        ips.append(ip_addr.ipAddress)

        return ips

    @reconnect_on_fault
    def get_vm_ip_address(self, vm, network, ipv6=True, ipv4=True):
        for nic in vm.guest.net:
            if nic.network == network.name:
                for ip_addr in nic.ipConfig.ipAddress:
                    if (ipv6 and (":" in ip_addr.ipAddress)) or (ipv4 and ("." in ip_addr.ipAddress)):
                        return ip_addr.ipAddress

        return None

    @reconnect_on_fault
    def create_gc_span_dvs(self, dvs, portgroup_name=GC_SPAN_PORTGROUP_PREFIX, vlan_id_start=0, vlan_id_end=4094):
        """
        Create span portgroup on given dvswitch
        :param dvs: The dvs to create the span on.
        """
        dvportgroup_config_spec = vim.DVPortgroupConfigSpec()
        dvportgroup_config_spec.name = portgroup_name
        dvportgroup_config_spec.description = "Guardicore SPAN promiscuous network for DVSwitch %s" % dvs.name
        dvportgroup_config_spec.type = vim.DistributedVirtualPortgroupPortgroupType.earlyBinding
        dvportgroup_config_spec.defaultPortConfig = vim.VMwareDVSPortSetting()

        security_policy = vim.DVSSecurityPolicy()
        security_policy.allowPromiscuous = vim.BoolPolicy()
        security_policy.allowPromiscuous.value = True
        security_policy.forgedTransmits = vim.BoolPolicy()
        security_policy.forgedTransmits.value = True
        security_policy.macChanges = vim.BoolPolicy()
        security_policy.macChanges.value = True
        dvportgroup_config_spec.defaultPortConfig.securityPolicy = security_policy

        vlan = vim.VmwareDistributedVirtualSwitchTrunkVlanSpec()
        vlan_id_range = vim.NumericRange()
        vlan_id_range.start = vlan_id_start
        vlan_id_range.end = vlan_id_end
        vlan.vlanId.append(vlan_id_range)
        dvportgroup_config_spec.defaultPortConfig.vlan = vlan
        task = dvs.AddDVPortgroup_Task([dvportgroup_config_spec])
        return task

    def create_gc_span_vss(self, host, vss, portgroup_name=GC_SPAN_PORTGROUP_PREFIX, vlan_id=4095):
        """
        Create span portgroup on given host and vswitch_name
        :param host: The host in which the vss is located on.
        :type host: vim.HostSystem
        :param vss: The name of the vss.
        :type vss: str.
        """
        host_portgroup_spec = vim.HostPortGroupSpec()
        host_portgroup_spec.name = portgroup_name
        host_portgroup_spec.vlanId = vlan_id
        host_portgroup_spec.vswitchName = vss
        host_portgroup_spec.policy = vim.HostNetworkPolicy()
        host_portgroup_spec.policy.security = vim.HostNetworkSecurityPolicy()
        host_portgroup_spec.policy.security.allowPromiscuous = True
        host_portgroup_spec.policy.security.forgedTransmits = True
        host_portgroup_spec.policy.security.macChanges = True
        host.configManager.networkSystem.AddPortGroup(host_portgroup_spec)

    def get_gc_span_dvs(self, dvs, portgroup_name=GC_SPAN_PORTGROUP_PREFIX):
        for portgroup in dvs.portgroup:
            if portgroup_name == portgroup.name:
                return portgroup
        return None

    def create_nic(self, network, nic_index, use_e1000_nic=False):
        # VM device
        nic = vim.vm.device.VirtualDeviceSpec()
        nic.operation = vim.vm.device.VirtualDeviceSpec.Operation.add

        if not use_e1000_nic:
            nic.device = vim.vm.device.VirtualVmxnet3()
            # from vmware docs: Clients should ensure that existing device keys are not reused as temporary key values
            # for the new device to be added (for example, by using unique negative integers as temporary keys).
            nic.device.key = (nic_index + 1) * (-1)
        else:
            LOG.info("Setting Nic as E1000")
            nic.device = vim.vm.device.VirtualE1000()
        # from vmware docs: Clients should ensure that existing device keys are not reused as temporary key values
        # for the new device to be added (for example, by using unique negative integers as temporary keys).
        nic.device.key = (nic_index + 1) * (-1)
        nic.device.wakeOnLanEnabled = True
        nic.device.addressType = 'assigned'

        nic.device.deviceInfo = vim.Description()
        nic.device.deviceInfo.label = 'Network Adapter %s' % (nic_index + 1)

        if isinstance(network, vim.dvs.DistributedVirtualPortgroup):
            nic.device.backing = vim.vm.device.VirtualEthernetCard.DistributedVirtualPortBackingInfo()
            nic.device.backing.port = vim.dvs.PortConnection()
            nic.device.backing.port.portgroupKey = network.key
            nic.device.backing.port.switchUuid = network.config.distributedVirtualSwitch.uuid
        else:
            nic.device.backing = vim.vm.device.VirtualEthernetCard.NetworkBackingInfo()
            nic.device.backing.network = network
            nic.device.backing.deviceName = network.name
            nic.device.backing.useAutoDetect = True

        nic.device.connectable = vim.vm.device.VirtualDevice.ConnectInfo()
        nic.device.connectable.startConnected = True
        nic.device.connectable.allowGuestControl = True
        return nic

    @reconnect_on_fault
    def add_nics_to_vm(self, vm, networks, start_index):
        new_nics = []
        for inner_index, network in enumerate(networks):
            current_index = inner_index + start_index
            new_nics.append(self.create_nic(network, current_index))

        vmconf = vim.vm.ConfigSpec()
        vmconf.deviceChange = new_nics

        # fire the reconfig task
        return vm.ReconfigVM_Task(spec=vmconf)

    @reconnect_on_fault
    def change_cpu_limit(self, vm, cpu_limit):
        vmconf = vim.vm.ConfigSpec()
        vmconf.cpuAllocation = vm.config.cpuAllocation
        vmconf.cpuAllocation.limit = cpu_limit

        # fire the reconfig task
        return vm.ReconfigVM_Task(spec=vmconf)

    def change_vm_cdroms_to_passthrough(self, vm):
        for device in vm.config.hardware.device:
            if not isinstance(device, vim.vm.device.VirtualCdrom):
                continue

            edited_cdrom = vim.vm.device.VirtualDeviceSpec()
            edited_cdrom.operation = vim.vm.device.VirtualDeviceSpec.Operation.edit
            device.backing = vim.vm.device.VirtualCdrom.RemotePassthroughBackingInfo()
            edited_cdrom.device = device

            vm_conf = vim.vm.ConfigSpec()
            vm_conf.deviceChange = [edited_cdrom]

            task = vm.ReconfigVM_Task(spec=vm_conf)
            self.wait_for_task(task=task, action_name="Edit VM's CD-ROM")

    def remove_nvram_from_vmx(self, vm, datacenter):
        """ removing nvram from vm vmx configuration
            ESXi credentials must belong to an ESX server that access to the vm vmx file """

        nvram_file_path = vm.summary.config.vmPathName.replace("] ", "]/").replace(".vmx", ".nvram")

        LOG.info("Going to remove nvram file from %s ", nvram_file_path)

        task = self._vsphere_content.fileManager.DeleteFile(nvram_file_path, datacenter)
        self.wait_for_task(task=task, action_name="Deleting NVRAM file from vm folder")

        spec = vim.vm.ConfigSpec()
        spec.extraConfig = []
        for configuration in vm.config.extraConfig:
            if "nvram" not in configuration.key:
                spec.extraConfig.append(configuration)

        task = vm.ReconfigVM_Task(spec=spec)
        self.wait_for_task(task=task, action_name="Reconfigure vm - remove nvram")

    def get_last_snapshot(self, vm, snapshot_name=None, snapshot_tree=None, creation_time=None):
        if not snapshot_name:
            if not vm:
                return None, None
            snapshot_tree = vm.snapshot.rootSnapshotList[0]
            snapshot_name = snapshot_tree.name
            creation_time = snapshot_tree.createTime
        for snapshot in snapshot_tree.childSnapshotList:
            if not snapshot.childSnapshotList:
                if not creation_time or snapshot.createTime > creation_time:
                    snapshot_name = snapshot.name
                    creation_time = snapshot.createTime
            else:
                snapshot_tree = snapshot
                self.get_last_snapshot(vm, snapshot_name, snapshot_tree, creation_time)
        return snapshot_name, creation_time

    @reconnect_on_fault
    def revert_machine_snapshot(self, vm, snapshot_name):
        if not hasattr(vm.snapshot, "rootSnapshotList"):
            raise VSphereException("The given vm \"%s\" does not have any snapshots" % vm.name)
        snapshots = vm.snapshot.rootSnapshotList
        found_snapshots = []
        for snapshot_obj in snapshots:
            found_snapshots += self._check_all_children_snapshots(snapshot_obj, snapshot_name)
        if len(found_snapshots) == 0:
            raise VSphereException("The machine \"%s\" does not have the snapshot \"%s\"" % (vm.name, snapshot_name))
        elif len(found_snapshots) > 1:
            raise VSphereException(
                "The machine \"%s\" has more than 1 snapshot with the name \"%s\"" % (vm.name, snapshot_name))
        else:
            snapshot_inner_snapshot_memory_obj = found_snapshots[0].snapshot
        LOG.info("Reverting machine \"%s\" to the snapshot \"%s\"", vm.name, snapshot_name)
        task = snapshot_inner_snapshot_memory_obj.RevertToSnapshot_Task()
        self.wait_for_task(task=task, action_name="Snapshot revert")

    def _check_all_children_snapshots(self, snapshot_object, wanted_snapshot_name):
        found_snapshots = []
        if snapshot_object.name == wanted_snapshot_name:
            found_snapshots.append(snapshot_object)
        for child_snapshot_object in snapshot_object.childSnapshotList:
            found_snapshots += self._check_all_children_snapshots(child_snapshot_object, wanted_snapshot_name)
        return found_snapshots

    @reconnect_on_fault
    def add_property(self, vm, property_name, property_value, property_key=None, property_label=None,
                     property_type="string"):
        return self.add_or_update_property(vm=vm, property_name=property_name, property_value=property_value,
                                           property_key=property_key, property_label=property_label,
                                           property_type=property_type, property_exists=False)

    @reconnect_on_fault
    def update_property(self, vm, property_name, property_value, property_key=None, property_label=None,
                        property_type="string"):
        return self.add_or_update_property(vm=vm, property_name=property_name, property_value=property_value,
                                           property_key=property_key, property_label=property_label,
                                           property_type=property_type, property_exists=True)

    @reconnect_on_fault
    def add_or_update_property(self, vm, property_name, property_value, property_key=None, property_label=None,
                               property_type="string", property_exists=None):
        """
        Add or update property to machine PropertyInfo
        """
        if property_exists is None:
            property_exists = (self.get_property(vm=vm, property_name=property_name) is not None)

        vapp_property_info = vim.VAppPropertyInfo()
        vapp_property_info.type = property_type
        vapp_property_info.id = property_name
        vapp_property_info.value = property_value

        if property_key:
            vapp_property_info.key = property_key
        if property_label:
            vapp_property_info.label = property_label

        vapp_property_spec = vim.VAppPropertySpec()
        vapp_property_spec.operation = \
            vim.ArrayUpdateOperation.add if not property_exists else vim.ArrayUpdateOperation.edit
        vapp_property_spec.info = vapp_property_info

        vm_config_spec = vim.VmConfigSpec()
        vm_config_spec.property = [vapp_property_spec]

        virtual_machine_config_spec = vim.VirtualMachineConfigSpec()
        virtual_machine_config_spec.vAppConfig = vm_config_spec

        return vm.ReconfigVM_Task(virtual_machine_config_spec)

    @staticmethod
    def get_property(vm, property_name):
        if not vm.config.vAppConfig:
            return None

        for vapp_property in vm.config.vAppConfig.property:
            if vapp_property.id == property_name:
                return vapp_property.value

        return None

    def edit_instance_id(self, vm, instance_id):
        """
        edit instance_id in ProductSection
        instance_id must not contain whitespaces
        """
        if True in [c in instance_id for c in string.whitespace]:
            raise ValueError("instance_id must not contain whitespaces: %s" % instance_id)

        vapp_product_info = vim.VAppProductInfo()
        vapp_product_info.instanceId = instance_id

        vapp_product_spec = vim.VAppProductSpec()
        vapp_product_spec.info = vapp_product_info
        vapp_product_spec.operation = vim.ArrayUpdateOperation.edit

        vm_config_spec = vim.VmConfigSpec()
        vm_config_spec.product = [vapp_product_spec]

        virtual_machine_config_spec = vim.VirtualMachineConfigSpec()
        virtual_machine_config_spec.vAppConfig = vm_config_spec

        return vm.ReconfigVM_Task(virtual_machine_config_spec)

    def get_datastores_by_folder(self, datacenter, ds_folder_name):
        """Returns datastores list under ds_folder_name"""
        if not ds_folder_name:
            raise ValueError("Datastore folder name can't be empty")

        if isinstance(datacenter, vim.Datacenter):
            datacenter_obj = datacenter
        else:
            datacenter_obj = self._get_obj(vim_type=[vim.Datacenter], name=datacenter)
            if not datacenter_obj:
                LOG.warn("Datacenter '%s' isn't found", datacenter)
                return False

        for ds_folder in datacenter_obj.datastoreFolder.childEntity:
            if ds_folder.name and (ds_folder_name.lower() == ds_folder.name.lower()):
                return ds_folder.childEntity
        raise VSphereException("Datastore Folder wasn't found - %s" % ds_folder_name)

    @staticmethod
    def get_host_global_unique_identifier(host):
        """
        Get a string the identify this host in a global unique way.
        """
        # NOTE: we use this monster host-id because moref is not unique enough among vcenter
        # and in fact all standalone ESX hosts have the same moref
        # see how compute it in vsphere_cache **(note that the way we do it must be the same)**
        return "{host_name}--{host_moref}--{host_bios_uuid}".format(
            host_name=host.name,
            host_moref=host._GetMoId(),
            host_bios_uuid=host.hardware.systemInfo.uuid,
        )

    def set_vm_cpu_limit(self, vm, cpu_limit):
        vmconf = vim.vm.ConfigSpec()
        vmconf.cpuAllocation = vm.config.cpuAllocation
        vmconf.cpuAllocation.limit = cpu_limit
        reconfigure_task = vm.ReconfigVM_Task(spec=vmconf)
        self.wait_for_task(task=reconfigure_task, action_name="Reconfigure %s cpu limit to %s" % (vm.name, cpu_limit))
