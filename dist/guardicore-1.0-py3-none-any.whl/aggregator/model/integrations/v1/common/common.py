from __future__ import annotations

from enum import Enum


class Connector(Enum):
    CLOUD_AZURE = 'cloud_azure'
    PACKETFENCE = 'packetfence'
