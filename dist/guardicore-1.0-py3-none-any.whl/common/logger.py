import os
import re
import sys
import gzip
import time
import socket
import logging.config
from logging import Formatter, FileHandler, StreamHandler, Logger
from logging.handlers import RotatingFileHandler, SYSLOG_UDP_PORT, TimedRotatingFileHandler

from enum import IntEnum

from common.py.utils.config import cfg
from common.py.saas.bootstrap import is_runtime_saas

DEBUG_ALL = False
IS_WINDOWS = sys.platform.startswith('win')
LINUX_LOG_PATH = "/var/log/guardicore"
WINDOWS_LOG_PATH = "c:\\windows\\temp"
COLORS_DEFAULT = True
DEFAULT_FORMAT = '%(asctime)s [%(process)d:%(levelname)s] %(module)s.%(funcName)s.%(lineno)d: %(message)s'
GC_LOGGER_ROOT = "guardicore"

if not IS_WINDOWS:
    import fcntl

LOG_FILE_SIZE = 10 * (2 ** 20)
LOG_BACKUP_COUNT = 10
DEF_LOG_PATH = WINDOWS_LOG_PATH if IS_WINDOWS else LINUX_LOG_PATH

LOGGER_OPTS = [cfg.BoolOpt('debug', short='d',
                           default=DEBUG_ALL,
                           help="Set all log level to debug"),
               cfg.StrOpt('path', short='l',
                          default=DEF_LOG_PATH,
                          help="Log file base path"),
               cfg.BoolOpt('log_to_file',
                           default=True,
                           help="Log to file"),
               cfg.BoolOpt('use_colors',
                           default=COLORS_DEFAULT,
                           help="Use colors in the logging console"),
               cfg.BoolOpt('full_line_color',
                           default=False,
                           help="Log coloring is set to entire line"),
               cfg.IntOpt('log_file_size',
                          default=LOG_FILE_SIZE,
                          help="Rotating log file size"),
               cfg.BoolOpt('compress_rotated_log',
                           default=False,
                           help="Should the rotated log be compressed"),
               cfg.IntOpt('backup_count',
                          default=LOG_BACKUP_COUNT,
                          help="Rotating log file count"),
               cfg.BoolOpt('use_syslog', short='syslog',
                           default=False,
                           help="Should we use the syslog server for logging messages"),
               cfg.StrOpt('syslog_host', short='host',
                          default="localhost",
                          help="Address of syslog host"),
               cfg.IntOpt('syslog_port', short='port',
                          default=SYSLOG_UDP_PORT,
                          help="port of syslog host"),
               cfg.BoolOpt('log_to_screen',
                           default=sys.stdout.isatty() or 'PYCHARM_HOSTED' in os.environ,
                           help="Should the logger print to screen")]

cfg.CONF.register_cli_opts(LOGGER_OPTS, "log")
cfg.CONF.register_opts(LOGGER_OPTS, "log")


class LogLevel(IntEnum):
    NOTSET = logging.NOTSET
    DEBUG = logging.DEBUG
    INFO = logging.INFO
    WARNING = logging.WARNING
    ERROR = logging.ERROR
    CRITICAL = logging.CRITICAL

    @staticmethod
    def from_str(level_name):
        return LOG_LEVEL_MAP.get(level_name)


LOG_LEVEL_MAP = {level.name: level for level in LogLevel}


def get_level_name(level):
    return LogLevel(level).name


def get_level(level_name):
    return LogLevel.from_str(level_name)


class PasswordMaskingFormatter(Formatter):
    """ Tries to mask passwords in the log message.
    If a password contains quotes (either single or double), the regular expression, used by the formatter,
    will mask the password partially. The formatter masks only debug messages due to performance reason.
    The masking is optional, if the mask_passwords parameter in the class constructor is False, no masking performed.
    """
    re1 = r'''(["']*\w*password\w*["']*[:=]*[\s]*["']*)([^"'\s]+)(["'\W])'''
    re2 = r':\/\/(.*?)\@'
    password_regex_replacements = {r'\1*****\3': re.compile(re1),
                                   r'://*****@': re.compile(re2)}

    @classmethod
    def mask_passwords(cls, s):
        for replacement_str, regex in cls.password_regex_replacements.items():
            s = regex.sub(replacement_str, s)
        return s

    def __init__(self, mask_passwords, *args, **kwargs):
        super(PasswordMaskingFormatter, self).__init__(*args, **kwargs)
        self.mask_passwords = mask_passwords

    def format(self, record):
        s = super(PasswordMaskingFormatter, self).format(record)
        # mask only debug
        if self.mask_passwords and record.levelno == logging.DEBUG:
            s = PasswordMaskingFormatter.mask_passwords(s)
        return s


class RemoteFormatter(PasswordMaskingFormatter):
    """class RemoteFormatter(Formatter)
    
    Add hostname parameter for a log record for remote log entries sent by
    syslog, etc.
    """

    def __init__(self, fmt, hostname, mask_passwords=False):
        super(RemoteFormatter, self).__init__(mask_passwords, fmt)

        self._format = fmt
        self._hostname = hostname

    def format(self, record):
        record.hostname = self._hostname
        return super(RemoteFormatter, self).format(record)


class ColoredFormatter(PasswordMaskingFormatter):
    """class ColoredFormatter(Formatter)

    A color formatter to support color logging.
    """

    BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE = range(8)
    COLORS = {'WARNING': YELLOW,
              'INFO': WHITE,
              'DEBUG': MAGENTA,
              'CRITICAL': RED,
              'ERROR': RED,
              }
    RESET_SEQ = "\033[0m"
    COLOR_SEQ = "\033[1;%dm"
    BOLD_SEQ = "\033[1m"

    def __init__(self, fmt, full_line_color=False, mask_passwords=False):
        super(ColoredFormatter, self).__init__(mask_passwords, fmt)

        if full_line_color:
            self.format = self._format_full_line_color
        else:
            self.format = self._format

    def _format_full_line_color(self, record):
        levelname = record.levelname

        if levelname in ColoredFormatter.COLORS:
            return ColoredFormatter.COLOR_SEQ % (30 + ColoredFormatter.COLORS[levelname]) + super(ColoredFormatter,
                                                                                                  self).format(
                record) + ColoredFormatter.RESET_SEQ

        return super(ColoredFormatter, self).format(record)

    def _format(self, record):
        levelname = record.levelname

        if levelname in ColoredFormatter.COLORS:
            levelname_color = ColoredFormatter.COLOR_SEQ % (
                    30 + ColoredFormatter.COLORS[levelname]) + levelname + ColoredFormatter.RESET_SEQ
            record.levelname = levelname_color

        return super(ColoredFormatter, self).format(record)


class CompressedRotatingFile(object):
    READ_BUFFER_SIZE = 1024 * 1024  # 1MB

    def __init__(self, filename):
        self.filename = filename

    def do_rollover(self, output_compress_file):
        if os.path.exists(output_compress_file):
            os.remove(output_compress_file)

        if os.path.exists(self.filename):
            # compress the file
            with open(self.filename, "rb") as unpacked, gzip.GzipFile(output_compress_file, "wb") as packed:
                while True:
                    chunk = unpacked.read(self.READ_BUFFER_SIZE)
                    if not chunk:
                        break
                    packed.write(chunk)

            # remove origin file
            try:
                os.remove(self.filename)
            except:
                pass

    def do_index_rollover(self, index):
        output_compress_file = self.filename + ".%d.gz" % index
        self.do_rollover(output_compress_file)


class CompressedRotatingFileHandler(RotatingFileHandler):
    """Class CompressedRotatingFileHandler(RotatingFileHandler)
    
    Extended version of RotatingFileHandler which compress the rotated
    file using gzip on each roll-over.
    """

    def __init__(self, filename, *args, **kwargs):
        super(CompressedRotatingFileHandler, self).__init__(filename, *args, **kwargs)
        self.file_compressor = CompressedRotatingFile(filename)

    def _open(self):
        stream = super(CompressedRotatingFileHandler, self)._open()

        # if possible, force the logger stream to be closed inside sub-processes to avoid
        # unnecessary fd leakage.
        if not IS_WINDOWS and getattr(stream, "fileno", None) is not None:
            fcntl.fcntl(stream.fileno(), fcntl.F_SETFD, fcntl.FD_CLOEXEC)

        return stream

    def doRollover(self):
        """
        Do a rollover, as described in __init__().
        """
        if self.stream:
            self.stream.close()
            self.stream = None

        if self.backupCount > 0:
            for i in range(self.backupCount - 1, 0, -1):
                sfn = "%s.%d.gz" % (self.baseFilename, i)
                dfn = "%s.%d.gz" % (self.baseFilename, i + 1)
                if os.path.exists(sfn):
                    if os.path.exists(dfn):
                        os.remove(dfn)
                    os.rename(sfn, dfn)
            dfn = self.baseFilename + ".1.gz"

            # Issue 18940: A file may not have been created if delay is True.
            self.file_compressor.do_rollover(dfn)
        if not getattr(self, 'delay', False):
            self.stream = self._open()


class RetryStreamHandler(StreamHandler):
    def __init__(self, retries=1, *args, **kwargs):
        super(RetryStreamHandler, self).__init__(*args, **kwargs)
        self.retries = retries

    def emit(self, record):
        if not hasattr(record, 'attempts'):
            record.attempts = self.retries
        return super(RetryStreamHandler, self).emit(record=record)

    def handleError(self, record):
        ei = sys.exc_info()
        if 3 == len(ei):
            exc_type, exc, tb = ei
            if isinstance(exc, IOError):
                record.attempts = getattr(record, 'attempts', 1)
                record.attempts -= 1
                if record.attempts > 0:
                    time.sleep(0)
                    self.emit(record)
                    return

        return super(RetryStreamHandler, self).handleError(record=record)


CONFIG = {'version': 1,
          'formatters': {
              'standard': {'()': 'common.logger.PasswordMaskingFormatter',
                           'mask_passwords': False,
                           'format': DEFAULT_FORMAT},
              'colored': {'()': 'common.logger.ColoredFormatter',
                          'full_line_color': False,
                          'format': DEFAULT_FORMAT,
                          'mask_passwords': False},
              'remote': {'()': 'common.logger.RemoteFormatter',
                         'hostname': socket.gethostname(),
                         'format': 'Guardicore: %(asctime)s [%(hostname)s:%(process)d:%(levelname)s] %(module)s.%(funcName)s.%(lineno)d: %(message)s',
                         'mask_passwords': False
                         }},
          'handlers': {'console': {'class': 'common.logger.RetryStreamHandler',
                                   'level': 'INFO',
                                   'formatter': 'standard',
                                   'retries': 1,
                                   'stream': 'ext://sys.stdout'}},
          'loggers': {},
          'disable_existing_loggers': False}


def _get_log_name(log_name, log_path):
    return os.path.join(log_path, "%s.log" % (log_name,))


def _flush_logger(logger):
    for handler in logger.handlers:
        handler.flush()


def init_time_rotated_log():
    logger_name = 'fast_labels'
    log_path = cfg.CONF.log.path
    if not os.path.isdir(log_path):
        os.makedirs(log_path)
    filename = _get_log_name(logger_name, log_path)
    handler = TimedRotatingFileHandler(filename=filename,
                                       when='MIDNIGHT',
                                       interval=1,
                                       backupCount=30)
    formatter = logging.Formatter(DEFAULT_FORMAT)
    handler.setFormatter(formatter)
    fast_logger = logging.getLogger('fast_labels_log')
    fast_logger.addHandler(handler)
    fast_logger.setLevel(logging.DEBUG)


def log_init(base_name, logger_name=GC_LOGGER_ROOT, log_path=None, debug=False,
             use_colors=COLORS_DEFAULT, use_stderr=False, set_excepthook=True, show_thread_name=False,
             log_to_screen=True, emit_init_msg=True, compress_rotated_log=False, stream_error_retries=1,
             uid=None, gid=None, mask_passwords=False):
    # SaaS - lot to stdout intstead of files
    CONFIG['loggers'][logger_name] = {'level': 'INFO', 'propagate': 0}
    if cfg.CONF.log.log_to_screen or log_to_screen or is_runtime_saas():
        CONFIG['loggers'][logger_name]['handlers'] = ['console']
    else:
        CONFIG['loggers'][logger_name]['handlers'] = []

    CONFIG['handlers']['console']['retries'] = stream_error_retries

    # add syslog if needed
    if cfg.CONF.log.use_syslog:
        CONFIG['handlers']['syslog'] = {'class': 'logging.handlers.SysLogHandler',
                                        'level': 'INFO',
                                        'formatter': 'remote',
                                        'address': (cfg.CONF.log.syslog_host, cfg.CONF.log.syslog_port)}

        CONFIG['loggers'][logger_name]['handlers'].append('syslog')

    if (use_colors or cfg.CONF.log.use_colors) and sys.stdout.isatty():
        CONFIG['handlers']['console']['formatter'] = 'colored'
        CONFIG['formatters']['colored']['full_line_color'] = cfg.CONF.log.full_line_color

    if use_stderr:
        CONFIG['handlers']['console']['stream'] = 'ext://sys.stderr'

    if is_runtime_saas():
        CONFIG['handlers']['console']['level'] = 'DEBUG'

    # SaaS - avoid logging to files
    # create file handler
    if cfg.CONF.log.log_to_file and not is_runtime_saas():
        # Set logger file name
        if not log_path:
            log_path = cfg.CONF.log.path
        if not os.path.isdir(log_path):
            os.makedirs(log_path)
        handler_name = 'file_%s' % base_name
        compress_rotated_log = compress_rotated_log or cfg.CONF.log.compress_rotated_log
        log_file_name = _get_log_name(base_name, log_path)
        CONFIG['handlers'][handler_name] = {
            'class': 'common.logger.CompressedRotatingFileHandler' if compress_rotated_log else 'logging.handlers.RotatingFileHandler',
            'level': 'DEBUG',
            'formatter': 'standard',
            'filename': log_file_name,
            'maxBytes': cfg.CONF.log.log_file_size,
            'backupCount': cfg.CONF.log.backup_count}
        CONFIG['loggers'][logger_name]['handlers'].append(handler_name)
    else:
        log_file_name = None

    # set all loggers to debug level
    if debug or cfg.CONF.log.debug:
        CONFIG['loggers'][logger_name]['level'] = "DEBUG"
        for handler in CONFIG['handlers']:
            CONFIG['handlers'][handler]['level'] = "DEBUG"

    if show_thread_name:
        for formatter in CONFIG['formatters'].values():
            if 'format' in formatter and "%(threadName)s" not in formatter['format']:
                formatter['format'] = formatter['format'].replace("%(process)d:",
                                                                  "%(process)d:%(threadName)s:")
    if mask_passwords:
        for formatter in CONFIG['formatters'].values():
            formatter['mask_passwords'] = True

    logging.config.dictConfig(CONFIG)
    logger = logging.getLogger(logger_name)

    if log_file_name is not None and uid is not None and gid is not None:
        os.chown(log_file_name, uid, gid)

    if set_excepthook:
        def log_uncaught_exceptions(ex_cls, ex, tb):
            logger.critical("Uncaught exception", exc_info=(ex_cls, ex, tb))

        sys.excepthook = log_uncaught_exceptions

    if emit_init_msg:
        logger.info(">>>>>>>>>> Initializing logger: PID %s <<<<<<<<<<", os.getpid())
    return logger


def get_logger(logger_name=GC_LOGGER_ROOT, module_name=None):
    if module_name:
        logger_name += "." + module_name
    return logging.getLogger(logger_name)


def get_new_logger(logger_name, logger_fname, logger_dir=LINUX_LOG_PATH, debug=True, syslog_to_file=False):
    new_logger = logging.getLogger(logger_name)
    new_logger.setLevel(logging.DEBUG)
    new_logger.propagate = False

    handler = CompressedRotatingFileHandler(os.path.join(logger_dir, logger_fname + ".log"),
                                            maxBytes=cfg.CONF.log.log_file_size,
                                            backupCount=cfg.CONF.log.backup_count)
    if syslog_to_file:
        handler.setFormatter(logging.Formatter('%(asctime)s [Message exported to syslog]:\n\n%(message)s\n'))
    else:
        handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
    handler.setLevel(logging.DEBUG if debug else logging.INFO)
    new_logger.addHandler(handler)
    return new_logger, handler


def branch_log(base_name, logger=None, log_path=None, use_colors=COLORS_DEFAULT, debug=True, show_thread_name=False):
    if logger is None:
        caller_path = sys._getframe(4).f_back.f_code.co_filename
        module_name = os.path.basename(caller_path)
        if module_name.startswith("__init__.py"):
            module_name = os.path.basename(os.path.dirname(caller_path))
        else:
            module_name = os.path.splitext(module_name)[0]
        logger = get_logger(module_name=module_name)

    if not log_path:
        log_path = cfg.CONF.log.path
    if not os.path.isdir(log_path):
        os.makedirs(log_path)

    format = DEFAULT_FORMAT
    if show_thread_name:
        format = format.replace("%(process)d:", "%(process)d:%(threadName)s:")

    formater = ColoredFormatter(format) if use_colors else Formatter(format)

    log_file_path = _get_log_name(base_name, log_path)

    handler = CompressedRotatingFileHandler(log_file_path,
                                            maxBytes=cfg.CONF.log.log_file_size,
                                            backupCount=cfg.CONF.log.backup_count)
    handler.setLevel(logging.DEBUG if debug else logging.INFO)
    handler.setFormatter(formater)
    logger.addHandler(handler)
    return logger


def attach_log(parent_log, module_name=None, logger_name=None):
    assert (module_name is None or logger_name is None) and (module_name is not None or logger_name is not None)

    if module_name:
        module = sys.modules.get(module_name, None)
        if module is None:
            parent_log.warn("Couldn't attach log of missing module %s", module_name)
            return

        child_logger = getattr(module, "LOG", None)
        if child_logger is None:
            parent_log.warn("Couldn't attach log of module %s without LOG", module_name)
            return
    else:
        child_logger = logging.getLogger(logger_name)

    for handler in parent_log.handlers:
        child_logger.addHandler(handler)


def get_log_content(logger=GC_LOGGER_ROOT, line_count=0):
    """
    To be used for remotely pulling logs. Only brings lines from current log file.
    :param logger:
    :param line_count:
    """
    logger = get_logger(logger)
    _flush_logger(logger)
    return_all = False
    logging_file = None
    for handler in logger.handlers:
        if isinstance(handler, FileHandler):
            logging_file = handler.baseFilename
            break
    if logging_file is None:
        raise Exception("Logs were not initialized. Call log_init.")
    with open(logging_file, 'r') as log_file:
        if line_count == 0:
            return log_file.read()
        offs = -100
        while True:
            try:
                log_file.seek(offs, 2)
            except IOError:
                log_file.seek(0)
                return_all = True
            lines = log_file.readlines()
            if return_all or (len(lines) > line_count):
                return ''.join(lines[-line_count:])
            offs *= 2


def get_log_handlers(logger):
    assert isinstance(logger, Logger)

    if logger.handlers:
        return logger.handlers

    while logger.parent:
        logger = logger.parent
        if logger.handlers:
            return logger.handlers


def is_debug(logger=GC_LOGGER_ROOT):
    logger = get_logger(logger)
    return logger.level <= logging.DEBUG


def format_short_time(t):
    if t > 0.1:
        return '{:.2f}s'.format(t)
    t *= 1000
    if t > 3:
        return '{:.2f}ms'.format(t)
    t *= 1000
    return '{:.2f}ns'.format(t)
