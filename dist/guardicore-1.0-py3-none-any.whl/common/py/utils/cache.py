import time
from collections import OrderedDict

from common.logger import get_logger

LOGGER = get_logger(module_name=__name__)


def create_cache(*args, **kwargs):
    size_limit = kwargs.pop("size_limit", None)
    if size_limit:
        return LimitedCache(size_limit=size_limit, *args, **kwargs)
    return Cache(*args, **kwargs)


class Cache(OrderedDict):
    pass


class LimitedCache(Cache):
    def __init__(self, *args, **kwargs):
        self.size_limit = kwargs.pop("size_limit")
        super(Cache, self).__init__(*args, **kwargs)
        self._check_size_limit()

    def __setitem__(self, key, value):
        super(LimitedCache, self).__setitem__(key, value)
        self._check_size_limit()

    def fetch(self, key):
        value = super(Cache, self).pop(key)
        self.__setitem__(key, value)
        return value

    def _check_size_limit(self):
        while len(self) > self.size_limit:
            self.popitem(last=False)


class ExpirableCache(object):
    def __init__(self, exp_timeout, name=None, size_limit=0, *args, **kwargs):
        self.exp_timeout = max(exp_timeout, 10)
        self.size_limit = size_limit
        self.name = name

        if size_limit == 0:
            self._cache = dict(*args, **kwargs)
        else:
            self._cache = OrderedDict(*args, **kwargs)

        self._next_cache_check = self._get_next_cache_check_time()

    def clear(self):
        self._cache.clear()

    def _get_next_cache_check_time(self):
        return time.time() + (self.exp_timeout / 3.0)

    def __len__(self):
        return len(self._cache)

    def __repr__(self):
        return "<ExpirableCache%s size=%d>" % ((" " + self.name) if self.name else "", len(self._cache))

    def _manage_cache(self):
        now = time.time()
        if self._next_cache_check >= now:
            return

        try:
            expired_pairs = [key for key, (_, exp_time) in self._cache.items() if exp_time < now]

            if self.name and expired_pairs:
                LOGGER.debug("Expired %d/%d entries: %s in %s cache", len(expired_pairs), len(self._cache), expired_pairs, self.name)
            self._cache = {key: value for key, value in self._cache.items() if key not in expired_pairs}
        except:
            LOGGER.exception("Error during in-memory cache expiration%s", ("of " + self.name) if self.name else "")
        finally:
            self._next_cache_check = self._get_next_cache_check_time()

    def __contains__(self, item):
        self._manage_cache()
        return item in self._cache

    def items(self):
        self._manage_cache()

        return [(key, value) for key, (value, exp_time) in self._cache.items()]

    def iteritems(self):
        self._manage_cache()

        for key, (value, exp_time) in self._cache.items():
            yield key, value

    def values(self):
        self._manage_cache()

        return [value for value, exp_time in self._cache.values()]

    def itervalues(self):
        self._manage_cache()

        for value, exp_time in self._cache.values():
            yield value

    def update_expiry_timeout(self, new_timeout):
        self.exp_timeout = new_timeout

    def get(self, key, default=None):
        self._manage_cache()

        value, _ = self._cache.get(key, (default, None))
        return value

    def pop(self, key, *args):
        self._manage_cache()

        if args:
            args = ((args[0], None), )
        value, _ = self._cache.pop(key, *args)
        return value

    def __setitem__(self, key, value):
        if self.size_limit and len(self._cache) >= self.size_limit and key not in self._cache:
            self._cache.popitem(last=False)

        self._cache[key] = (value, time.time() + self.exp_timeout)

    def __getitem__(self, item):
        self._manage_cache()

        value = self._cache[item]
        return value[0]

    def __delitem__(self, key):
        self._manage_cache()

        try:
            del self._cache[key]
        except KeyError:
            # We suppress the error on nonexistent entries because they may be removed from time to time anyway.
            pass
