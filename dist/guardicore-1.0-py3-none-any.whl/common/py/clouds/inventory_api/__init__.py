from common.py.clouds import common_opts, label_opts
from common.py.clouds.inventory_api.model import AuthenticationScheme
from common.py.utils.config import cfg
from common.py.utils.config.types import Structure

DEFAULT_REPORT_EXPIRATION = 3600

# inventory-time API specific configurations
inventory_api_opts = [cfg.StrOpt('rest_username', default="gc-api",
                                 help="Username for authenticating the inventory API"),
                      cfg.StrOpt('rest_password', secret=True,
                                 help="Password for authenticating the inventory API"),
                      cfg.StrOpt('integration_token', default=None,
                                 help="Integration token for authenticating the inventory API"),
                      cfg.StrOpt('authentication_scheme', choices=list(AuthenticationScheme.__members__.keys()),
                                 default=AuthenticationScheme.UserPassword.name,
                                 help="Authentication scheme to use for authenticating the inventory API"),
                      cfg.StrOpt('allowed_incoming', default="",
                                 help="List of allowed source incoming CIDRs in the form of 'X.Y.Z.W/len' separated"
                                      " by commas"),
                      cfg.IntOpt('report_expiration', default=DEFAULT_REPORT_EXPIRATION,
                                 help="Time in seconds to keep report existence since original report time"),
                      cfg.BoolOpt('overwrite_ips', default=True, help='When turned off the IPs reported '
                                                                      'will not update the asset IPs'),
                      ] + common_opts + label_opts

INVENTORY_API_AUTH_STRUCTURE = Structure(inventory_api_opts)

INVENTORY_API_AUTH_OPTS = [cfg.IntOpt('update_timeout_seconds',
                                      default=10 * 60,
                                      help="Inventory API update timeout in seconds")]


def register_opts():
    cfg.CONF.register_opt(cfg.Opt('inventory_api_configuration', type=INVENTORY_API_AUTH_STRUCTURE),
                          group="orchestration")

    cfg.CONF.register_opts(opts=INVENTORY_API_AUTH_OPTS, group="inventory_api_auth")
