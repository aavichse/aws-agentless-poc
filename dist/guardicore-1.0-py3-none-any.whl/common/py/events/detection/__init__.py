from enum import IntEnum

from common.py.models.events.base_event import BaseEvent
from mongoengine import StringField
from common.py.utils.mongo import IntEnumField


class IntegrityDetectionEvent(BaseEvent):
    class Visibility(IntEnum):
        Invisible = 1
        Background = 2
        Front = 3

    DEFAULT_VISIBILITY = Visibility.Invisible
    GROUP = None
    TYPE_TITLE = None

    meta = {
        'allow_inheritance': True,
        'indexes': ['time',
                    ('incident_id', 'time')
        ]
    }

    visibility = IntEnumField(enum_type=Visibility, default=None)

    # Added by management:
    incident_id = StringField()

    def process(self):
        self.save()

    def get_visibility(self):
        return self.visibility if self.visibility is not None else self.DEFAULT_VISIBILITY