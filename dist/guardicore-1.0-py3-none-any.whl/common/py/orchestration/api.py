import attr
from enum import IntEnum, Enum
from common.py.events.attrs import Dictable
from common.logger import get_logger

LOGGER = get_logger()


class OrchestrationEntityType(Enum):
    VMS = 'vms'
    NETWORKS = 'networks'
    HOSTS = 'hosts'
    GROUP = 'groups'
    K8S_SERVICES = 'k8s_services'
    K8S_CONTROLLERS = 'k8s_controllers'
    K8S_NODES = 'k8s_nodes'
    CLOUD_RESOURCE = 'cloud_resource'
    GENERIC = 'generic'
    K8S_NAMESPACES = 'k8s_namespaces'
    K8S_CLUSTER = 'k8s_cluster'

    CLOUD_COMPUTE = 'cloud_compute'
    CLOUD_STORAGE = 'cloud_storage'
    CLOUD_DATABASE = 'cloud_database'
    CLOUD_TOPOLOGY = 'cloud_topology'
    USER_TO_GROUPS = 'user_to_groups'


@attr.s(slots=True, hash=True)
class AggregatorAPIModel(object):
    id = attr.ib()


@attr.s(frozen=True, slots=True, hash=True)
class OrchestrationEntityReport(object):
    entity_type = attr.ib(type=OrchestrationEntityType)
    total_entity_counter = attr.ib(type=int)
    entity_list = attr.ib(type=list,
                          default=attr.Factory(list))


@attr.s(slots=True, hash=True)
class OrchestrationReport(object):
    report = attr.ib(type=dict, default=attr.Factory(dict), validator=attr.validators.deep_mapping(
        key_validator=attr.validators.in_({e.value for e in OrchestrationEntityType}),
        value_validator=attr.validators.instance_of(OrchestrationEntityReport),
    ))


@attr.s(slots=True, hash=True)
class AggregatorGenericOrchestrationModel(AggregatorAPIModel):
    name = attr.ib(type=str, default="")
    metadata = attr.ib(type=dict, default=attr.Factory(dict))


@attr.s(slots=True, hash=True)
class AggregatorKnownIpInfoAPIModel(Dictable):
    ip_address = attr.ib()
    mac_address = attr.ib()


@attr.s(slots=True, hash=True)
class AggregatorNicInfoAPIModel(Dictable):
    vif_id = attr.ib()
    mac_address = attr.ib()
    network_id = attr.ib()
    network_name = attr.ib()
    cloud_network = attr.ib(default=None)
    is_cloud_public = attr.ib(default=False)
    vlan_id = attr.ib(default=0)
    switch_id = attr.ib(default=None)
    ip_addresses = attr.ib(default=attr.Factory(list))


@attr.s(slots=True, hash=True)
class AggregatorVirtualMachineAPIModel(AggregatorAPIModel):
    name = attr.ib()
    tenant_name = attr.ib()
    nics = attr.ib()
    is_on = attr.ib()
    host_id = attr.ib()
    bios_uuid = attr.ib(default=None)
    instance_id = attr.ib(default=None)
    orchestration_labels = attr.ib(default=attr.Factory(tuple), hash=True)
    metadata = attr.ib(default=attr.Factory(tuple), hash=False)
    subtype = attr.ib(type=tuple, default=attr.Factory(tuple))
    scoping_details = attr.ib(default=None)

    @classmethod
    def from_dict(cls, data):
        # See GC-37502 why this is necessary. 'host_id' or other field may be missing from entity
        if not data.get('host_id'):
            data['host_id'] = None
        try:
            return cls(**{attribute.name: data.get(attribute.name) for attribute in cls.__attrs_attrs__})
        except KeyError as e:
            LOGGER.debug('KeyError while recreating report. printing entities data: {}'.format(data))
            raise e


@attr.s(slots=True, hash=True)
class AggregatorNetworkAPIModel(AggregatorAPIModel):
    name = attr.ib()
    vlan_id = attr.ib()
    orchestration_labels = attr.ib(default=attr.Factory(tuple), hash=True)


@attr.s(slots=True, hash=True)
class AggregatorHostAPIModel(AggregatorAPIModel):
    name = attr.ib()
    cluster = attr.ib()
    orchestration_labels = attr.ib(default=attr.Factory(tuple), hash=True)
    metadata = attr.ib(default=attr.Factory(tuple), hash=False)


@attr.s(slots=True, hash=True)
class AggregatorGroupAPIModel(AggregatorAPIModel):
    name = attr.ib()
    dn = attr.ib(default=None)


@attr.s(slots=True, hash=True)
class AggregatorUserToGroupsAPIModel(AggregatorAPIModel):
    groups = attr.ib(type=list, default=attr.Factory(list))


class OrchestrationRecommendationAction(IntEnum):
    Stop = 1
    Snapshot = 2
    Suspend = 3
    DisconnectNetworkCards = 4


class OrchestrationProviderStatus(IntEnum):
    Unknown = 1
    Down = 2
    Up = 3


class K8ServiceType(IntEnum):
    Unknown = 0
    External_name = 1
    ClusterIP = 2
    NodePort = 3
    LoadBalancer = 4


class K8ControllerType(IntEnum):
    Unknown = 0
    ReplicaSet = 1
    DaemonSet = 2
    Deployment = 3
    StatefulSet = 4
    Job = 5
    CronJob = 6
    ReplicationController = 7


class K8sClusterType(Enum):
    AKS = "AKS"
    GKE = "GKE"
    EKS = "EKS"
    OCP = "OCP"
    RKE = "RKE"
    K8S = "K8S"


@attr.s(frozen=True, slots=True, hash=True)
class AggregatorK8sAPIModel(AggregatorAPIModel):
    name = attr.ib(type=str)
    namespace = attr.ib(type=str)
    cluster = attr.ib(type=str)
    labels = attr.ib(type=tuple, validator=attr.validators.deep_iterable(
        member_validator=attr.validators.instance_of(tuple)), default=attr.Factory(tuple))
    annotations = attr.ib(type=tuple, validator=attr.validators.deep_iterable(
        member_validator=attr.validators.instance_of(tuple)), default=attr.Factory(tuple))


@attr.s(frozen=True, slots=True, hash=True)
class AggregatorKubernetesServicePort(object):
    name = attr.ib(type=str, default=None)
    node_port = attr.ib(type=int, default=None)
    port = attr.ib(type=int, default=None)
    protocol = attr.ib(type=str, default=None)
    target_port = attr.ib(type=int, default=None)


@attr.s(frozen=True, slots=True, hash=True)
class AggregatorKubernetesService(AggregatorK8sAPIModel):
    cluster_ip = attr.ib(type=str, default=None)
    cluster_id = attr.ib(type=str, default=None)
    load_balancer_ip = attr.ib(type=str, default=None)
    service_type = attr.ib(type=K8ServiceType, default=K8ServiceType.Unknown)
    ports = attr.ib(type=tuple, validator=attr.validators.deep_iterable(
        member_validator=attr.validators.instance_of(AggregatorKubernetesServicePort)), default=attr.Factory(tuple))
    selector = attr.ib(type=tuple, validator=attr.validators.deep_iterable(
        member_validator=attr.validators.instance_of(tuple)), default=attr.Factory(tuple))
    external_ips = attr.ib(type=tuple, validator=attr.validators.deep_iterable(
        member_validator=attr.validators.instance_of(str)), default=attr.Factory(tuple))
    load_balancer_ingress_ips = attr.ib(type=tuple, validator=attr.validators.deep_iterable(
        member_validator=attr.validators.instance_of(str)), default=attr.Factory(tuple))


@attr.s(frozen=True, slots=True, hash=True)
class AggregatorKubernetesLabelSelectorRequirement(object):
    key = attr.ib(type=str, default=None)
    operator = attr.ib(type=str, default=None)  # In, NotIn, Exists and DoesNotExist.
    values = attr.ib(type=tuple, validator=attr.validators.deep_iterable(
        member_validator=attr.validators.instance_of(str)), default=attr.Factory(tuple))


@attr.s(frozen=True, slots=True, hash=True)
class AggregatorKubernetesV1LabelSelector(object):
    match_expressions = attr.ib(type=tuple, validator=attr.validators.deep_iterable(
        member_validator=attr.validators.instance_of(AggregatorKubernetesLabelSelectorRequirement)),
                                default=attr.Factory(tuple))
    match_labels = attr.ib(type=tuple, validator=attr.validators.deep_iterable(
        member_validator=attr.validators.instance_of(tuple)), default=attr.Factory(tuple))


@attr.s(frozen=True, slots=True, hash=True)
class AggregatorKubernetesOwnerReference(object):
    kind = attr.ib(type=str)
    name = attr.ib(type=str)
    uid = attr.ib(type=str)


@attr.s(frozen=True, slots=True, hash=True)
class AggregatorKubernetesController(AggregatorK8sAPIModel):
    type = attr.ib(type=K8ControllerType, default=K8ControllerType.Unknown)
    metadata = attr.ib(type=tuple, default=attr.Factory(tuple))  # (type specific fields, for example replica_count)
    selector = attr.ib(type=AggregatorKubernetesV1LabelSelector, default=None)
    owner_references = attr.ib(type=tuple, validator=attr.validators.deep_iterable(
        member_validator=attr.validators.instance_of(AggregatorKubernetesOwnerReference)), default=attr.Factory(tuple))
    dependants_labels = attr.ib(type=tuple, validator=attr.validators.deep_iterable(
        member_validator=attr.validators.instance_of(tuple)), default=attr.Factory(tuple))


@attr.s(frozen=True, slots=True, hash=True)
class AggregatorKubernetesNode(AggregatorK8sAPIModel):
    provider_id = attr.ib(type=str, default=attr.Factory(str))
    ip_addresses = attr.ib(type=tuple, validator=attr.validators.deep_iterable(
        member_validator=attr.validators.instance_of(str)), default=attr.Factory(tuple))
    bios_uuid = attr.ib(type=str, default=attr.Factory(str))
    cluster_id = attr.ib(type=str, default=None)


@attr.s(frozen=True, slots=True, hash=True)
class AggregatorKubernetesNamespace(AggregatorAPIModel):
    name = attr.ib(type=str)
    labels = attr.ib(type=tuple, validator=attr.validators.deep_iterable(
        member_validator=attr.validators.instance_of(tuple)), default=attr.Factory(tuple))
    annotations = attr.ib(type=tuple, validator=attr.validators.deep_iterable(
        member_validator=attr.validators.instance_of(tuple)), default=attr.Factory(tuple))


@attr.s(frozen=True, slots=True, hash=True)
class AggregatorKubernetesCluster(AggregatorAPIModel):
    name = attr.ib(type=str)
    cluster_id = attr.ib(type=str)
    cluster_type = attr.ib(type=K8sClusterType)
    cluster_version = attr.ib(type=str)
    node_count = attr.ib(type=int)


@attr.s(frozen=True, slots=True, hash=True)
class AggregatorCloudResourceAPIModel(AggregatorAPIModel):
    name = attr.ib(type=str)
    type = attr.ib(type=str)
    location = attr.ib(type=str)
    tags = attr.ib(type=dict)
    subscription_id = attr.ib(type=str)
    subscription_name = attr.ib(type=str)
    resource_group_name = attr.ib(type=str)
    metadata = attr.ib(type=dict, default=attr.Factory(dict))


@attr.s(frozen=True, slots=True, hash=True)
class AggregatorCloudNetworkInfoAPIModel(AggregatorAPIModel):
    network = attr.ib(type=str)
    reachable_networks = attr.ib(type=list, default=attr.Factory(list))
