from enum import Enum
from functools import partial

import orjson
import rapidjson
from netaddr import IPAddress, IPNetwork

from common.py.utils.encoding.json import json_convert

JSONDecodeError = orjson.JSONDecodeError

try:
    from bson import ObjectId
except ImportError:
    ObjectId = None


def default(obj, drop_nons=False):
    if isinstance(obj, Enum):
        return obj.value

    from common.py.events.attrs import Dictable  # avoid circular dependency Dictable <-> fast_json
    if isinstance(obj, Dictable):
        if hasattr(obj, '__slots__'):
            return {attr: getattr(obj, attr) for attr in obj.__slots__
                    if not drop_nons or getattr(obj, attr) is not None}
        else:
            return {obj_key: obj_value for obj_key, obj_value in obj.__dict__.items()
                    if not drop_nons or obj_value is not None}

    # This is to support SON based conversions
    if isinstance(obj, dict):
        return dict(obj)

    if isinstance(obj, set):
        return list(obj)

    if isinstance(obj, (IPAddress, IPNetwork)):
        return str(obj)

    if ObjectId and isinstance(obj, ObjectId):
        return str(obj)

    raise TypeError("Unable to serialize %r (type: %s)" % (obj, type(obj)))


def dumps(obj, cls=None, indent=None, strict_int=False, sort_keys=False,
          separators=None, number_mode=rapidjson.NM_NATIVE, drop_nons=False):
    if cls:     # assumption that RabbitMsgJSONEncoder is specified, call its encode function directly
        obj = json_convert.encode_objects(obj)

    if (not indent or indent == 2) and number_mode:
        # orjson is faster than rapid json (the name wasn't enough to beat that competition),
        # but it supports fewer options, so we use it only when we can.
        options = 0
        if strict_int:
            options |= orjson.OPT_STRICT_INTEGER
        if indent == 2:
            options |= orjson.OPT_INDENT_2
        if sort_keys:
            options |= orjson.OPT_SORT_KEYS

        return orjson.dumps(obj,
                            default=partial(default, drop_nons=drop_nons),
                            option=options).decode("utf-8")

    return rapidjson.dumps(obj, datetime_mode=rapidjson.DM_ISO8601, number_mode=number_mode,
                           default=partial(default, drop_nons=drop_nons), ensure_ascii=False,
                           indent=indent, uuid_mode=rapidjson.UM_CANONICAL,
                           sort_keys=sort_keys)


def loads(deserialized_str, cls=None, support_datetime=False):
    if not support_datetime:
        ret = orjson.loads(deserialized_str)
    else:
        datetime_mode = rapidjson.DM_ISO8601 if support_datetime else rapidjson.DM_NONE
        ret = rapidjson.loads(deserialized_str, datetime_mode=datetime_mode, number_mode=rapidjson.NM_NATIVE)

    if cls:     # assumption that RabbitMsgJSONDecoder is specified, call its decode function directly
        ret = json_convert.decode_objects(ret)

    return ret


def json_extract(obj, *keys):
    """Recursively fetch values from nested JSON."""
    arr = []

    def extract(obj, arr, *keys):
        """Recursively search for values of key in JSON tree."""
        if isinstance(obj, dict):
            for k, v in obj.items():
                if k in keys:
                    arr.append(v)
                elif isinstance(v, (dict, list)):
                    extract(v, arr, *keys)
        elif isinstance(obj, list):
            for item in obj:
                extract(item, arr, *keys)
        return arr

    values = extract(obj, arr, *keys)
    return values