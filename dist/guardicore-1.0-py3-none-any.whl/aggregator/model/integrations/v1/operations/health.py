from __future__ import annotations

from enum import Enum
from typing import Dict, List, Optional
from uuid import UUID

from pydantic import AwareDatetime, BaseModel, Field, field_serializer

from ..common.common import Connector


class ComponentDetails(BaseModel):
    component_version: Optional[str] = Field(None, alias='component-version')
    public_ip_addresses: Optional[List[str]] = Field(None, alias='public-ip-addresses')
    private_ip_addresses: Optional[List[str]] = Field(
        None, alias='private-ip-addresses'
    )
    hostname: Optional[str] = None
    dc_inventory_revision: int = Field(..., alias='dc-inventory-revision')
    policy_revision: int = Field(..., alias='policy-revision')
    config_revision: Optional[int] = Field(None, alias='config-revision')


class Status(Enum):
    UP = 'up'
    INITIALIZING = 'initializing'
    CONNECTING = 'connecting'
    STOPPED = 'stopped'
    DOWN = 'down'
    PARTIALLY_UP = 'partially_up'
    ERROR = 'error'
    MISSING = 'missing'
    VERIFYING = 'verifying'
    VERIFICATION_FAILED = 'verification_failed'


class Metric(BaseModel):
    name: str = Field(..., description='the metric that will be added to telegraf')
    value: float
    tag_name: Optional[str] = None
    tag_value: Optional[str] = None


class Severity(Enum):
    INFO = 'info'
    WARNING = 'warning'
    ERROR = 'error'


class SystemEvent(BaseModel):
    source: Connector
    source_id: UUID = Field(..., alias='source-id')
    timestamp: AwareDatetime
    category: Optional[str] = Field(None, examples=['deployment'])
    severity: Severity
    title: str
    message: str
    additional_info: Optional[Dict[str, str]] = Field(
        None, examples=[{'region-code': 'eastus', 'region-name': 'East US'}]
    )


class ComponentMetrics(BaseModel):
    component_id: UUID = Field(..., alias='component-id')
    component_type: str = Field(..., alias='component-type')
    component_metrics: List[Metric] = Field(..., alias='component-metrics')


class ServiceStatus(BaseModel):
    service_status: Status = Field(..., alias='service-status')
    msg: Optional[str] = None

    @field_serializer('service_status')
    def serialize_status(self, service_status: str):
        return service_status.value.upper()


class ApplicationStatus(BaseModel):
    application_status: Status = Field(..., alias='application-status')
    services_status: Optional[Dict[str, ServiceStatus]] = Field(
        None, alias='services-status'
    )

    @field_serializer('application_status')
    def serialize_status(self, application_status: str):
        return application_status.value.upper()


class ComponentStatus(BaseModel):
    overall_status: Status = Field(..., alias='overall-status')
    applications_status: Optional[Dict[str, ApplicationStatus]] = Field(
        None, alias='applications-status'
    )

    @field_serializer('overall_status')
    def serialize_status(self, overall_status: str):
        return overall_status.value.upper()


class ComponentHealth(BaseModel):
    component_id: UUID = Field(..., alias='component-id')
    component_type: Connector = Field(..., alias='component-type')
    component_details: ComponentDetails = Field(..., alias='component-details')
    status: ComponentStatus= Field(..., serialization_alias='health')
    statistics: Optional[Dict] = None
