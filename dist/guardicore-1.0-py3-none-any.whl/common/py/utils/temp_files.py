import os
import shutil
import tempfile
from contextlib import contextmanager


@contextmanager
def temp_dir_context():
    """
    A temp dir context manager.
    usage:
            with temp_dir_context() as temp_dir:
                do stuff
    """
    temp_dir = tempfile.mkdtemp()
    try:
        yield temp_dir
    finally:
        shutil.rmtree(temp_dir, True)


@contextmanager
def named_temp_dir_context(name=None):
    """
    A named temp dir context manager.

    usage:
            with named_temp_dir_context(some_name) as named_temp_dir:
                do stuff
    """
    if not name:
        raise Exception('You must provide a name, if you need an unnamed temp dir context, use temp_dir_context')
    with temp_dir_context() as parent_dir:
        named_dir = os.path.join(parent_dir, name)
        os.makedirs(named_dir)
        yield named_dir


@contextmanager
def named_temp_file_context(name=None):
    """
    A named temp file context manager.

    usage:
            with named_temp_file_context(some_name) as named_temp_file:
                do stuff
    """
    if not name:
        raise Exception("You must provide a name. Unnamed files aren't supported")
    with temp_dir_context() as parent_dir:
        named_file = os.path.join(parent_dir, name)
        yield named_file
