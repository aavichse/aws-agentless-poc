from __future__ import print_function

import ipaddress
import os
import random
import shutil
import sys
import re
import six
import yaml
import time
import json
# Crypt lib is not supported in windows.
if sys.platform.startswith("win"):
    crypt = None
else:
    import crypt
import socket
import struct
import getpass
from collections import OrderedDict
from optparse import OptionParser, SUPPRESS_HELP

from netaddr import IPAddress

BASE_PATH = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
if __name__ == "__main__":
    sys.path.insert(0, BASE_PATH)

from common.py.utils.linux.apis.distro import get_linux_distro, NetworkManager, ID_VERSION_MAP, LinuxDistro
from six.moves import configparser
from common.py.utils.setup_wizard.setup_utilities import LOGGER_NAME, setup_utilities, PRODUCT_SECTION_CONFIG_PATH
from common.py.utils.setup_wizard.model import NavigateBack, PasswordWeak, PasswordInvalid, Skip, NetworkAddressMode, \
    TaskFailed, HostConfigTask
from common.logger import get_logger, log_init
from common.py.utils.config.oslo_config.cfg import OsloSecret
from common.py.utils.generic import subprocess_call_independent
from common.py.utils.linux.ip_lib import IPWrapper
from common.py.model.exceptions import GuardicoreException
from common.py.utils.setup_wizard.consts import SETUP_CONFIGURATION_PATH

__author__ = 'uri'

ROOT_USERNAME = 'root'
ADMIN_USERNAME = 'admin'
TLS_USERNAME = 'gc-cert'

USER_PASSWORD_MIN_LEN = 6
USER_PASSWORD_MAX_LEN = 40

BASE_NETWORK_INTERFACES_FILE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'interfaces')
GUARDICORE_CONFIGURATION_PATH = '/etc/guardicore/guardicore.conf'
NETWORK_INTERFACE_SET_MARK_PATH = '/etc/guardicore/network_interface_mark'
SUCCESSFUL_RUN_MARK_PATH = '/etc/guardicore/setup_wizard_mark'
MANAGEMENT_DNS_RECORD = 'gc-management'
SCEP_SERVER_DNS_RECORD = 'scep-server' #FIXME: can be removed
RESTSERVER_DNS_RECORD = 'GuardicoreRESTServer'
MENDER_DNS_RECORD = 'gc-mender'
AGGR_HPVM_STORAGE_PATH = "/usr/share/guardicore/storage"
GIT_CONFIG_REPO_URI = "git/guardicore_cfg.git"
GIT_CONFIG_REPO_PATH = "/usr/share/guardicore/storage/guardicore_cfg"
DR_COMPONENTS_CONFIG = "/etc/guardicore/dr_components_config.json"
SYSTEMD_STUB_RESOLVE_CONF_PATH = "/host/var/run/systemd/resolve/stub-resolv.conf"

MONICORE_CTRL_BIN_PATH = '/usr/bin/monicore-ctrl'
START_MONICORE_COMMAND = ['monicore-ctrl', 'start']
STOP_MONICORE_COMMAND = ['monicore-ctrl', 'stop']
RESTART_MONICORE_COMMAND = ['monicore-ctrl', 'restart']
RELOAD_MONICORE_COMMAND = ['monicore-ctrl', 'reload']
STATUS_MONICORE_COMMAND = ['monicore-ctrl', 'status']
IFUP_COMMAND = ['ifup']
IFDOWN_COMMAND = ['ifdown']
ADD_STATIC_ROUTE_COMMAND = "up route add -net {network} netmask {netmask} gw {gateway}\n"

DEFAULT_MANAGEMENT_ADDRESS = ''
DEFAULT_SCEP_ENDPOINT = 'scep'
MGMT_CONNECTIVITY_ERROR_CODE = 14
MANAGEMENT_PORT_LIST = [443,    # Certificates & Repositories
                        ]

ALLOWED_DOMAIN_REGEX = re.compile(
    r"^(([a-zA-Z]{1})|([a-zA-Z]{1}[a-zA-Z]{1})|"        # domain pt.1
    r"([a-zA-Z]{1}[0-9]{1})|([0-9]{1}[a-zA-Z]{1})|"     # domain pt.2
    r"([a-zA-Z0-9][-_.a-zA-Z0-9]{0,61}[a-zA-Z0-9]))\."  # domain pt.3
    r"([a-zA-Z]{2,13}|(xn--[a-zA-Z0-9]{2,30}))$"        # TLD
)  # taken from 'validators' package

FQDN_REGEX = re.compile(
    r"^((?!-)[-A-Z\d]{1,62}(?<!-)\.)+[A-Z]{1,62}\.?$", re.IGNORECASE
)  # taken from 'fqdn' package

HOSTNAME_REGEX = re.compile(
    r"^[-a-zA-Z0-9]*$"
)

URL_REGEX = regex = re.compile(  # noqa: W605
    r"^(?:" + \
    # IP address dotted notation octets
    # excludes loopback network 0.0.0.0
    # excludes reserved space >= 224.0.0.0
    # excludes network & broadcast addresses
    # (first & last IP address of each class)
    r"(?:(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])" + \
    r"(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}" + \
    r"(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4])))" + \
    r"|" + \
    # IPv6 RegEx from https://stackoverflow.com/a/17871737
    r"\[(" + \
    # 1:2:3:4:5:6:7:8
    r"([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|" + \
    # 1::                              1:2:3:4:5:6:7::
    r"([0-9a-fA-F]{1,4}:){1,7}:|" + \
    # 1::8             1:2:3:4:5:6::8  1:2:3:4:5:6::8
    r"([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|" + \
    # 1::7:8           1:2:3:4:5::7:8  1:2:3:4:5::8
    r"([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|" + \
    # 1::6:7:8         1:2:3:4::6:7:8  1:2:3:4::8
    r"([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|" + \
    # 1::5:6:7:8       1:2:3::5:6:7:8  1:2:3::8
    r"([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|" + \
    # 1::4:5:6:7:8     1:2::4:5:6:7:8  1:2::8
    r"([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|" + \
    # 1::3:4:5:6:7:8   1::3:4:5:6:7:8  1::8
    r"[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|" + \
    # ::2:3:4:5:6:7:8  ::2:3:4:5:6:7:8 ::8       ::
    r":((:[0-9a-fA-F]{1,4}){1,7}|:)|" + \
    # fe80::7:8%eth0   fe80::7:8%1
    # (link-local IPv6 addresses with zone index)
    r"fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]+|" + \
    r"::(ffff(:0{1,4})?:)?" + \
    r"((25[0-5]|(2[0-4]|1?[0-9])?[0-9])\.){3}" + \
    # ::255.255.255.255   ::ffff:255.255.255.255  ::ffff:0:255.255.255.255
    # (IPv4-mapped IPv6 addresses and IPv4-translated addresses)
    r"(25[0-5]|(2[0-4]|1?[0-9])?[0-9])|" + \
    r"([0-9a-fA-F]{1,4}:){1,4}:" + \
    r"((25[0-5]|(2[0-4]|1?[0-9])?[0-9])\.){3}" + \
    # 2001:db8:3:4::192.0.2.33  64:ff9b::192.0.2.33
    # (IPv4-Embedded IPv6 Address)
    r"(25[0-5]|(2[0-4]|1?[0-9])?[0-9])" + \
    r")\]|" + \
    # host name
    u"(?:(?:(?:[a-z\u00a1-\uffff0-9]-?)*[a-z\u00a1-\uffff0-9]+)\\.?)+)" + \
    # port number
    r"(?::\d{2,5})?" + \
    # resource path
    u"(?:/[-a-z\u00a1-\uffff0-9._~%!$&'()*+,;=:@/]*)?" + \
    # query string
    r"(?:\?\S*)?" + \
    # fragment
    r"(?:#\S*)?" + \
    r"$",
    re.UNICODE | re.IGNORECASE
) # taken from 'validators' package

LOG = get_logger(module_name=LOGGER_NAME)


def installer_wrapper(f):
    def wrapper(self, *args):
        try:
            f(self, *args)
        except Exception as e:
            self._report_error(e)
        return None
    return wrapper


class SetupFailureError(GuardicoreException):
    pass


class InvalidSetupConfigError(SetupFailureError):
    pass


class CollectionStep(object):
    def __init__(self, func, enabled=True):
        self.func = func
        self.enabled = enabled


class SetupWizard(object):
    """
    Setup Wizard base class which provides generic setup wizard structure
    """
    HOSTS_PATH = '/etc/hosts'
    DHCLIENT_CONF_PATH = '/etc/dhcp/dhclient.conf'
    RESOLVE_CONF_PATH = '/etc/resolv.conf'
    SHADOW_FILE_PATH = '/etc/shadow'
    RELEASE_FILE_PATH = '/etc/os-release'
    NETPLAN_FILE_PATH = '/etc/netplan/guardicore_interfaces.yaml'
    # Changed later to '/etc/netplan/guardicore_interfaces_{interface_name}.yaml'
    PASSWORD_SET_MARK_PATH = '/etc/guardicore/root_password_mark'

    def __init__(self, setup_dialog, gc_service_name=None, mandatory_config_keys=None, optional_config_keys=None,
                 config_component_name=None):
        """
        SetupWizard constructor
        :param setup_dialog: a dialog class (should inherit from SetupDialog) that will handle the dialog
        """
        self._log_init(base_name=LOGGER_NAME, debug=True, use_stderr=False, log_to_screen=False)
        LOG.info("Starting Setup Wizard")
        self.setup_dialog = setup_dialog
        self.setup_username = self.setup_dialog.setup_username
        self.gc_service_name = gc_service_name
        self.config_component_name = config_component_name
        self._mandatory_config_keys = mandatory_config_keys if mandatory_config_keys else []
        self._optional_config_keys = optional_config_keys if optional_config_keys else []
        self.quiet_mode = None
        self.logger_mode = None
        self.dry_mode = None
        self.saas_mode = None
        self._ansible_extra_vars = []
        self.is_simulation_setup = None
        self.is_upgrade = None
        self.conf_file = None
        self.first_error = None
        self.is_any_error = False
        self.is_connectivity_error = False
        self.exit_code = 0
        self.stderr = None
        self.network_interfaces_file_path = '/etc/network/interfaces'

        self.FIRST_TIME_TASK_MARKER = {
            HostConfigTask.SYSTEM_PASSWORD: self.PASSWORD_SET_MARK_PATH,
            HostConfigTask.NETWORK_INTERFACES: NETWORK_INTERFACE_SET_MARK_PATH
        }

        self.task_completed = {task: os.path.isfile(marker) for task, marker in self.FIRST_TIME_TASK_MARKER.items()}

        self.collection_steps = []
        self.installation_steps = OrderedDict()
        self.configuration = dict.fromkeys(self._mandatory_config_keys + self._optional_config_keys, None)
        self._verify_user()

        self.handle_commandline()

    @staticmethod
    def _log_init(base_name, debug=True, use_stderr=False, log_to_screen=False):
        log_init(base_name=base_name, debug=debug, use_stderr=use_stderr, log_to_screen=log_to_screen)

    def handle_commandline(self, sys_argv=None):
        """
        a method that parses the commandline and loads configuration accordingly
        """
        parser = OptionParser()
        parser.add_option("-c", action="store", dest="conf_file", help="Configuration file", default=None)
        parser.add_option("-q", action="store_true", dest="quiet_mode",
                          help="Quiet mode - run without collection from user. Use with configuration file argument, "
                          "or setup runs with last configuration", default=False)
        parser.add_option("-l", action="store_true", dest="logger_mode",
                          help="Logger mode - show log in output when running in quiet mode "
                               "(ignored if not in quiet mode)", default=False)
        parser.add_option("-s", action="store_true", dest="saas_mode",
                          help="SaaS mode- fixed network setup", default=False)
        parser.add_option("-m", "--managed", action="store_true", dest="host_managed",
                          help="Enable managed host mode -- skips several steps", default=False)
        parser.add_option("-d", action="store_true", dest="dry_mode",
                          help="Dry mode- collect and dump configuration only", default=False)
        parser.add_option("-z", action="store_true", dest="ignore_last_config", default=False,
                          help="Ignore the last configuration")
        parser.add_option("--first-time-run", action="store_true", dest="first_time_run", default=False, help=SUPPRESS_HELP)
        parser.add_option("--check-reconfigure", action="store_true", dest="check_reconfigure", default=False,
                          help=SUPPRESS_HELP)
        parser.add_option("--simulation-setup", action="store_true", dest="simulation_setup", default=False, help=SUPPRESS_HELP)
        parser.add_option("--upgrade-setup", action="store_true", dest="upgrade_setup", default=False, help=SUPPRESS_HELP)
        options, args = self.parse_args(sys_argv, parser)

        self.conf_file = options.conf_file
        self.quiet_mode = options.quiet_mode
        self.logger_mode = options.logger_mode
        self.saas_mode = options.saas_mode
        self.host_managed = options.host_managed
        self.dry_mode = options.dry_mode
        self.first_time_mode = options.first_time_run
        self.reconfigure_mode = options.check_reconfigure
        self.is_simulation_setup = options.simulation_setup
        self.ignore_last_config = options.ignore_last_config
        self.is_upgrade = options.upgrade_setup

        if self.first_time_mode or self.reconfigure_mode:
            # first time run/reconfigure mode is always in quiet mode
            self.quiet_mode = True
            display_mode = 'first time run' if self.first_time_mode else 'reconfigure'
            if self.conf_file is not None:
                error_msg = "Cannot run in {mode} mode with configuration file, please try again.".format(
                    mode=display_mode)
                LOG.error(error_msg)
                print(error_msg)
                sys.exit(1)

            if self.dry_mode:
                error_msg = "Cannot run in {mode} mode and dry mode at the same time, please try again.".format(
                    mode=display_mode)
                LOG.error(error_msg)
                print(error_msg)
                sys.exit(1)

            if self.saas_mode:
                error_msg = "Cannot run in {mode} mode and saas mode at the same time, please try again.".format(
                    mode=display_mode)
                LOG.error(error_msg)
                print(error_msg)
                sys.exit(1)

            local_ovf_env_properties = setup_utilities.get_local_ovf_env_setup_wizard_config()
            setup_wizard_env_config = setup_utilities.get_ovf_env_setup_wizard_config()
            if self.reconfigure_mode and local_ovf_env_properties and setup_wizard_env_config \
                    and local_ovf_env_properties == setup_wizard_env_config:
                LOG.debug("No change detected in OVF setup wizard configuration in check-reconfigure mode. Existing...")
                sys.exit(0)

            LOG.info("Running in %s mode", display_mode)
            if setup_wizard_env_config is not None:
                with open(PRODUCT_SECTION_CONFIG_PATH, 'w') as fo:
                    fo.write(setup_wizard_env_config)
                self.conf_file = PRODUCT_SECTION_CONFIG_PATH
            else:
                log_msg = "Cannot find {mode} mode configuration, aborting.".format(mode=display_mode)
                LOG.info(log_msg)
                print(log_msg)
                sys.exit(0)
        else:
            # load configuration if it exists in dump location
            if not self.conf_file and not self.dry_mode and not self.ignore_last_config:
                if os.path.isfile(SETUP_CONFIGURATION_PATH):
                    self.conf_file = SETUP_CONFIGURATION_PATH

        if self.dry_mode:
            if self.quiet_mode:
                error_msg = "Cannot run in dry mode and quiet mode at the same time, please try again."
                LOG.error(error_msg)
                print(error_msg)
                sys.exit(1)

            LOG.info("Running in dry mode")

        if self.conf_file and self.ignore_last_config:
            LOG.warning("Configuration file explicitly entered, last configuration is irrelevant")

        if self.quiet_mode:
            if not self.conf_file:
                error_msg = "Configuration file is needed for quiet mode, please try again."
                LOG.error(error_msg)
                print(error_msg)
                sys.exit(1)
            else:
                LOG.info("Running in quiet mode")
                if self.logger_mode:
                    LOG.info("Running in logger mode - Restarting logger for logging to screen")
                    log_init(base_name=LOGGER_NAME, debug=True, use_stderr=False, log_to_screen=True)
        else:
            self.setup_dialog.set_title()
            if not self.setup_dialog.is_initialized:
                error_msg = "SetupDialog is not initialized, Cannot run in non-quiet mode."
                LOG.error(error_msg)
                print(error_msg)
                sys.exit(1)

        if self.saas_mode:
            LOG.info("Running in saas mode")

        if self.host_managed:
            LOG.info("Running in Managed Host mode")
            self.task_completed = {task: True for task in self.FIRST_TIME_TASK_MARKER.keys()}


    def parse_args(self, sys_argv, parser):
        return parser.parse_args(sys_argv)

    @staticmethod
    def _verify_user():
        running_user = getpass.getuser()
        if running_user not in [ADMIN_USERNAME, ROOT_USERNAME]:
            raise InvalidSetupConfigError("This setup should run by privileged users."
                                          " Please try again with '%s' or '%s' user.", ADMIN_USERNAME, ROOT_USERNAME)

    @staticmethod
    def _hash_password(password):
        """
        a method that returns a salted hashed password
        """
        return crypt.crypt(password, crypt.mksalt(crypt.METHOD_SHA512))

    @staticmethod
    def _check_password_validity(password):
        """
        a method that checks validity of a password for length and complexity
        the method raises a descriptive exception if the password is invalid
        """
        if "" == password:
            raise PasswordWeak("Password can't be empty")
        elif re.match(r'^[\w-]+$', password) is None:
            raise PasswordInvalid("Password cannot contain symbols")
        elif USER_PASSWORD_MAX_LEN < len(password):
            raise PasswordWeak("Password is too long")
        elif USER_PASSWORD_MIN_LEN > len(password):
            raise PasswordWeak("Password is too short")

        # TODO: add more password strength validations

    @staticmethod
    def _check_ip_address_validity(address, allow_cidr=False):
        """
        a method that checks if a string is a valid ip address
        :param address: the ip address to check validity
        :param allow_cidr: True to allow CIDR format, False if not
        :return: True if valid address and False if not
        """
        if not isinstance(address, six.string_types):
            return False

        if allow_cidr:
            try:
                ipaddress.ip_network(six.text_type(address))
                return True
            except:
                return False

        try:
            socket.inet_aton(address)
        except socket.error:
            return False

        return True

    @staticmethod
    def _check_url_validity(url):
        """
        a method that checks if a string is a valid ip address
        :param url: the url to check
        :return: True if valid url and False if not
        """
        if not isinstance(url, six.string_types):
            return False

        return URL_REGEX.match(url) is not None

    @staticmethod
    def _check_fqdn_validity(fqdn):
        """
        a method that checks if a string is a valid fqdn address
        taken from 'fqdn' package
        :param fqdn: the address to check
        :return: True if valid fqdn and False if not
        """
        length = len(fqdn)
        if fqdn.endswith('.'):
            length -= 1
        if length > 253:
            return False
        return bool(FQDN_REGEX.match(fqdn))

    @staticmethod
    def _check_hostname_validity(hostname):
        """
        a method that checks if a string is a valid hostname for the aggregator/collector
        :param hostname: the hostname to check
        :return: True if valid hostname and False if not
        """
        return bool(HOSTNAME_REGEX.match(hostname))

    @classmethod
    def get_current_dns_servers(cls):
        """
        a method that returns a list of all current dns server addresses
        """
        servers = []
        try:
            with open(cls.RESOLVE_CONF_PATH ,'r') as fo:
                resolve_conf = fo.readlines()
                for line in resolve_conf:
                    if line.startswith("nameserver"):
                        servers.append(line.split()[1])
        except Exception as e:
            LOG.warning("Failed gathering DNS servers: %s", e)
        return servers

    @staticmethod
    def _check_get_ip_or_dns_validity(address):
        if SetupWizard._check_ip_address_validity(address):
            return True
        elif SetupWizard._check_dns_validity(address):
            return True
        else:
            return False

    @staticmethod
    def _check_dns_validity(address):
        """
        a method that checks if a string is a valid DNS address
        :param address: the address to check validity
        :return: True if valid address and False if not
        """
        if ALLOWED_DOMAIN_REGEX.match(address) is not None:
            return True
        return False

    @staticmethod
    def _load_configuration_file(import_file_path):
        if not os.path.isfile(import_file_path):
            raise SetupFailureError("Cannot find configuration file '%s'", import_file_path)

        try:
            with open(import_file_path, 'r') as configuration_file:
                return json.load(configuration_file)
        except (IOError, OSError) as exc:
            raise SetupFailureError("Error reading configuration file '%s': %s", import_file_path, exc)
        except ValueError as exc:
            raise InvalidSetupConfigError("Invalid configuration was given '%s': %s", import_file_path, exc)
        except Exception as exc:
            raise SetupFailureError("Cannot load configuration file '%s': %s", import_file_path, exc)

    def align_scep_to_mgmt_address(self, config):
        """
            Aligns the SCEP server address with the management address in the configuration
            to ensure that the configuration does not point to an unnecessary duplicate address for
            SCEP and management.
            Args:
                self: The instance of the class that contains the configuration dictionary.
                config: A dictionary containing the configuration settings
            Returns:
                None: Modifies the class's configuration dictionary in place if conditions are met.
            """

        scep_address = (config.get('scep_server_address') or '').split(':')[0]
        management_address = config.get('management_address', '')
        if scep_address and management_address and scep_address == management_address:
            self.configuration['scep_server_address'] = None

    def _import_configuration(self, import_file_path):
        """
        a method that loads a configuration file and verifies it according to the relevant component
        the method stores the loaded configuration as a dict as "configuration" member of the class
        :param import_file_path: a path for the configuration file
        """

        config = self._load_configuration_file(import_file_path)
        non_mandatory_keys = list(config.keys())

        # verify all mandatory keys
        for member in self._mandatory_config_keys:
            if member not in config:
                raise InvalidSetupConfigError("Invalid configuration was given, %s is missing", member)
            non_mandatory_keys.remove(member)

        for member in non_mandatory_keys:
            if member not in self._optional_config_keys:
                raise InvalidSetupConfigError("Invalid configuration was given, '%s' is invalid", member)

        self.configuration.update(config)
        self.align_scep_to_mgmt_address(config)

        if self.quiet_mode and not self.task_completed[HostConfigTask.SYSTEM_PASSWORD] \
                and not self.configuration.get('{username}_password'.format(username=self.setup_username)):
            raise InvalidSetupConfigError("{username} password was not set yet and missing from configuration".format(username=self.setup_username))

    def _export_configuration(self, export_file_path=SETUP_CONFIGURATION_PATH):
        """
        a method that export the setup configuration to a reusable json file
        :param export_file_path: path to the exported json
        """

        # remove unneeded optional keys from configuration
        for key, value in list(self.configuration.items()):
            if value is None and key in self._optional_config_keys:
                LOG.info('Key "{}" value is None, removing from configuration export'.format(key))
                del self.configuration[key]

        try:
            with open(export_file_path, 'w') as config_file:
                json.dump(self.configuration, config_file, indent=4, separators=(',', ': '), sort_keys=True)
            LOG.info("Config file saved successfully at: %s", export_file_path)
        except Exception as exc:
            LOG.error("Failed saving config file to %s: %s", export_file_path, exc)
            return False

        return True

    def _report_error(self, error):
        LOG.exception("Unhandled exception (with full trace): %s" % str(error))
        if not self.first_error:
            self.first_error = error
        self.is_any_error = True
        raise TaskFailed

    @staticmethod
    def flush_log():
        [handler.flush() for handler in LOG.handlers]

    def _mark_successful_run(self):
        with open(SUCCESSFUL_RUN_MARK_PATH, 'w'):
            pass
        LOG.info("Setup completed successfully, and machine was marked with file: %s", SUCCESSFUL_RUN_MARK_PATH)

    ###################################
    # "wrapper" methods section
    ###################################

    def wrapper_management_address(self):
        """
        a wrapper method for "collect_ip_address"
        """
        if self.configuration['management_address']:
            address_to_display = self.configuration['management_address']
        else:
            address_to_display = DEFAULT_MANAGEMENT_ADDRESS
        management_address = \
            self.setup_dialog.collect_ip_address(address_to_display=address_to_display,
                                                 ip_address_validity_function=SetupWizard._check_get_ip_or_dns_validity,
                                                 address_description="Guardicore Management Server Address",
                                                 text="\nEnter Guardicore Management Server IP or DNS record:")
        self.configuration['management_address'] = management_address

    def wrapper_network_interfaces(self):
        """
        a wrapper method for "collect_network_interfaces"
        """
        if self.host_managed or self.task_completed[HostConfigTask.NETWORK_INTERFACES]:
            LOG.info("Skipping network interface collection")
            network_interfaces = {}
        else:
            network_interfaces = self.setup_dialog.collect_network_interfaces(ip_address_validity_function=self._check_ip_address_validity)
        self.configuration['local_network_interfaces'] = network_interfaces

    def wrapper_tls_keys_password(self):
        """
        a wrapper method for "collect_tls_keys_password"
        """
        current_password = self.configuration.get('secure_communication_password')

        # make sure we don't have a None type but empty string
        if not current_password:
            current_password = ""

        tls_keys_password = \
            self.setup_dialog.collect_tls_keys_password(password_validity_function=self._check_password_validity,
                                                        init=current_password)
        self.configuration['secure_communication_password'] = tls_keys_password

    def wrapper_deployment_mode(self):
        """
        a wrapper method for "collect_deployment_mode"
        """
        deployment_mode = self.setup_dialog.collect_deployment_mode(self.configuration['deployment_mode'])
        self.configuration['deployment_mode'] = deployment_mode

    ###################################
    # "install" methods section
    ###################################
    @classmethod
    def install_users_passwords(cls, root_password):
        """
        a method that changes the root user password and disables admin user login
        """

        if not root_password:
            raise InvalidSetupConfigError("Cannot set empty password")

        with open(cls.SHADOW_FILE_PATH, 'r') as fo:
            shadow_object = [line.strip().split(':') for line in fo.readlines()]

        for line in shadow_object:
            username = line[0]

            if username == ROOT_USERNAME:
                line[1] = root_password
                LOG.info("%s password set" % ROOT_USERNAME)

            # setting exclamation mark in shadow file prevents from future logging
            elif username == ADMIN_USERNAME:
                line[1] = '!'
                LOG.info("%s password disabled" % ADMIN_USERNAME)

        shadow_object = [":".join(line) for line in shadow_object]
        shadow_object = "\n".join(shadow_object)
        with open(cls.SHADOW_FILE_PATH, 'w') as fo:
            fo.write(shadow_object)

        return True

    def install_network_interfaces(self, network_conf):
        """
        a method that edits the local network interfaces and sets DHCP client if needed
        """
        if self.task_completed[HostConfigTask.NETWORK_INTERFACES] and os.path.isfile(NETWORK_INTERFACE_SET_MARK_PATH):
            LOG.info("Network interfaces installation completed")
            return

        # TODO: This is REALLY bad! see SetupDialog.collect_network_interfaces comments.
        if not isinstance(network_conf, dict):
            LOG.info("Skipping local network settings")
            return

        distro, version = get_linux_distro(os_release_path=self.RELEASE_FILE_PATH)
        supported_os = ID_VERSION_MAP.get((distro, version), None)
        if supported_os is None:
            raise SetupFailureError("Network interface configuration for {} {} is not supported. "
                                    "Try re-running installation with --managed option".format(distro, version))

        if supported_os.network_manager == NetworkManager.Interfaces:
            self.install_network_interfaces_file(network_conf)
        elif supported_os.network_manager == NetworkManager.Netplan:
            self.network_interfaces_file_path = self.NETPLAN_FILE_PATH
            self.install_network_interfaces_netplan(network_conf, supported_os)
        elif supported_os.network_manager == NetworkManager.NetworkManager:
            self.network_interfaces_file_path = "/etc/sysconfig/network-scripts/ifcfg"
            self.install_network_interfaces_dbus(network_conf)

        self.task_completed[HostConfigTask.NETWORK_INTERFACES] = True
        with open(NETWORK_INTERFACE_SET_MARK_PATH, 'w') as fo:
            pass

    def install_network_interfaces_file(self, network_conf):
        any_dhcp = False
        edited_interfaces = []

        network_interfaces_backup = "%s_backup" % self.network_interfaces_file_path

        # backup only if file exists
        if os.path.isfile(self.network_interfaces_file_path):
            shutil.copy(self.network_interfaces_file_path, network_interfaces_backup)
            LOG.info("A copy of %s was copied to %s as backup" %
                     (self.network_interfaces_file_path, network_interfaces_backup))

        with open(BASE_NETWORK_INTERFACES_FILE_PATH, 'r') as fo:
            new_interfaces_content = fo.read()

        for interface_name, interface_config in network_conf.items():

            if NetworkAddressMode.Skip.name == interface_config:
                LOG.info("Skipping local interface: %s" % interface_name)
                continue

            LOG.info("Editing network settings for interface: %s" % interface_name)
            edited_interfaces.append(interface_name)

            # edit interface configuration
            if NetworkAddressMode.DHCP.name == interface_config:
                any_dhcp = True
                LOG.info("DHCP configuration found for interface: %s" % interface_name)
                new_interfaces_content += "\n\n" \
                                          "auto {interface_name}\n" \
                                          "iface {interface_name} inet dhcp".format(interface_name=interface_name)

            elif isinstance(interface_config, dict):
                LOG.info("Static configuration found for interface: %s" % interface_name)
                new_interfaces_content += "\n\n" \
                                          "auto {interface_name}\n" \
                                          "iface {interface_name} inet static\n" \
                                          "   address {address}\n" \
                                          "   netmask {netmask}\n".format(interface_name=interface_name,
                                                                          address=interface_config['IP address'],
                                                                          netmask=interface_config['Subnet mask'])
                if interface_config.get('Default gateway', None):
                    new_interfaces_content += "   gateway {gateway}\n".format(gateway=interface_config['Default gateway'])
                if interface_config.get('DNS server', None):
                    new_interfaces_content += "   dns-nameservers {dns}\n".format(dns=interface_config['DNS server'])
                if interface_config.get('Route network', None) and interface_config.get('Route netmask', None) and \
                        interface_config.get('Route gateway', None):
                    new_interfaces_content += "   %s\n" % ADD_STATIC_ROUTE_COMMAND.\
                        format(network=interface_config['Route network'],
                               netmask=interface_config['Route netmask'],
                               gateway=interface_config['Route gateway'])
                if interface_config.get('MTU', None):
                    new_interfaces_content += "   mtu {mtu}\n".format(mtu=interface_config['MTU'])

            else:
                raise InvalidSetupConfigError("Unknown configuration for interface %s (type: %s):  %s",
                                              interface_name, type(interface_config), interface_config)

            if any_dhcp:
                self._update_dhcp_client_config()

        if new_interfaces_content:
            with open(self.network_interfaces_file_path, 'w') as interface_fo:
                LOG.info("writing new content to interface file: %r", new_interfaces_content)
                interface_fo.write(new_interfaces_content)

        # turn on the interfaces
        self.restart_interfaces(edited_interfaces)

    def install_network_interfaces_dbus(self, network_conf):
        raise SetupFailureError("Network interface configuration for RHEL linux distributions is not supported. "
                                "Try re-running installation with --managed option")

    def install_network_interfaces_netplan(self, network_conf, os_config):

        any_dhcp = False
        edited_interfaces = []

        network_interfaces_backup = "%s_backup" % self.network_interfaces_file_path

        # backup only if file exists
        if os.path.isfile(self.network_interfaces_file_path):
            shutil.copy(self.network_interfaces_file_path, network_interfaces_backup)
            LOG.info("A copy of %s was copied to %s as backup" %
                     (self.network_interfaces_file_path, network_interfaces_backup))

        if len(network_conf) > 0:
            # remove all existing (default) files, so it will not conflict our configuration
            netplan_dir = os.path.dirname(self.network_interfaces_file_path)
            for filename in os.listdir(netplan_dir):
                if filename.endswith(".yaml"):
                    try:
                        LOG.debug("Removing %s to avoid interface configuration conflicts", filename)
                        os.remove(os.path.join(netplan_dir, filename))
                    except Exception as e:
                        LOG.error("Exception raised when trying to delete %s. Reason: %s", filename, e)

            # create new netplan conf files (*.yaml)
            for interface_name, interface_config in network_conf.items():
                new_interfaces_dict = {}

                if NetworkAddressMode.Skip.name == interface_config:
                    LOG.info("Skipping local interface: %s" % interface_name)
                    continue

                LOG.info("Editing network settings for interface: %s, config: %s", interface_name, interface_config)
                edited_interfaces.append(interface_name)

                # edit interface configuration
                if NetworkAddressMode.DHCP.name == interface_config:
                    any_dhcp = True
                    LOG.info("DHCP configuration found for interface: %s" % interface_name)
                    new_interfaces_dict[interface_name] = {'addresses': [], 'dhcp4': True, 'dhcp-identifier': 'mac'}

                elif isinstance(interface_config, dict):
                    LOG.info("Static configuration found for interface: %s" % interface_name)

                    netmask = interface_config['Subnet mask']
                    ip_prefix = IPAddress(netmask).netmask_bits()
                    ip_address = interface_config['IP address']
                    address = ['{ip_address}/{ip_prefix}'.format(ip_address=ip_address, ip_prefix=ip_prefix)]
                    new_interfaces_dict[interface_name] = {'addresses': address, 'dhcp4': 'no', 'dhcp6': 'no'}

                    if interface_config.get('Default gateway', None):
                        if os_config.id == LinuxDistro.UBUNTU and os_config.version_id >= '22.04':      # lexicographic compare
                            # 'gateway4' is deprecated
                            new_interfaces_dict[interface_name]['routes'] = [{
                                'to': 'default', 'via': interface_config['Default gateway']
                            }]
                        else:
                            new_interfaces_dict[interface_name]['gateway4'] = interface_config['Default gateway']
                    if interface_config.get('DNS server', None):
                        nameservers = interface_config['DNS server'].split(' ')
                        new_interfaces_dict[interface_name]['nameservers'] = {'addresses': nameservers}
                    if interface_config.get('Route network', None) and interface_config.get('Route netmask', None) and \
                            interface_config.get('Route gateway', None):
                        route_network = interface_config['Route network']
                        route_prefix = IPAddress(interface_config['Route netmask']).netmask_bits()
                        route_address = '{route_network}/{route_prefix}'.format(route_network=route_network,
                                                                                route_prefix=route_prefix)
                        if not 'routes' in new_interfaces_dict[interface_name]:
                            new_interfaces_dict[interface_name]['routes'] = []
                        new_interfaces_dict[interface_name]['routes'].append({'to': route_address,
                                                                              'via': interface_config['Route gateway']})

                else:
                    raise InvalidSetupConfigError("Unknown configuration for interface %s (type: %s):  %s",
                                                  interface_name, type(interface_config), interface_config)

                new_interfaces_content = {'network': {'ethernets': new_interfaces_dict, 'version': 2}}

                # Netplan networking (e.g. 18.04 - Bionic) should write each interface configuration to a file:
                interface_file = self.network_interfaces_file_path.replace('.yaml',
                                                                           '_{iface}.yaml'.format(iface=interface_name))
                LOG.info("saving netplan configuration: %r", yaml.safe_dump(new_interfaces_content))
                with open(interface_file, 'w+') as interface_fd:
                    interface_fd.write(yaml.safe_dump(new_interfaces_content))

        if any_dhcp:
            self._update_dhcp_client_config()

    def _update_dhcp_client_config(self):
        # set dhclient timeout so we won't block in case of missing dhcp server
        LOG.info("Setting dhclient configuration with timeout")
        if os.path.isfile(self.DHCLIENT_CONF_PATH):
            try:
                with open(self.DHCLIENT_CONF_PATH, 'r') as dhcp_fo:
                    dhclient_conf = [line.strip() for line in dhcp_fo.readlines()]
                    for index, line in enumerate(list(dhclient_conf)):
                        if line.startswith("#timeout"):
                            line = "timeout 10;"
                            dhclient_conf[index] = line

                dhclient_conf = "\n".join(dhclient_conf)
                with open(self.DHCLIENT_CONF_PATH, 'w') as dhcp_fo:
                    dhcp_fo.write(dhclient_conf)
            except Exception as e:
                LOG.warning("Couldn't open dhclient configuration file, skipping: %s" % e)
        else:
            LOG.warning("Couldn't find dhclient configuration file, skipping")

    @installer_wrapper
    def installer_management_ip(self):
        LOG.info("Installing management ip in hosts file")
        SetupWizard.install_host_ip(MANAGEMENT_DNS_RECORD, self.configuration['management_address'])

    @classmethod
    def install_host_ip(cls, host_name, ip_address):
        """
        a method that sets a host ip address in the in the hosts file (/etc/hosts)
        the method is adding a record if it doesn't exist, or edits it if it's different than expected
        """
        record_found = False
        LOG.info("Editing hosts file for host: %s, with ip: %s" % (host_name, ip_address))
        with open(cls.HOSTS_PATH, 'r') as fo:
            hosts_object = [line.strip().split() for line in fo.readlines()]
            for line in hosts_object:
                if len(line) > 1:
                    if host_name == line[1]:
                        LOG.info("Host record found: %s" % line)
                        record_found = True
                        if ip_address:
                            if ip_address != line[0]:
                                LOG.info("Host record should be changed")
                                line[0] = ip_address
                            else:
                                LOG.info("Host record should not be changed")
                                return
                        else:
                            LOG.info("Host record should be removed")
                            line[0] = line[1] = ""

        if ip_address and not record_found:
            LOG.info("Host record wasn't found, adding a new one")
            hosts_object.append([ip_address, host_name])

        new_hosts_content = [" ".join(line) for line in hosts_object]
        new_hosts_content = [line for line in new_hosts_content if line]
        new_hosts_content = "\n".join(new_hosts_content)
        new_hosts_content = '{}{}'.format(new_hosts_content, "\n")

        with open(cls.HOSTS_PATH, 'w') as fo:
            fo.write(new_hosts_content)

    @staticmethod
    def install_check_connectivity_port(ip_address, ports_list):
        """
        a function that check connectivity to a specific ip address and a port list by opening a socket
        the function returns True if all ports are reachable or False if any were unreachable
        """
        connectivity_status = True

        for port in ports_list:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.connect((ip_address, port))
                sock.close()
                LOG.info("Connectivity check succeeded to: %s:%s" % (ip_address, port))

            except:
                LOG.error("Connectivity check failed to: %s:%s" % (ip_address, port))
                connectivity_status = False

        return connectivity_status

    @staticmethod
    def install_edit_conf_file(config_update, conf_file=GUARDICORE_CONFIGURATION_PATH):
        """
        a method that edits guardicore configuration file
        :param conf_file: path to configuration file
        :param config_update: a dict with (section, key) as key, and value as configuration value
                              if the value is None - the value will be erased
        """

        LOG.info("Editing configuration: %s" % conf_file)

        # strict false in py3 to resolve duplicate confs
        conf_object = configparser.ConfigParser(strict=False) if six.PY3 else configparser.ConfigParser()
        conf_object.read(conf_file)

        for (section, key), value in config_update.items():
            LOG.info("Setting configuration: [{section}]:{key} - {value}".format(section=section,
                                                                                 key=key,
                                                                                 value=value))
            if not conf_object.has_section(section):
                conf_object.add_section(section)
            if value is None:
                if conf_object.has_option(section, key):
                    conf_object.remove_option(section, key)
            else:
                conf_object.set(section, key, value)

        LOG.info("Saving configuration file: %s" % conf_file)
        with open(conf_file, 'w') as fo:
            conf_object.write(fo)

    @staticmethod
    def get_conf_file_sections(conf_file=GUARDICORE_CONFIGURATION_PATH):
        if not os.path.exists(conf_file):
            return None

        # strict false in py3 to resolve duplicate sections
        conf_object = configparser.ConfigParser(strict=False) if six.PY3 else configparser.ConfigParser()
        conf_object.read(conf_file)
        return conf_object.sections()

    @staticmethod
    def remove_conf_file_section(section, conf_file=GUARDICORE_CONFIGURATION_PATH):
        if not os.path.exists(conf_file):
            return None

        conf_object = configparser.ConfigParser(strict=False) if six.PY3 else configparser.ConfigParser()
        conf_object.read(conf_file)
        section_items = conf_object.items(section=section)
        conf_object.remove_section(section=section)
        LOG.info("Removing section %s from configuration file: %s" % (section, conf_file))
        with open(conf_file, 'w') as fo:
            conf_object.write(fo)

        return section_items

    @classmethod
    def monicore_get_all_services(cls):
        """
        a function that returns all current monicore services
        :return:
        """
        if not cls.is_monicore_ctrl_installed():
            LOG.debug("Not getting monicore status. monicore-ctrl is not installed")
            return None

        command = STATUS_MONICORE_COMMAND
        result = subprocess_call_independent(command, merge_stderr=False)
        if result['exit_code']:
            raise SetupFailureError("Failed getting all current monicore services with command:%s ,because: %s-%s",
                                    command, result['exit_code'], result['stderr'])
        formatted_output = result['stdout'].replace("'", '"')
        services = list(json.loads(formatted_output).keys())
        LOG.info("Monicore services found: %s", services)
        return services

    @classmethod
    def monicore_start_services(cls, service_name=None, restart=False):
        """
        a method that starts a service with monicore
        starts all services if service_name is None
        """
        if not cls.is_monicore_ctrl_installed():
            LOG.debug("Not starting monicore services. monicore-ctrl is not installed")
            return

        if service_name:
            services = [service_name]
        else:
            services = ['all']

        for service in services:
            if restart:
                command = RESTART_MONICORE_COMMAND + [service]
                message = "Restarting monicore service '%s' with command: %s", service, command
            else:
                command = START_MONICORE_COMMAND + [service]
                message = "Starting monicore service '%s' with command: %s", service, command
            LOG.info(message)
            subprocess_call_independent(command, merge_stderr=False)
            # we don't look at monicore's output for starting services, as it might return false output

    @classmethod
    def monicore_stop_services(cls, service_name=None):
        """
        a method that starts a service with monicore
        stops all services if service_name is None
        """
        if not cls.is_monicore_ctrl_installed():
            LOG.debug("Not stopping monicore services. monicore-ctrl is not installed")
            return None

        if service_name:
            services = [service_name]
        else:
            services = ['all']
        for service in services:
            command = STOP_MONICORE_COMMAND + [service]
            LOG.info("Stopping monicore service '%s' with command: %s", service, command)
            subprocess_call_independent(command, merge_stderr=False)
            # we don't look at monicore's output for stopping services, as it might return false output

    @classmethod
    def monicore_reload_configuration(cls):
        """
        a method that reloads monicore configuration
        """
        if not cls.is_monicore_ctrl_installed():
            LOG.debug("Not reloading monicore configuration. monicore-ctrl is not installed")
            return None

        command = RELOAD_MONICORE_COMMAND
        result = subprocess_call_independent(command, merge_stderr=False)
        if result['exit_code']:
            raise SetupFailureError("Failed reloading monicore configuration command: %s ,because: %s-%s",
                                    command, result['exit_code'], result['stderr'])

        LOG.info("Monicore configuration reloaded successfully")


    @staticmethod
    def is_monicore_ctrl_installed():
        return os.path.isfile(MONICORE_CTRL_BIN_PATH) and os.access(MONICORE_CTRL_BIN_PATH, os.X_OK)

    @staticmethod
    def get_selected_opts(multiple_choice_list):
        """
        a method that take lists like SetupDialog.collect_multiple_options output and return the selected opts names
        :param multiple_choice_list:
        :return: list of the names of the selected opts
        """
        if not multiple_choice_list:
            return []
        selected_opts = []
        for opt in multiple_choice_list:
            if isinstance(opt, six.string_types):
                selected_opts.append(opt)
                continue
            if len(opt) != 3:
                raise SetupFailureError("Failed parsing %s. should be in length 3", opt)
            if opt[2]:
                selected_opts.append(opt[0])
        return selected_opts

    @staticmethod
    def configuration_translation(config, config_translation):
        """
        a method which translate flat configuration to group,key
        :param config: configuration dict
        :param config_translation: list of triplets of name in config, group int the config file and key in the config file
        :return:  dict- the key is tuple of the section and key and the value is the value
        """
        update_dict = {}
        for config_name, section, key in config_translation:
            update_dict[(section, key)] = config[config_name]
        return update_dict

    @staticmethod
    def install_edit_configuration(config_name, config_file_path, config_dict):
        """
        a method that edit configuration file
        :arg config_name the configuration name (used for logging)
        :arg config_file_path the configuration file path
        :arg config_dict the configuration dict- the key is tuple of the section and key and the value is the value

        """
        # list of triplets of ma_setup_name, group in guest_installer config, key in guest_installer

        if not os.path.exists(config_file_path):
            LOG.warning("%s doesn't exist. Skipping %s configuration",
                        config_name, config_file_path)
            return

        LOG.info("Editing %s configuration", config_name)
        SetupWizard.install_edit_conf_file(conf_file=config_file_path,
                                           config_update=config_dict)

    def restart_interfaces(self, edited_interfaces):
        for interface_name in edited_interfaces:
            try:
                self.turn_off_network_interface(interface_name)
                self.turn_on_network_interface(interface_name)
                time.sleep(2)
            except Exception as e:
                LOG.warning("Couldn't turn on interface: %s" % e)

    def turn_off_network_interface(self, interface_name):
        """
        a method that turns off a network interface
        """
        LOG.info("Turning off the interface: %s" % interface_name)
        command = IFDOWN_COMMAND + [interface_name, '-i', self.network_interfaces_file_path]
        LOG.info("Running command: %s" % command)

        result = subprocess_call_independent(command, merge_stderr=False)
        if result['exit_code']:
            raise SetupFailureError("Failed running command: %s ,because: %s-%s", command, result['exit_code'],
                                    result['stderr'])

    def turn_on_network_interface(self, interface_name):
        """
        a method that turns on a network interface
        """
        LOG.info("Turning on the interface: %s" % interface_name)
        command = IFUP_COMMAND + [interface_name, '-i', self.network_interfaces_file_path]
        LOG.info("Running command: %s" % command)

        result = subprocess_call_independent(command, merge_stderr=False)
        if result['exit_code']:
            raise SetupFailureError("Failed running command: %s ,because: %s-%s", command, result['exit_code'],
                                    result['stderr'])

    @staticmethod
    def get_details_from_interface_name(interface_name):
        """
        a function that gets available data about interface from interface name
        :param interface_name: name of interface (string)
        :return: dict with ip_address, netmask, cidr, name
                 returns empty dict if interface_name wasn't found
        """
        interface = None
        result = {}
        interfaces_objects = IPWrapper().get_devices(exclude_loopback=True)
        LOG.info('Looking for interface %s, Existing interfaces: %s' % (interface_name,
                 [interface.name for interface in interfaces_objects]))
        for interface_object in interfaces_objects:
            if interface_name == interface_object.name:
                interface = interface_object
        if not interface:
            return result

        try:
            result['name'] = interface_name
            result['cidr'] = interface.addr.list()[0]['cidr']
            result['ip_address'], mask = result['cidr'].split('/')
            bits = 0xffffffff ^ (1 << 32 - int(mask)) - 1
            result['netmask'] = socket.inet_ntoa(struct.pack('>I', bits))

        except Exception as e:
            LOG.error("Couldn't get details about interface '%s' - %s" % (interface_name, e))
            raise

        return result

    @installer_wrapper
    def installer_stop_main_service(self):
        SetupWizard.monicore_stop_services(self.gc_service_name)

    @installer_wrapper
    def installer_start_main_service(self):
        SetupWizard.monicore_start_services(self.gc_service_name)

    @installer_wrapper
    def installer_network(self):
        if not self.task_completed[HostConfigTask.NETWORK_INTERFACES]:
            LOG.info("Installing network interfaces")
            self.install_network_interfaces(self.configuration['local_network_interfaces'])
            self.task_completed[HostConfigTask.NETWORK_INTERFACES] = True
            with open(NETWORK_INTERFACE_SET_MARK_PATH, 'w') as fo:
                pass

    def _clone_git_repo(self, repo_ip):
        """
        Clones the git repo from the given host. It will try to clone twice before raising an exception
        """
        # clone the repository
        git_clone_cmd = "git clone https://%s:%s@%s/%s" % (TLS_USERNAME,
                                                           OsloSecret.decode(self.configuration[
                                                                                 'secure_communication_password']),
                                                           repo_ip, GIT_CONFIG_REPO_URI)

        result = subprocess_call_independent(git_clone_cmd.split(), cwd=AGGR_HPVM_STORAGE_PATH,
                                             merge_stderr=True)
        if result['exit_code']:
            # In case the first clone attempt failed, retry
            time.sleep(15)
            result = subprocess_call_independent(git_clone_cmd.split(), cwd=AGGR_HPVM_STORAGE_PATH,
                                                 merge_stderr=True)
        # If the clone failed again, raise an exception
        if result['exit_code']:
            raise SetupFailureError("Error creating git configuration repository with cmd '%s'\n%s",
                                    git_clone_cmd,
                                    result['stdout'])

        return result

    @installer_wrapper
    def installer_create_git_repo_and_execute_ansible(self):
        dr_components_config = {}

        if self.config_component_name is None:
            return

        if os.path.isfile(DR_COMPONENTS_CONFIG):
            with open(DR_COMPONENTS_CONFIG) as dr_components_config_file:
                dr_components_config = json.load(dr_components_config_file)

        LOG.info("Creating git config repository")

        # support management DNS
        try:
            shutil.copy(SYSTEMD_STUB_RESOLVE_CONF_PATH, SetupWizard.RESOLVE_CONF_PATH)
        except Exception as e:
            LOG.error("Couldn't copy file: %s -> %s: %s", SYSTEMD_STUB_RESOLVE_CONF_PATH,
                      SetupWizard.RESOLVE_CONF_PATH, e)

        # TODO: fix this ASAP, need to make management REST server TLS certificates with CA chain so we could
        # verify the server with SSL
        git_config_cmd = "git config --global http.sslVerify false"
        result = subprocess_call_independent(git_config_cmd.split(), merge_stderr=True)
        if result['exit_code']:
            raise SetupFailureError("Error configuration git configuration repository with cmd '%s'\n%s",
                                    git_config_cmd, result['stdout'])

        # make sure storage directory is created
        if not os.path.isdir(os.path.dirname(GIT_CONFIG_REPO_PATH)):
            os.makedirs(os.path.dirname(GIT_CONFIG_REPO_PATH))

        # remove previous configuration repo if exists
        if os.path.isdir(GIT_CONFIG_REPO_PATH):
            LOG.debug("Removing old git configuration repository under '%s'", GIT_CONFIG_REPO_PATH)
            shutil.rmtree(GIT_CONFIG_REPO_PATH)

        primary_repo_ip = self.configuration['management_address']
        secondary_repo_ip = dr_components_config.get('designated_standby_ip_address')

        try:
            # Clone the git repo using the primary ip.
            result = self._clone_git_repo(primary_repo_ip)
        except SetupFailureError:
            # Cloning the repo using the primary ip has failed. Trying to use the secondary.
            if secondary_repo_ip:
                result = self._clone_git_repo(secondary_repo_ip)
            else:
                # Failed to clone from the secondary
                raise

        LOG.info("Created git repo:\n%s", result['stdout'])
        self.run_pullconfig_ansible()

    def run_pullconfig_ansible(self):
        env = os.environ.copy()
        env['ANSIBLE_EXTRA_VARS'] = " ".join(self._ansible_extra_vars)
        LOG.info("Running ansible with extra vars: %s", env['ANSIBLE_EXTRA_VARS'])

        result = subprocess_call_independent(["bash",
                                              os.path.join(AGGR_HPVM_STORAGE_PATH, "guardicore_cfg/pull_config.sh"),
                                              self.config_component_name], merge_stderr=True, env=env)
        if result['exit_code']:
            raise SetupFailureError("Error running pull config for the first time for component '%s':\n%s",
                                    self.config_component_name, result['stdout'])
        else:
            LOG.info("Executed config repository for the first time with component name '%s':\n%s",
                     self.config_component_name, result['stdout'])

    ###################################
    # setup process methods section
    ###################################

    def setup_greetings(self):
        """
        a method that greets the user at the beginning of the setup
        """
        LOG.info("Displaying greetings message")
        self.setup_dialog.general_greetings(dry_mode=self.dry_mode)

    def setup_pre_collect(self):
        """
        a method that runs prior to the collection process
        mainly for gathering system data or for first time running
        """
        # collect root password
        LOG.info("Running pre installation")
        if self.task_completed[HostConfigTask.SYSTEM_PASSWORD]:
            LOG.info("{username} password was set before - not setting password".format(username=self.setup_username))

        else:
            if not self.quiet_mode:
                LOG.info("Collecting {username} password from the user".format(username=self.setup_username))
                ready = False
                while not ready:
                    try:
                        system_password = self.setup_dialog.\
                            collect_machine_password(min_password_len=USER_PASSWORD_MIN_LEN,
                                                     password_validity_function=SetupWizard._check_password_validity)
                    except NavigateBack:
                        self.setup_dialog.general_msgbox(title="Cannot Go Back",
                                                         text="\nPassword must be changed in order to proceed.",
                                                         height=7)
                        continue

                    self.configuration["{username}_password".format(username=self.setup_username)] = \
                        self._hash_password(system_password)

                    if not self.dry_mode:
                        ready = self.setup_dialog.general_password_set()
                    else:
                        break

            if not self.dry_mode:
                system_password = self.configuration.get("{username}_password".format(username=self.setup_username))
                if not system_password or self.install_users_passwords(system_password):
                    # mark password was set
                    with open(self.PASSWORD_SET_MARK_PATH, 'w') as fp:
                        fp.write("wizard " + time.ctime() + os.linesep)

            else:
                LOG.info("Not setting password in dry mode")

            self.task_completed[HostConfigTask.SYSTEM_PASSWORD] = True

    def _setup_convert_collection_steps(self):
        new_collection_steps = []
        for step in self.collection_steps:
            if isinstance(step, CollectionStep):
                new_collection_steps.append(step)
            else:
                new_collection_steps.append(CollectionStep(step))

        self.collection_steps = new_collection_steps

    def setup_disable_collection_step(self, func):
        """
        this function works only on Collection steps (should be called only after _convert_collection_steps)
        """
        steps = [step for step in self.collection_steps if func == step.func]
        for step in steps:
            step.enabled = False
            LOG.info("Disabled func: %s", func)

    def setup_enable_collection_step(self, func):
        """
        this function works only on Collection steps (should be called only after _convert_collection_steps)
        """
        steps = [step for step in self.collection_steps if isinstance(step, CollectionStep) and func == step.func]
        for step in steps:
            step.enabled = True

    def setup_collect(self):
        """
        a method that calls all the configuration collection tasks and sets root password
        """
        LOG.info("Running collection")
        self._setup_convert_collection_steps()
        num_of_tasks = len(self.collection_steps)

        if num_of_tasks < 1:
            LOG.info("No collection tasks in queue, skipping")
            return

        current_task = 0
        while True:
            try:
                if self.collection_steps[current_task].enabled:
                    LOG.info("Calling collection task: %s" % self.collection_steps[current_task].func)
                    self.collection_steps[current_task].func()
                    LOG.info("Collection task finished: %s" % self.collection_steps[current_task].func)
                else:
                    LOG.debug("Skipping disabled task: %s", self.collection_steps[current_task].func)
            except NavigateBack:
                previous_task = current_task - 1
                while previous_task >= 0 and not self.collection_steps[previous_task].enabled:
                    previous_task -= 1
                if previous_task < 0:
                    LOG.info("Can't navigate back from step %d because there are no previous enabled steps", current_task)
                else:
                    current_task = previous_task
                continue
            except Skip:
                pass
            current_task += 1
            if current_task == len(self.collection_steps):
                break
        LOG.info("Collection steps finished with the following configuration: %s" % self.configuration)

    def setup_post_collect(self):
        LOG.info("Post-collection step finished")

    def setup_review(self):
        """
        a method that asks the user for permission to continue right before installation
        this method is recommended to be overridden with a presentation for the specific component
        """
        LOG.info("Running review")
        if self.dry_mode:
            return True

        title = "Ready to Install"
        message = "Setup will now install your configuration.\n" \
                  "Click Yes to continue or No to edit your configuration"

        return self.setup_dialog.general_confirm_to_proceed(text=message, title=title)

    def setup_verify(self):
        """
        a method that runs in all modes of operation just before installing
        """
        LOG.info("Running verify")

        # dump json configuration
        if not self._export_configuration(export_file_path=SETUP_CONFIGURATION_PATH):
            raise SetupFailureError("Error exporting JSON configuration to file")

    def setup_install(self):
        LOG.info("Running install")
        task_counter = 0
        total_tasks_number = len(self.installation_steps)
        description = ""

        if not self.quiet_mode:
            self.setup_dialog.install_start_installation()
        for task, description in self.installation_steps.items():
            percentage = task_counter * 100 // total_tasks_number
            LOG.info("Calling installation task: %s" % description)
            if not self.quiet_mode:
                self.setup_dialog.install_step_update(percentage, description)

            try:
                task()
                LOG.info("Installation task finished successfully: %s " % description)
            except Exception as e:
                error_message = "Failed in running installation task: %s: %s" % (description, e)
                LOG.exception(error_message)
            finally:
                self.flush_log()

            task_counter += 1
            if not self.quiet_mode:
                time.sleep(1)

        if total_tasks_number > 0:
            percentage = task_counter * 100 // total_tasks_number
        else:
            percentage = 100
            description = ""

        if not self.quiet_mode:
            self.setup_dialog.install_step_update(percentage, description)
            time.sleep(round(random.uniform(0, 1), 1))

        LOG.info("Finished running all installation tasks")

    def setup_summary(self):
        """
        a method that calls for a summary screen
        """
        LOG.info("Running summary")
        self.setup_dialog.general_summary(error=self.first_error)

    def setup_pre_install(self):
        """
        a method that runs before the installation steps
        this is a proper place to change installation steps if needed (override this function)
        """
        LOG.info("No pre-installation steps")

    def encrypt_passwords(self):
        """
         a method that runs just before the installation steps (after the pre_install step, before the install step)
         this function encrypts passwords that are set during the collection step, which is skipped when using the
         quiet mode (upgrade + installation using an existing conf file)
        """
        self.configuration['secure_communication_password'] =\
            OsloSecret.encode(self.configuration['secure_communication_password'])

    def setup_post_install(self):
        """
        a method that runs just after the installation steps
        this is a proper place to run extra collection & installation steps, after setup was running
        """
        LOG.info("No post-installation steps")

    def setup_error_output(self):
        """
        a method that handles the setup errors output
        """
        if self.is_connectivity_error:
            self.exit_code = MGMT_CONNECTIVITY_ERROR_CODE
            self.stderr = "Connectivity check to Management server failed\n"
            LOG.error("Setup failed")
        elif self.is_any_error:
            self.exit_code = 1
            self.stderr = "An error has occurred during setup\n"
            LOG.error("Setup failed")
        else:
            self.exit_code = 0
            self._mark_successful_run()

    def start(self):
        """
        the main method that executes the setup process
        """
        try:
            if self.conf_file:
                LOG.info("Initializing with configuration file: %s" % self.conf_file)
                self._import_configuration(self.conf_file)
                LOG.info('Configuration: \n{}'.format(json.dumps(self.configuration, indent=4)))

            if not self.quiet_mode:
                self.setup_greetings()
            self.setup_pre_collect()

            if not self.quiet_mode:
                self.setup_collect()

                while not self.setup_review():
                    self.setup_collect()
                self.setup_post_collect()

            self.encrypt_passwords()

            self.setup_verify()
            if not self.dry_mode:
                self.setup_pre_install()
                self.setup_install()
                self.setup_post_install()

            if not self.quiet_mode:
                self.setup_summary()

            if not self.dry_mode:
                self.setup_error_output()

        except (SystemExit, KeyboardInterrupt):
            LOG.warning("Setup was aborted by the user")
            self.stderr = "Setup was aborted by the user\n"
            self.exit_code = 130

        except:
            self.is_any_error = True
            self.exit_code = 1
            LOG.exception("Unhandled error in the setup flow")
            self.stderr = "Unhandled error in the setup flow\n"
            if not self.quiet_mode:
                error_message = "Please see /var/log/guardicore/setup_wizard.log for details"
                self.setup_dialog.general_display_error(error_message=error_message)

        finally:
            if not self.quiet_mode:
                self.setup_dialog.clear_screen()
                self.setup_dialog.reset_shell()

        if self.stderr:
            sys.stderr.write(self.stderr)
        elif self.quiet_mode and not self.logger_mode:
            sys.stdout.write("Setup completed successfully\n")
        sys.exit(self.exit_code)
