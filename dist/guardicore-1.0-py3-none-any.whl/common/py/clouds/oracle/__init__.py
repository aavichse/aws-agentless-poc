from common.py.clouds import common_opts, label_opts
from common.py.utils.config import cfg
from common.py.utils.config.types import List, String, Structure

ORACLE_REGION_FREE_TEXT = 'Other (free text)'
ORACLE_REGIONS = ['ap-seoul-1', 'ap-tokyo-1', 'ca-toronto-1', 'eu-frankfurt-1', 'uk-london-1',
                  'us-ashburn-1', 'us-phoenix-1',
                  ORACLE_REGION_FREE_TEXT]

oracle_opts = [
                  cfg.StrOpt('user_ocid', help="OCID of the user calling the API"),
                  cfg.StrOpt('key_pair_fingerprint', help="Fingerprint for the key pair being used"),
                  cfg.ExtendedOpt('private_key',
                                  default=[],
                                  type=List(item_type=String(unicode=True, quotes=True), bounds=True),
                                  multi_line_text=True,
                                  secret=True,
                                  help="Content of the private key (PEM format)"),
                  cfg.StrOpt('private_key_passphrase', secret=True,
                             help="Passphrase used for the key, if it is encrypted (optional)"),
                  cfg.StrOpt('tenancy_ocid', help="OCID of tenancy"),
                  cfg.StrOpt('region', choices=ORACLE_REGIONS, help="OCI home region", default=ORACLE_REGIONS[0]),
                  cfg.StrOpt('region_free_text', default=None,
                             help="This will be used only when selecting '{}' under Region".format(
                                 ORACLE_REGION_FREE_TEXT)),
                  cfg.BoolOpt('query_all_regions', default=False, help="Query all regions subscribed by tenancy"),
                  cfg.StrOpt('proxy_url', default=None, help="Optional HTTP/HTTPS proxy URL"),
              ] + common_opts + label_opts

ORACLE_AUTH_STRUCTURE = Structure(oracle_opts)

ORACLE_AUTH_OPT = [cfg.IntOpt('update_timeout_seconds',
                              default=10 * 60,
                              help="Oracle OCI update timeout in seconds")]


def register_opts():
    cfg.CONF.register_opt(cfg.Opt('oracle_configuration', type=ORACLE_AUTH_STRUCTURE), group="orchestration")
    cfg.CONF.register_opts(opts=ORACLE_AUTH_OPT, group="oracle_auth")
