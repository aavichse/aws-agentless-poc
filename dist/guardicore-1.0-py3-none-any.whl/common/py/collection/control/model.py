import os
import re
import attr
import inspect
import posixpath
from enum import IntEnum
from flask import Response, request
from werkzeug.exceptions import InternalServerError, HTTPException
from common.logger import get_logger
from common.singleton import Singleton
from common.py.apis.rabbitutils import RabbitMsgJSONEncoder
from common.py.utils.config.six import fastjson

LOG = get_logger(module_name=__name__)

MATCH_WORKER_SOCK = re.compile(r"([a-z_]+)_(\d+)\.sock")
MATCH_MASTER_SOCK = re.compile(r"([a-z_]+)\.sock")

CONTORL_SOCK_BASE_PATH = "/var/run/aggregator/control"


class ResponseWrappingType(IntEnum):
    NoWrapping = 1
    JsonWrapping = 2
    StrWrapping = 3


@attr.s
class ControlCommand(object):
    path = attr.ib()
    func = attr.ib()
    methods = attr.ib()
    help = attr.ib(default="")
    prefix = attr.ib(default=None)
    wrapped = attr.ib(default=ResponseWrappingType.JsonWrapping)

    def __getattr__(self, item):
        if item == '__name__':
            return self.func.__name__

        return object.__getattr__(item)

    def __call__(self, *args, **kwargs):
        try:
            if self.wrapped == ResponseWrappingType.JsonWrapping:
                return _wrapped_ctrl_command_json(self.func, *args, **kwargs)
            elif self.wrapped == ResponseWrappingType.StrWrapping:
                return _wrapped_ctrl_command_raw(self.func, *args, **kwargs)
        except Exception as exc:
            LOG.exception("Error while dispatching a call to control command %s", self)
            raise InternalServerError(description=str(exc))

        return self.func(*args, **kwargs)

    def do_help(self):
        return Response(self.help + os.linesep)


CONTROL_ATTR = '_control_method'


def control(path, methods=("GET", ), wrapped=ResponseWrappingType.JsonWrapping, prefix=None, help=None):
    """control(path, methods=("GET", ), wrapped=ResponseWrappingType.JsonWrapping, prefix=None, help=None)

    Decorator to add REST endpoints to an AggregatorService subclass.
    """
    def _wrapper(f):
        setattr(f, CONTROL_ATTR, ControlCommand(path=path, func=None, help=help, methods=methods,
                                                wrapped=wrapped, prefix=prefix))
        return f
    return _wrapper


def _wrapped_ctrl_command_raw(f, *args, **kwargs):
    try:
        ret = f(*args, **kwargs)
    except HTTPException:
        raise

    if isinstance(ret, HTTPException):
        return ret

    return Response(str(ret) + os.linesep)


def _wrapped_ctrl_command_json(f, *args, **kwargs):
    try:
        ret = f(*args, **kwargs)
    except HTTPException as exc:
        return exc

    if isinstance(ret, HTTPException):
        return ret

    try:
        indent = 2 if request.values.get('pretty', "false") == "true" else None
        json_reply_dump = fastjson.dumps(ret, cls=RabbitMsgJSONEncoder, indent=indent)
    except Exception as exc:
        return InternalServerError("Error while dumping reply to JSON: {}\n\nReply:\n{}".format(exc, repr(ret)))

    return Response(json_reply_dump + os.linesep)


def get_method_ctrl_cmd(service, method):
    ctrl_cmd = getattr(method, CONTROL_ATTR, None)
    if ctrl_cmd:
        ctrl_cmd.func = method
    return ctrl_cmd


def get_service_ctrl_commands(service):
    ctrl_commands = []
    for member_name, member in inspect.getmembers(service, inspect.ismethod):
        method_ctrl_cmd = get_method_ctrl_cmd(service, member)
        if method_ctrl_cmd is not None:
            ctrl_commands.append(method_ctrl_cmd)
    return ctrl_commands


def _get_ctrl_server_ref():
    return ".".join(__name__.split(".")[:-1] + ["control_server", "ControlServer"])


def register_service_control_commands(service, prefix=None, control_service=None):
    prefix = prefix or service.name
    control_service = control_service or Singleton.get_instance_by_key(_get_ctrl_server_ref())
    ctrl_commands = get_service_ctrl_commands(service)
    if ctrl_commands and control_service:
        control_service.register_ctrl_commands(prefix=prefix, ctrl_commands=ctrl_commands)


def register_control_command(path, func, prefix, methods=("GET", ), wrapped=ResponseWrappingType.JsonWrapping,
                             help=None):
    control_service = Singleton.get_instance_by_key(_get_ctrl_server_ref())
    ctrl_command = ControlCommand(path=path, func=func, help=help, methods=methods, prefix=prefix, wrapped=wrapped)
    if control_service:
        control_service.register_ctrl_commands(prefix=prefix, ctrl_commands=[ctrl_command])
    else:  # this flow should only happen for UT's
        LOG.warning("Couldn't register command %s because control service ins't found", ctrl_command)


def _get_server_meta_from_sock(sock_path):
    if not sock_path.endswith(".sock"):
        return None

    worker_match = MATCH_WORKER_SOCK.match(sock_path)
    if worker_match is not None:
        return worker_match.group(1), int(worker_match.group(2))

    master_match = MATCH_MASTER_SOCK.match(sock_path)
    if master_match is not None:
        return master_match.group(1), 0

    if "orchestration" in sock_path:
        orchestration = sock_path.replace(".sock", "")
        return orchestration, 0

    return None


def list_all_open_ctrl_servers():
    servers = []
    for sock_path in os.listdir(CONTORL_SOCK_BASE_PATH):
        meta = _get_server_meta_from_sock(sock_path)
        if not meta:
            continue
        servers.append(meta)

    return servers


def build_ctrl_sock_path(component_name, worker_index=0, special_id=None):
    """build_ctrl_sock_path(component_name, worker_index=0, special_id=None) -> path
    :param component_name: the name/type of the component (e.g. mitigation, datapath, ...)
    :param worker_index: the index of the worker (in case there is one, otherwise 0)
    :param special_id: specific ID of the component. Used in case where the same component type might
    have multiple instances with different IDs, like in the case of orchestration or exporter service.
    :return: the path of the unix-socket for the control server
    """

    sock_name = component_name
    if worker_index:
        sock_name += "_%d" % (worker_index, )
    if special_id:
        sock_name += "_%s" % (special_id, )
    sock_name += ".sock"

    return posixpath.join(CONTORL_SOCK_BASE_PATH, sock_name)
