from __future__ import annotations

from typing import List

from pydantic import BaseModel, Field, RootModel

from ..common.inventory import InventoryItem


class NetworkConnections(BaseModel):
    network: str
    reachable_networks: List[str] = Field(..., alias='reachable-networks')


class NetworkTopology(RootModel[List[NetworkConnections]]):
    root: List[NetworkConnections]

    def __getattr__(self, attr: str):
        return getattr(self.root, attr)

    def __iter__(self):
        for item in self.root:
            yield item


class Inventory(RootModel[List[InventoryItem]]):
    root: List[InventoryItem]

    def __getattr__(self, attr: str):
        return getattr(self.root, attr)

    def __iter__(self):
        for item in self.root:
            yield item
