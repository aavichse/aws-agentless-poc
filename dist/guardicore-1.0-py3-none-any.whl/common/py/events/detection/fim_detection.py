from mongoengine import StringField, DateTimeField, IntField
from common.py.utils.mongo import IntEnumField
from common.py.events.detection import IntegrityDetectionEvent
from common.py.events import LongHashType
from common.py.events.detection_server.fim_scan import FIMPathScanVerdict


class FimDetectionEvent(IntegrityDetectionEvent):
    GROUP = 'File Integrity Detection'
    DEFAULT_VISIBILITY = IntegrityDetectionEvent.Visibility.Front
    check_time = DateTimeField(required=True)
    last_valid_time = DateTimeField()
    file_modified_time = DateTimeField()
    asset_id = StringField(required=True)
    file_path = StringField(required=True)
    file_hash_value = StringField()
    file_owner_name = StringField()
    verdict = IntEnumField(enum_type=FIMPathScanVerdict)
    label_id = StringField()
    label_name = StringField()
    file_hash_type = IntEnumField(enum_type=LongHashType, required=True)
    error_description = StringField()
    valid_template_id = StringField()
    valid_label_name = StringField()
    template_revision = IntField(required=True)
