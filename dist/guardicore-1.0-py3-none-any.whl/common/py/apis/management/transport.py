from common.py.apis.management import ManagementAPIError

GREENLET_KILL_TIMEOUT = 30
GREENLET_JOIN_TIMEOUT = 30
GREENLET_POOL_TIMEOUT = 30

try:
    import eventlet
    import eventlet.event
    import eventlet.timeout
    import eventlet.semaphore

    class EventletTransport(object):
        sleep = staticmethod(eventlet.sleep)
        spawn = staticmethod(eventlet.spawn)

        Lock = eventlet.semaphore.Semaphore
        Timeout = eventlet.timeout.Timeout

        @staticmethod
        def get_greenlet_exception(gt):
            try:
                gt.wait()  # we don't care about return values, only exceptions
                return None
            except Exception as e:
                # TODO: need to switch to return sys.exc info.
                return e

        class Event(object):
            def __init__(self):
                self._e = eventlet.event.Event()

            def set(self):
                return self._e.send()

            def reset(self):
                return self._e.reset()

            def wait(self):
                self._e.wait()

except ImportError:
    EventletTransport = None

try:
    import gevent
    import gevent.monkey
    import gevent.ssl
    import gevent.event
    import gevent.lock
    import gevent.timeout

    class GEventTransport(object):
        sleep = staticmethod(gevent.sleep)
        spawn = staticmethod(gevent.spawn)

        Lock = gevent.lock.Semaphore
        Timeout = gevent.timeout.Timeout

        @staticmethod
        def get_greenlet_exception(gt):
            return gt.exc_info

        class Event(object):
            def __init__(self):
                self._e = gevent.event.Event()

            def set(self):
                return self._e.set()

            def reset(self):
                return self._e.clear()

            def wait(self):
                return self._e.wait()

except ImportError:
    GEventTransport = None

try:
    import gevent
    import gevent.pool

    class GEventPoolTransport(GEventTransport):

        _POOL = None

        @classmethod
        def setup(cls, size):
            if cls._POOL is not None:
                raise ManagementAPIError("Transport pool for rabbitmq client was already created")

            cls._POOL = gevent.pool.Pool(size=size)

        @classmethod
        def clean(cls):
            if cls._POOL is not None:
                cls._POOL.kill(timeout=GREENLET_KILL_TIMEOUT)
                cls._POOL.join(timeout=GREENLET_JOIN_TIMEOUT)

        @classmethod
        def spawn(cls, func, *args, **kwargs):
            """Non-blocking spawn of Greenlet in pool
            return Added to pool and started greenlet in case of success
                   None otherwise
            """
            try:
                callback_greenlet = gevent.Greenlet(func, *args, **kwargs)
                cls._POOL.start(callback_greenlet, blocking=True, timeout=GREENLET_POOL_TIMEOUT)
                return callback_greenlet
            except gevent.pool.PoolFull:
                pass

except ImportError:
    GEventPoolTransport = None
