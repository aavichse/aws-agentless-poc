from copy import deepcopy

from common.py.data_export.exporter import AuditLogEntryExporterMixin, Exporter, AgentLogExporterMixin, \
    IncidentExporterMixin, SystemAlertExporterMixin, LabelChangesLogExporterMixin, NetworkLogsExporterMixin, \
    InsightAlertExporterMixin
from common.py.data_export.exporters.network_log_syslog import NETWORK_LOG_SYSLOG_CONF_GROUP, network_log_syslog_opts, \
    NetworkLogSyslogExporter
from common.py.data_export.exporters.events_syslog import EventsSyslogExporter, events_syslog_opts, \
    EVENTS_SYSLOG_CONF_GROUP, DEFAULT_SYSLOGGER__AGGR_PATH
from common.py.data_export.exporters.syslog_utils import base_syslog_opts, SyslogType, BASE_SYSLOG_GROUP
from common.py.data_export import IntegrationType
from common.py.models.events import EventStatus
from common.py.utils.config import cfg

SYSLOG_TYPE_TO_CLASS_MAPPING = {
    SyslogType.EVENTS_SYSLOG.value: EventsSyslogExporter,
    SyslogType.NETWORK_LOG_SYSLOG.value: NetworkLogSyslogExporter
}

SYSLOG_TYPE_TO_OPTS_MAPPING = {
    SyslogType.EVENTS_SYSLOG.value: (EVENTS_SYSLOG_CONF_GROUP, events_syslog_opts),
    SyslogType.NETWORK_LOG_SYSLOG.value: (NETWORK_LOG_SYSLOG_CONF_GROUP, network_log_syslog_opts)
}


class SyslogIntegrationManager(Exporter, AgentLogExporterMixin, IncidentExporterMixin, SystemAlertExporterMixin,
                               AuditLogEntryExporterMixin, LabelChangesLogExporterMixin, NetworkLogsExporterMixin,
                               InsightAlertExporterMixin):
    CONF_OPTS = [
        (BASE_SYSLOG_GROUP, base_syslog_opts),
        (EVENTS_SYSLOG_CONF_GROUP, events_syslog_opts),
        (NETWORK_LOG_SYSLOG_CONF_GROUP, network_log_syslog_opts)
    ]
    INTEGRATION_TYPE = IntegrationType.SYSLOG

    def __init__(self, conf, is_test_connection=False, is_running_from_aggregator=False):
        super(SyslogIntegrationManager, self).__init__(conf)

        self._is_test_connection = is_test_connection
        self._is_running_from_aggregator = is_running_from_aggregator
        self._syslog_exporters = {}
        if is_running_from_aggregator:
            self._init_syslog_exporters()

    def update_syslog_conf_list(self, conf):
        self._close_syslog_exporters()
        self.conf = conf
        self._init_syslog_exporters()

    def _close_syslog_exporters(self):
        for syslog in self._syslog_exporters.values():
            syslog.close_syslog_exporter()
        self._syslog_exporters = {}

    def _init_syslog_exporters(self):
        for syslog in self.conf:
            conf = self._build_oslo_conf_object(syslog)

            syslog_id = conf.base_syslog_exporter.id
            syslog_name = conf.base_syslog_exporter.name
            syslog_type = conf.base_syslog_exporter.syslog_type
            syslog_class = SYSLOG_TYPE_TO_CLASS_MAPPING[syslog_type]
            syslog_args = dict(conf=conf,
                               is_test_connection=self._is_test_connection,
                               syslog_id=syslog_id)

            # Merge the additional conf to the syslog_Args.
            # This will make the aggregator and mgmt logic run the same flow
            syslog_args.update(syslog.get("additional_conf", {}))
            if conf.base_syslog_exporter.export_through_aggregators == self._is_running_from_aggregator:
                self.logger.debug('Adding %s: %s, id: %s', syslog_type, syslog_name, syslog_id)
                self._syslog_exporters[syslog_id] = syslog_class(**syslog_args)
        self.logger.debug('Added {} syslog exporters successfully'.format(len(self._syslog_exporters)))

    @classmethod
    def _build_oslo_conf_object(cls, syslog_conf):
        syslog_type = syslog_conf.get('syslog_type')
        conf = cfg.ConfigOpts()

        conf_group, conf_opts = SYSLOG_TYPE_TO_OPTS_MAPPING.get(syslog_type)
        conf.register_opts(base_syslog_opts, group=BASE_SYSLOG_GROUP)
        conf.register_opts(conf_opts, group=conf_group)

        for option, value in syslog_conf.items():
            if option in getattr(conf, conf_group).keys():
                conf.set_override(name=option, override=value, group=conf_group)
            elif option in getattr(conf, BASE_SYSLOG_GROUP).keys():
                conf.set_override(name=option, override=value, group=BASE_SYSLOG_GROUP)
            else:
                # This means that the exporter got a config for a different exporter, and this can be ignored
                pass

        return conf

    @classmethod
    def is_exported_through_aggregators(cls, syslog_dict):
        """
        This method is used by the aggregator, and it gets a dict of {syslog_id: configurations} from the mgmt
        """
        for syslog in syslog_dict.values():
            if syslog.get('export_through_aggregators'):
                return True
        return False

    @classmethod
    def is_exported_from_management(cls, syslog_list):
        """
        This method is used by the mgmt's data-export manager, and it gets a list of [syslog_configuration_dict]
        """
        for syslog in syslog_list:
            if not syslog.get('export_through_aggregators'):
                return True
        return False

    @classmethod
    def get_syslog_logger_paths(cls, syslog_dict):
        """
        Used by the aggregator to verify that the paths exists and create them if needed
        """
        syslog_paths = set()
        for syslog in syslog_dict.values():
            if syslog.get('export_through_aggregators'):
                if syslog.get('syslog_logger_path'):
                    syslog_paths.add(syslog.get('syslog_logger_path'))
                else:
                    syslog_paths.add(DEFAULT_SYSLOGGER__AGGR_PATH)
        return syslog_paths

    @classmethod
    def test_connection(cls, test_conf, message):
        integration_manager = None
        try:
            integration_manager = cls([test_conf], is_test_connection=True,
                                      is_running_from_aggregator=test_conf.get('export_through_aggregators', False))
            integration_manager._init_syslog_exporters()
            if len(integration_manager._syslog_exporters) != 1:
                raise Exception("Exporter wasn't added to the Syslog Integration manager")
            integration_manager._syslog_exporters['syslog-test'].test_connection(message)
        finally:
            if integration_manager:
                integration_manager._close_syslog_exporters()

    # ******* Exporters properties: *******

    @property
    def agent_log_export_enabled(self):
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.EVENTS_SYSLOG.value and syslog.agent_log_export_enabled:
                return True
        return False

    @property
    def incident_export_enabled(self):
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.EVENTS_SYSLOG.value and syslog.incident_export_enabled:
                return True
        return False

    @property
    def system_report_export_enabled(self):
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.EVENTS_SYSLOG.value and syslog.system_report_export_enabled:
                return True
        return False

    @property
    def system_report_minimum_severity(self):
        minimum_severity = None
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.EVENTS_SYSLOG.value:
                current_severity = syslog.system_report_minimum_severity
                minimum_severity = current_severity if \
                    not minimum_severity or EventStatus[current_severity] < EventStatus[minimum_severity] \
                    else minimum_severity
        return minimum_severity

    @property
    def audit_log_export_enabled(self):
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.EVENTS_SYSLOG.value and syslog.audit_log_export_enabled:
                return True
        return False

    @property
    def label_changes_export_enabled(self):
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.EVENTS_SYSLOG.value and syslog.label_changes_export_enabled:
                return True
        return False

    @property
    def insight_alerts_export_enabled(self):
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.EVENTS_SYSLOG.value and syslog.insight_alerts_export_enabled:
                return True
        return False

    @property
    def network_log_export_enabled(self):
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.NETWORK_LOG_SYSLOG.value and syslog.network_log_export_enabled:
                return True
        return False

    # ******* Exporting methods: *******

    def export_agent_log(self, agent_log_record):
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.EVENTS_SYSLOG.value and syslog.agent_log_export_enabled:
                syslog.export_agent_log(agent_log_record)

    def export_agent_alerts_status_report(self, agent_alerts_status_report_record):
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.EVENTS_SYSLOG.value and syslog.agent_log_export_enabled:
                syslog.export_agent_alerts_status_report(agent_alerts_status_report_record)

    def export_incident(self, incident):
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.EVENTS_SYSLOG.value and syslog.incident_export_enabled:
                syslog.export_incident(incident)

    def export_generic_incident(self, message):
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.EVENTS_SYSLOG.value and syslog.incident_export_enabled:
                syslog.export_generic_incident(message)

    def export_system_alert(self, system_alert):
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.EVENTS_SYSLOG.value and syslog.system_report_export_enabled \
                    and self._passed_minimum_alert_severity(system_alert, syslog.system_report_minimum_severity):
                syslog.export_system_alert(system_alert)

    def export_audit_log_entry(self, entry):
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.EVENTS_SYSLOG.value and syslog.audit_log_export_enabled:
                syslog.export_audit_log_entry(entry)

    def export_label_change_log(self, label_change_log):
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.EVENTS_SYSLOG.value and syslog.label_changes_export_enabled:
                syslog.export_label_change_log(label_change_log)

    def export_insight_alert(self, alert):
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.EVENTS_SYSLOG.value and syslog.insight_alerts_export_enabled:
                syslog.export_insight_alert(alert)

    def export_network_log(self, network_log_record):
        # flag to decide if deepcopy of the record is needed to be sent to the nw logs exporters to improve performance
        is_exporters_have_label_filter = self._check_if_nw_logs_exporters_have_label_filter(self._syslog_exporters.values())
        for syslog in self._syslog_exporters.values():
            if syslog.type == SyslogType.NETWORK_LOG_SYSLOG.value and syslog.network_log_export_enabled:
                syslog.export_network_log(deepcopy(network_log_record) if is_exporters_have_label_filter else network_log_record)

    @staticmethod
    def _check_if_nw_logs_exporters_have_label_filter(exporters):
        for syslog_exporter in exporters:
            if syslog_exporter.type == SyslogType.NETWORK_LOG_SYSLOG.value:
                if syslog_exporter.is_filter_by_labels():
                    return True
        return False

    # ******* Utils methods: *******

    @classmethod
    def _passed_minimum_alert_severity(cls, alert, exporter_min_severity):
        return getattr(EventStatus, alert['status']).value >= getattr(EventStatus, exporter_min_severity).value
