from enum import IntEnum
from common.logger import get_logger
from common.py.model.exceptions import GuardicoreException

LOG = get_logger(module_name=__name__)


class ServiceState(IntEnum):
    Uninitialized = 1
    Initialized = 2
    Started = 3
    Stopped = 4


class InvalidServiceState(GuardicoreException):
    def __init__(self, service, desired_state):
        super(InvalidServiceState, self).__init__("Invalid %s service state, needed to be %r but current state is %r",
                                                  service.__class__.__name__, desired_state, service.get_state())


class Service(object):
    """Class Service()

    General purpose service class.
    """

    def __init__(self):
        self._state = ServiceState.Uninitialized

    def get_state(self):
        return self._state

    def set_state(self, state):
        self._state = state

    def is_initialized(self):
        return self._state in (ServiceState.Initialized, ServiceState.Started)

    def initialize(self):
        """initialize()

        Initialize the service. Raise an exception in case of error.
        """

        if ServiceState.Uninitialized == self._state:
            self._state = ServiceState.Initialized
            self._on_state_change_event()
        else:
            raise GuardicoreException("Invalid state change in service %s initialization"
                                      " (initialized called when state is %s)", self.__class__.__name__,
                                      self._state.name)

    def verify(self):
        """verify()

        Verify environment for the service and raise an exception in case
        of verification error.
        """

        raise NotImplementedError()

    def start(self):
        """start()

        Start running the service.
        """

        if ServiceState.Initialized == self._state:
            self._state = ServiceState.Started
            self._on_state_change_event()
        else:
            raise GuardicoreException("Invalid state change in service %s starting (%s)", self.__class__.__name__,
                                      self._state.name)

    def cleanup(self):
        """cleanup()

        Service cleanup routine."""
        LOG.debug("Service changed state to stopped: %r", self)
        self._state = ServiceState.Stopped
        self._on_state_change_event()

    def _on_state_change_event(self):
        pass

    def _validate_state(self, state, raise_exception=True):
        """_validate_state(state, raise_exception=True)

        Ensure that the service is in the desired state we want. If not, either
        raise exception or return False (True if OK).
        """

        assert isinstance(state, ServiceState), \
            "Invalid type for service state in validation: %r" % (state,)

        # ensure that we're in the state we want
        if state != self._state:
            if raise_exception:
                raise InvalidServiceState(self, state)
            return False

        return True


def advance_service_state(service, end_state=ServiceState.Started, verify=True):
    assert isinstance(service, Service)

    current_service_state = service.get_state()
    if current_service_state.value > end_state.value:
        raise ValueError("Can't advance service '%s' state to less advanced state" % (service,))

    while current_service_state.value < end_state.value:
        if current_service_state == ServiceState.Uninitialized:
            service.initialize()
            if verify:
                service.verify()
        elif current_service_state == ServiceState.Initialized:
            service.start()
        elif current_service_state == ServiceState.Started:
            service.cleanup()

        if current_service_state == service.get_state():
            raise GuardicoreException("Service %s didn't advanced state from %s", service, service.get_state())
        current_service_state = service.get_state()

    return current_service_state
