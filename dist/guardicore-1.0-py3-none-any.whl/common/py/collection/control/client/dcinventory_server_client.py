from aggregator.services.enforcement.plugins.policy.model import LatestPolicyInventoryItemsIDs
from common.py.collection.control.client.component_client import AggregatorComponentControlClient
from common.py.model.aggregator import AggregatorComponent
from common.logger import get_logger


LOG = get_logger(module_name=__name__)


class DCInventoryServerControlClient(AggregatorComponentControlClient):
    def __init__(self, component_name=AggregatorComponent.DCInventory, **kwargs):
        super(DCInventoryServerControlClient, self).__init__(component_name=component_name, **kwargs)

    def get_mini_inventory(self, enforcing_entity, entity_api_version, required_ids):
        """
        Create centra inventory for an integration enforcing entity, based on schema defined in contracts github repo
        @param enforcing_entity: str
        @param entity_api_version: str
        @param required_ids: LatestPolicyInventoryItemsIDs
        """
        payload = {'ee': enforcing_entity, 'version': entity_api_version, 'ids': required_ids.as_dict()}
        return self.call_with_reconnect(uri='/inventory/integration/mini_inventory', method='POST', json=payload)

