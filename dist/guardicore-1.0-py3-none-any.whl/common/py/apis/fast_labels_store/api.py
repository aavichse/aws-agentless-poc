from collections import defaultdict
import re

from common.logger import get_logger
from common.py.apis.etcd.api import EtcdAPI, EtcdPutRequest, EtcdWatchPut, EtcdWatchDelete

LOG = get_logger(module_name=__name__)

class FastLabelsNetworkUpdate:
    def __init__(self):
        self.asset_ips = {}             # asset_id -> string representing the list of IPs (comma-separated)

    def set_asset_ips(self, asset_id, ips):
        self.asset_ips[asset_id] = ips

    @property
    def assets(self):
        return self.asset_ips.keys()

class FastLabelsIPList:
    def __init__(self):
        self.ipv4_ips = set()
        self.ipv6_ips = set()

    def __repr__(self):
        # for showing correctly in debug logs
        return str(self.__dict__)

class FastLabelsFlatLabel(FastLabelsIPList):
    def __init__(self, revision, key, value):
        super().__init__()
        self.revision = revision
        self.key = key
        self.value = value

class FastLabelsLabel:
    def __init__(self, assets, revision, key, value):
        # revision: int (this label's revision)
        # assets: dict {asset_id: FastLabelsIPList}
        # key: string
        # value: string
        self.assets = assets
        self.revision = revision
        self.key = key
        self.value = value

    def flatten(self):
        # Build a FastLabelsFlatLabel including the label revision + the IPs of all the assets
        flat_label = FastLabelsFlatLabel(revision=self.revision, key=self.key, value=self.value)

        for asset in self.assets:
            flat_label.ipv4_ips.update(asset.ip_list.ipv4_ips)
            flat_label.ipv6_ips.update(asset.ip_list.ipv6_ips)

        return flat_label

class FastLabelsAsset:
    def __init__(self, revision, ip_list):
        # revision: int (this asset's revision)
        # ip_list: FastLabelsIPList
        self.revision = revision
        self.ip_list = ip_list

class FastLabelsSnapshot:
    def __init__(self, revision, assets):
        # revision: int (entire snapshot revision)
        # assets: dict {label_id: FastLabelsAsset}
        self.revision = revision
        self.assets = assets

class FastLabelsAssetUpdatedEvent:
    def __init__(self, asset_id, ip_list, revision):
        self.asset_id = asset_id
        self.ip_list = ip_list
        self.revision = revision

class FastLabelsAssetDeletedEvent:
    def __init__(self, asset_id, revision):
        self.asset_id = asset_id
        self.revision = revision

class FastLabelsWatchEvents(list):
    # List of events (FastLabelsAssetUpdatedEvent + FastLabelsAssetDeletedEvent) + latest_revision
    def __init__(self, latest_revision):
        self.latest_revision = latest_revision

class FastLabelsStore:
    _KEY_CONFIG_LABEL_IDS = '/fast-labels/config/label-ids'
    _PREFIX_ASSET = '/fast-labels/assets/'
    _KEY_ASSET = '/fast-labels/assets/{asset_id}'
    _RE_ASSET = re.compile('^/fast-labels/assets/([^/]+)$')

    def __init__(self, etcd_url, etcd_username, etcd_password):
        self._etcd = EtcdAPI(url=etcd_url, username=etcd_username, password=etcd_password)

        self._asset_id_to_lease = {}  # asset id --> etcd lease for this asset id
        self.aggregator_lease = None
        self.temp_lease = None


    def get_fast_label_ids(self):
        label_ids = self._etcd.get_value(self._KEY_CONFIG_LABEL_IDS)
        if label_ids is None:
            return set()

        return set(label_ids.split(','))

    def set_fast_label_ids(self, label_ids):
        self._etcd.put_one(self._KEY_CONFIG_LABEL_IDS, ','.join(sorted(label_ids)))

    def create_temp_lease(self, ttl):
        temp_lease =  self._etcd.create_lease(lease_ttl=ttl)
        if temp_lease:
            self.temp_lease = temp_lease
            LOG.debug("Temporary lease %s created.", self.temp_lease)
        else:
            LOG.error("Failed to create temporary lease!")

    def create_aggregator_lease(self, ttl):
        # We now assume the global key doesn't exist in etcd (or we would have returned) and we start creating it.
        # First, create new lease.
        self.aggregator_lease = self._etcd.create_lease(lease_ttl=ttl)
        if self.aggregator_lease:
            LOG.info("Global lease %s created.", self.aggregator_lease)
        else:
            LOG.error("Failed to create global lease!")

    def keepalive_aggregator_lease(self):
        if not self.aggregator_lease:
            return
        LOG.debug("Keeping alive all assets with lease %s", self.aggregator_lease)
        if not self._etcd.keepalive_lease(self.aggregator_lease):
            LOG.warn("Failed to keep-alive global lease: %s", self.aggregator_lease)

    def put_network_update(self, network_update):
        put_requests = []
        for asset_id in network_update.assets:
            if asset_id in network_update.asset_ips:
                # Note: Add lease to value to force etcd write if it was changed (e.g. due to migration between aggregators).
                value = ' '.join([str(self.aggregator_lease), network_update.asset_ips[asset_id]])
                put_requests.append(EtcdPutRequest(key=self._KEY_ASSET.format(asset_id=asset_id),
                                                   value=value,
                                                   lease=self.aggregator_lease))
            else:
                LOG.error("Missing IPs when putting asset %s", asset_id)

        LOG.debug('Putting network update with %d assets', len(put_requests))
        self._etcd.put_many(put_requests)

    def remove_asset(self, asset_id):
        if not self.temp_lease:
            LOG.warn('Cannot remove asset_id %s no temp lease', asset_id)
            return

        LOG.info('Moving asset %s from aggregator lease %s to temp lease %s', asset_id, self.aggregator_lease, self.temp_lease)
        key=self._KEY_ASSET.format(asset_id=asset_id)
        old_value = self._etcd.get_value(key)
        if not old_value:
            LOG.warn("Asset %s not exist, will not set temp lease for it", asset_id)
            return
        words = old_value.split(' ')
        if len(words) < 2:
            LOG.warn("Asset %s has bad value format %s", asset_id, old_value)
            return
        new_val= ' '.join([str(self.temp_lease), words[1]])
        changed = self._etcd.compare_and_set_lease(key=self._KEY_ASSET.format(asset_id=asset_id),
                                                   old_lease=self.aggregator_lease,
                                                   new_lease=self.temp_lease,
                                                   value=new_val)
        LOG.info('Moving asset %s to temp lease %s result %s', asset_id, self.temp_lease, changed)

    @classmethod
    def _parse_asset_key(cls, key, value=None):
        match = cls._RE_ASSET.match(key)
        if not match:
            LOG.warning("Bad key format: %s", key)
            return None, None, None

        # The format in etcd is /fast-labels/assets/<asset_id> = lease ip1,ip2,ip3, ... e.g. (aggregator lease of 7587875744037774618):
        # 7587875744037774618 100.100.100.160,172.17.0.89,200.200.200.159,2001:1860:1860:0:2c30:1313:217d:c15a,2001:2860:2860:0:cc52:90a7:c41f:26bd
        # The below will set words[0] = 7587875744037774618 words[1]=100.100.100.160,172.17.0.89,200.200.200.159,...

        asset_id = match.group(1)

        ip_list = FastLabelsIPList()
        if value is not None:
            # words = [lease, ips]
            words = value.split(' ')
            if len(words) < 2:
                LOG.warning('Bad format in asset "%s": %s', asset_id, value)
            else:
                ips = words[1]
                for ip in ips.split(','):
                    # IPv4 addresses never have ':' and always have '.'
                    # IPv6 addresses always have ':' and sometimes have '.'
                    # So we need to check IPv6 first, else we might be adding IPv6 addresses to the IPv4 list
                    if ':' in ip:
                        ip_list.ipv6_ips.add(ip)
                    elif '.' in ip:
                        ip_list.ipv4_ips.add(ip)
                    else:
                        LOG.warning('Bad IP format asset "%s": %s', asset_id, ip)

        return asset_id, ip_list

    def get_fast_labels_snapshot(self):
        """
        Get all label contents.
        Returns a FastLabelsSnapshot.
        """

        kvrs, snapshot_revision = self._etcd.get_values(prefix=self._PREFIX_ASSET)
        snapshot = FastLabelsSnapshot(revision=snapshot_revision, assets={})

        for key, value, revision in kvrs:
            asset_id, ip_list = self._parse_asset_key(key, value)
            if asset_id is None:
                continue

            if asset_id in snapshot.assets:
                asset = snapshot.assets[asset_id]
                # Not really using asset's revision, only in here for debuggability.
                asset.revision = max(asset.revision, revision)
                snapshot.assets[asset_id] = FastLabelsAsset(revision=asset.revision, ip_list=ip_list)
            else:
                snapshot.assets[asset_id] = FastLabelsAsset(revision=revision, ip_list=ip_list)

        return snapshot

    def watch_labels(self, start_revision):
        """
        Watch for label changes.
        Generator that yields FastLabelsWatchEvents objects.
        Raises a TimeoutError when there are no events for a while.
        """

        for watch_response in self._etcd.watch(prefix=self._PREFIX_ASSET,
                                               start_revision=start_revision):
            events = FastLabelsWatchEvents(latest_revision=watch_response.latest_revision)

            for event in watch_response:
                if isinstance(event, EtcdWatchPut):
                    asset_id, ip_list = self._parse_asset_key(event.key, event.value)
                    if asset_id is not None:
                        events.append(FastLabelsAssetUpdatedEvent(asset_id=asset_id, ip_list=ip_list,
                                                                  revision=event.revision))

                elif isinstance(event, EtcdWatchDelete):
                    asset_id, ip_list = self._parse_asset_key(event.key)
                    if asset_id is not None:
                        events.append(FastLabelsAssetDeletedEvent(asset_id=asset_id,
                                                                  revision=event.revision))

            yield events

    def defrag(self):
        self._etcd.defrag()
