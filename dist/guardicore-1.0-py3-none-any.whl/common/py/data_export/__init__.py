from enum import IntEnum


class IntegrationType(IntEnum):
    SYSLOG = 1