import argparse
import os
import logging

from common.py.utils.setup_wizard.certificator import certificator, TLS_FOLDER_PATH


def parse_certificator_marker(path):
    key = None
    conf = dict()
    with open(path) as f:
        for line in f.readlines():
            line = line.strip()
            # sanity on 'None' as str
            if line.startswith("#") or line == 'None':
                pass
            elif '[' in line and ']' in line:
                key = line.replace("[", "").replace("]", "").strip()
                conf[key] = []
            elif line:
                assert key is not None
                conf[key].append(line)

    return conf


def parse_args():
    parser = argparse.ArgumentParser(description='Certificator')
    parser.add_argument("-c", "--config", type=str,
                        help="Certificator marker")
    parser.add_argument("-d", "--dst-dir", type=str,
                        help="Destination directory for certs")
    args = parser.parse_args()
    return args


def format_sni(base, suffix):
    if suffix:
        return "%s-%s" % (base, suffix)
    else:
        return base


def main():
    args = parse_args()
    conf = parse_certificator_marker(args.config)

    for ca in conf.get("ca_files"):
        ca, suffix = ca.split(":")
        # should be equivalent to:
        # certificator -s {{ certificate_snis | join(' ') }} -g {{ guest_ips | join (' ') }} -d {{ aggr_tls_path }} -m {{ cert_peer_sign_methods | join (' ') }} --certificate-valid-before {{ certificates_valid_before }}"
        certificate_snis = conf.get('certificate_snis', [])
        certificate_sans = conf.get('certificate_sans', [])

        # we add here the the ca suffix to sni (so different ca would have different SNI)
        all_alternative_names = certificate_sans + [format_sni(sni, suffix) for sni in certificate_snis]

        guest_ips = conf.get('guest_ips', [])
        certificates_valid_before = int(conf.get('certificates_valid_before', [14])[0])
        cert_peer_sign_methods = conf.get('cert_peer_sign_methods', [])
        intermediate_ca_cert_path = os.path.join(TLS_FOLDER_PATH, ca, "cert.pem")
        intermediate_ca_key_path = os.path.join(TLS_FOLDER_PATH, ca, "key.pem")
        logging.info("Run certificator create certs for CA: %s (alt names: %s)", ca, all_alternative_names)
        certificator(dst_dir=args.dst_dir,
                     guests_ips=guest_ips,
                     alternative_dns_names=all_alternative_names,
                     not_before_nof_days=certificates_valid_before,
                     guardicore_ca_file=None,  # no need for ca if we don't plan to create intermediate ca
                     aggregator_intermediate_cert_file=intermediate_ca_cert_path,
                     aggregator_intermediate_key_file=intermediate_ca_key_path,
                     aggregator_cas_chain_file=None,  # no need for ca if we don't plan to create intermediate ca
                     cert_sign_methods=cert_peer_sign_methods,
                     cert_name_suffix=suffix,
                     create_intermediate=False)


if __name__ == "__main__":
    main()
