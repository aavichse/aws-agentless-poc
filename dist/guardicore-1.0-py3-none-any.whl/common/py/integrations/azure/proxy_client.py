from azure.eventhub._pyamqp._decode import _DECODE_BY_CONSTRUCTOR
from aggregator.model.integrations import DEFAULT_VERSION
from common.logger import get_logger
from common.py.integrations.base import BaseProxyClient
from common.py.integrations.model import MsgType
from common.py.events.mitigation.machine_details import AgentType

LOG = get_logger(module_name=__name__)


class AzureProxyClient(BaseProxyClient):
    AGENT_TYPE = AgentType.CloudApplication
    TOPIC_NAME_TO_MSG_TYPE = {
        "gcapp-flowlogs-ehub": MsgType.FLOWS
    }
    TOPIC_NAME_TO_MODEL = {
        "gcapp-flowlogs-ehub": "provider.reveal.ConnectionInfo"
    }

    @staticmethod
    def get_api_version(msg):
        headers = AzureProxyClient._decode_eventhub_headers(msg)
        if headers and "contract-version" in headers:
            api_version = headers["contract-version"]
            return api_version if api_version.startswith("v") else "v{ver}".format(ver=api_version)
        return DEFAULT_VERSION

    @staticmethod
    def _decode_eventhub_headers(msg):
        """Azure Eventhub encodes headers in custom encoding, use the same library to decode.
        The first byte in the value field is a type identifier code that's used to locate the decoder function.
        """
        decoded_headers = {}
        if msg.headers():
            try:
                for k, v in dict(msg.headers()).items():
                    mv_value = memoryview(v)
                    decoder_func = _DECODE_BY_CONSTRUCTOR[mv_value[0]]
                    _, decoded_value = decoder_func(mv_value[1:])
                    decoded_headers[k] = decoded_value.decode() if isinstance(decoded_value, bytes) else decoded_value
            except Exception:
                LOG.exception("Failed to decode eventhub headers. Raw headers: %s", msg.headers())
                return {}
        return decoded_headers

    @classmethod
    def from_config(cls, connection_info, service_config):
        kafka_config = {
            'bootstrap.servers': connection_info['manifest']['eventhub_hostname']['value'] + ":9093",
            'security.protocol': 'PLAINTEXT',
            #'sasl.mechanism': 'PLAIN',
            #'sasl.username': '$ConnectionString',
            #'sasl.password': connection_info['manifest']['eventhub_connection_string']['value'],
            'group.id': service_config['consumer_group'],
            'enable.auto.commit': True,
        }
        return cls(kafka_config=kafka_config,
                   request_timeout=service_config['kafka_request_timeout'])
