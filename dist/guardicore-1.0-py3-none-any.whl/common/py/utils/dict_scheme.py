import re
from collections import Mapping
import base64
import netaddr
import six
from netaddr import AddrFormatError
from six import add_metaclass, integer_types
from common.py.utils.str import to_bytes
from common.py.utils.config.six import string_types, text_type
from abc import ABCMeta, abstractmethod

from common.logger import get_logger

LOG = get_logger(module_name=__name__)


class _MissingField(object):
    pass


MissingField = _MissingField()


class _InvalidScheme(object):
    pass

InvalidScheme = _InvalidScheme()


class SchemeValidationError(Exception):
    def __init__(self, obj, field_name, err_msg):
        super(SchemeValidationError, self).\
            __init__("Object %r failed scheme validation with field '%s': %s" % (obj, field_name, err_msg))


@add_metaclass(ABCMeta)
class Constraint(object):

    @abstractmethod
    def enforce(self, value):
        raise NotImplementedError()


class TypeConstraint(Constraint):
    def __init__(self, *type_obj):
        self.type_obj = type_obj

    def __repr__(self):
        return "<TypeConstraint {}>".format(", ".join(t.__name__ for t in self.type_obj))

    def enforce(self, value):
        return value if isinstance(value, self.type_obj) else InvalidScheme


class _TypeIPAddress(TypeConstraint):
    MIN_IP_STR_LEN = 7  # 0.0.0.0
    MAX_IP_STR_LEN = 40  # max IPv6 length

    def __init__(self):
        super(_TypeIPAddress, self).__init__(str, text_type, netaddr.IPAddress)

    def enforce(self, value):
        if InvalidScheme == super(_TypeIPAddress, self).enforce(value):
            return InvalidScheme

        # minor optimization to avoid netaddr parsing
        elif not isinstance(value, netaddr.IPAddress) and \
                not (_TypeIPAddress.MIN_IP_STR_LEN <= len(value) <= _TypeIPAddress.MAX_IP_STR_LEN):
            return InvalidScheme

        try:
            return netaddr.IPAddress(value, flags=netaddr.INET_PTON)
        except (ValueError, AddrFormatError):
            return InvalidScheme


TypeIPAddress = _TypeIPAddress()


class _TypePort(TypeConstraint):
    def __init__(self):
        super(_TypePort, self).__init__(integer_types)

    def enforce(self, value):
        if InvalidScheme == super(_TypePort, self).enforce(value):
            return InvalidScheme

        return value if (0 <= value <= 0xFFFF) else InvalidScheme


TypePort = _TypePort()


class _TypeVlan(TypeConstraint):
    def __init__(self):
        super(_TypeVlan, self).__init__(integer_types)

    def enforce(self, value):
        return value if (0 <= value <= 4092) else InvalidScheme


TypeVlan = _TypeVlan()


class _TypeBase64(TypeConstraint):
    def __init__(self):
        super(_TypeBase64, self).__init__(str, text_type)

    def enforce(self, value):
        if InvalidScheme == super(_TypeBase64, self).enforce(value):
            return InvalidScheme

        try:
            decoded_value = base64.b64decode(to_bytes(value))
            return decoded_value
        except Exception:
            return InvalidScheme


TypeBase64 = _TypeBase64()


class Or(Constraint):
    def __init__(self, *constraints):
        self._constraints = constraints

    def enforce(self, value):
        for constraint in self._constraints:
            result = constraint.enforce(value)
            if result != InvalidScheme:
                return result
        return InvalidScheme


class GreaterConstraint(Constraint):
    def __init__(self, limit):
        self.limit = limit

    def enforce(self, value):
        return value if (not value or value > self.limit) else InvalidScheme


class GreaterEqualConstraint(Constraint):
    def __init__(self, limit):
        self.limit = limit

    def enforce(self, value):

        return value if (not value or value >= self.limit) else InvalidScheme


class LowerConstraint(Constraint):
    def __init__(self, limit):
        self.limit = limit

    def enforce(self, value):
        return value if (not value or value < self.limit) else InvalidScheme


class LowerEqualConstraint(Constraint):
    def __init__(self, limit):
        self.limit = limit

    def enforce(self, value):
        return value if (not value or value <= self.limit) else InvalidScheme


class EnumConstraint(Constraint):
    def __init__(self, *enum_values):
        self.enum_values = set(enum_values)

    def enforce(self, value):
        return value if (value in self.enum_values) else InvalidScheme


class TypeSequence(TypeConstraint):
    def __init__(self, *schemes):
        for scheme in schemes:
            assert isinstance(scheme, DictScheme) or type(scheme) == type(str) or isinstance(scheme, TypeConstraint)

        super(TypeSequence, self).__init__(list, tuple, set)
        self._schemes = schemes

    def enforce(self, value):
        value = super(TypeSequence, self).enforce(value)
        if InvalidScheme == value:
            return InvalidScheme

        for item in value:
            item_validated = False
            for scheme in self._schemes:
                if ((type(scheme) == type(str)) and isinstance(item, scheme)) or \
                        (isinstance(scheme, DictScheme) and (scheme(item) is not None)) or \
                        (isinstance(scheme, TypeConstraint) and not isinstance(scheme, DictScheme)
                         and scheme.enforce(item) != InvalidScheme):
                    item_validated = True
                    break

            if not item_validated:
                return InvalidScheme

        return value


class TypeSubScheme(TypeConstraint):
    def __init__(self, dict_scheme):
        assert isinstance(dict_scheme, DictScheme)

        super(TypeSubScheme, self).__init__(dict)
        self._dict_scheme = dict_scheme

    def enforce(self, value):
        value = super(TypeSubScheme, self).enforce(value)
        if InvalidScheme == value:
            return InvalidScheme

        if InvalidScheme == self._dict_scheme(value):
            return InvalidScheme

        return value


class TypeDictEntry(TypeConstraint):
    MAP_KEY_NAME = 'key'
    MAP_VALUE_NAME = 'value'

    def __init__(self):
        super(TypeDictEntry, self).__init__(dict)

    def enforce(self, value):
        value = super(TypeDictEntry, self).enforce(value)
        if InvalidScheme == value:
            return InvalidScheme

        entry_key = value.get(self.MAP_KEY_NAME)
        entry_value = value.get(self.MAP_VALUE_NAME)
        if entry_key is None or entry_value is None or len(value) != 2:
            return InvalidScheme

        return value


class _TypeFloat(TypeConstraint):
    def __init__(self):
        super(_TypeFloat, self).__init__(float, int)

    def enforce(self, value):
        if InvalidScheme != super(_TypeFloat, self).enforce(value):
            try:
                return float(value)
            except ValueError:
                return InvalidScheme


TypeFloat = _TypeFloat()

Positive = GreaterEqualConstraint(0)
Negative = LowerConstraint(0)
TypeNone = TypeConstraint(type(None))
TypeInt = TypeConstraint(*six.integer_types)
TypeBool = TypeConstraint(bool)
TypeIntOrNone = Or(TypeInt, TypeNone)
TypePositiveOrNone = Or(Positive, TypeNone)
TypeFloatOrNone = Or(TypeFloat, TypeNone)
TypeString = TypeConstraint(*six.string_types)
TypeBytes = TypeConstraint(bytes)
TypeStringOrNone = Or(TypeString, TypeNone)
TypeSequenceOrNone = lambda *sequence_schema: Or(TypeSequence(*sequence_schema), TypeNone)


class TypeStringNotEmpty(TypeConstraint):
    def __init__(self):
        super(TypeStringNotEmpty, self).__init__(str, text_type)

    def enforce(self, value):
        if not value:
            return InvalidScheme

        return TypeString.enforce(value)


class TypeStringLength(TypeConstraint):
    def __init__(self, limit, not_empty=False):
        super(TypeStringLength, self).__init__(str, text_type)
        self._limit = limit
        self._not_empty = not_empty

    def enforce(self, value):
        result = TypeString.enforce(value)

        if result == InvalidScheme or len(value) > self._limit or (self._not_empty and not value):
            return InvalidScheme

        return result


class TypeMacAddress(TypeConstraint):
    MAC_ADDRESS_MATCH = re.compile("[0-9a-fA-F]{2}([-:]?)[0-9a-fA-F]{2}(\\1[0-9a-fA-F]{2}){4}$")
    MAC_ADDRESS_LENGTH_LIMIT = 18

    def __init__(self,):
        super(TypeMacAddress, self).__init__(str, text_type)

    def enforce(self, value):
        # validating the mac address is a string
        result = TypeStringLength(limit=TypeMacAddress.MAC_ADDRESS_LENGTH_LIMIT, not_empty=True).enforce(value)

        if not TypeMacAddress.MAC_ADDRESS_MATCH.match(value):
            return InvalidScheme

        return result


class DictField(object):
    def __init__(self, name, optional=False, constraints=None):
        if constraints is None:
            constraints = []

        self.name = name
        self.optional = optional
        self.constraints = constraints

    def __repr__(self):
        return "<Field %s (%s)>" % (self.name, "optional" if self.optional else "mandatory")

    def validate(self, obj):
        value = obj.get(self.name, MissingField)
        if value == MissingField:
            if self.optional:
                return
            return MissingField

        for constraint in self.constraints:
            value = constraint.enforce(value)
            if InvalidScheme == value:
                return InvalidScheme

        obj[self.name] = value
        return obj


class OptionalDictField(DictField):
    def __init__(self, name, *constraints):
        super(OptionalDictField, self).__init__(name, optional=True, constraints=constraints)


class MandatoryDictField(DictField):
    def __init__(self, name, *constraints):
        super(MandatoryDictField, self).__init__(name, optional=False, constraints=constraints)


class DictScheme(object):
    def __init__(self, *fields):
        self.verbose = True
        self.fields = []
        for field in fields:
            if isinstance(field, DictField):
                self.fields.append(field)
            elif isinstance(field, DictScheme):
                self.fields += field.fields
            else:
                raise TypeError("Invalid field name: %r" % (field, ))

    def set_verbose(self, verbose):
        self.verbose = verbose

    def _validate_obj(self, obj):
        if not isinstance(obj, (dict, Mapping)):
            if self.verbose:
                LOG.debug("Invalid object in validation, type %s no dict: %r", type(obj), obj)

            return InvalidScheme

        for field in self.fields:
            field_validation = field.validate(obj)
            if InvalidScheme == field_validation:
                if self.verbose:
                    LOG.debug("Invalid object field '%s' in validation: %r", field.name, obj)
                return InvalidScheme
            elif MissingField == field_validation:
                if self.verbose:
                    LOG.debug("Missing object field '%s' in validation: %r", field.name, obj)
                return InvalidScheme

        return obj

    def __call__(self, *objs):
        if 1 == len(objs):
            obj = self._validate_obj(objs[0])
            if InvalidScheme == obj:
                return None

            return obj

        # validate objects
        validated_objs = [self._validate_obj(obj) for obj in objs]

        # filter out validation failed objects
        return [obj
                for obj in validated_objs
                if obj != InvalidScheme]


TypeDictEntryList = TypeSequence(TypeDictEntry())
TypeDictEntryListOrNone = Or(TypeDictEntryList, TypeNone)
