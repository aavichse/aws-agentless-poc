import logging
import sys
from datetime import datetime

import six

from common.logger import is_debug
from common.py.data_export.exporter import AgentLogExporterMixin, IncidentExporterMixin, SystemAlertExporterMixin, \
    AuditLogEntryExporterMixin, LabelChangesLogExporterMixin, InsightAlertExporterMixin
from common.py.data_export.exporters.syslog_utils import BaseSyslogExporter, SyslogFormat, DEFAULT_DELIMITER, \
    SyslogFormatDisplayName
from common.py.events.mitigation.network import ManagementMatchingVerdict
from common.get_version import MAJOR_VERSION
from common.logger import get_logger, get_new_logger
from common.py.models.events import EventSeverity
from common.py.utils.config import cfg
from common.py.utils.config.oslo_config.types import List
from common.py.utils.config.types import String
from common.py.utils.datetime_utils import timestamp_to_date
from common.py.data_export.exporters.syslog_datetime import TimeField

# SYSLOG EXPORTER OPTIONS
EVENTS_SYSLOG_CONF_GROUP = 'events_syslog_exporter'

events_syslog_opts = [
    cfg.BoolOpt('export_incidents_to_syslog',
                default=False,
                required=True,
                help='send incidents to a syslog server'),
    cfg.BoolOpt('export_insight_alerts_to_syslog',
                default=False,
                required=True,
                help='send Insight alerts to a syslog server'),
    cfg.BoolOpt('export_agents_log_to_syslog',
                default=True,
                required=True,
                help='send agents log to a syslog server'),
    cfg.BoolOpt('export_alerts_to_syslog',
                default=False,
                required=True,
                help='export system alerts to syslog'),
    cfg.StrOpt('alert_minimum_severity',
               default='WARNING',
               choices=['COMPLETED', 'INFO', 'WARNING', 'ERROR'],
               required=False),
    cfg.BoolOpt('export_audit_log_to_syslog',
                default=False,
                required=True),
    cfg.BoolOpt('export_full_change_segmentation_rules',
                default=False,
                required=True),
    cfg.BoolOpt('export_label_changes_to_syslog',
                default=False,
                required=True),
    cfg.BoolOpt('syslog_logger_to_file',
                default=False,
                required=True),
    cfg.ExtendedOpt('syslog_logger_path',
                    default='',
                    type=String(unicode=six.PY3, quotes=six.PY2)),
    cfg.BoolOpt('report_agent_events_individually',
                default=False,
                required=True),
    cfg.BoolOpt('report_agent_labels_to_syslog',
                default=False,
                help='Report agent labels to syslog'),
    cfg.ExtendedOpt('agent_labels_syslog_report_list',
                    default=[],
                    type=List(item_type=String(quotes=True), bounds=True),
                    required=True,
                    help='Filter labels reported to syslog by key: value'),
]


LOGGER = get_logger()

DEFAULT_SYSLOGGER__MGMT_PATH = '/tmp/storage/exporters' if sys.platform.startswith('darwin') else '/storage/exporters'
DEFAULT_SYSLOGGER__AGGR_PATH = '/var/log/guardicore/cluster_service/syslog_exporter'


class EventsSyslogExporter(BaseSyslogExporter, AgentLogExporterMixin, IncidentExporterMixin, SystemAlertExporterMixin,
                           AuditLogEntryExporterMixin, LabelChangesLogExporterMixin, InsightAlertExporterMixin):
    """
    Exports incidents to a Syslog server.
    """
    def __init__(self, conf, syslog_id, is_test_connection=False, **kwargs):
        super(EventsSyslogExporter, self).__init__(conf, is_test_connection=is_test_connection, syslog_id=syslog_id)
        self.syslog_logger = logging.getLogger('guardicore_exports.syslog:{}'.format(syslog_id))
        self.syslog_logger.propagate = False
        self.display_rule_id = kwargs.get('display_rule_id', True)
        self.use_generic_incidents_only = kwargs.get('use_generic_incidents_only', True)
        self.replace_incidents_with_security_event = kwargs.get('replace_incidents_with_security_event', False)
        # Log messages to file:
        self.logger_to_file = None
        self.logger_to_file_handler = None
        if not is_test_connection:
            path = self.get_syslog_logger_path(self.conf)
            try:
                self.logger_to_file, self.logger_to_file_handler = \
                    get_new_logger('syslog.{}'.format(syslog_id),
                                   'syslog_exporter.{}'.format(syslog_id),
                                   logger_dir=path, syslog_to_file=True)
            except Exception as ex:
                self.logger.warning('Error while initializing log file on path: %r. error: %r', path, ex)

    @classmethod
    def is_exported_through_aggregators(cls, conf):
        return conf.base_syslog_exporter.export_through_aggregators

    @classmethod
    def get_syslog_logger_path(cls, conf):
        path = conf.events_syslog_exporter.syslog_logger_path
        if not path:
            path = DEFAULT_SYSLOGGER__AGGR_PATH if cls.is_exported_through_aggregators(conf) \
                else DEFAULT_SYSLOGGER__MGMT_PATH
        return path

    def close_syslog_exporter(self):
        super(EventsSyslogExporter, self).close_syslog_exporter()
        if self.logger_to_file_handler is not None:
            self.logger_to_file.removeHandler(self.logger_to_file_handler)
            self.logger_to_file_handler.close()

    # ******* Exporters properties: *******

    @property
    def agent_log_export_enabled(self):
        return self.conf.events_syslog_exporter.export_agents_log_to_syslog

    @property
    def incident_export_enabled(self):
        return self.conf.events_syslog_exporter.export_incidents_to_syslog

    @property
    def system_report_export_enabled(self):
        return self.conf.events_syslog_exporter.export_alerts_to_syslog

    @property
    def system_report_minimum_severity(self):
        return self.conf.events_syslog_exporter.alert_minimum_severity

    @property
    def audit_log_export_enabled(self):
        return self.conf.events_syslog_exporter.export_audit_log_to_syslog

    @property
    def label_changes_export_enabled(self):
        return self.conf.events_syslog_exporter.export_label_changes_to_syslog

    @property
    def insight_alerts_export_enabled(self):
        return self.conf.events_syslog_exporter.export_insight_alerts_to_syslog

    # ******* Exporting methods: *******

    def _export_message(self, message):
        self.logger.debug("Exporting to syslog the formatted message: {}".format(message))
        super(EventsSyslogExporter, self)._export_message(message)
        if self.logger_to_file and self.conf.events_syslog_exporter.syslog_logger_to_file:
            self.logger_to_file.critical(message)

    def export_agent_log(self, agent_log_record):
        if not self._is_syslog_defined():
            return

        if is_debug():
            self.logger.debug("Exporting agent log %s to Syslog %s, server %s:%d",
                              agent_log_record['id'],
                              self.id,
                              self.conf.base_syslog_exporter.syslog_host,
                              self.conf.base_syslog_exporter.syslog_port)

        if self.conf.events_syslog_exporter.report_agent_events_individually:
            self.logger.info("Reporting %r individual agent events for agent log id %r", agent_log_record['count'],
                             agent_log_record['id'])
            agent_log_records = self._split_agent_log_record(agent_log_record)
            for record in agent_log_records:
                self._report_agent_log_record(record)

        else:
            self._report_agent_log_record(agent_log_record)

    def export_agent_alerts_status_report(self, agent_alerts_status_report_record):
        if not self._is_syslog_defined():
            return

        self.logger.info("Exporting agent alerts status report to Syslog %s, server %s:%d",
                         self.id,
                         self.conf.base_syslog_exporter.syslog_host,
                         self.conf.base_syslog_exporter.syslog_port)

        self._report_agent_alerts_status_report_record(agent_alerts_status_report_record)

    def _report_agent_log_record(self, agent_log_record):
        message = self._prepare_syslog_agent_log_message(agent_log_record)
        self._export_message(message)

    def _report_agent_alerts_status_report_record(self, agent_alerts_status_report):
        message = self._prepare_syslog_agent_alerts_status_report_message(agent_alerts_status_report)
        self._export_message(message)

    @staticmethod
    def _split_agent_log_record(agent_log_record):
        agent_log_records = []

        for aggregated_agent in agent_log_record['aggregated']:
            agent_log_record_copy = agent_log_record.copy()
            agent_log_record_copy['count'] = 1

            agent_log_record_copy['aggregated'] = [aggregated_agent]
            agent_log_records.append(agent_log_record_copy)

        return agent_log_records

    def export_incident(self, incident):
        if not self._is_syslog_defined():
            return

        if not self.use_generic_incidents_only and \
            ((self.conf.base_syslog_exporter.syslog_format == SyslogFormat.CEF.value
                and not self.conf.base_syslog_exporter.export_through_aggregators)
                or (self.conf.base_syslog_exporter.syslog_format == SyslogFormatDisplayName.CEF.value
                    and self.conf.base_syslog_exporter.export_through_aggregators)):
            self._export_message(self._prepare_incident_cef_message(incident))
        elif not self.use_generic_incidents_only and self.conf.base_syslog_exporter.syslog_format == SyslogFormat.RFC_5424.value:
            details = self.get_incident_details(incident, delimiter=';')
            self._export_message(self._prepare_rfc_5424_message(
                message_type='Security event' if self.replace_incidents_with_security_event else 'Incident',
                message_function=self._prepare_incident_text_message,
                message_function_args=[details]))

    def export_generic_incident(self, message):
        if not self._is_syslog_defined():
            return

        message.display_rule_id = self.display_rule_id
        message.replace_incidents_with_security_event = self.replace_incidents_with_security_event

        # This big if condition can be reduced changing the ticket GC-45601
        if (self.conf.base_syslog_exporter.syslog_format == SyslogFormat.ARCSIGHT_CEF.value
                and not self.conf.base_syslog_exporter.export_through_aggregators)\
                or (self.conf.base_syslog_exporter.syslog_format == SyslogFormatDisplayName.ARCSIGHT_CEF.value
                    and self.conf.base_syslog_exporter.export_through_aggregators):
            for incident_details in message.to_cef_details():
                formatted_message = self._prepare_generic_incident_cef_message(incident_details)
                self._export_message(formatted_message)
        elif self.use_generic_incidents_only and \
                ((self.conf.base_syslog_exporter.syslog_format == SyslogFormat.CEF.value
                    and not self.conf.base_syslog_exporter.export_through_aggregators)
                    or (self.conf.base_syslog_exporter.syslog_format == SyslogFormatDisplayName.CEF.value
                        and self.conf.base_syslog_exporter.export_through_aggregators)):
            for incident_details in message.to_legacy_cef_details():
                formatted_message = self._prepare_generic_incident_cef_message(incident_details)
                self._export_message(formatted_message)
        elif self.conf.base_syslog_exporter.syslog_format == SyslogFormat.NATIVE.value:
            for incident_details in message.to_native_details():
                formatted_message = self._prepare_incident_text_message(
                    incident_details,
                    delimiter=DEFAULT_DELIMITER)
                self._export_message(formatted_message)
        elif self.use_generic_incidents_only and \
                self.conf.base_syslog_exporter.syslog_format == SyslogFormat.RFC_5424.value:
            for incident_details in message.to_rfc5424_details():
                formatted_message = self._prepare_rfc_5424_message(
                    message_type='Security event' if self.replace_incidents_with_security_event else 'Incident',
                    message_function=self._prepare_incident_text_message,
                    message_function_args=[incident_details])
                self._export_message(formatted_message)

    def export_insight_alert(self, alert):
        if not self._is_syslog_defined():
            return

        self.logger.info(
            "Exporting Insight alert to Syslog %s, server %s:%d; query: %s, agent IP: %s, agent hostname: %s",
            self.id,
            self.conf.base_syslog_exporter.syslog_host,
            self.conf.base_syslog_exporter.syslog_port,
            alert['query_name'],
            alert['agent_ip'],
            alert['agent_hostname'])

        message = self._prepare_insight_alert_message(alert)
        self._export_message(message)

    def export_system_alert(self, system_alert):
        if not self._is_syslog_defined():
            return
        if not system_alert.get('id'):
            # this code should not be reached - GC-40176
            LOGGER.error('Received a system event without "id": %s \nUsing "error_code" or "uuid" instead',
                         str(system_alert))
            system_alert['id'] = system_alert.get('error_code') or system_alert['uuid']
        self.logger.info("Exporting system-alert %s to Syslog %s, server %s:%d",
                         system_alert['id'],
                         self.id,
                         self.conf.base_syslog_exporter.syslog_host,
                         self.conf.base_syslog_exporter.syslog_port)

        message = self._prepare_syslog_system_alert_message(system_alert)
        self._export_message(message)

    def export_audit_log_entry(self, entry):
        if not self._is_syslog_defined():
            return

        # audit-log entries do not always contain id field
        # e.g. when it's a "logout" entry, it's not saved to mongo hence no "id"
        self.logger.info("Exporting audit-log entry %s to Syslog %s, server %s:%d",
                         entry.get('_id', entry.get('title')),
                         self.id,
                         self.conf.base_syslog_exporter.syslog_host,
                         self.conf.base_syslog_exporter.syslog_port)

        message = self._prepare_audit_log_message(entry)
        self._export_message(message)

    def export_label_change_log(self, label_change_log):
        if not self._is_syslog_defined():
            return

        self.logger.info("Exporting label change log on asset: %s to Syslog %s, server %s:%d",
                         label_change_log['asset_name'],
                         self.id,
                         self.conf.base_syslog_exporter.syslog_host,
                         self.conf.base_syslog_exporter.syslog_port)

        message = self._prepare_syslog_label_change_message(label_change_log)
        self._export_message(message)

    # ******* Message preparing methods: *******
    def _prepare_incident_cef_message(self, incident):
        cef_exporter = self._get_cef_exporter()

        start_time = self.get_formatted_time_from_date(incident['start_time'], TimeField.CEF_HEADER)

        cef_exporter.extract_incident_cef_fields(incident, start_time,
                                                 self.conf.base_syslog_exporter.max_syslog_tags_len,
                                                 self.replace_incidents_with_security_event)

        now_timestamp = self.get_formatted_time_from_date(datetime.utcnow(), TimeField.CEF_HEADER)

        message = cef_exporter.create_cef_message(
            display_hostname=self.conf.base_syslog_exporter.display_hostname,
            now_timestamp=now_timestamp)

        return self._limit_mgs_length(message, self.get_max_syslog_message_len())

    def _prepare_generic_incident_cef_message(self, incident_message):

        incident_message["extensions"]["start"] = self.get_formatted_time_from_date(
            timestamp_to_date(incident_message["extensions"]["start"]),
            TimeField.CEF_START)

        cef_exporter = self._get_cef_exporter(version=MAJOR_VERSION, **incident_message)

        now_timestamp = self.get_formatted_time_from_date(datetime.utcnow(), TimeField.CEF_HEADER)

        message = cef_exporter.create_cef_message(
            display_hostname=self.conf.base_syslog_exporter.display_hostname,
            now_timestamp=now_timestamp)

        self._limit_mgs_length(message, self.get_max_syslog_message_len())
        return message

    def _prepare_incident_text_message(self, details, delimiter):
        message = "New {severity} severity security {event_type} reported by " \
                  "the Guardicore Security Suite{delimiter}{delimiter}" \
                  "ID: {incident_id}{delimiter}" \
                  "URL: {incident_url}{delimiter}{delimiter}" \
                  "Description: {description}{delimiter}{delimiter}" \
                  "Severity: {severity}{delimiter}" \
                  "Start Time: {start_time}{delimiter}" \
                  "End Time: {end_time}{delimiter}{delimiter}"
        message += "File Modified Time: {file_modified_time}{delimiter}" if details.get('file_modified_time') else ""
        message += "File Owner Name: {file_owner_name}{delimiter}" if details.get('file_owner_name') else ""
        message += "Rule ID: {rule_id}{delimiter}" if details.get('rule_id') else ""
        message += "Affected Assets:{delimiter}{assets}{delimiter}{delimiter}" \
                   "{labels}{delimiter}{delimiter}" \
                   "Tags: {tags}{delimiter}{delimiter}" \
                   "Summary: {delimiter}{summary}"

        # Format
        details['delimiter'] = delimiter
        details['incident_url'] = details['url']

        details['event_type'] = "incident" if 'incident_id' in details else "event"
        details['incident_id'] = details.get('incident_id', details.get('security_event_id'))

        details['start_time'] = self.get_formatted_time_from_date(details['start_time'])
        details['end_time'] = self.get_formatted_time_from_date(details['end_time'])

        details['tags'] = ', '.join(details['tags'])
        details['assets'] = delimiter.join(details['assets'])
        details['labels'] = delimiter.join(details['labels'])

        return message.format(**details)

    def _prepare_insight_alert_message(self, insight_alert):
        if self.conf.base_syslog_exporter.syslog_format in (SyslogFormat.CEF.value, SyslogFormat.ARCSIGHT_CEF.value):
            return self._prepare_insight_alert_cef_message(insight_alert)
        elif self.conf.base_syslog_exporter.syslog_format == SyslogFormat.RFC_5424.value:
            severity = EventsSyslogExporter._to_rfc5424_severity(EventSeverity(insight_alert['severity']))
            return self._prepare_rfc_5424_message(
                message_type='Insight-alert',
                message_function=self._prepare_insight_alert_text_message,
                message_function_args=[insight_alert, severity])
        else:
            severity = EventSeverity(insight_alert['severity']).name.lower()
            return self._prepare_insight_alert_text_message(insight_alert, severity)

    def _prepare_insight_alert_cef_message(self, incident):
        start_time = self.get_formatted_time_from_date(incident["start_time"])

        extensions = dict(msg=incident['query_name'],
                          dvc=incident['agent_ip'],
                          dvchost=incident['agent_hostname'],
                          act=ManagementMatchingVerdict.ALERTED_BY_MANAGEMENT.name,
                          start=start_time)

        severity = EventsSyslogExporter._to_cef_severity(EventSeverity(incident['severity']))
        cef_exporter = self._get_cef_exporter(device_event_class_id='Insight alert',
                                              name=incident['query_name'],
                                              severity=severity,
                                              extensions=extensions)
        now_timestamp = self.get_formatted_time_from_date(datetime.utcnow(), TimeField.CEF_HEADER)
        message = cef_exporter.create_cef_message(
            display_hostname=self.conf.base_syslog_exporter.display_hostname,
            now_timestamp=now_timestamp)

        return self._limit_mgs_length(message, self.get_max_syslog_message_len())

    def _prepare_insight_alert_text_message(self, incident, severity, delimiter=DEFAULT_DELIMITER):
        start_time = self.get_formatted_time_from_date(incident["start_time"])

        return "New Insight alert reported by the Guardicore Security Suite{delimiter}" \
               "Name: {name}{delimiter}" \
               "Severity: {severity}{delimiter}" \
               "Time: {time}{delimiter}" \
               "Device IP: {device_ip}{delimiter}" \
               "Device Name: {device_name}{delimiter}".format(name=incident['query_name'],
                                                              severity=severity,
                                                              time=start_time,
                                                              device_ip=incident['agent_ip'],
                                                              device_name=incident['agent_hostname'],
                                                              delimiter=delimiter)

    def _prepare_syslog_label_change_message(self, label_change_log):
        if self.conf.base_syslog_exporter.syslog_format in (SyslogFormat.CEF.value, SyslogFormat.ARCSIGHT_CEF.value):
            return self._prepare_label_change_cef_message(label_change_log)
        elif self.conf.base_syslog_exporter.syslog_format == SyslogFormat.RFC_5424.value:
            return self._prepare_rfc_5424_message(message_type='Label-Change-Log',
                                                  message_function=self._prepare_label_change_text_message,
                                                  message_function_args=[label_change_log])
        else:
            return self._prepare_label_change_text_message(label_change_log)

    def _prepare_label_change_cef_message(self, label_change_log):
        extensions = dict(id=label_change_log['id'],
                          msg=self._limit_mgs_length(self._prepare_label_change_text_message(label_change_log, ', '),
                                                     self.get_max_syslog_message_len()))
        cef_exporter = self._get_cef_exporter(device_event_class_id='Label Change',
                                              name='Asset Label Change',
                                              extensions=extensions)

        now_timestamp = self.get_formatted_time_from_date(datetime.utcnow(), TimeField.CEF_HEADER)

        message = cef_exporter.create_cef_message(
            display_hostname=self.conf.base_syslog_exporter.display_hostname,
            now_timestamp=now_timestamp)

        return self._limit_mgs_length(message, self.get_max_syslog_message_len())

    @staticmethod
    def _prepare_label_change_text_message(label_change_log, delimiter=DEFAULT_DELIMITER):
        message = dict(delimiter=delimiter)
        message['asset_name'] = label_change_log['asset_name']
        message['asset_id'] = label_change_log['asset_id']
        message['asset_ips'] = label_change_log['asset_ips']
        message['added_labels'] = ", ".join(label['name'] for label in label_change_log['added_labels']) or 'None'
        message['removed_labels'] = ", ".join(label['name'] for label in label_change_log['removed_labels']) or 'None'
        message['added_label_groups'] = ", ".join(label_group['name'] for label_group in
                                                  label_change_log['added_label_groups']) or 'None'
        message['removed_label_groups'] = ", ".join(label_group['name'] for label_group in
                                                    label_change_log['removed_label_groups']) or 'None'
        message['all_labels'] = ", ".join(label['name'] for label in label_change_log['all_labels']) or 'None'
        message['all_label_groups'] = ", ".join(label_group['name'] for label_group in
                                                label_change_log['all_label_groups']) or 'None'
        message['change_cause'] = label_change_log['change_cause']
        message['changed_by_name'] = label_change_log['changed_by']['name']
        message['changed_by_type'] = label_change_log['changed_by']['type'].capitalize()
        return "New label change entry reported by the Guardicore Security Suite{delimiter}" \
               "Asset name: {asset_name}{delimiter}" \
               "Asset id: {asset_id}{delimiter}" \
               "IP Addresses: {asset_ips}{delimiter}" \
               "Added Labels: {added_labels}{delimiter}" \
               "Removed labels: {removed_labels}{delimiter}" \
               "Added Label Groups: {added_label_groups}{delimiter}" \
               "Removed Label Groups: {removed_label_groups}{delimiter}" \
               "Resulting labels: {all_labels}{delimiter}" \
               "Resulting label Groups: {all_label_groups}{delimiter}" \
               "Change cause: {change_cause}{delimiter}"\
               "Changed by: {changed_by_type}-{changed_by_name}".format(**message)

    def _prepare_audit_log_message(self, entry):
        details = dict(request=entry.get('path'),
                       act=entry.get('title'),
                       suser=entry.get('username'),
                       msg=entry.get('description'),
                       src=entry.get('remote_addr'))

        if self.conf.events_syslog_exporter.export_full_change_segmentation_rules:
            details['details'] = entry.get('details')

        if self.conf.base_syslog_exporter.syslog_format in (SyslogFormat.CEF.value, SyslogFormat.ARCSIGHT_CEF.value):
            return self._prepare_audit_log_cef_message(details)
        elif self.conf.base_syslog_exporter.syslog_format == SyslogFormat.RFC_5424.value:
            return self._prepare_rfc_5424_message(message_type='Audit',
                                                  message_function=self._prepare_audit_log_text_message,
                                                  message_function_args=[details])
        else:
            return self._prepare_audit_log_text_message(details)

    def _prepare_audit_log_cef_message(self, details):
        cef_exporter = self._get_cef_exporter(device_event_class_id='Audit Record',
                                              name='Audit Record', severity='Unknown',
                                              extensions=details)

        now_timestamp = self.get_formatted_time_from_date(datetime.utcnow(), TimeField.CEF_HEADER)

        message = cef_exporter.create_cef_message(
            display_hostname=self.conf.base_syslog_exporter.display_hostname,
            now_timestamp=now_timestamp)

        return self._limit_mgs_length(message, self.get_max_syslog_message_len())

    @classmethod
    def _prepare_audit_log_text_message(cls, details, delimiter=DEFAULT_DELIMITER):
        message = "New audit log entry reported by the Guardicore Security Suite{delimiter}{delimiter}" \
                  "Username: {suser}{delimiter}" \
                  "IP Address: {src}{delimiter}{delimiter}" \
                  "Title: {act}{delimiter}{delimiter}" \
                  "Description: {msg}".format(delimiter=delimiter, suser=details['suser'],
                                              src=details['src'], act=details['act'], msg=details['msg'])
        entry_details = details.get('details')
        if entry_details:
            message += "{delimiter}{delimiter}Details: {entry_details}".format(delimiter=delimiter,
                                                                               entry_details=entry_details)
        return message

    def _prepare_syslog_system_alert_message(self, system_alert):
        if self.conf.base_syslog_exporter.syslog_format in (SyslogFormat.CEF.value, SyslogFormat.ARCSIGHT_CEF.value):
            return self._prepare_system_alert_cef_message(system_alert)
        elif self.conf.base_syslog_exporter.syslog_format == SyslogFormat.RFC_5424.value:
            return self._prepare_rfc_5424_message(message_type='System-Alert',
                                                  message_function=self._prepare_system_alert_text_message,
                                                  message_function_args=[system_alert])
        else:
            return self._prepare_system_alert_text_message(system_alert)

    def _prepare_system_alert_cef_message(self, system_alert):
        extensions = dict(id=system_alert['uuid'],
                          src=system_alert['event_source'],
                          shost=system_alert['event_source_hostname'],
                          msg=system_alert['cause'],
                          rawEvent=self._limit_mgs_length(system_alert['description'],
                                                          self.conf.base_syslog_exporter.max_description_len))
        cef_exporter = self._get_cef_exporter(device_event_class_id='System Event',
                                              name='System Event', severity=system_alert['status'],
                                              extensions=extensions)
        now_timestamp = self.get_formatted_time_from_date(datetime.utcnow(), TimeField.CEF_HEADER)

        message = cef_exporter.create_cef_message(
            display_hostname=self.conf.base_syslog_exporter.display_hostname,
            now_timestamp=now_timestamp)

        return self._limit_mgs_length(message, self.get_max_syslog_message_len())

    def _prepare_syslog_agent_log_message(self, agent_log_record):
        labels_to_report = \
            BaseSyslogExporter.sanitize_empty_lists(self.conf.events_syslog_exporter.agent_labels_syslog_report_list) \
            if self.conf.events_syslog_exporter.report_agent_labels_to_syslog else None

        if self.conf.base_syslog_exporter.syslog_format in (SyslogFormat.CEF.value, SyslogFormat.ARCSIGHT_CEF.value):
            return self._prepare_agent_log_cef_message(agent_log_record, labels_to_report)
        elif self.conf.base_syslog_exporter.syslog_format == SyslogFormat.RFC_5424.value:
            return self._prepare_rfc_5424_message(message_type='Agent',
                                                  message_function=self._prepare_agent_log_text_message,
                                                  message_function_args=[agent_log_record, labels_to_report])
        else:
            return self._prepare_agent_log_text_message(agent_log_record, labels_to_report=labels_to_report)

    def _prepare_syslog_agent_alerts_status_report_message(self, agent_alerts_status_report):

        if self.conf.base_syslog_exporter.syslog_format in (SyslogFormat.CEF.value, SyslogFormat.ARCSIGHT_CEF.value):
            return self._prepare_agent_alerts_status_report_cef_message(agent_alerts_status_report)
        elif self.conf.base_syslog_exporter.syslog_format == SyslogFormat.RFC_5424.value:
            return self._prepare_rfc_5424_message(message_type='Agent',
                                                  message_function=self._prepare_agent_alerts_status_report_text_message,
                                                  message_function_args=[agent_alerts_status_report])
        return self._prepare_agent_alerts_status_report_text_message(agent_alerts_status_report)

    def _prepare_agent_log_cef_message(self, agent_log_record, labels_to_report=None):
        start_time = self.get_formatted_time_from_date(timestamp_to_date(agent_log_record['report_time']))

        extensions = dict(id=agent_log_record['id'],
                          shost=agent_log_record['origin'],
                          start=start_time,
                          cs1Label='Affected Agents',
                          cs1=self.get_agent_log_affected_agents(agent_log_record, labels_to_report=labels_to_report),
                          msg=self._limit_mgs_length(agent_log_record['message'],
                                                     self.conf.base_syslog_exporter.max_description_len))

        cef_exporter = self._get_cef_exporter(device_event_class_id='Agent Log Event',
                                              name='Agent Log Event', severity=agent_log_record['severity'],
                                              extensions=extensions)
        now_timestamp = self.get_formatted_time_from_date(datetime.utcnow(), TimeField.CEF_HEADER)

        message = cef_exporter.create_cef_message(
            display_hostname=self.conf.base_syslog_exporter.display_hostname,
            now_timestamp=now_timestamp)

        return self._limit_mgs_length(message, self.get_max_syslog_message_len())

    def _prepare_agent_alerts_status_report_cef_message(self, agent_status_alerts_record):
        start_time = self.get_formatted_time_from_date(timestamp_to_date(agent_status_alerts_record['report_time']))

        extensions = dict(shost=agent_status_alerts_record['origin'],
                          start=start_time,
                          cs1Label='Affected Agents',
                          msg=self._limit_mgs_length(agent_status_alerts_record['message'],
                                                     self.conf.base_syslog_exporter.max_description_len))

        cef_exporter = self._get_cef_exporter(device_event_class_id='Agent alerts status Event',
                                              name='Agent alerts status Event', severity='INFO',
                                              extensions=extensions)
        now_timestamp = self.get_formatted_time_from_date(datetime.utcnow(), TimeField.CEF_HEADER)

        message = cef_exporter.create_cef_message(
            display_hostname=self.conf.base_syslog_exporter.display_hostname,
            now_timestamp=now_timestamp)

        return self._limit_mgs_length(message, self.get_max_syslog_message_len())

    @staticmethod
    def _to_cef_severity(event_severity):
        if event_severity == EventSeverity.High:
            return 8
        if event_severity == EventSeverity.Medium:
            return 5
        if event_severity == EventSeverity.Low:
            return 3
        return 1

    @staticmethod
    def _to_rfc5424_severity(event_severity):
        if event_severity == EventSeverity.High:
            return 4
        if event_severity == EventSeverity.Medium:
            return 5
        if event_severity == EventSeverity.Low:
            return 6
        return 1
