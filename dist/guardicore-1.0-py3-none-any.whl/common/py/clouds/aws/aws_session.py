from boto3 import Session
from boto3 import client as botoclient
from botocore.exceptions import ClientError

from common.py.clouds.aws import AwsAuthenticationMethod, AwsAuthenticationMethodDescriptions
from common import logger

LOG = logger.get_logger(module_name=__name__)


class AwsException(Exception):
    def __init__(self, err_msg, *args):
        Exception.__init__(self, err_msg % args)


class AwsSession(object):
    def __init__(self, authentication_method,
                 gc_aws_access_key_id, gc_aws_secret_access_key,
                 customer_access_key_id, customer_secret_access_key,
                 region_name, role_arn, external_id):
        if authentication_method == AwsAuthenticationMethodDescriptions[AwsAuthenticationMethod.CustomerCredentials]:
            LOG.info('BYOL On-premises Orchestration')
            if not customer_secret_access_key:
                raise AwsException('Customer Secret Access Key must be supplied when using Customer Account Credentials')
            if not customer_access_key_id:
                raise AwsException('Customer Access Key ID must be supplied when using Customer Account Credentials')

            self._session = Session(aws_access_key_id=customer_access_key_id,
                                    aws_secret_access_key=customer_secret_access_key,
                                    region_name=region_name)

            if role_arn:
                # In AWS Console user should follow these steps:
                # - IAM Management: Create Role -> MockOrchestrationConfigAnother AWS Account -> Enter the Customer Account ID (same account).
                # -> get Role ARN -> Enter in UI
                self._session = self.get_assumed_role_session(self._session.client('sts'), role_arn, external_id,
                                                              region_name)

        elif authentication_method == AwsAuthenticationMethodDescriptions[AwsAuthenticationMethod.GuardicoreCredentials]:
            LOG.info('SaaS outside AWS Orchestration')
            if not gc_aws_secret_access_key:
                raise AwsException('Guardicore Secret Access Key must be supplied when using Guardicore Account Credentials')
            if not gc_aws_access_key_id:
                raise AwsException('Guardicore Access Key ID must be supplied when using Guardicore Account Credentials')
            if not role_arn:
                raise AwsException('Customer ARN must be supplied when using Guardicore Account Credentials')
            if not external_id:
                raise AwsException('External ID must be supplied when using Guardicore Account Credentials')

            # In AWS Console user should follow these steps:
            # - IAM Management: Create Role -> Another AWS Account -> Enter the Guardicore Account ID.
            # -> get Role ARN -> Enter in UI

            gc_session = Session(aws_access_key_id=gc_aws_access_key_id,
                                 aws_secret_access_key=gc_aws_secret_access_key,
                                 region_name=region_name)

            self._session = self.get_assumed_role_session(gc_session.client('sts'), role_arn, external_id, region_name)

        elif authentication_method == AwsAuthenticationMethodDescriptions[AwsAuthenticationMethod.InternalAws]:
            LOG.info('SaaS/BYOL on AWS Orchestration')
            if role_arn:
                # In AWS Console user should follow these steps:
                # - IAM Management: Create Role -> Another AWS Account -> Enter the Customer Account ID (same account)
                # -> get Role ARN -> Enter in UI

                # - IAM Management: Create Role -> AWS Service -> EC2. Add sts:AssumeRole Permissions.
                #   https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_use_permissions-to-switch.html
                # - EC2: Attach role to Instance
                self._session = self.get_assumed_role_session(botoclient('sts'), role_arn, external_id, region_name)
            else:
                # In AWS Console user should follow these steps:
                # - IAM Management: Create Role -> AWS Service -> EC2.
                # - EC2: Attach role to Instance
                self._session = Session(region_name=region_name)

        else:
            raise AwsException('Unrecognized login strategy: %r', authentication_method)

        self.region_name = region_name

    @staticmethod
    def get_assumed_role_session(sts_client, role_arn, external_id, region_name):
        assume_role_kwargs = {'RoleArn': role_arn,
                              'RoleSessionName': "GuardicoreRoleSession"}

        if external_id:
            assume_role_kwargs['ExternalId'] = external_id

        LOG.info('Assuming role with parameters: %r', assume_role_kwargs)
        assumed_role = sts_client.assume_role(**assume_role_kwargs)
        assumed_role_credentials = assumed_role['Credentials']

        return Session(aws_access_key_id=assumed_role_credentials['AccessKeyId'],
                       aws_secret_access_key=assumed_role_credentials['SecretAccessKey'],
                       aws_session_token=assumed_role_credentials['SessionToken'],
                       region_name=region_name)

    def connectivity_check(self):
        try:
            self._session.client('ec2').describe_regions()
        except ClientError as e:
            LOG.error('Failed to connect to EC2 region %s error %s %s', self._session.region_name,
                      e.response['Error']['Code'], e)
            raise
        except Exception as e:
            LOG.error('Encountered exception while trying to connect to EC2 region %s %s',
                      self._session.region_name, e)
            raise

    def get_resource(self, resource_type):
        return self._session.resource(resource_type)

    def get_client(self, client_type):
        return self._session.client(client_type)
