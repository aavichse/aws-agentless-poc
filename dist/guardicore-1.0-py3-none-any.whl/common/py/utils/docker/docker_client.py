import os
from six import add_metaclass

import docker
try:
    import dockerpty
except ImportError:
    dockerpty = None
from docker.errors import ContainerError, ImageNotFound, APIError, NotFound
from urllib3.exceptions import ReadTimeoutError

from common.logger import get_logger
from common.singleton import Singleton
from common.py.utils.docker.model import DockerContainerStatus, DockerContainerInfo

LOG = get_logger(module_name=__name__)


def safe_container_operation(op):
    def wrapper(docker_client, container, **kwargs):
        try:
            new_container = op(docker_client, container, **kwargs)
            return new_container or container
        except NotFound:
            LOG.debug("Container %s for '%s' is not running", container.short_id, container.name)
            docker_client._containers.pop(container.name, None)
            return None
        except APIError:
            LOG.exception("Failed to %s container %s for '%s'", op.__name__, container.short_id, container.name)
            docker_client._containers.pop(container.name, None)
            return None

    return wrapper


@add_metaclass(Singleton)
class DockerClient(object):

    DOCKET_SOCKET_PATH = '/var/run/docker.sock'

    def __init__(self):
        self.client = docker.from_env()
        self._containers = {}
        self._docker_gid = None

    @property
    def docker_gid(self):
        if not self._docker_gid:
            self._docker_gid = self._get_docker_gid()
        return self._docker_gid

    def start_container(self, name, run_with_docker_group=False, **kwargs):
        """
        Start container. Similar to ``docker start`` command if the container has already been created or ``docker run``
        otherwise. The container always start in detached state
        :param name: container name
        :param run_with_docker_group: run the container with group docker to allow the container to spawn nested containers
        :param kwargs: Takes the same arguments as ~docker.models.containers.ContainerCollection.run
        :return: DockerContainerInfo
        """

        @safe_container_operation
        def _start_container(self, container):
            container.start()
            return self.client.containers.get(name)

        container = self.get_container(name=name)
        if container:
            container = _start_container(self, container)

        if not container:
            try:
                if run_with_docker_group:
                    self._add_docker_gid_to_container_args(kwargs)
                container = self.client.containers.run(detach=True, name=name, **kwargs)
                LOG.info("Container %s created for '%s' with image '%s' in state %s", container.short_id,
                         container.name, container.image, container.status)
                self._containers[name] = container
            except (ContainerError, ImageNotFound, APIError) as e:
                LOG.exception("Failed to run container '%s'", name)
                return DockerContainerInfo(status=DockerContainerStatus.FAIL_CREATE, status_msg=str(e))

        return self.to_container_status(container)

    def stop_container(self, name):
        """
        Stops a container. Similar to ``docker stop`` command
        :param name: container name
        :return:
        """
        @safe_container_operation
        def _stop_container(self, container):
            container.stop()

        container = self.get_container(name=name)
        if container:
            container = _stop_container(self, container)

        if container:
            LOG.info("Container %s for '%s' stopped", container.short_id, container.name)
        else:
            LOG.debug("Failed to stop container for '%s'. Container not found", name)

    def remove_container(self, name, **kwargs):
        """
        Remove container. Similar to ``docker rm`` command
        :param name: container name
        :return:
        """

        @safe_container_operation
        def _remove_container(self, container, **kwargs):
            container.remove(force=True, **kwargs)

        def _ensure_container_disconnected_from_networks(self, name):
            for network in self.client.networks.list():
                # NOTE: reload the network or else network.containers is empty/outdated
                network.reload()
                try:
                    network.disconnect(name, force=True)
                except APIError:  # ignore network disconnect errors
                    pass
                except:
                    LOG.exception("Failed disconnecting '%s' from network %s", name, network)

            LOG.debug("Container %s is disconnected from all networks", name)

        container = self.get_container(name=name)
        if container:
            container = _remove_container(self, container, **kwargs)
            self._containers.pop(name, None)

        if container:
            LOG.info("Container %s for '%s' removed", container.short_id, container.name)
        else:
            LOG.debug("Failed to remove container for '%s'. Container not found", name)

        _ensure_container_disconnected_from_networks(self, name=name)

    def kill_container(self, name, signal=None):
        """
         Kill or send a signal to the container
        :param name: container name
        :param signal(str or int): The signal to send. Defaults to ``SIGKILL``
        :return:
        """

        @safe_container_operation
        def _kill_container(self, container):
            container.kill(signal=signal)

        container = self.get_container(name=name)
        if container and self.container_status(name).is_running:
            container = _kill_container(self, container)

        if container:
            LOG.info("Signal %s was sent to container %s with id %s", signal, container.name, container.short_id)
        else:
            LOG.warn("Failed to send signal %s container for '%s'. Container not found or not running", signal, name)

    def container_status(self, name, log_lines_limit=None):
        """
        Return the container status in the form DockerContainerInfo
        :param name: container name
        :param log_lines_limit: Number of lines to capture from the end of the container logs
        :return: DockerContainerInfo
        """
        try:
            container = self.client.containers.get(name)
            self._containers[name] = container
            return self.to_container_status(container=container, log_lines_limit=log_lines_limit)
        except NotFound as e:
            self._containers.pop(name, None)
            LOG.debug("Failed to get container status for '%s' from docker API. Container not found", name)
            return DockerContainerInfo(status=DockerContainerStatus.NOT_FOUND, status_msg=str(e))
        except APIError as e:
            LOG.exception("Failed to get container status for '%s' from docker API")
            return DockerContainerInfo(status=DockerContainerStatus.UNKNOWN, status_msg=str(e))
        except ReadTimeoutError as e:
            LOG.warn("Timed out getting container status for '%s' %s", str(e))
            return DockerContainerInfo(status=DockerContainerStatus.TIMEOUT, status_msg=str(e))

    def get_container(self, name):
        if name in self._containers:
            return self._containers[name]

        try:
            container = self.client.containers.get(name)
            self._containers[name] = container
            return container
        except NotFound:
            self._containers.pop(name, None)
            return None
        except APIError:
            return None

    def get_container_id(self, name):
        container = self.get_container(name=name)
        return container.short_id if container else None

    def run_container_attached(self, name, run_with_docker_group=False, **kwargs):
        """
        Run container in attached mode for debugging purposes
        :param name: container name
        :param run_with_docker_group: run the container with group docker to allow the container to spawn nested containers
        :param kwargs: Takes the same arguments as ~docker.models.containers.ContainerCollection.run
        :return:
        """
        container = self.get_container(name=name)
        if container:
            LOG.error("Container %s for '%s' already exist", container.short_id, name)
            return

        try:
            if run_with_docker_group:
                self._add_docker_gid_to_container_args(kwargs)
            container = self.client.containers.create(name=name, stdin_open=True, tty=True, **kwargs)
            if dockerpty:
                dockerpty.start(self.client.api, container.id)
            else:
                LOG.error("Missing module dockerpty")
        except (ImageNotFound, APIError):
            LOG.exception("Failed to create container '%s'", name)
        except Exception:
            LOG.exception("Failed to start container '%s'", name)

    @staticmethod
    def to_container_status(container, status_msg=None, log_lines_limit=None):
        logs = container.logs(tail=log_lines_limit) if log_lines_limit else None
        return DockerContainerInfo(status=DockerContainerStatus.from_str(container.status),
                                   container_id=container.short_id, status_msg=status_msg,
                                   logs=logs)

    @staticmethod
    def _get_docker_gid():
        try:
            stat_info = os.stat(DockerClient.DOCKET_SOCKET_PATH)
            LOG.info("Found docker group id %s", stat_info.st_gid)
            return stat_info.st_gid
        except OSError:
            LOG.warn("Can't run container with docker group id. Failed to find docker socket %s",
                     DockerClient.DOCKET_SOCKET_PATH)
        return None

    def _add_docker_gid_to_container_args(self, kwargs):
        if 'group_add' in kwargs:
            kwargs['group_add'].append(self.docker_gid)
        else:
            kwargs['group_add'] = [self.docker_gid]

    def container_exec(self, name, cmd, **kwargs):
        """
         Run exec cmd to the container
        :param name: container name
        :param cmd (str or list): Command to be executed
        :return:(ExecResult): A tuple of (exit_code, output)
        exit_code: (int):
            Exit code for the executed command or ``None`` if
            either ``stream```or ``socket`` is ``True``.
        output: (generator or str):
            If ``stream=True``, a generator yielding response chunks.
            If ``socket=True``, a socket object for the connection.
            A string containing response data otherwise.
        """
        try:
            container = self.get_container(name)
            return container.exec_run(cmd, **kwargs)
        except NotFound:
            LOG.error("Container for '%s' not found ", name)
        except APIError:
            LOG.exception("Failed to exec cmd '%s' on '%s'", cmd, name)

        return None, None
