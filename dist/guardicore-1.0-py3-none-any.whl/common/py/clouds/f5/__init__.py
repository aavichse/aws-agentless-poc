from common.py.utils.config import cfg, six
from common.py.clouds import common_opts, label_opts
from common.py.utils.config.oslo_config import types
from common.py.utils.config.types import Structure

AGGREGATOR_IP_PARAMATER = '(aggregator_ip)'

SINGLE_F5_STRUCTURE = Structure([cfg.StrOpt('device_name', help="device name", required=True),
                                 cfg.StrOpt('address', help="IP address for the SOAP API"),
                                 cfg.StrOpt('user', help="user name for the SOAP API"),
                                 cfg.StrOpt('password', secret=True,
                                            help=r"password for the SOAP API (note: using $ signs in the password requires escaping \$)"),
                                 cfg.StrOpt('webhook_url',
                                            help="by default will be http://{}:80".format(AGGREGATOR_IP_PARAMATER))],
                                name='single_f5_struct')

f5_opts = [
              cfg.Opt(name='f5_big_ip_device_list',
                      type=types.List(item_type=SINGLE_F5_STRUCTURE, bounds=True),
                      default=[]),
              cfg.BoolOpt('import_common_partition_only', default=False,
                          help="Import Metadata Only From /Common Partition Instead Of All Partitions"),

          ] + common_opts + label_opts

F5_OPT_STRUCTURE = Structure(f5_opts)

F5_AUTH_OPTS = []

F5_FF_OPTS = [cfg.BoolOpt('filter_destinations_ipv4_wildcards', default=True,
                                help="Filters assets which contain destination IP '0.0.0.0' and '.app' in the asset name."
                                     "These tend to be iApps configured by templates."), ]


def register_opts():
    cfg.CONF.register_opt(cfg.Opt(name='f5_configuration', type=F5_OPT_STRUCTURE), group="orchestration")
    cfg.CONF.register_opt(cfg.BoolOpt('f5_non_common_partitions_enabled', default=True), group="orchestration")

