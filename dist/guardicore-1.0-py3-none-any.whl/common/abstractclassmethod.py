# Backported from Python 3.3's abc.py.
# See also: http://stackoverflow.com/questions/11217878/python-2-7-combine-abc-abstractmethod-and-classmethod


class abstractclassmethod(classmethod):
    __isabstractmethod__ = True

    def __init__(self, callable):
        callable.__isabstractmethod__ = True
        super(abstractclassmethod, self).__init__(callable)
