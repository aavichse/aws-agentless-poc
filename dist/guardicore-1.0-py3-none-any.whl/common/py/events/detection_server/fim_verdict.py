from enum import IntEnum


class FIMPathScanVerdict(IntEnum):
    MATCH = 1
    VIOLATION = 2
    NOT_FILE = 3
    FILE_MISSING = 4
    FILE_TOO_BIG = 5
    NETWORK_PATH = 6
    ERROR = 7
    CONFLICT = 8
