from common.logger import get_logger
from common.py.models.events import EventSeverity, get_error_code
from common.py.utils.resource import deconstruct_template, read_resource

UNKNOWN_DETAIL_STRING = 'N/A'
LOGGER = get_logger()

class Exporter(object):
    """
    Exporters should inherit from this class and put in modules under the management.utils.data_export.exporters package.
    Exporters should also inherit from the exporter mixins (below) based on what items they support exporting.
    Items such as incidents, audit log entries, and IoCs are passed to all enabled and supporting exporters.
    """
    # override by subclasses to define which conf options to register, and under which group
    # syntax: CONF_OPTS = [(group_name, options)]
    CONF_OPTS = []

    def __init__(self, conf):
        self.logger = get_logger()
        self.conf = conf

    def get_exporter_greenlets(self):
        """
        Override by subclasses that have spawned greenlets
        """
        return []

    @classmethod
    def is_exported_through_aggregators(cls, conf):
        """
        Override by subclasses to export through aggregators instead of through management
        :param conf: oslo configuration
        :return: True to export through aggregators, False otherwise.
        """
        return False

    @classmethod
    def is_exported_from_management(cls, conf):
        return not cls.is_exported_through_aggregators(conf)


class RequiredExportFieldException(ValueError):
    def __init__(self, exporter, event, field, *args):
        message = 'Error exporting {event} on {exporter}: {required_field} is not configured'.format(event=event,
                                                                                                     exporter=exporter,
                                                                                                     required_field=field)
        super(RequiredExportFieldException, self).__init__(message, *args)


class AgentLogExporterMixin(object):
    """
    Mixin for Exporter derived classes that support exporting incidents.
    """

    @property
    def agent_log_export_enabled(self):
        """
        Override to (conditionally) enable agent log export
        :return:
        """
        return False

    def export_agent_log(self, agent_log_record):
        """
        Abstract. Export agent log.
        :param agent_log_record:
        :return:
        """
        raise NotImplementedError()

    def export_agent_alerts_status_report(self, agent_alerts_status_report_record):
        """
        Abstract. Export agent alerts status report log.
        :param agent_alerts_status_report_record:
        :return:
        """
        raise NotImplementedError()

    def _prepare_agent_log_text_message(self, agent_log_record, labels_to_report=None, delimiter='\n'):
        affected_agents = self.get_agent_log_affected_agents(agent_log_record=agent_log_record,
                                                             labels_to_report=labels_to_report)
        agent_log_str = "New agent log{delimiter}{delimiter}" \
                        "Origin: {origin}{delimiter}" \
                        "Affected Agents: {affected_agents}{delimiter}" \
                        "Severity: {severity}{delimiter}" \
                        "Message: {message}{delimiter}".format(origin=agent_log_record['origin'],
                                                               message=agent_log_record['message'],
                                                               affected_agents=affected_agents,
                                                               delimiter=delimiter,
                                                               severity=agent_log_record['severity'])
        return agent_log_str

    def _prepare_agent_alerts_status_report_text_message(self, agent_alerts_status_report, delimiter='\n'):
        LOGGER.debug('Going to send agent_alerts_status_report %s', agent_alerts_status_report)
        agent_log_str = " New Agent alerts status report{delimiter}{delimiter}" \
                        " Origin: {origin}{delimiter}" \
                        " Message: {message}{delimiter}".format(origin=agent_alerts_status_report['origin'],
                                                               message=agent_alerts_status_report['message'],
                                                               delimiter=delimiter)
        return agent_log_str

    @classmethod
    def get_agent_log_affected_agents(cls, agent_log_record, labels_to_report=None, limit_aggregated=5):
        """
        :param agent_log_record: agent log message
        :param labels_to_report: list of labels to report (cfg.syslog_exporter.agent_labels_syslog_report_list)
        :param limit_aggregated: num of aggregated events per message
        :return:
        """
        agents_data = []
        for aggregated_tuple in agent_log_record['aggregated'][:limit_aggregated]:
            extra_data = []

            if 'source' in aggregated_tuple and aggregated_tuple['source']:
                extra_data.append("ip: {}".format(aggregated_tuple['source']))

            if 'component_id' in aggregated_tuple:
                extra_data.append("component_id: {}".format(aggregated_tuple['component_id']))

            if labels_to_report is not None and 'labels' in aggregated_tuple:
                # report all labels if labels_to_report is an empty list or report only label_name in labels_to_report
                relevant_labels = [label_name for label_name in aggregated_tuple['labels']
                                   if label_name in labels_to_report or labels_to_report == []]
                if relevant_labels:
                    extra_data.append("labels: {}".format(", ".join(relevant_labels)))

            if extra_data:
                aggregated_tuple_str = "{} ({})".format(aggregated_tuple['hostname'], ", ".join(extra_data))
            else:
                aggregated_tuple_str = "{}".format(aggregated_tuple['hostname'])

            agents_data.append(aggregated_tuple_str)

        agents_data_str = ", ".join(agents_data)
        aggregated_len = len(agent_log_record['aggregated'])

        if aggregated_len > limit_aggregated:
            rest_aggregated = limit_aggregated - aggregated_len
            agents_data_str = "{agents_data_str}, +{rest_aggregated} more".format(agents_data_str=agents_data_str,
                                                                                  rest_aggregated=rest_aggregated)

        return agents_data_str


class IncidentExporterMixin(object):
    """
    Mixin for Exporter derived classes that support exporting incidents.
    """

    @property
    def incident_export_enabled(self):
        """
        Override to (conditionally) enable incident export
        :return:
        """
        return False

    def export_incident(self, incident):
        """
        Abstract. Export incident.
        :param incident:
        :return:
        """
        raise NotImplementedError()

    def export_generic_incident(self, message):
        """
        Abstract. Export generic incident.
        :param message: GenericIncidentMessage that contains all the data needed to be exported
        :return:
        """
        raise NotImplementedError()

    @classmethod
    def get_incident_details(cls, incident, delimiter='\n'):
        severity = EventSeverity(incident['severity']).name.lower()
        description = deconstruct_template(template=read_resource('incidents', incident['_cls'])['description'],
                                           arguments=incident['description_template_args'])
        summary = delimiter.join(
            '%d. ' % (i + 1) + deconstruct_template(template=story['template'], arguments=story['arguments']) + '.'
            for i, story in enumerate(incident['stories'])) if 'stories' in incident else UNKNOWN_DETAIL_STRING

        affected_assets = []
        for affected_asset in incident['affected_assets']:
            label = ', '.join(affected_asset['labels'])
            if affected_asset.get('vm') is not None:
                title = affected_asset['vm']['name']
            else:
                title = affected_asset['ip']

            affected_assets.append("{title} ({label})".format(title=title,
                                                              label=label))

        affected_labels = []
        for side in ['source', 'destination']:
            side_labels = '{}_labels'.format(side)
            if side_labels in incident:
                affected_labels.append("{side} labels: {labels}".format(side=side.capitalize(),
                                                                        labels=','.join(incident.get(side_labels, []))))

        file_modified_time = None
        file_owner_name = None
        if incident.get('type') == 'Integrity':
            file_modified_time = incident.get('file_modified_time', None)
            file_owner_name = incident.get('file_owner_name', None)

        formatted_incident = {
            'title': 'New {severity} severity security incident reported by Guardicore Security Suite'.format(
                severity=severity),
            'incident_id': incident['id'],
            'url': incident['url'],
            'description': description,
            'severity': severity,
            'assets': affected_assets,
            'labels': affected_labels,
            'tags': set(tag.get('display_name', 'N/A') for tag in incident['tags']),
            'summary': summary,
            'start_time': incident['start_time'],
            'end_time': incident['end_time'],
            'file_modified_time': file_modified_time,
            'file_owner_name': file_owner_name
        }
        return formatted_incident


class IoCExporterMixin(object):
    """
    Mixin for Exporter derived classes that support exporting IoCs.
    """

    @property
    def ioc_export_enabled(self):
        """
        Override to (conditionally) enable IoC export
        :return:
        """
        return False

    def export_iocs(self, incident, ioc_list):
        """
        Abstract. Export IoC.
        :param incident:
        :return:
        """
        raise NotImplementedError()


class AuditLogEntryExporterMixin(object):
    """
    Mixin for Exporter derived classes that support exporting audit log entries.
    """

    @property
    def audit_log_export_enabled(self):
        """
        Override to (conditionally) enable Audit Log export
        :return:
        """
        return False

    def export_audit_log_entry(self, entry):
        """
        Abstract. Export Audit Log entry.
        :param entry:
        :return:
        """
        raise NotImplementedError()


class SystemAlertExporterMixin(object):
    """
    Mixin for Exporter derived classes that support exporting system alerts.
    """

    @property
    def system_report_export_enabled(self):
        """
        Override to (conditionally) enable system-alert export
        :return:
        """
        return False

    @property
    def system_report_minimum_severity(self):
        return None

    def export_system_alert(self, alert):
        """
        Abstract. Export alert.
        :param alert:
        :return:
        """
        raise NotImplementedError()

    @staticmethod
    def _prepare_system_alert_text_message(system_alert, delimiter='\n'):
        if 'error_code' not in system_alert:
            error_code = get_error_code(description=system_alert['description'])
            system_alert['error_code'] = error_code

        alert_str = "New system alert{delimiter}{delimiter}" \
                    "Severity: {status}{delimiter}" \
                    "Error Code: {error_code}{delimiter}" \
                    "Cause: {cause}".format(status=system_alert['status'],
                                            error_code=system_alert['error_code'],
                                            cause=system_alert['cause'],
                                            delimiter=delimiter)

        # remove exception (Traceback) from alert's description:
        description = system_alert['description'].split('Traceback', 1)[0].strip()
        if description:
            alert_str += "{delimiter}Description: {description}".format(description=description, delimiter=delimiter)

        return alert_str


class LabelChangesLogExporterMixin(object):
    """
    Mixin for Exporter derived classes that support exporting label changes entries.
    """

    @property
    def label_changes_export_enabled(self):
        """
        Override to (conditionally) enable Label Changes log export
        :return:
        """
        return False

    def export_label_change_log(self, entry):
        """
        Abstract. Export Label changes log.
        :param entry:
        :return:
        """
        raise NotImplementedError()


class NetworkLogsExporterMixin(object):
    """
    Mixin for Exporter derived classes that support exporting network logs.
    """

    @property
    def network_log_export_enabled(self):
        """
        Override to (conditionally) enable network log export
        :return:
        """
        return False

    def export_network_log(self, network_log_record):
        raise NotImplementedError()


class InsightAlertExporterMixin(object):
    """
    Mixin for Exporter derived classes that support exporting Insight alerts.
    """

    @property
    def insight_alerts_export_enabled(self):
        """
        Override to (conditionally) enable Insight alerts export
        :return:
        """
        return False

    def export_insight_alert(self, alert):
        """
        Abstract. Export Audit Log entry.
        :param alert:
        :return:
        """
        raise NotImplementedError()
