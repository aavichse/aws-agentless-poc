import os


def get_mongodb_url(default_url):
    """
    Get an injected MongoDB DNS name
    :param default_url: default URL to use in case we can't find an injected one as an env variable
    :return:
    """
    return _get_service_url(env_var_name='GC_MONGODB_SERVICE_DNS', default_url=default_url)


def get_etcd_url(default_url):
    """
    Get an injected etcd DNS name
    :param default_url: default URL to use in case we can't find an injected one as an env variable
    :return:
    """
    return _get_service_url(env_var_name='GC_ETCD_SERVICE_DNS', default_url=default_url)


def get_elasticsearch_url(default_url):
    """
    Get an injected Elasticsearch DNS name
    :param default_url: default URL to use in case we can't find an injected one as an env variable
    :return:
    """
    return _get_service_url(env_var_name='GC_ELASTICSEARCH_SERVICE_DNS', default_url=default_url)


def get_clickhouse_url(default_url):
    """
    Get an injected ClicHouse DNS name
    :param default_url: default URL to use in case we can't find an injected one as an env variable
    :return:
    """
    return _get_service_url(env_var_name='GC_CLICKHOUSE_SERVICE_DNS', default_url=default_url)


def get_rabbitmq_url(default_url):
    """
    Get an injected RabbitMQ DNS name
    :param default_url: default URL to use in case we can't find an injected one as an env variable
    :return:
    """
    return _get_service_url(env_var_name='GC_RABBITMQ_SERVICE_DNS',  default_url=default_url)


def get_influxdb_url(default_url):
    """
    Get an injected InfluxDB DNS name
    :param default_url: default URL to use in case we can't find an injected one as an env variable
    :return:
    """
    return _get_service_url(env_var_name='GC_INFLUXDB_SERVICE_DNS', default_url=default_url)


def get_telegraf_url(default_url):
    """
    Get an injected Telegraf DNS name
    :param default_url: default URL to use in case we can't find an injected one as an env variable
    :return:
    """
    return _get_service_url(env_var_name='GC_TELEGRAF_SERVICE_DNS', default_url=default_url)


def get_postgres_url(default_url):
    """
    Get an injected Telegraf DNS name
    :param default_url: default URL to use in case we can't find an injected one as an env variable
    :return:
    """
    return _get_service_url(env_var_name='GC_POSTGRES_SERVICE_DNS', default_url=default_url)


def truncate_redis_name(name):
    """
    :param name: Redis name to truncate
    This solves the 32 char helm 'releaseName' limitation and the kubernetes 63 char label value limitation
    We truncate the redis names so they could run in the SaaS

    IF FOR SOME REASON THIS IS CHANGED it also needs to be changed at:
    https://github.com/guardicode/guardicore_cloud @ file cloud/api_server/api_models/deployment/defaults/redis.go
    """
    return name[0:32]


def get_redis_url(name, default_url):
    """
    Get an injected Redis server DNS name
    :param default_url: default URL to use in case we can't find an injected one as an env variable
    :param name: The name of the Redis to get - this is the Redis's name as defined in NamedService
    :return:
    """
    name = truncate_redis_name(name)
    name_as_env_var = name.replace('-', '_').upper()
    env_var_name = "GC_{}_DNS_URL".format(name_as_env_var)
    return _get_service_url(env_var_name, default_url=default_url)


def get_monitoring_url(default_url):
    """
    Get an injected monitoring service to get statsd reports
    :param default_url: default URL to use in case we can't find an injected one as an env variable
    :return:
    """
    return _get_service_url(env_var_name='HOST_IP', default_url=default_url)


def get_policy_manager_url(default_url):
    """
    Get an injected policy-manager DNS name
    :param default_url: default URL to use in case we can't find an injected one as an env variable
    :return:
    """
    return _get_service_url(env_var_name='GC_POLICY_MANAGER_DNS', default_url=default_url)


def get_rest_server_url(default_url):
    """
    Get an injected monitoring service to get REST server URL
    :param default_url: default URL to use in case we can't find an injected one as an env variable
    :return:
    """
    return _get_service_url(env_var_name='REST_SERVER_URL', default_url=default_url)


def _get_service_url(env_var_name, default_url):
    url = os.environ.get(env_var_name, None)
    if not url:
        return default_url

    namespace = get_namespace()
    if namespace is not None:
        url = url.replace('default', namespace)

    return url


def get_namespace():
    return os.environ.get('NAMESPACE_NAME')


def get_service_name():
    return os.environ.get('NAME')


def get_version():
    return os.environ.get("VERSION")
