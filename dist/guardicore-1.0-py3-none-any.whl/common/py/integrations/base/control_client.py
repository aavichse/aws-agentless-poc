import functools
import pydantic
import requests

from aggregator.model.integrations import IntegrationModels
from common.logger import get_logger

LOG = get_logger(module_name=__name__)

class IntegrationControlClientException(Exception):
    pass


class BaseControlClient:
    FUNC_TRANSLATION = {}
    FUNC_PAGINATION_TRANSLATION = {}

    def __new__(cls, *args, **kwargs):
        instance = super(BaseControlClient, cls).__new__(cls)
        for name, request_params in instance.FUNC_TRANSLATION.items():
            setattr(instance, name, functools.partial(instance._send_request, **request_params))
        for name, request_params in instance.FUNC_PAGINATION_TRANSLATION.items():
            setattr(instance, name, functools.partial(instance._pagination, **request_params))
        return instance

    def __init__(self, url, api_version, *args, **kwargs):
        self.headers = {"Content-Type": "application/json"}
        self.url = url
        self.models = IntegrationModels(effective_version=api_version)
        self._health_report_cb = self.default_conn_health_cb
        # timeouts for the "requests" module (seconds value)
        self._connect_timeout = 10
        self._read_timeout = 50

    @property
    def api_version(self):
        return self.models.api_version

    @property
    def connect_timeout(self):
        return self._connect_timeout

    @connect_timeout.setter
    def connect_timeout(self, value):
        self._connect_timeout = value

    @property
    def read_timeout(self):
        return self._read_timeout

    @read_timeout.setter
    def read_timeout(self, value):
        self._read_timeout = value

    def _send_request(self, request_type, uri, ign_codes=None, json=None, request_model=None, response_model=None,
                      *args, **kwargs):
        if json and request_model:
            # validate and serialize
            model = getattr(self.models, request_model)
            json = model.model_validate(json).model_dump(by_alias=True, exclude_none=True, mode="json")

        url = "{}/{}".format(self.url, uri.format(version=self.models.api_version))
        try:
            rsp = requests.request(request_type, url=url, headers=self.headers, json=json,
                                   timeout=(self._connect_timeout, self._read_timeout), *args, **kwargs)
            rsp.model = None
            self._health_report_cb(success=True)
            try:
                rsp.raise_for_status()
                if response_model:
                    rsp.model = getattr(self.models, response_model).model_validate_json(rsp.content)
            except pydantic.ValidationError:
                LOG.warning("Failed to parse response as model '%s': %s", response_model, rsp.content)
                raise
            except requests.HTTPError:
                status = rsp.status_code
                if ign_codes and status in ign_codes:
                    pass
                elif status == 401:
                    LOG.error("Unauthorized~!")
                else:
                    LOG.exception("Failed! status code: %d error: %s json: %s" % (status, rsp.content, json))
            return rsp
        except (requests.ConnectionError, requests.Timeout) as err:
            LOG.exception("Failed! connectivity issue: %s", str(err))
            self._health_report_cb(success=False, err=str(err))
        return None

    def _pagination(self, request_type, uri, response_model=None, *args, **kwargs):
        rsp = self._send_request(request_type, uri, *args, **kwargs)
        if not rsp:  # response code 5XX and 4XX
            return None

        data = rsp.json()
        while "next" in rsp.links:
            next_uri = uri + "?" + rsp.links['next']['url']
            rsp = self._send_request(request_type, next_uri, *args, **kwargs)
            if not rsp:
                return None
            data.extend(rsp.json())

        # validate response model
        if response_model:
            model = getattr(self.models, response_model)
            try:
                data = model.model_validate(data)
            except pydantic.ValidationError:
                LOG.warning("Failed to parse response as model '%s': %s", response_model, data)
                raise

        return data

    def default_conn_health_cb(self, success, err=None):
        pass

    def set_conn_health_cb(self, health_report_cb):
        self._health_report_cb = health_report_cb

    def get_environment_details(self):
        raise IntegrationControlClientException("Not implemented")
