from common.py.clouds import common_opts, label_opts
from common.py.utils.config import cfg
from common.py.utils.config.types import Port, Structure, List, String

# kubernetes specific configurations
kubernetes_opts = [cfg.StrOpt('auth_host', help="Kubernetes server IP address"),
                   cfg.Opt('auth_port', default=6443, help="Kubernetes server authentication port",
                           type=Port()),
                   cfg.BoolOpt('validate_certificate', help="Validate SSL certificate to the server",
                               default=False),
                   cfg.StrOpt('service_account_token', help="Service account token from Kubernetes secret",
                              default=None),
                   cfg.ExtendedOpt('ca_cert_data', default=[], type=List(item_type=String(unicode=True, quotes=True),
                                                                         bounds=True),
                                   multi_line_text=True, help="Cluster CA certificate (PEM format)"),

                   # AKS Reserved prefixes: https://learn.microsoft.com/en-us/azure/aks/use-labels
                   cfg.ExtendedOpt('aks_k8s_label_recognition_pattern', type=String(), hidden=True,
                                   help="AKS Kubernetes Recognition Pattern", default='kubernetes.azure.com'),
                   # GKE Node pools: https://cloud.google.com/kubernetes-engine/docs/concepts/node-pools
                   cfg.ExtendedOpt('gke_k8s_label_recognition_pattern', type=String(), hidden=True,
                                   help="GKE Kubernetes Recognition Pattern", default='cloud.google.com'),
                   # EKS Managed node groups: https://docs.aws.amazon.com/eks/latest/userguide/managed-node-groups.html
                   cfg.ExtendedOpt('eks_k8s_label_recognition_pattern', type=String(), hidden=True,
                                   help="EKS Kubernetes Recognition Pattern", default='eks.amazonaws.com'),
                   cfg.ExtendedOpt('ocp_k8s_label_recognition_pattern', type=String(), hidden=True,
                                   help="OCP Kubernetes Recognition Pattern", default='node.openshift.io'),
                   
                   cfg.ExtendedOpt('ocp_k8s_annotations_recognition_pattern', type=String(), hidden=True,
                                   help="OCP Kubernetes Recognition Pattern", default='node.openshift.io'),
                   cfg.ExtendedOpt('rke_k8s_annotations_recognition_pattern', type=String(), hidden=True,
                                   help="RKE Kubernetes Recognition Pattern", default='rke.cattle.io'),
                   ] + common_opts

KUBERNETES_AUTH_STRUCTURE = Structure(kubernetes_opts)

KUBERNETES_AUTH_OPTS = [cfg.IntOpt('update_timeout_seconds', default=10 * 60,
                                   help="Kubernetes update timeout in seconds"),
                        cfg.IntOpt('access_token_check_period', default=60,
                                   help="Kubernetes access token renewal check period in seconds"),
                        cfg.IntOpt('access_token_pre_expiration_renew_period', default=10 * 60,
                                   help="How many seconds before access token expires to fetch another token")]


def register_opts():
    cfg.CONF.register_opt(cfg.Opt('kubernetes_configuration', type=KUBERNETES_AUTH_STRUCTURE), group="orchestration")
    cfg.CONF.register_opts(KUBERNETES_AUTH_OPTS, "kubernetes_auth")
