import attr
import numpy as np
from bitarray import bitarray


@attr.s
class Uint128(object):
    low64 = attr.ib(type=np.uint64)
    high64 = attr.ib(type=np.uint64)

    def __int__(self):
        return (self.high64 << 64) | self.low64

    def as_int(self):
        return self.__int__()

    @classmethod
    def from_int(cls, value):
        low64 = value & 0xFFFFFFFFFFFFFFFF
        high64 = (value >> 64) & 0xFFFFFFFFFFFFFFFF
        return cls(low64, high64)


@attr.s
class UserToUserGroups(object):
    """
    A single user, and its usergroup memberships, represented as a bitvector
    """
    userid = attr.ib(type=Uint128)  # Represents uint128
    usergroups_bv = attr.ib(type=list)  # A list of np.uint64


@attr.s
class UsergroupToIndexMapping(object):
    """
    A single mapping between group and its index in the bitvectors
    """
    usergroup = attr.ib(type=np.uint16)
    index = attr.ib(type=np.uint16)


@attr.s
class UsergroupMappingData(object):
    """
    A user->usergroups mapping data in bitvector representation.
    See https://guardicore.atlassian.net/wiki/spaces/~5cbde146e494c810153acd89/pages/4405821465/Azure+AD+Aggregator+-+Agent+schema
    """
    group_memberships = attr.ib(type=list)  # Represents List[UserToUserGroups]
    usergroup_idxs = attr.ib(type=list)  # Represents List[UsergroupToIndexMapping]
    revision = attr.ib(type=int)
    is_full_update = attr.ib(type=bool)
    _groups = attr.ib(type=list, default=[])  # Hidden property, excluded from as_dict
    _membership_dict = attr.ib(type=dict, default={})  # Hidden property, excluded from as_dict

    def as_dict(self):
        def _converter(o):
            if isinstance(o, list):
                return [_converter(item) for item in o]
            if isinstance(o, dict):
                return {k: _converter(v) for k, v in o.items()}
            if isinstance(o, np.uint64) or isinstance(o, np.uint16):
                return int(o)
            if isinstance(o, (UserToUserGroups, UsergroupToIndexMapping, Uint128)):
                return attr.asdict(o)
            return o

        asdict = attr.asdict(self)
        asdict.pop('_groups', None)
        asdict.pop('_membership_dict', None)
        for key, value in asdict.items():
            asdict[key] = _converter(value)
        return asdict

    @property
    def groups(self):
        """
        :rtype: list[np.uint16]
        """
        if not self._groups:
            self._groups = [mapping.usergroup for mapping in self.usergroup_idxs]
        return self._groups

    @property
    def membership_dict(self):
        if not self._membership_dict:
            self._membership_dict = {int(member.userid): member.usergroups_bv for member in self.group_memberships}
        return self._membership_dict

    def get_single_user_group_list(self, user):
        """
        :type user: int
        :rtype: list[np.uint16]
        """
        usergroups_bv = self.membership_dict.get(user, None)
        if usergroups_bv:
            groups_bv = BitVectorConversionUtils.convert_uint64_list_to_bitvector(usergroups_bv,
                                                                                  len(self.usergroup_idxs))
            return BitVectorConversionUtils.bitvector_and_indexes_to_groups(groups_bv, self.usergroup_idxs)
        return []

    def get_usergroup_memberships_as_dict(self):
        """
        Calculate the usergroup memberships from BV and indexes and return it as a dictionary
        :rtype: dict
        :return: A usergroup membership dict, for example: {(0,1): [1,2], (0,2): [2]}.
        """
        membership_dict = {}
        for membership in self.group_memberships:
            bv = BitVectorConversionUtils.convert_uint64_list_to_bitvector(membership.usergroups_bv,
                                                                           len(self.usergroup_idxs))
            groups = BitVectorConversionUtils.bitvector_and_indexes_to_groups(bv, self.usergroup_idxs)
            membership_dict[(membership.userid.high64, membership.userid.low64)] = groups
        return membership_dict


class UsergroupMappingDataFactory:
    @staticmethod
    def create_usergroup_mapping_data(group_memberships, revision):
        """
       :param dict group_memberships: A dict with mapping from users to usergroup membership,
                                      i.e {(0,1): [1, 2], (0,2): [1,2]}  (userid is tuple of (high64,low64))
       :param int revision: The mapping revision as saved in management
       :return: UsergroupMappingData which is in BitVector representation, ready to be sent to agent.
       :rtype: UsergroupMappingData
       For examples see tests/common/py/utils/test_usergroup_mapping.py
       """
        unique_groups = BitVectorConversionUtils.get_unique_groups_from_membership_dict(group_memberships)
        return UsergroupMappingData(
            group_memberships=BitVectorConversionUtils.build_bv_membership_list_from_dict(group_memberships,
                                                                                          unique_groups),
            usergroup_idxs=BitVectorConversionUtils.build_index_mapping_list(unique_groups),
            revision=revision,
            is_full_update=True)

    @staticmethod
    def create_usergroup_mapping_data_diff(old, new):
        """
        :param UsergroupMappingData old: the previous mapping data
        :param UsergroupMappingData new: the new mapping data
        :return: an UsergroupMappingData object that represents a diff between two mappings.
        :rtype: UsergroupMappingData
        For examples see tests/common/py/utils/test_usergroup.py
        """
        changed_groups = UsergroupMappingDataFactory.get_changed_groups_between_mappings(old, new)
        index_mapping = BitVectorConversionUtils.build_index_mapping_list(changed_groups)
        new_membership_dict = new.get_usergroup_memberships_as_dict()
        old_membership_dict = old.get_usergroup_memberships_as_dict()
        redundant_users = {}
        for user, bv in new_membership_dict.items():
            if old_membership_dict.get(user) and old_membership_dict[user] == new_membership_dict[user]:
                redundant_users[user] = bv
        new_membership_dict = {user: bv for user, bv in new_membership_dict.items() if user not in redundant_users}
        group_memberships = BitVectorConversionUtils.build_bv_membership_list_from_dict(
            group_memberships=new_membership_dict, groups=changed_groups)
        return UsergroupMappingData(group_memberships=group_memberships,
                                    usergroup_idxs=index_mapping,
                                    revision=new.revision,
                                    is_full_update=False)

    @staticmethod
    def from_dict(mapping_data_dict):
        if mapping_data_dict.get('policy'):
            mapping_data_dict = mapping_data_dict.get('policy')
        group_memberships_list = mapping_data_dict.get('group_memberships')
        usergroup_idxs_list = mapping_data_dict.get('usergroup_idxs')
        usergroup_idxs = [UsergroupToIndexMapping(usergroup=np.uint16(idx.get('usergroup')),
                                                  index=(np.uint16(idx.get('index'))))
                          for idx in usergroup_idxs_list]
        group_memberships = []
        for membership in group_memberships_list:
            userid = Uint128(low64=membership.get('userid').get('low64'),
                             high64=membership.get('userid').get('high64'))
            usergroups_bv = membership.get('usergroups_bv')
            group_memberships.append(UserToUserGroups(userid=userid, usergroups_bv=usergroups_bv))
        revision = mapping_data_dict.get('revision')
        is_full_update = mapping_data_dict.get('is_full_update')
        return UsergroupMappingData(group_memberships, usergroup_idxs, revision, is_full_update)

    @staticmethod
    def get_changed_groups_between_mappings(old, new):
        """
        :param UsergroupMappingData old: the previous mapping data
        :param UsergroupMappingData new: the new mapping data
        :return: a list of groups that were added\removed between the two revisions
        :rtype: list
        """
        all_changed_groups = set()
        for membership in new.group_memberships:  # For each user
            new_groups = set(new.get_single_user_group_list(int(membership.userid)))
            old_groups = set(old.get_single_user_group_list(int(membership.userid)))
            changed_groups = new_groups.symmetric_difference(old_groups)
            all_changed_groups.update(changed_groups)
        return list(all_changed_groups)

    @staticmethod
    def users_removed_between_mappings(old, new):
        """
        :param UsergroupMappingData old: the previous mapping data
        :param UsergroupMappingData new: the new mapping data
        :return: if any user from the previous mapping is missing in the new mapping
        :rtype: bool
        """
        new_users_set = (membership.userid for membership in new.group_memberships)
        for membership in old.group_memberships:
            if membership.userid not in new_users_set:
                return True
        return False

    @staticmethod
    def validate_diff_not_empty(mapping_data_diff):
        if not mapping_data_diff.usergroup_idxs or not mapping_data_diff.group_memberships:
            return False
        return True


class BitVectorConversionUtils:

    @staticmethod
    def build_index_mapping_list(groups):
        """
        :param list groups: a list of groups
        :return: a list of UsergroupToIndex mapping objects, that indicate which bit in the bitvector corresponds to
         which group.
        :rtype: list
        """
        return [UsergroupToIndexMapping(usergroup=group, index=index) for index, group in
                enumerate(groups)]

    @staticmethod
    def build_bv_membership_list_from_dict(group_memberships, groups=None):
        """
        :param dict group_memberships: a dictionary with user group memberships, i.e {(1, 1): [1,2], (2,2): [3,4]}
                                       the key is a tuple of userid (high64 and low64) and the value is a list of groups
        :param list groups: a list of groups which membership should be checked for each user
        :return:  a UserToUserGroups object for each user, by converting its group memberships to a bitvector
        and then converting that bitvector to a list of uint64 (later concatenated on agent side).
        :rtype: list
        """
        if groups is None:
            groups = BitVectorConversionUtils.get_unique_groups_from_membership_dict(group_memberships)
        group_memberships_list = []
        for user in group_memberships:
            bitvector = bitarray()
            for group in groups:
                bitvector.append(1 if group in group_memberships[user] else 0)
            bitvector.reverse()  # BitArray creates LTR bitvector, we want RTL
            group_memberships_list.append(UserToUserGroups(userid=Uint128(high64=user[0], low64=user[1]),
                                                           usergroups_bv=BitVectorConversionUtils.
                                                           convert_bitvector_to_uint64_list(bitvector)))
        return group_memberships_list

    @staticmethod
    def get_unique_groups_from_membership_dict(group_memberships):
        """
        :param dict group_memberships: a dictionary of group memberships (i.e {1: [1,2]}
        :rtype list[int]:
        :return: Flatten all groups into a single list and remove duplicates
        """
        return list(set([group for sublist in
                        [group_memberships[user] for user in group_memberships.keys()]
                        for group in sublist]))

    @staticmethod
    def convert_bitvector_to_uint64_list(bv):
        """
        :param bitarray bv: a bitvector of any size
        :rtype: list[np.uint64]
        :return: a list of uint64 which represents a split bitvector
        Receives a BitVector of any size and splits it into a list of uint64.
        The list is built from right to left, last 64 members are the first uint64 on the list, and so on.
        Example: bitarray(11111...11) (x80 times) -> [1111...11 (x64 times), 11..11 (x16 times)]
        """

        chunk_size = 64
        bv_chunks = []
        while bv:
            bv_chunks.append(bv[-chunk_size:])
            bv = bv[:-chunk_size]
        return [np.uint64(int(bv_chunk.to01(), 2)) for bv_chunk in bv_chunks]

    @staticmethod
    def convert_uint64_list_to_bitvector(bv_chunks, bv_len):
        """
        :param list[np.uint64] bv_chunks: chunks of the original bitvector that were split into uint64 list
        :param int bv_len: the length of the desired bitvector
        :return: the complete bitvector
        :rtype: bitarray
        Receives a list of uint64 and converts it to a single BitVector
        """
        if not bv_chunks:
            return bitarray()
        bv_string = ""
        for chunk in bv_chunks[:-1]:
            bv_string = format(chunk, "064b") + bv_string
        bv_string = format(bv_chunks[-1], 'b') + bv_string  # Remove padding from last member to remove leading 0
        arr = [1 if char == '1' else 0 for char in bv_string]
        bv = bitarray()
        len_diff = bv_len - len(arr)
        if len_diff > 0:  # Fill missing zeroes from left
            bv.extend([0 for _ in range(len_diff)])
        bv.extend(arr)
        return bv

    @staticmethod
    def bitvector_and_indexes_to_groups(bitvector, indexes):
        """
        :param bitarray bitvector: a bitvector
        :param list[UsergroupToIndexMapping] indexes: a list of usergroup to index mapping
        :return: a list of groups that the user is a member of (only the groups with the group bit turned on)
        :rtype: list[np.uint16]
        Convert a bitvector with its index mapping to a list of groups the user is member of.
        For example, bitvector 110 and indexes [1: 123, 2: 456, 3: 789] will return [123, 456].
        """
        group_list = []
        index_dict = {mapping.index: mapping.usergroup for mapping in indexes}
        bitvector.reverse()  # For convenience, we traverse BV from left to right
        for i, bit in enumerate(bitvector):
            if bit == 1:
                group_list.append(index_dict[i])
        return group_list
