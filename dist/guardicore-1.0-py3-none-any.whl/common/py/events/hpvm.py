from enum import IntEnum  # USE enum34 PACKAGE FOR THIS

__author__ = 'Lior'

class RedirectActionDetails(IntEnum):
    Empty = 0
    RejectError = 1
    RejectNoService = 2
    RejectNonAvailable = 3
    RejectPreviousFailure = 4
    RejectAttackerConfigurationError = 5
    RejectBlockingList = 6
    RejectOsMismatch = 7
    RejectAllocationLoadBalancing = 8

class RedirectAction(IntEnum):
    Inspect = 1
    Reject = 2
    Ignore = 3


class HPVMState(IntEnum):
    Enable = 1
    Disable = 2

