import attr
from common.py.clouds import common_opts
from common.py.utils.config import cfg
from common.py.utils.config.oslo_config import types
from common.py.utils.config.types import Structure


MAX_NUM_ENTRIES_IN_LOG = 3000
DEFAULT_ENTRIES_IN_CHUNK = 1000
DEFAULT_JUMP_FACTOR = 8
DEFAULT_REVEAL_POLLING_PERIOD = 60
DEFAULT_MD_POLLING_PERIOD = 30
POLICY_VALIDATION_ATTEMPT_TIME = DEFAULT_MD_POLLING_PERIOD + 5

MAXIMUM_RULES = 10000
MAXIMUM_GC_RULES = 1002
MAXIMUM_SITES = 1000
ENTRIES_PER_SITE = 195
OVERALL_SUBNETS = 47500


@attr.s()
class LPARAdvancedConfig(object):
    disable_adaptive_max_events = attr.ib(default=False)
    maximum_number_events = attr.ib(default=MAX_NUM_ENTRIES_IN_LOG)
    high_watermark_time_percent = attr.ib(default=80)
    low_watermark_time_percent = attr.ib(default=20)
    adaptive_jump_factor = attr.ib(default=DEFAULT_JUMP_FACTOR)
    ftp_block_size = attr.ib(default=8192)
    entries_in_read_chunk = attr.ib(default=DEFAULT_ENTRIES_IN_CHUNK)
    ftp_connection_reuse_time = attr.ib(default=300)
    ftp_connection_retries = attr.ib(default=3)
    log_retention = attr.ib(default=4)
    verbose_log = attr.ib(default=False)
    use_ftps = attr.ib(default=True)
    ignore_pasv_host = attr.ib(default=False)
    add_external_address = attr.ib(default=False)
    aggregator_behind_nat = attr.ib(default=False)
    maximum_gc_rules = attr.ib(default=MAXIMUM_GC_RULES)
    maximum_rl_rules = attr.ib(default=MAXIMUM_RULES)
    maximum_sites = attr.ib(default=MAXIMUM_SITES)
    entries_per_site = attr.ib(default=ENTRIES_PER_SITE)
    overall_subnets = attr.ib(default=OVERALL_SUBNETS)
    policy_validation_time = attr.ib(default=None)


lpar_advanced = LPARAdvancedConfig()

lpar_config_str = []
for k, v in lpar_advanced.__dict__.items():
    if v is not None:
        lpar_config_str.append(str(k) + ":" + str(v))

SINGLE_LPAR_STRUCTURE = Structure([cfg.StrOpt('lpar_name', help="device name"),
                                   cfg.Opt('address', type=types.String(), help="IP address of the LPAR (IP or IP:port)"),
                                   cfg.StrOpt('user', help="user name for the LPAR access"),
                                   cfg.StrOpt('password', help="password for the LPAR access", secret=True),
                                   cfg.Opt('data_ips', help="IPs configured in LPAR (semicolon separated)",
                                           type=cfg.types.String()),
                                   ],
                                  name='single_lpar_struct')

lpar_opts = [cfg.Opt(name='lpar_agents_list', type=types.List(item_type=SINGLE_LPAR_STRUCTURE, bounds=True),
                     default=[]),
             cfg.IntOpt('reveal_polling_period', help="Interval (in seconds) to check for network events ",
                        default=DEFAULT_REVEAL_POLLING_PERIOD),
             cfg.IntOpt('machine_details_polling_period', help="Interval (in seconds) to check for network events ",
                        default=DEFAULT_MD_POLLING_PERIOD),
             cfg.ExtendedOpt('advanced', default=lpar_config_str,
                             type=types.List(item_type=types.String(unicode=True, quotes=True),
                                             bounds=True),
                             multi_line_text=True,
                             help="Advanced configuration parameters")
             ] + common_opts

LPAR_OPT_STRUCTURE = Structure(lpar_opts)


cfg.CONF.register_opt(cfg.Opt(name='lpar_configuration', type=LPAR_OPT_STRUCTURE), group="orchestration")
def register_opts():
    pass
