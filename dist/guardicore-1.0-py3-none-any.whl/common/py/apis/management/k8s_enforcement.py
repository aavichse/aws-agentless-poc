import attr

from common.py.events.attrs import Dictable, enum_attr, int_attr, string_attr
from common.py.events.agent import AgentStatusFlagType
from common.py.utils.attr_base import AttrBase
from common.py.apis.management.agent_details import StatusFlagSeverity


@attr.s()
class K8sClusterInfoUpdate(Dictable):
    cluster_id = attr.ib(type=str)
    cluster_name = attr.ib(type=str)
    cluster_version = attr.ib(type=str)
    agent_tag = attr.ib(type=str)
    policy_revision = attr.ib(type=int)
    inventory_revision = attr.ib(type=int)
    configuration_revision = attr.ib(type=int)
    flags = attr.ib(default=attr.Factory(dict)) # type: {AgentStatusFlagType: K8sEnforcementStatusFlags}
    supported_features = attr.ib(default=attr.Factory(list)) # type: "EnforcementFeatures"


@attr.s(frozen=True)
class K8sEnforcementStatusFlags(AttrBase):
    flag_type = enum_attr(enum_type=AgentStatusFlagType)
    raised_time = attr.ib(type=int, default=None)
    description = attr.ib(type=str, default='')
    severity = enum_attr(enum_type=StatusFlagSeverity, default=StatusFlagSeverity.INFORMATION)
    details = attr.ib(type=dict, default=attr.Factory(dict))

    @classmethod
    def from_dict(cls, data):
        return cls(**data)


@attr.s
class K8sEnforcementConfiguration(Dictable):
    debug_enabled = attr.ib(type=bool)
    enforcement_mode = attr.ib(type=bool)


@attr.s
class K8sEnforcementConfigurationUpdate(Dictable):
    cluster_id = string_attr()
    configuration = attr.ib(type=K8sEnforcementConfiguration)
    configuration_revision = int_attr()
