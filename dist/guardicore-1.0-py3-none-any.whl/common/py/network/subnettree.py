import sys

import six

if not sys.platform.startswith('win'):
    from SubnetTree import SubnetTree
else:
    from pytricia import PyTricia as SubnetTree