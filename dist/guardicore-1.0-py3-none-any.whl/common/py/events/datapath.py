from enum import IntEnum

__author__ = 'Eddie'


class RedirectDirection(IntEnum):
    FromVif = 0
    ToVif = 1
    Both = 2


class DatapathAction(IntEnum):
    Redirect = 1
    Monitor = 2
    RateLimited = 3


class RedirectReason(IntEnum):
    SynTimeout = 1
    BlockedPort = 2
    ArpTimeout = 3
    FirewallBlockedPort = 4
    UDPUnreachable = 5
    PolicyBlockedPort = 6


class SPEventType(IntEnum):
    SPClosed = 1


class NonTCPServiceTypes(IntEnum):
    ARP_TYPE = 0
    ICMP_TYPE = (2**16 + 1) # 65537


class VisibilityMessageType(IntEnum):
    VISIBILITY = 1
    TRAFFIC_INFO = 2
