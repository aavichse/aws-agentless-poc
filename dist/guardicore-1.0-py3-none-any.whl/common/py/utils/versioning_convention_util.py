import re

from common.logger import get_logger

LOGGER = get_logger()

NEW_VERSIONING = "new"
OLD_VERSIONING = "old"
NO_MATCH = "none"

NEW_CONVENTION_REGEX = r"(v|V)(?P<major>\d+)\.(?P<minor>\d+)\.(?P<fix>\d+)\-(?P<date>\d{6})\.(?P<commit_id>[a-zA-Z\d]{7})\.(?P<job_num>\d+)$"
OLD_CONVENTION_REGEX = r"(build_v)(?P<major>\d+)_(?P<date>\d{8})_(?P<serial>\d+)$"


class VersioningConventionUtil(object):

    @classmethod
    def versioning_classifier(cls, release_candidate, check_old_versioning=True):
        new_versioning_pattern = re.compile(NEW_CONVENTION_REGEX)
        old_versioning_pattern = re.compile(OLD_CONVENTION_REGEX) if check_old_versioning else None
        if new_versioning_pattern.match(release_candidate):
            LOGGER.debug("versioning classifier result for: {} is NEW_VERSIONING".format(str(release_candidate)))
            return NEW_VERSIONING
        elif check_old_versioning and old_versioning_pattern.match(release_candidate):
            LOGGER.debug("versioning classifier result for: {} is OLD_VERSIONING".format(str(release_candidate)))
            return OLD_VERSIONING
        else:
            LOGGER.debug("versioning classifier result for: {} is NO_MATCH".format(str(release_candidate)))
            return NO_MATCH

    @classmethod
    def parse_new_versioning_rc(cls, release_candidate):
        match = re.search(NEW_CONVENTION_REGEX, release_candidate)
        if not match:
            LOGGER.debug("{} doesn't match new versioning".format(str(release_candidate)))
            return {}

        major = match.group('major')
        minor = match.group('minor')
        fix = match.group('fix')
        date = "20" + match.group('date')
        commit_id = match.group('commit_id')
        job_num = match.group('job_num')

        return {"major": int(major), "minor": int(minor), "fix": int(fix), "date": date,
                "commit_id": commit_id,
                "job_num": int(job_num)}

    @classmethod
    def parse_old_versioning_rc(cls, release_candidate):
        match = re.search(OLD_CONVENTION_REGEX, release_candidate)
        if not match:
            LOGGER.debug("{} doesn't match old versioning".format(str(release_candidate)))
            return {}
        major = match.group('major')
        date = match.group('date')
        serial = match.group('serial')

        return {"major": int(major), "date": date, "serial": int(serial)}

    @staticmethod
    def convert_new_versioning_rc_to_old(release_candidate):
        # translate "new" convention archive names to "old convention"
        # v<major>.<minor>.<hash>-<YYMMDD>.<hash>.<jenkins_id> ---> build_v<major>_<YYYYMMDD>_<jenkins_id>

        if not release_candidate:
            return ''
        match = re.search(OLD_CONVENTION_REGEX[:-1], release_candidate)
        if match:
            return match.group()
        match = re.search(NEW_CONVENTION_REGEX[:-1], release_candidate)
        if match:
            major = match.group('major')
            date = "20" + match.group('date')
            serial = match.group('job_num')
            return 'build_v' + major + '_' + date + '_' + serial
        return release_candidate

    @staticmethod
    def is_rc1_older_than_rc2_new_versioning(rc1, rc2):
        parsed_rc1 = VersioningConventionUtil.parse_new_versioning_rc(release_candidate=rc1)
        parsed_rc2 = VersioningConventionUtil.parse_new_versioning_rc(release_candidate=rc2)
        if parsed_rc1['major'] != parsed_rc2['major']:
            LOGGER.error("The major versions of the compared RC's: {}, {} are not equal {} != {}".format(rc1, rc2,
                                                                                                         parsed_rc1[
                                                                                                             'major'],
                                                                                                         parsed_rc2[
                                                                                                             'major']))
        if parsed_rc1['minor'] < parsed_rc2['minor']:
            return True
        if parsed_rc1['minor'] == parsed_rc2['minor']:
            if parsed_rc1['fix'] < parsed_rc2['fix']:
                return True
            if parsed_rc1['fix'] == parsed_rc2['fix']:
                if parsed_rc1['date'] < parsed_rc2['date']:
                    return True
                if parsed_rc1['date'] == parsed_rc2['date'] and parsed_rc1['job_num'] < parsed_rc2['job_num']:
                    return True
        return False

    @staticmethod
    def is_rc1_older_than_rc2_old_versioning(rc1, rc2):
        parsed_rc1 = VersioningConventionUtil.parse_old_versioning_rc(release_candidate=rc1)
        parsed_rc2 = VersioningConventionUtil.parse_old_versioning_rc(release_candidate=rc2)
        if parsed_rc1['date'] < parsed_rc2['date']:
            return True
        if parsed_rc1['date'] == parsed_rc2['date'] and \
                parsed_rc1['serial'] < parsed_rc2['serial']:
            return True
        return False
