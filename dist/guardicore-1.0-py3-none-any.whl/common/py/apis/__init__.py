import inspect
import os
from enum import IntEnum, Enum

from common import get_guardicore_storage_root

__author__ = 'Lior'

BASE_TLS_PATH = os.path.join(get_guardicore_storage_root(), 'storage', 'certs', 'tls')

MANAGEMENT_REST_API_PORT = 443
MANAGEMENT_INSTANCE_BASE_PORT = 8000
DEFAULT_REST_API_PORT = 8442

GUARDICORE_VHOST_NAME = 'guardicore'
DEFAULT_RABBITMQ_USERNAME = 'guardicore'
DEFAULT_RABBITMQ_PASSWORD = 'mbuble'
REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT = 120  # This helps detect disconnections earlier
DEFAULT_RABBIT_HEARTBEAT = 300
DEFAULT_RABBITMQ_CALLBACK_POOL_SIZE = None # If set to 'None' Pool is unlimited

DLQ_MESSAGE_TTL = 100000

RPC_MSG_TYPE_KEY = 'message_type'

# queue pools
DATA_RPC_QUEUE_POOL_SIZE = 100


class MessagePriority(object):
    # only for connectivity checks (which are the only thing which is expected to return fast)
    CONNECTIVITY_CHECK_MESSAGE_PRIORITY = 2
    # blocking messages (usually on component initialization)
    BLOCKING_MESSAGE_PRIORITY = 1
    # event messages
    LOW_MESSAGE_PRIORITY = 0


RPC_MESSAGE_TIMEOUT_ADDITIONAL = 1

DEFAULT_RPC_TIMEOUT_SECS = {
    MessagePriority.CONNECTIVITY_CHECK_MESSAGE_PRIORITY: 30,
    MessagePriority.BLOCKING_MESSAGE_PRIORITY: 10 * 60
}

REST_API_BASE_URL = '/api/v2.0/'
NEW_REST_API_BASE_URL = '/api/v3.0/'
AUTOMATION_API_BASE_URL = NEW_REST_API_BASE_URL + 'api/automation_api/v1/'
REST_API_BASE_URL_V4 = '/api/v4.0/'
REST_API_ORIGIN = "API_CALL"


class RPCQueue(object):
    # Monicore
    MONITOR_RPC_QUEUE_NAME = 'monitor_management_rpc_queue'
    MANAGEMENT_UPGRADER_QUEUE_NAME = 'management_upgrader_queue'
    MANAGEMENT_DIFFPATCH_QUEUE_NAME = 'management_diffpatch_queue'
    MANAGEMENT_ROOTFS_UPGRADE_QUEUE_NAME = 'management_rootfs_upgrader_{queue_number}'

    # Management RPC Queues
    CONTROL_EVENTS_RPC_QUEUE_NAME = 'management_rpc_queue'
    DECEPTION_EVENTS_RPC_QUEUE_NAME_TEMPLATE = 'deception_rpc_server_{queue_number}'
    VISIBILITY_RPC_QUEUE_NAME = 'visibility_rpc_server'
    DASHBOARD_RPC_QUEUE_NAME = 'dashboard_rpc_server'
    NETWORK_EVENTS_RPC_QUEUE_NAME = 'network_events_rpc_queue'
    DNS_INFO_RPC_QUEUE_NAME = 'dns_info_rpc_queue'
    ORCHESTRATION_RPC_QUEUE_NAME = 'orchestration_rpc_queue'
    AGENT_CONFIGURATION_RPC_QUEUE_NAME = 'agent_configuration_rpc_queue'
    MACHINE_UPDATE_RPC_QUEUE_NAME = 'machine_update_rpc_queue'
    DETECTION_AGENT_RPC_QUEUE_NAME = 'detection_agent_rpc_queue'
    DC_INVENTORY_RPC_QUEUE_NAME = 'datacenter_inventory_rpc_queue'
    AGENT_EVENT_RPC_QUEUE_NAME = 'agent_event_rpc_queue'
    AGENT_INSTALLATION_PROFILES_RPC_QUEUE_NAME = 'agent_installation_profiles_rpc_queue'
    SYSTEM_EVENTS_RPC_QUEUE_NAME = 'system_events_rpc_queue'
    ACTIVE_DIRECTORY_RPC_QUEUE_NAME = 'active_directory_rpc_queue'
    AGENT_UPGRADES_RPC_QUEUE = 'agent_upgrades_rpc_queue'
    AGENT_KO_UPGRADES_RPC_QUEUE = 'agent_ko_upgrades_rpc_queue'
    PLUGINS_SERVICE_RPC_QUEUE_NAME = 'plugins_service_rpc_queue'
    AGENT_QUERY_RPC_QUEUE_NAME = 'osquery_rpc_queue'
    EVENTS_EXPORT_MGT_RPC_QUEUE_NAME = 'events_export_mgt_rpc_queue_name'
    EVENTS_EXPORT_AGGR_RPC_QUEUE_NAME = 'events_export_aggr_rpc_queue_name'
    NETWORK_LOGS_EXPORT_MGT_RPC_QUEUE_NAME = 'network_logs_export_mgt_rpc_queue_name'
    NETWORK_LOGS_EXPORT_AGGR_RPC_QUEUE_NAME = 'network_logs_export_aggr_rpc_queue_name'
    COMMANDS_EXPORT_AGGR_RPC_QUEUE_NAME = 'commands_export_aggr_rpc_queue_name'
    USER_GROUPS_SNAPSHOT_RPC_QUEUE_NAME = 'user_groups_snapshot_rpc_queue'
    SYSLOG_ADDITIONAL_CONF_AGGR_RPC_QUEUE_NAME = 'syslog_additional_conf_aggr_rpc_queue_name'

    # Detection RPC Queues
    ENRICHMENT_MANAGERS_DECEPTION_INCIDENT_QUEUE_NAME = 'enrichment_managers_deception_incident'
    ENRICHMENT_MANAGERS_PASSIVE_DETECTION_INCIDENT_QUEUE_NAME = 'enrichment_managers_passive_detection_incident'
    ENRICHMENT_MANAGERS_INTEGRITY_INCIDENT_QUEUE_NAME = 'enrichment_managers_passive_integrity_incident'
    Q_CLIENT_QUEUE_NAME = 'q_client_daemons'
    VISIBILITY_INSPECTION_POLICY_VIOLATIONS_QUEUE_NAME = 'visibility_inspection_policy_violations'
    VISIBILITY_INSPECTION_REPUTATION_QUEUE_NAME = 'visibility_inspection_reputation'
    REMOTE_ELASTIC_SYNCING_QUEUE_NAME = 'remote_elastic_syncing_manager'

    # Management RPC DLQs
    VISIBILITY_RPC_DLQ_NAME = 'visibility_rpc_server_dlq'

    SINGLE_QUEUE_NAMES = []  # auto-generated in a sec
    MULTI_QUEUE_NAMES = [DECEPTION_EVENTS_RPC_QUEUE_NAME_TEMPLATE]

    # Dashboard Streamer RPC Queues
    DASHBOARD_STREAMER_RPC_QUEUE_NAME_PREFIX = 'dashboard_streamer_rpc'


class RPCExchange(object):
    # Honeypot
    HONEYPOT_EXCHANGE_NAME = 'honeypot_exchange'

    # Aggregator & Aggregator components
    AGGREGATOR_EXCHANGE_NAME = 'aggregator_exchange'
    DATAPATH_EXCHANGE_NAME = 'datapath_exchange'
    MITIGATION_AGENT_EXCHANGE_NAME = 'mitigation_agent_exchange'
    DETECTION_AGENTS_SERVER_EXCHANGE_NAME = 'detection_agents_server_exchange'
    CONTROLLER_SERVER_EXCHANGE_NAME = 'controller_server_exchange'
    ENFORCEMENT_SERVER_EXCHANGE_NAME = 'enforcement_server_exchange'
    DC_INVENTORY_AGGR_SERVICE_EXCHANGE_NAME = 'datacenter_inventory_consumer_exchange'

    # Monicore
    MONITOR_EXCHANGE_NAME = 'component_monitor_exchange'

    # Management Internals - Detection
    ENRICHERS_EXCHANGE_NAME = 'enrichers'
    VISIBILITY_INSPECTOR_EXCHANGE_NAME = 'visibility_inspector'
    SIMILARITY_EXCHANGE_NAME = 'similarity'
    Q_CLIENT_EXCHANGE_NAME = 'q_client'
    REMOTE_ELASTIC_SYNCING_EXCHANGE_NAME = 'remote_elastic_syncing'
    AGENT_DIAGNOSTICS_EXCHANGE_NAME = 'agent_diagnostics'

    # RPC Servers Exchanges
    DATA_EXPORTER_EXCHANGE_NAME = 'data_exporter_exchange'  # changed in order to enable the exchange type change
    DATA_EXPORTER_MGMT_ONLY_EXCHANGE_NAME = 'data_export_exchange_mgmt_only'
    CONTROL_EXCHANGE_NAME = 'control_exchange'
    VISIBILITY_EXCHANGE_NAME = 'visibility_exchange'
    DECEPTION_EXCHANGE_NAME = 'deception_exchange'
    NETWORK_EVENT_EXCHANGE_NAME = 'network_event_exchange'
    ORCHESTRATION_EXCHANGE_NAME = 'orchestration_exchange'
    AGENT_CONFIGURATION_EXCHANGE_NAME = 'agent_configuration_exchange'
    MACHINE_UPDATE_EXCHANGE_NAME = 'machine_update_exchange'
    AGENT_EVENT_EXCHANGE_NAME = 'agent_event_exchange'
    DNS_EXCHANGE_NAME = 'dns_exchange'
    DASHBOARD_EXCHANGE_NAME = 'dashboard_exchange'
    DC_INVENTORY_EXCHANGE_NAME = 'datacenter_inventory_exchange'
    LOG_EVENTS_EXCHANGE_NAME = 'log_events_exchange'
    ACTIVE_DIRECTORY_EXCHANGE_NAME = 'active_directory_exchange'
    PLUGINS_SERVICE_EXCHANGE_NAME = 'plugins_service_exchange'
    DASHBOARD_STREAMER_EXCHANGE_NAME = 'dashboard_streamer_exchange'
    USER_GROUPS_SNAPSHOT_EXCHANGE_NAME = 'user_groups_snapshot_exchange'

    # Management RPC DLX
    VISIBILITY_RPC_DLX_NAME = 'visibility_rpc_server_dlx'


RPCQueue.SINGLE_QUEUE_NAMES = [member_value
                               for member_name, member_value in inspect.getmembers(RPCQueue)
                               if (not member_name.startswith('_')  # eliminates builtin properties
                                   and isinstance(member_value, str)
                                   and member_value not in RPCQueue.MULTI_QUEUE_NAMES)]

ALL_RPC_EXCHANGE_NAMES = [member_value
                          for member_name, member_value in inspect.getmembers(RPCExchange)
                          if not member_name.startswith('_')  # eliminates builtin properties
                          and isinstance(member_value, str)]

FANOUT_RPC_EXCHANGE_NAMES = [RPCExchange.MONITOR_EXCHANGE_NAME,
                             RPCExchange.DATA_EXPORTER_EXCHANGE_NAME]

EXCHANGES_TO_FEDERATE = [RPCExchange.MACHINE_UPDATE_EXCHANGE_NAME]


class RPCMessage(object):
    class Aggregator(object):
        AGGREGATOR_NOTIFY_AGGREGTORS_LIST_CHANGE = 'aggregator_notify_aggregators_list_change'
        AGGREGATOR_NOTIFY_HONEYPOTS_LIST_CHANGE = 'aggregator_notify_honeypot_list_change'
        AGGREGATOR_GET_ORCHESTRATION_DETAILS = 'aggregator_get_orchestration_details'
        AGGREGATOR_GET_STATE = 'aggregator_get_state'
        AGGREGATOR_NOTIFY_ORCHESTRATION_CONFIGURATION_CHANGE = 'aggregator_notify_orchestration_configuration_change'
        AGGREGATOR_ORCHESTRATION_CONNECTIVITY_TEST = 'aggregator_orchestration_connectivity_test'
        AGGREGATOR_REPORT_ORCHESTRATION_CONNECTIVITY_TEST_RESULT = 'aggregator_report_orchestration_connectivity_test_result'
        AGGREGATOR_GET_AGENTS_INSTALLATION_PASSWORD_RPC_FUNC_NAME = 'get_agents_installation_password'
        AGGREGATOR_GET_INSTALLATION_PROFILES_CONFIGURATION_RPC_FUNC_NAME = 'get_installation_profiles_configuration'
        AGGREGATOR_FLUSH_CACHE = 'aggregator_flush_cache'
        AGGREGATOR_DEBUG_CONNECT = 'aggregator_debug_connect'
        AGGREGATOR_AGENT_SDK_CONNECT = 'aggregator_agent_sdk_connect'
        AGGREGATOR_GET_CONFIGURATION = 'aggregator_get_configuration'
        AGGREGATOR_GET_ZOOKEEPER_ID = 'aggregator_get_zookeeper_id'
        AGGREGATOR_GET_PROTECTED_SUBNETS = 'aggregator_list_protected_subnets'
        AGGREGATOR_PROTECTED_SUBNETS_MESSAGE_TYPE = 'aggregator_update_protected_subnets'
        AGGREGATOR_REPORT_AGENTS_ALIVE_RPC_FUNC_NAME = 'alive_agents'
        AGGREGATOR_REPORT_AGENT_EVENT_RPC_FUNC_NAME = 'aggregator_report_agent_event_rpc'
        AGGREGATOR_REPORT_AGENT_UNINSTALL_EVENT_RPC_FUNC_NAME = 'aggregator_report_agent_uninstall_event_rpc'
        AGGREGATOR_LIST_ALL_AGGREGATORS_RPC_FUNC_NAME = "aggr_list_all_aggregators"
        AGGREGATOR_LIST_ALL_HONEYPOTS_RPC_FUNC_NAME = "aggr_list_all_honeypots"
        AGGREGATOR_REPORT_AGENT_UPGRADES_RPC_FUNC_NAME = 'aggregator_report_agent_upgrades'
        AGGREGATOR_REPORT_AGENT_KO_UPGRADES_RPC_FUNC_NAME = 'aggregator_report_agent_ko_upgrades'
        AGGREGATOR_OSQUERY_RESULTS_RPC_FUNC_NAME = 'aggregator_osquery_result'
        AGGREGATOR_GET_SYSTEM_CONFIGURATION_RPC_FUNC_NAME = 'aggregator_get_system_configuration'
        AGGREGATOR_GET_AGENT_MONITORING_CONFIGURATION_RPC_FUNC_NAME = 'aggregator_get_agent_monitoring_configuration'
        AGGREGATOR_REPORT_AGENT_MIGRATION_RPC_FUNC_NAME = 'aggregator_report_agent_migrations'
        AGGREGATOR_CLEAR_NGINX_CACHE = 'aggregator_clear_nginx_cache'
        AGGREGATOR_NOTIFY_ORCHESTRATION_USER_GROUPS_WITH_AZURE_AD_CHANGED = 'aggregator_notify_orchestration_user_groups_with_azure_ad_changed'
        AGGREGATOR_RUN_BLOODHOUND = 'aggregator_run_bloodhound'
        AGGREGATOR_REPORT_BLOODHOUND_STATUS = 'aggregator_report_bloodhound_status'
        AGGREGATOR_ABORT_BLOODHOUND = 'aggregator_abort_bloodhound'
        AGGREGATOR_DELETE_BLOODHOUND = 'aggregator_delete_bloodhound'

    class K8sOperations(object):
        K8S_CLUSTER_OPERATIONS_UPDATE_CLUSTER_INFO_RPC_FUNC_NAME = 'k8s_cluster_operation_update_cluster_info'
        K8S_CLUSTER_CONFIG_UPDATE_MESSAGE_TYPE = 'k8s_cluster_config_update'

    class Agent(object):
        AGENT_CONFIG_UPDATE_MESSAGE_TYPE = 'agents_configurations_update'
        AGENTS_CONFIGURATIONS_REPORT_RESULT = 'agents_configurations_update_result'
        AGENT_GET_CONFIGURATION = 'agents_get_configuration'
        INSTALLATION_PROFILES_CONFIGURATION_UPDATE_MESSAGE_TYPE = 'installation_profiles_configuration_update'

    class Datapath(object):
        DATAPATH_POLICY_CHANGE_MESSAGE_TYPE = 'policy'
        DATAPATH_STATE_CHANGE_MESSAGE_TYPE = 'state'
        DATAPATH_SERVICE_PROVIDER_CLOSE_NOTIFICATION_MESSAGE_TYPE = 'sp_close_dp_notification'
        DATAPATH_GET_STATE_RPC_FUNC_NAME = 'datapath_get_state_rpc'
        DATAPATH_GET_POLICIES_RPC_FUNC_NAME = 'datapath_get_policies_rpc'
        DATAPATH_REPORT_DNS_INFO_RPC_FUNC_NAME = 'datapath_report_dns_info'

    class Honeypot(object):
        HONEYPOT_STATE_CHANGE_MESSAGE_TYPE = 'state'
        HONEYPOT_MACHINE_DETAILS_UPDATE_MESSAGE_TYPE = 'machine_details'
        HONEYPOT_GET_STATE_RPC_FUNC_NAME = 'honeypot_get_state_rpc'
        HONEYPOT_GET_MACHINE_DETAILS_RPC_FUNC_NAME = 'honeypot_get_machine_details_ips_rpc'
        HONEYPOT_GET_SSH_KEY_PAIRS_SEEDS_POOL_RPC_FUNC_NAME = 'honeypot_get_ssh_key_pairs_seeds_pool'
        HONEYPOT_REPORT_NEW_SP_INITIAL_STATE = "honeypot_report_new_sp_initial_state"
        HONEYPOT_LIST_ALL_HONEYPOTS_RPC_FUNC_NAME = 'honeypot_list_all_honeypots'
        HONEYPOT_NOTIFY_HONEYPOTS_LIST_CHANGE = 'honeypot_notify_honeypot_list_change'

    class MitigationAgent(object):
        # MitigationAgent-Management API
        MITIGATION_AGENT_STATE_CHANGE_MESSAGE_TYPE = 'state'
        MITIGATION_AGENT_GET_STATE_RPC_FUNC_NAME = 'mitigation_agent_get_state_rpc'
        MITIGATION_AGENT_REPORT_MACHINE_DETAILS_UPDATE_RPC_FUNC_NAME = 'mitigation_agent_report_machine_details_rpc'
        MITIGAIION_AGENT_GET_MAX_CONNECTIONS_PER_AGENT_RPC_FUNC_NAME = 'get_max_connections_per_agent'
        MITIGATION_AGENT_MAX_CONNECTIONS_PER_AGENT_MESSAGE_TYPE = 'max_connections_per_agent'

    class Monitor(object):
        # ComponentMonitor - Interface calls
        MONITOR_GET_DEBUG_LOGS_MESSAGE_TYPE = 'get_debug_logs'
        MONITOR_START_SERVICE_MESSAGE_TYPE = '_create_new_service'
        MONITOR_STOP_SERVICE_MESSAGE_TYPE = 'stop_service'
        MONITOR_RESTART_SERVICE_MESSAGE_TYPE = 'restart_service'

        # ComponentMonitor - RPC calls
        MONITOR_MANAGER_IS_UP_FUNC_NAME = 'monitor_manager_is_up'
        MONITOR_PUT_DEBUG_LOG_RPC_FUNC_NAME = 'put_debug_logs'
        MONITOR_START_SERVICES_RPC_FUNC_NAME = 'start_services_rpc'
        MONITOR_STOP_SERVICES_RPC_FUNC_NAME = 'stop_services_rpc'
        MONITOR_RESTART_SERVICES_RPC_FUNC_NAME = 'restart_services_rpc'
        MONITOR_REPORT_SERVICES_STATUS_RPC_FUNC_NAME = 'report_services_status'
        MONITOR_REPORT_SERVICES_INFORMATION_RPC_FUNC_NAME = 'report_services_information'

        # Upgrader-Management API
        UPGRADE_STATUS_MESSAGE_TYPE = 'upgrade_status'
        INITIATE_UPGRADE_MESSAGE_TYPE = 'initiate_upgrade'
        DIFFERENTIAL_PATCH_STATUS_MESSAGE_TYPE = 'differential_patch_status'
        INITIATE_DIFFERENTIAL_PATCH_MESSAGE_TYPE = 'initiate_differential_patch'
        ROOTFS_UPGRADE_STATUS_MESSAGE_TYPE = 'rootfs_upgrade_status'
        INITIATE_ROOTFS_UPGRADE_MESSAGE_TYPE = 'initiate_rootfs_upgrade'

    class DetectionServer(object):
        # Detection Server - Management API
        DETECTION_AGENTS_SERVER_GET_STATE_RPC_FUNC_NAME = 'detection_agents_server_get_state_rpc'
        DETECTION_AGENTS_SERVER_STATE_CHANGE_MESSAGE_TYPE = 'state'
        DETECTION_AGENTS_SERVER_FIM_SCAN_REPORT_RPC_FUNC_NAME = 'detection_agents_server_fim_scan_report_rpc'
        DETECTION_AGENTS_SERVER_GET_FIM_POLICY_RPC_FUNC_NAME = 'detection_agents_server_get_fim_policy'
        FIM_POLICY_UPDATE_MESSAGE_TYPE = 'update_fim_policy'
        DETECTION_AGENTS_SERVER_OSQUERY_COMMAND_FUNC_NAME = 'detection_agents_server_osquery_command'

    class EnforcementServer(object):
        # Enforcement Server - Management API
        ENFORCEMENT_SERVER_GET_STATE_RPC_FUNC_NAME = 'enforcement_server_get_state_rpc'
        ENFORCEMENT_SERVER_STATE_CHANGE_MESSAGE_TYPE = 'state'
        ENFORCEMENT_POLICY_RPC_FUNC_NAME = 'get_enforcement_policy'
        ENFORCEMENT_POLICY_UPDATE_MESSAGE_TYPE = 'update_enforcement_policy'
        CURRENT_REVISION_NUMBER_RPC_FUNC_NAME = 'get_current_policy_revision'
        CURRENT_REVISION_NUMBER = 'update_current_policy_revision'
        DNS_SECURITY_STATUS_RPC_FUNC_NAME = 'get_dns_blocking_status'
        DNS_SECURITY_STATUS_MESSAGE_TYPE = 'dns_blocking_status'
        DNS_BLOCKLISTS_RPC_FUNC_NAME = 'get_dns_blocklists'
        DNS_BLOCKLISTS_MESSAGE_TYPE = 'dns_blocklists'
        OFF_CORPORATE_CONFIG_RPC_FUNC_NAME = 'get_off_corporate_config'
        OFF_CORPORATE_CONFIG_MESSAGE_TYPE = 'off_corporate_config'
        FAST_POLICY_RPC_FUNC_NAME = 'get_fast_policy_status'
        FAST_POLICY_MESSAGE_TYPE = 'fast_policy_status'
        WORKSITES_CONFIG_RPC_FUNC_NAME = 'get_worksites_config'
        WORKSITES_CONFIG_MESSAGE_TYPE = 'worksites_config'
        USERGROUP_MAPPING_GET_RPC_FUNC = 'get_usergroup_mapping'
        USERGROUP_MAPPING_CHANGED_RPC_FUNC = 'usergroup_mapping_changed'
        USER_GROUP_MAPPING_MESSAGE_TYPE = 'user_group_mapping_feature_status'
        USER_GROUP_MAPPING_CONFIG_GET_RPC_FUNC = 'get_user_group_mapping_config'
        TRAFFIC_ENCRYPTION_NOTIFY_STATUS = 'traffic_encryption_notify_status'
        TRAFFIC_ENCRYPTION_GET_STATUS = 'traffic_encryption_get_status'

    class ControllerServer(object):
        # Controller Server - Management API
        CONTROLLER_SERVER_START_AGENT_MODULES_FUNC_NAME = 'controller_server_start_agent_modules'
        CONTROLLER_SERVER_STOP_AGENT_MODULES_FUNC_NAME = 'controller_server_stop_agent_modules'
        CONTROLLER_SERVER_COLLECT_AGENT_DIAGNOSTICS_FUNC_NAME = 'controller_server_collect_agent_diagnostics'
        CONTROLLER_SERVER_STOP_COLLECT_AGENT_DIAGNOSTICS_FUNC_NAME = 'controller_server_stop_collect_agent_diagnostics'
        CONTROLLER_SERVER_SEND_AGENT_DIAGNOSTICS_FUNC_NAME = 'controller_server_send_agent_diagnostics'
        CONTROLLER_SERVER_UPGRADE_AGENT_BUNDLES = 'controller_server_upgrade_agent_bundles'
        CONTROLLER_SERVER_UPGRADE_AGENT_KO = 'controller_server_upgrade_agent_ko'
        CONTROLLER_SERVER_MIGRATE_AGENTS = 'controller_server_migrate_agents'
        CONTROLLER_SERVER_CONNECTED_AGENTS = 'controller_server_connected_agents'
        FAST_POLICY_RPC_FUNC_NAME = 'get_fast_policy_status'
        FAST_POLICY_MESSAGE_TYPE = 'fast_policy_status'
        CONTROLLER_SERVER_RESTART_AGENTS_FUNC_NAME = 'controller_server_restart_agents'

    class Configuration(object):
        SYSTEM_CONFIGURATION_CHANGE_MESSAGE_TYPE = 'system_configuration_change'
        CONFIGURATION_CHANGED_MESSAGE = 'configuration_changed'

    class Enricher(object):
        # Enricher - Management API
        ENRICHMENT_ENRICH_INCIDENT_MESSAGE_TYPE = 'enrich_incident'
        ENRICHMENT_KILL_WORKER_MESSAGE_TYPE = 'kill_worker'
        ENRICHMENT_INCIDENT_END_MESSAGE_TYPE = 'end_incident'
        ENRICHMENT_NEW_EVENT_MESSAGE_TYPE = 'new_event'
        ENRICHMENT_NEW_EVENTS_MESSAGE_TYPE = 'new_events'

    class VisibilityInspector(object):
        # Visibility Inspector - Management API
        VISIBILITY_INSPECTOR_NEW_BUCKET_MESSAGE_TYPE = 'new_bucket_id'

    class Similarity(object):
        # Similarity - Management API
        SIMILARITY_NEW_INCIDENT_MESSAGE_TYPE = 'new_incident'

    class QClient(object):
        # Q Client - Management API
        Q_CLIENT_START_PROCESSING_MESSAGE_TYPE = 'start_processing'
        Q_CLIENT_EXPORT_INCIDENT_MESSAGE_TYPE = 'export_incident'
        Q_CLIENT_REPORT_MISCLASSIFICATION_MESSAGE_TYPE = 'report_misclassification'

    class RemoteElasticSync(object):
        # Remote Elastic Syncing From Mongo - Management API
        REMOTE_ELASTIC_SYNCING_MESSAGE_TYPE = 'sync_document'

    class Exporters(object):
        # Exporters - Management API
        EXPORT_INCIDENT_MESSAGE_TYPE = 'export_incident'
        EXPORT_INCIDENT_IOCS_MESSAGE_TYPE = 'export_incident_iocs'
        EXPORT_GENERIC_INCIDENT_MESSAGE_TYPE = 'export_generic_incident'
        EXPORT_AUDIT_LOG_ENTRY_MESSAGE_TYPE = 'export_audit_log_entry'
        EXPORT_SYSTEM_ALERT_MESSAGE_TYPE = 'export_system_alert'
        EXPORT_SAVED_MAP_STATUS_MESSAGE_TYPE = 'export_saved_map_status'
        EXPORT_AGENT_LOG_MESSAGE_TYPE = 'export_agent_log'
        EXPORT_AGENT_ALERTS_STATUS_REPORT_MESSAGE_TYPE = 'export_agent_alerts_status_report'
        EXPORT_LABEL_CHANGES_LOG_MESSAGE_TYPE = 'export_label_changes_log'
        EXPORT_NETWORK_LOG_MESSAGE_TYPE = 'export_network_log'
        EXPORT_INSIGHT_ALERT_LIST_MESSAGE_TYPE = 'export_insight_alert_list'
        GET_SYSLOG_CONFIGURATION_RPC_FUNC_NAME = 'get_syslog_exporter_configuration'
        GET_EXPORTER_ADDITIONAL_CONFIGURATION_RPC_FUNC_NAME = 'get_exporter_additional_configuration'
        GET_EXPORTER_INSTANCES_FUNC_NAME = 'get_exporter_instances'
        SYSLOG_CONNECTIVITY_TEST = 'syslog_connectivity_test'
        REPORT_SYSLOG_CONNECTIVITY_TEST_RESULT = 'report_syslog_connectivity_test_result'

    class Control(object):
        # Control RPC
        CONNECTIVITY_CHECK_RPC_FUNC_NAME = 'connectivity_check'
        REPORT_MONGOENGINE_EVENT_RPC_FUNC_NAME = 'report_mongo_event_rpc'
        PUT_AGENTS_DEBUG_LOG_RPC_FUNC_NAME = 'put_agents_debug_log_rpc'
        CONFIGURATION_CHANGE_MESSAGE_TYPE = 'configuration'
        STATE_CHANGE_MESSAGE_TYPE = 'state'
        AGENTS_STATE_CHANGE_MESSAGE_TYPE = 'agents_state'
        COMPONENT_ALIVE_RPC_FUNC_NAME = 'component_is_alive'
        COMPONENT_UPDATE_DETAILS_RPC_FUNC_NAME = 'update_component_details'
        COMPONENT_GET_CONFIGURATION_RPC_FUNC_NAME = 'get_configuration_rpc'

    class Orchestration(object):
        REPORT_AGGREGATOR_ORCHESTRATION_UPDATE = 'report_aggregator_orchestration_update'
        REPORT_AGGREGATOR_ORCHESTRATION_CONNECTIVITY = 'report_aggregator_orchestration_connectivity'
        USER_GROUP_MAPPING_MESSAGE_TYPE = 'user_group_mapping_feature_status'
        ENTRA_ID_TO_MGMT_FULL_SYNC_INTERVAL_MESSAGE_TYPE = 'entra_id_to_mgmt_full_sync_interval'

    class Deception(object):
        # Deception RPC
        REPORT_DECEPTION_EVENT_RPC_FUNC_NAME = 'report_deception_event_rpc'
        REPORT_DECEPTION_MONGOENGINE_EVENT_RPC_FUNC_NAME = 'report_deception_mongo_event_rpc'
        REPORT_DECEPTION_EVENTS_BULK_RPC_FUNC_NAME = 'report_deception_events_bulk_rpc'

    class Visibility(object):
        # Visibility RPC
        REPORT_DECEPTION_EVENT_FOR_VISIBILITY_RPC_FUNC_NAME = 'report_deception_event_for_visibility_event_rpc'
        REPORT_VISIBILITY_MONGOENGINE_EVENT_RPC_FUNC_NAME = 'report_visibility_mongo_event_rpc'

    class Dashboard(object):
        # Dashboard RPC
        REPORT_DASHBOARD_STATISTICS_EVENT_RPC_FUNC_NAME = 'report_dashboard_statistics_event_rpc'

    class DatacenterInventory(object):
        # DC Inventory RPC
        GET_DC_INVENTORY_SNAPSHOT_RPC_FUNC_NAME = 'get_dc_inventory_snapshot'
        REFRESH_DC_INVENTORY_SNAPSHOT_RPC_FUNC_NAME = 'refresh_and_publish_dc_inventory_snapshot'
        DC_INVENTORY_UPDATE_MESSAGE_TYPE = 'dc_inventory_update'

    class AgentDiagnosticsControl(object):
        # Agent diagnostics control
        STOP_AGENT_DIAGNOSTICS_COLLECTION = 'stop_agent_diagnostics_collection_rpc'

    class Logs(object):
        # Log Events RPC
        REPORT_MANAGEMENT_SYSTEM_EVENT_RPC_FUNC_NAME = 'report_management_system_event_rpc'
        REPORT_COMPONENT_SYSTEM_EVENT_RPC_FUNC_NAME = 'report_component_system_event_rpc'

    class ActiveDirectory(object):
        REPORT_ACTIVE_DIRECTORY_UPDATE = 'report_active_directory_update'
        GET_ALL_ACTIVE_DIRECTORY_GROUPS = 'get_all_active_directory_groups'

    class PluginsService(object):
        # Plugins Service RPC
        WEBHOOK_EVENT_TRIGGERED = 'plugins_service_webhook_event'
        PLUGIN_ACTION_TRIGGERED = 'plugin_action_triggered'

    class CloudApp(object):
        CLOUD_APP_UPDATE_FLAGS = 'cloud_app_update_flags'
        CLOUD_APP_UPDATE_HEALTH = 'cloud_app_update_health'
        CLOUD_APP_REGISTER_SERVICE_CONFIG_OPTS = 'cloud_app_register_service_config_opts'
        CLOUD_APP_GET_SERVICE_CONFIG = 'cloud_app_get_service_config'
        CLOUD_APP_NOTIFY_SERVICE_CONFIG = 'cloud_app_notify_service_config'
        CLOUD_APP_COLLECT_LOGS = 'cloud_app_collect_logs'
        CLOUD_APP_COLLECT_LOGS_READY = 'cloud_app_collect_logs_ready'

    class Integrations(object):
        GET_CONFIGS = 'get_configs'
        TEST_CONNECT = 'test_connect'
        CONNECT_RESULT = 'connect_result'
        NOTIFY_CONFIGS = 'notify_configs'


class ComponentIDPrefix(object):
    # Honeypot
    HONEYPOT_ID_PREFIX = 'HP-'

    # Aggregator & Aggregator Components
    AGGREGATOR_ID_PREFIX = 'AGR-'
    DATAPATH_ID_PREFIX = 'DP-'
    MITIGATION_AGENT_ID_PREFIX = 'MA-'
    DETECTION_AGENTS_SERVER_ID_PREFIX = 'DS-'
    ENFORCEMENT_SERVER_ID_PREFIX = 'ES-'
    CONTROLLER_SERVER_ID_PREFIX = 'CS-'
    PROXY_SERVER_ID_PREFIX = 'CP-'

    # Agent
    AGENT_ID_PREFIX = 'AG-'

    # Monicore
    MONICORE_ID_PREFIX = 'MC-'


class RPCRoutingKey(object):
    BROADCAST_ROUTING_KEY = 'broadcast'

    ENRICHMENT_MANAGERS_DECEPTION_INCIDENT_ROUTING_KEY = 'enrichment_managers_deception_incident'
    ENRICHMENT_MANAGERS_PASSIVE_DETECTION_INCIDENT_ROUTING_KEY = 'enrichment_managers_passive_detection_incident'
    ENRICHMENT_MANAGERS_INTEGRITY_INCIDENT_ROUTING_KEY = 'enrichment_managers_integrity_incident'
    VISIBILITY_INSPECTION_REPUTATION_ROUTING_KEY = 'visibility_inspection_reputation'
    VISIBILITY_INSPECTION_POLICY_VIOLATIONS_ROUTING_KEY = 'visibility_inspection_policy_violations'
    SIMILARITY_MANAGER_COMPLEX_CLUSTERING_ROUTING_KEY_WIN = 'similarity_managers_complex_win'
    SIMILARITY_MANAGER_COMPLEX_CLUSTERING_ROUTING_KEY_LINUX = 'similarity_managers_complex_linux'
    SIMILARITY_MANAGER_SIMPLE_CLUSTERING_ROUTING_KEY = 'similarity_managers_simple'
    Q_CLIENT_ROUTING_KEY = 'q_client_daemons'
    REMOTE_ELASTIC_SYNCING_ROUTING_KEY = 'remote_elastic_syncing_manager'


class ComponentType(IntEnum):
    DATAPATH = 1
    HONEYPOT = 2
    MITIGATION_AGENT = 3
    AGENT = 10
    AGGREGATOR = 11
    ENFORCEMENT_SERVER = 13
    MONICORE = 14
    DETECTION_AGENTS_SERVER = 15
    CONTROLLER_SERVER = 16
    PROXY_SERVER = 17
    GENERIC = 40

    @property
    def normal(self):
        return self.name.lower()

    @property
    def prefix(self):
        return {ComponentType.DATAPATH: ComponentIDPrefix.DATAPATH_ID_PREFIX,
                ComponentType.HONEYPOT: ComponentIDPrefix.HONEYPOT_ID_PREFIX,
                ComponentType.MITIGATION_AGENT: ComponentIDPrefix.MITIGATION_AGENT_ID_PREFIX,
                ComponentType.AGENT: ComponentIDPrefix.AGENT_ID_PREFIX,
                ComponentType.AGGREGATOR: ComponentIDPrefix.AGGREGATOR_ID_PREFIX,
                ComponentType.MONICORE: ComponentIDPrefix.MONICORE_ID_PREFIX,
                ComponentType.ENFORCEMENT_SERVER: ComponentIDPrefix.ENFORCEMENT_SERVER_ID_PREFIX,
                ComponentType.DETECTION_AGENTS_SERVER: ComponentIDPrefix.DETECTION_AGENTS_SERVER_ID_PREFIX,
                ComponentType.PROXY_SERVER: ComponentIDPrefix.PROXY_SERVER_ID_PREFIX,
                ComponentType.CONTROLLER_SERVER: ComponentIDPrefix.CONTROLLER_SERVER_ID_PREFIX}[self]

    @property
    def exchange(self):
        return {ComponentType.DATAPATH: RPCExchange.DATAPATH_EXCHANGE_NAME,
                ComponentType.HONEYPOT: RPCExchange.HONEYPOT_EXCHANGE_NAME,
                ComponentType.MITIGATION_AGENT: RPCExchange.MITIGATION_AGENT_EXCHANGE_NAME,
                ComponentType.AGGREGATOR: RPCExchange.AGGREGATOR_EXCHANGE_NAME,
                ComponentType.ENFORCEMENT_SERVER: RPCExchange.ENFORCEMENT_SERVER_EXCHANGE_NAME,
                ComponentType.DETECTION_AGENTS_SERVER: RPCExchange.DETECTION_AGENTS_SERVER_EXCHANGE_NAME,
                ComponentType.PROXY_SERVER: RPCExchange.AGGREGATOR_EXCHANGE_NAME,
                ComponentType.CONTROLLER_SERVER: RPCExchange.CONTROLLER_SERVER_EXCHANGE_NAME}[self]


class AgentComponentType(IntEnum):
    DECEPTION_AGENT = 1
    REVEAL_AGENT = 2
    ENFORCEMENT_AGENT = 3
    DETECTION_AGENT = 4
    CONTROLLER = 5
    ACCESS_AGENT = 6

    @property
    def normal(self):
        return self.name.lower()

    @property
    def module_name(self):
        return self.name.lower().replace('_agent', '')


class ComponentStatus(IntEnum):
    UNKNOWN = 0
    INITIALIZING = 1
    REPEATED_INITIALIZING = 2  # No need to report this from components
    UP = 3
    SHUTTING_DOWN = 4
    DOWN = 5
    PARTIALLY_UP = 6
    MISSING = 7
    RUNTIME_ERROR = 8
    FORCED_DOWN = 9
    OFFLINE = 10
    PENDING = 11

    @classmethod
    def get_down_statuses(cls):
        return {cls.SHUTTING_DOWN, cls.DOWN, cls.FORCED_DOWN}

    @classmethod
    def get_error_statuses(cls):
        return {cls.RUNTIME_ERROR, cls.SHUTTING_DOWN, cls.DOWN,
                cls.REPEATED_INITIALIZING}

    @classmethod
    def map_status(cls, status):
        """
        Maps between ComponentStatus and front-end status
        Must be in sync with ui/app/components/administration/components/common/componentStatusConstants.ts
        """
        status_mapping = {
            cls.UP: "Up",
            cls.INITIALIZING: "Initializing",
            cls.PENDING: "Connecting",
            cls.FORCED_DOWN: "Stopped",
            cls.OFFLINE: "Down",
            cls.PARTIALLY_UP: "Partially Up",
            cls.DOWN: "Error",
            cls.REPEATED_INITIALIZING: "Error",
            cls.SHUTTING_DOWN: "Error",
            cls.RUNTIME_ERROR: "Error",
            cls.MISSING: "Missing",
            cls.UNKNOWN: "Missing"
        }
        return status_mapping.get(status, "Unknown")


class UpgradeStatus(IntEnum):
    NotStarted = 0
    Initiated = 1
    Started = 2
    InProgress = 3
    Successful = 4
    Failed = 5
    Skipped = 6
    UpToDate = 7


class AggregatorType(IntEnum):
    COLLECTOR = 1
    AGENT_AGGREGATOR = 2


class EnrichmentType(IntEnum):
    NewIncident = 1
    Reenrichment = 2
    Experimental = 3


class IntegrationType(Enum):
    Cloud = "cloud"
    PACKETFENCE = "packetfence"


EnrichmentPriorities = {EnrichmentType.NewIncident: 1,
                        EnrichmentType.Reenrichment: 0,
                        EnrichmentType.Experimental: 0}


def component_queue_name(component_id):
    return '%s' % (component_id,)

def numbered_queue_name(queue_name, queue_number):
    return queue_name.format(queue_number=queue_number)

def format_to_federated(name):
    return "federated_" + name
