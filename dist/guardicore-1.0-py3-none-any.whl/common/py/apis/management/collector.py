from common.py.apis import RPCExchange, RPCMessage
from common.py.apis.management.rabbit import RabbitMQManagementAPI
from common.py.configuration.agent_configuration_schema import CONFIGURABLE_AGENT_TYPES
from common.py.events.mitigation.machine_details import MachineDetailsUpdate, AgentType


class CollectorAPI(RabbitMQManagementAPI):
    def add_agent_config_update_callback(self, callback_func):
        """"
        Callback to handle the processing of agents configuration updates from management
        """
        # TODO we might need to filter the message to this specific agent type related config only
        self.add_callback(RPCMessage.Agent.AGENT_CONFIG_UPDATE_MESSAGE_TYPE,
                          lambda message: callback_func(message.get('agents_configurations')))

    def report_agents_config_update_results(self, update_results):
        """
        Sends a report on agent configuration updates towards the management
        :param update_results: a dict of results in the following form:
                {
                  <machine_id>:
                  {
                    "revision_id": <now>,
                    "report": {
                        <agent_component_name>: {
                            "enabled": {
                                "success": <true|false>,
                                "error": <error in case of failure
                            },
                        <agent_component_name>: {
                            ...
                        }
                    },
                  }
                }
        :return: the result of the management RPC call
        """
        return self.call_management_rpc(rpc_func_name=RPCMessage.Agent.AGENTS_CONFIGURATIONS_REPORT_RESULT,
                                        exchange=RPCExchange.AGENT_CONFIGURATION_EXCHANGE_NAME,
                                        update_result=update_results,
                                        blocking=False)

    def get_agents_configuration(self, *agent_types):
        """
        Fetch all agents configuration

        :param agent_types: optional. Filter configuration of specific agent type
        :type  agent_types: list of AgentType enums
        :return: the entire configuration of all agents in the form of :
                    {
                      <machine_id>:
                      {
                        "revision_id": <now>,
                        "config": {
                            <agent_component_name>:
                            {
                                <option_name>: <option_value>,
                                ...
                            }
                        }
                      },
                      ...
                    }
        """

        assert all([isinstance(a, AgentType) for a in agent_types])
        if not agent_types:
            agent_types = list(CONFIGURABLE_AGENT_TYPES)
        return self.call_management_rpc(rpc_func_name=RPCMessage.Agent.AGENT_GET_CONFIGURATION,
                                        exchange=RPCExchange.AGENT_CONFIGURATION_EXCHANGE_NAME,
                                        agent_types=agent_types,
                                        blocking=True)
    @property
    def closed(self):
        return self.close_required

    def report_machine_details_update(self, updates):
        """
        :param updates: a list of MachineDetailsUpdate machine update objects
        """
        for update in updates:
            update.event_source = self.component_id
            assert isinstance(update, MachineDetailsUpdate)
        self.call_management_rpc(RPCMessage.MitigationAgent.MITIGATION_AGENT_REPORT_MACHINE_DETAILS_UPDATE_RPC_FUNC_NAME,
                                 exchange=RPCExchange.MACHINE_UPDATE_EXCHANGE_NAME,
                                 updates=[update.to_mongo() for update in updates])

