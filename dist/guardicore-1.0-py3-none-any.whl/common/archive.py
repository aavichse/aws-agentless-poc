from enum import Enum


class ArchiveType(Enum):
    ZIP = 'zip'
    TAR_GZ = 'tar.gz'
