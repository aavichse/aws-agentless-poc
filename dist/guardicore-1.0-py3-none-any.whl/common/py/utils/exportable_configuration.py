def edit_exportable_configuration(disable_export=False, limit=0, ordering_field='_id'):
    """
    Collections are exportable by default with `gc-info export`.
    Using this decorator, collections can be marked not exportable
    or the export can be limited to last X documents
    :param disable_export: If True, collection won't be exported using `gc-info export`
    :param limit: If assigned to a non-zero value, will define how many of the latest documents to export
    :param ordering_field: Field that will be used to order the latest X documents
    """
    def decorated(cls):
        try:
            if disable_export:
                cls.is_exportable_configuration = None
            else:
                cls.is_exportable_configuration = dict(limit=limit, ordering_field=ordering_field)
        except:
            pass
        return cls
    return decorated