
import sys
import logging
from pyVmomi import vim
from datetime import datetime, timedelta
from common.py.clouds.vsphere.vsphere_client import VSphereClient


MAX_EVENT_COLLECTOR_PAGE_SIZE = 1000


def main():
    logging.basicConfig(format="%(asctime)s [%(levelname)s] %(module)s.%(funcName)s.%(lineno)d: %(message)s",
                        stream=sys.stdout, level=logging.DEBUG)

    host, user, passwd = sys.argv[1:]

    vsphere = VSphereClient(admin_user=user, admin_password=passwd, auth_host=host)
    logging.info("connecting to %r...", vsphere)

    vsphere.connect()
    try:
        logging.info("connected")

        evt_mgr = vsphere.get_events_manager()

        # last week events filter
        time_spec_filter = vim.event.EventFilterSpec.ByTime()
        now = datetime.now()
        time_spec_filter.beginTime = now - timedelta(days=7)
        time_spec_filter.endTime = now

        # migration events filter
        event_type_ids = ["VmCreatedEvent", "VmClonedEvent", "VmEmigratingEvent", "VmDeployedEvent", "VmRegisteredEvent",
                          "VmFailedMigrateEvent", "VmMigratedEvent", "MigrationErrorEvent", "MigrationEvent",
                          "DrsVmMigratedEvent", "VmRelocatedEvent"]
        evt_filter = vim.event.EventFilterSpec(time=time_spec_filter, eventTypeId=event_type_ids)

        logging.info("collecting...")
        event_history_collector = evt_mgr.CreateCollectorForEvents(evt_filter)
        event_history_collector.SetCollectorPageSize(MAX_EVENT_COLLECTOR_PAGE_SIZE)
        events = event_history_collector.latestPage
        total = len(events)
        evt_index = 0

        logging.info("enumerating:")
        while 0 < len(events):
            for event in events:
                evt_index += 1
                logging.info("%d\t%s\t%s", evt_index, event.createdTime, event.fullFormattedMessage)
                logging.debug("%s", str(event))
                event_history_collector.ResetCollector()
            events = event_history_collector.ReadPreviousEvents(MAX_EVENT_COLLECTOR_PAGE_SIZE)
            total += len(events)

        logging.info("Logged %d events", total)
    finally:
        vsphere.close()

    return 0

if __name__ == '__main__':
    sys.exit(main())