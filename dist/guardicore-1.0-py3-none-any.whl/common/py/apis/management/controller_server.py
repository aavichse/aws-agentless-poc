import base64

from common.py.apis import DEFAULT_RABBITMQ_USERNAME, DEFAULT_RABBITMQ_PASSWORD, \
    REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT, ComponentType, AgentComponentType, AggregatorType, \
    RPCExchange, RPCMessage
from common.py.apis.management import UNKNOWN_API_VERSION
from common.py.apis.management.aggregating_system_component import AggregatorBaseComponentManagementAPI
from common.py.apis.management.collector import CollectorAPI
from common.logger import get_logger


LOG = get_logger(module_name=__name__)


class ControllerServerManagementAPI(AggregatorBaseComponentManagementAPI):
    COMPONENT_TYPE = ComponentType.CONTROLLER_SERVER
    AGENTS_COMPONENT_TYPE = AgentComponentType.CONTROLLER
    RABBIT_API_CLASS = CollectorAPI
    COMPONENT_BASE_URI = 'aggregators'

    def __init__(self, management_hosts, agent_id, version=UNKNOWN_API_VERSION, user=DEFAULT_RABBITMQ_USERNAME,
                 password=DEFAULT_RABBITMQ_PASSWORD, configuration_schema=None, aggregator_configuration_schema=None,
                 associated_mgmt_configuration=None, agent_details=None, guest_installation_details=None,
                 aggregator_type=AggregatorType.COLLECTOR, aggregator_features=None, collector_type=None, **kwargs):
        component_id = self.COMPONENT_TYPE.prefix + agent_id
        component_details = agent_details if agent_details is not None else {}
        component_details.update(dict(version=version,
                                      associated_mgmt_configuration=associated_mgmt_configuration,
                                      management_host=management_hosts[-1],
                                      guest_installation_details=guest_installation_details))
        component_details['agent_id'] = agent_id

        super(ControllerServerManagementAPI, self).__init__(
            management_hosts=management_hosts,
            agent_id=agent_id,
            user=user,
            password=password,
            version=version,
            exchange=RPCExchange.CONTROLLER_SERVER_EXCHANGE_NAME,
            component_id=component_id,
            aggregator_type=aggregator_type,
            aggregator_features=aggregator_features,
            collector_type=collector_type,
            component_details=component_details,
            heartbeat=REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT,
            configuration_schema=configuration_schema,
            aggregator_configuration_schema=aggregator_configuration_schema,
            **kwargs)

        self.agents_details = {}

    def add_start_agent_modules_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.ControllerServer.CONTROLLER_SERVER_START_AGENT_MODULES_FUNC_NAME,
                                    lambda message: callback_func(message['agent_uuids'], message['modules']))

    def add_stop_agent_modules_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.ControllerServer.CONTROLLER_SERVER_STOP_AGENT_MODULES_FUNC_NAME,
                                    lambda message: callback_func(message['agent_uuids'], message['modules']))

    def add_restart_agents_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.ControllerServer.CONTROLLER_SERVER_RESTART_AGENTS_FUNC_NAME,
                                    lambda message: callback_func(message['agent_uuids']))

    def add_collect_agent_diagnostics_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.ControllerServer.CONTROLLER_SERVER_COLLECT_AGENT_DIAGNOSTICS_FUNC_NAME,
                                    lambda message: callback_func(diagnostics_id=message['diagnostics_id'],
                                                                  agent_uuids=message['agent_uuids'],
                                                                  verbose_debug_logs=message['verbose_debug_logs'],
                                                                  log_size=message['log_size'],
                                                                  agent_logs=message['agent_logs'],
                                                                  agent_server_logs=message['agent_server_logs'],
                                                                  certificate_details=message['certificate_details'],
                                                                  agent_local_config=message['agent_local_config'],
                                                                  server_details=message['server_details'],
                                                                  rotated_logs=message['rotated_logs'],
                                                                  verbose_timer=message['verbose_timer'],
                                                                  zendesk_upload=message['zendesk_upload'],
                                                                  zendesk_url=message['zendesk_url'],
                                                                  zendesk_username=message['zendesk_username'],
                                                                  mgmt_upload=message['mgmt_upload'],
                                                                  k8s_diagnostics=message['k8s_diagnostics']))

    def add_stop_collect_agent_diagnostics_callback(self, callback_func):
        self.rabbitapi.add_callback(
            RPCMessage.ControllerServer.CONTROLLER_SERVER_STOP_COLLECT_AGENT_DIAGNOSTICS_FUNC_NAME,
            lambda message: callback_func(diagnostics_id=message['diagnostics_id']))

    def send_agent_diagnostics(self, diagnostics_id, agent_uuid, agent_source, agent_hostname,
                               diagnostics_data, diagnostics_archive_type, verbose_diagnostics=False,
                               failed_status=False):
        self.rabbitapi.call_management_rpc(RPCMessage.ControllerServer.CONTROLLER_SERVER_SEND_AGENT_DIAGNOSTICS_FUNC_NAME,
                                           exchange=RPCExchange.AGENT_EVENT_EXCHANGE_NAME,
                                           diagnostics_id=diagnostics_id,
                                           agent_uuid=agent_uuid,
                                           source=agent_source,
                                           hostname=agent_hostname,
                                           verbose_diagnostics=verbose_diagnostics,
                                           diagnostics_data=base64.b64encode(bytes(diagnostics_data,
                                                                                   encoding='cp437')).decode('cp437'),
                                           diagnostics_archive_type=diagnostics_archive_type,
                                           failed_status=failed_status)

    def add_upgrade_agent_bundles_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.ControllerServer.CONTROLLER_SERVER_UPGRADE_AGENT_BUNDLES,
                                    lambda message: callback_func(message['upgrade_job_id'], message['agent_uuids'],
                                                                  message['agent_bundles'], message['configuration'],
                                                                  message['profile']))

    def add_migrate_agents_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.ControllerServer.CONTROLLER_SERVER_MIGRATE_AGENTS,
                                    lambda message: callback_func(message['job_id'], message['agent_ids'],
                                                                  message['target_aggregator']))

    def add_fast_policy_status_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.ControllerServer.FAST_POLICY_MESSAGE_TYPE,
                                    lambda message: callback_func(message['configuration']))

    def add_worksites_status_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.ControllerServer.WORKSITES_CONFIG_MESSAGE_TYPE,
                                    lambda message: callback_func(message['configuration']))

    def get_fast_policy_status(self):
        return self.rabbitapi.call_management_rpc(RPCMessage.ControllerServer.FAST_POLICY_RPC_FUNC_NAME,
                                                  blocking=True)

    def get_worksites_status(self):
        return self.rabbitapi.call_management_rpc(RPCMessage.ControllerServer.WORKSITES_CONFIG_RPC_FUNC_NAME,
                                                  blocking=True)

    def add_upgrade_agent_ko_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.ControllerServer.CONTROLLER_SERVER_UPGRADE_AGENT_KO,
                                    lambda message: callback_func(message['ko_upgrade_job_id'], message['agent_uuids']))
