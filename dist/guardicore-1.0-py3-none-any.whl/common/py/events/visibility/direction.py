from common.py.model.fastenum import Enum


class ConnectionDirection(Enum):
    SOURCE = 'source'
    DESTINATION = 'destination'
