from multiprocessing import cpu_count

__author__ = 'itamar'


def get_cpu_model():
    MODEL_PREFIX = 'model\t\t:'

    try:
        for x in [line[len(MODEL_PREFIX):].strip()
                  for line in open("/proc/cpuinfo", "r")
                  if line.startswith(MODEL_PREFIX)]:
            return int(x)
    except:
        pass
    return 0


def get_cpu_family():
    FAMILY_PREFIX = "cpu family\t:"

    try:
        for x in [line[len(FAMILY_PREFIX):].strip()
                  for line in open("/proc/cpuinfo", "r")
                  if line.startswith(FAMILY_PREFIX)]:
            return int(x)
    except Exception as exc:
        pass
    return 0


def get_cpu_count():
    return cpu_count()


CPU_MODEL_NAME = "%d_%d" % (get_cpu_model(), get_cpu_family())


def get_cpu_model_name():
    return CPU_MODEL_NAME
