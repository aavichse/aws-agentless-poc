from common.logger import LogLevel
from common.py.utils.config import cfg
from common.py.utils.config.oslo_config import types
from common.py.utils.config.types import Structure

# active_directory specific configurations
active_directory_opts = [
    cfg.StrOpt('domain_name', help="Fully qualified domain name"),
    cfg.StrOpt('login_username', help="Service username. should be userPrincipalName (user@domain.com)"),
    cfg.StrOpt('login_password', secret=True, help="Service password"),
    cfg.StrOpt('base_dn', default=None,
               help="OU from which the search for groups will commence. e.g. OU=Users and Groups,DC=domain,DC=com"),
    cfg.BoolOpt('use_ssl', default=True),
    cfg.Opt('servers', default=[], type=types.List(item_type=types.String(quotes=True, unicode=True), bounds=True),
            help="List of AD servers. A server format is <host>[:<port>]. e.g: my.server.com / 10.0.0.4 / 11.0.0.5:443"),
    cfg.IntOpt('orchestration_full_report_interval', help="Interval in which to run a full report (in seconds)",
               default=1800),
]

AD_AUTH_STRUCTURE = Structure(active_directory_opts)

AD_AUTH_OPTS = [cfg.IntOpt('update_timeout_seconds', default=10 * 60,
                           help="Active directory update timeout in seconds"),
                cfg.IntOpt('ldap_server_connection_hard_timeout', default=30,
                           help="Hard timeout in seconds for the ldap operations"),
                cfg.IntOpt('ldap_search_page_size', default=500,
                           help="LDAP page size for paged search operations"),
                cfg.StrOpt('ldap_log_level', default=LogLevel.NOTSET.name,
                           choices=[level.name for level in LogLevel],
                           help="LDAP adapter logging"),
                cfg.IntOpt('ldap_restartable_tries', default=2,
                           help="LDAP reconnect retries")]


def register_opts():
    cfg.CONF.register_opt(cfg.Opt('active_directory_configuration', type=AD_AUTH_STRUCTURE), group="orchestration")
    cfg.CONF.register_opts(opts=AD_AUTH_OPTS, group="active_directory_auth")
