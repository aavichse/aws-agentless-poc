from functools import wraps

import statsd

from common.application import Application
from common.logger import get_logger
from common.py.saas.bootstrap import is_runtime_saas
from common.py.saas.configuration import get_telegraf_url

LOGGER = get_logger()


STATSD_PORT = 8126
CLOUD_STATSD_PORT = 8126


class GCStatsd(object):
    """
    wrapper for sending statsd metrics to Influx/DD
    """

    def __init__(self, host='localhost', port=STATSD_PORT):
        self.client = statsd.StatsClient(host, port)
        self._extra_tags = dict()

    def update_client(self, host='localhost', port=STATSD_PORT):
        self.client = statsd.StatsClient(host, port)

    def _add_extra_tags(fn):
        @wraps(fn)
        def decorated(self, metric, value=1, tags=None, save_to_influx=True):
            if self._extra_tags:
                tags = tags or dict()
                tags.update(self._extra_tags)
            return fn(self, metric, value, tags, save_to_influx)
        return decorated

    def _add_extra_tags_to_event(fn):
        @wraps(fn)
        def decorated(self, title, text, tags=None, *args, **kwargs):
            if self._extra_tags:
                tags = tags or dict()
                tags.update(self._extra_tags)
            return fn(self, title, text, tags, *args, **kwargs)
        return decorated

    def _build_metric_string(self, metric, tags=None):
        if tags is None:
            return metric

        tags_str = ",".join(["{key}={value}".format(key=k, value=v) for k, v in tags.items()])

        metric_to_return = metric + "," + tags_str

        # statsd can't handle unicode characters, remove them
        metric_to_return = metric_to_return.encode("ascii", "ignore").decode()

        return metric_to_return

    def _build_tags_for_dd(self, tags=None):
        if tags is None:
            return None
        return ["{key}:{value}".format(key=k, value=v) for k, v in tags.items()]

    @_add_extra_tags
    def incr(self, metric, value=1, tags=None, save_to_influx=True):
        """
        :param metric: a hierarchical string separated by "." (i.e: agents.cpu.general_cpu_usage)
        :param tags: dictionary containing all tags associated with this metric
        """
        if save_to_influx:
            self.client.incr(self._build_metric_string(metric=metric, tags=tags), count=value)

    @_add_extra_tags
    def decr(self, metric, value=1, tags=None, save_to_influx=True):
        """
        :param metric: a hierarchical string separated by "." (i.e: agents.cpu.general_cpu_usage)
        :param tags: dictionary containing all tags associated with this metric
        """
        if save_to_influx:
            self.client.decr(self._build_metric_string(metric=metric, tags=tags), count=value)

    @_add_extra_tags
    def gauge(self, metric, value, tags=None, save_to_influx=True):
        """
        :param metric: a hierarchical string separated by "." (i.e: agents.cpu.general_cpu_usage)
        :param tags: dictionary containing all tags associated with this metric
        """
        if save_to_influx:
            self.client.gauge(self._build_metric_string(metric=metric, tags=tags), value=value)

    @_add_extra_tags
    def set(self, metric, value, tags=None, save_to_influx=True):
        """
        :param metric: a hierarchical string separated by "." (i.e: agents.cpu.general_cpu_usage)
        :param tags: dictionary containing all tags associated with this metric
        """
        if save_to_influx:
            self.client.set(self._build_metric_string(metric=metric, tags=tags), value=value)

    @_add_extra_tags
    def histogram(self, metric, value, tags=None, save_to_influx=True):
        """
        :param metric: a hierarchical string separated by "." (i.e: agents.cpu.general_cpu_usage)
        :param tags: dictionary containing all tags associated with this metric
        """
        if save_to_influx:
            self.client.timing(self._build_metric_string(metric=metric, tags=tags), delta=value)

    @_add_extra_tags
    def timing(self, metric, value, tags=None, save_to_influx=True):
        """
        :param metric: a hierarchical string separated by "." (i.e: agents.cpu.general_cpu_usage)
        :param tags: dictionary containing all tags associated with this metric
        """
        if save_to_influx:
            self.client.timing(self._build_metric_string(metric=metric, tags=tags), delta=value)

    @_add_extra_tags_to_event
    def event(self, title, text, tags=None, aggregation_key=None, alert_type=None, source_type_name=None):
        """
        :param tags: dictionary containing all tags associated with this event
        """
        LOGGER.warning("Influx does not support events. Dropping event: %r", title)


class GCStatsdWithComponentId(GCStatsd):
    """
    wrapper for sending statsd metrics to Influx/DD, adding component ID to tags
    """

    def __init__(self):
        super(GCStatsdWithComponentId, self).__init__()
        self._extra_tags = dict(component_id=Application.get_id())


# Used to report metrics to our internal InfluxDB
print("Initializing STATSD client...")
if is_runtime_saas():
    telegraf_host = get_telegraf_url(default_url="localhost")
    print("Using STATSD with '%s:%s'" % (telegraf_host, CLOUD_STATSD_PORT))
    STATSD = GCStatsd(host=telegraf_host, port=CLOUD_STATSD_PORT)
else:
    print("Using STATSD with 'localhost:%s'" % STATSD_PORT)
    STATSD = GCStatsd()
STATSD_WITH_COMPONENT_ID = GCStatsdWithComponentId()
