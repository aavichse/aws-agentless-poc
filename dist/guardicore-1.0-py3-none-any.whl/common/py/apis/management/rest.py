import datetime
import gzip
import json
import os

try:
    from json.decoder import JSONDecodeError
except ImportError:
    # for python 2.7 which doesn't support JSONDecodeError
    JSONDecodeError = ValueError

import logging
from functools import wraps

import requests
from requests.auth import AuthBase
import requests.exceptions
from requests.status_codes import codes
import six
from six.moves.urllib.parse import urljoin

from common.py.apis import MANAGEMENT_REST_API_PORT, NEW_REST_API_BASE_URL
from common.py.apis.management import ManagementAPIError

__author__ = 'Amit'

TIME_FORMAT_STRING = "%Y/%m/%d %H:%M:%S.%f"  # this should be parsable by dateutil.parser


class RESTAuthenticationError(ManagementAPIError):
    def __init__(self, response):
        data = response.json()
        super(RESTAuthenticationError, self).__init__('%s: %s' % (data['error'],
                                                                  data['description']))
        self.data = data


class DatetimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.strftime(TIME_FORMAT_STRING)
            # Let the base class default method raise the TypeError
        return json.JSONEncoder.default(self, obj)


class JWTAuth(AuthBase):
    """Attaches JWT Authentication to the given Request object."""

    def __init__(self, token):
        # setup any auth-related data here
        if token is None:
            raise ManagementAPIError("REST Token not set!")
        self.token = token

    def __call__(self, r):
        # modify and return the request
        r.headers['Authorization'] = 'Bearer ' + self.token
        return r


def rest_auto_reconnect():
    def decorator(f):
        @wraps(f)
        def decorated(self, *args, **kwargs):
            try:
                return f(self, *args, **kwargs)
            except RESTAuthenticationError as e:
                if not self.rest_auth_enabled or not self.auto_reconnect:
                    # either this is an authentication request which failed,
                    # or authentication is disabled but the server probably thinks authentication *is* required.
                    raise

                self.logger.error('Rest authentication error: %s', str(e))
                self.logger.info("Token might have expired; re-authenticating")
                self.connect()
                return f(self, *args, **kwargs)

        return decorated

    return decorator


class RESTManagementAPI(object):
    CHUNK_SIZE = 1024

    def __init__(self, management_host, username=None, password=None, rest_auth_enabled=True,
                 auto_connect=True, auto_reconnect=True, port=MANAGEMENT_REST_API_PORT, ssl=True,
                 two_factor_auth=False, use_scripts_api=False, keep_last_response=False):

        self.logger = logging.getLogger('guardicore.RESTManagementAPI')
        self.callback_func = None
        self.management_host = management_host

        self.http_server_root = '{protocol}://{host}:{port}'.format(protocol='https' if ssl else 'http',
                                                                    host=self.management_host,
                                                                    port=port)

        self._requests_session = requests.Session()
        self._requests_session.verify = False

        self._keep_last_response = keep_last_response
        self.last_response = None

        self.json_encoder = DatetimeEncoder()

        self.token = None
        self.rest_username = username
        self.rest_password = password
        self.rest_auth_enabled = rest_auth_enabled
        self.auto_connect = auto_connect
        self.auto_reconnect = auto_reconnect
        self.two_factor_auth = two_factor_auth
        self.authentication_handler = self.rest_authenticate

        self.use_scripts_api = use_scripts_api

        if self.rest_auth_enabled and self.auto_connect:
            self.connect()

    def connect(self):
        self.authentication_handler(self.rest_username, self.rest_password)

    def set_token(self, token):
        """
        Set JWT token, used for authentication with REST API
        :param token:
        """
        self.logger.info("Setting REST token")
        self.token = token
        self._requests_session.auth = JWTAuth(self.token)  # so others can use this session

    def kerberos_authenticate(self, host):
        """
        Perform a kerberos authentication
        :param host: Centra host name
        """
        try:
            from common.py.apis.kerberos.kerberos_manager import KerberosManager
        except ImportError:
            self.logger.error('Failed to import kerberos manager- kerberos package is missing. please install it')
            raise

        self.logger.info('Kerberos Authenticating')

        kerberos_token = KerberosManager.get_kerberos_token(host)
        if not kerberos_token:
            self.logger.error('Empty kerberos token- authentication failed')
            raise ManagementAPIError('Kerberos authentication failed')

        data = {'is_implicit_authentication': True}
        data = self.json_encoder.encode(data)
        headers = {'Authorization': 'Negotiate {}'.format(kerberos_token)}
        response = self._query(uri=urljoin(NEW_REST_API_BASE_URL, 'authenticate'),
                               method='POST',
                               data=data,
                               headers=headers,
                               authenticate=False)

        token = response['access_token']
        self.set_token(token)
        self.logger.info("REST token obtained and set")

    def rest_authenticate(self, rest_username, rest_password):
        """
        Perform JWT authentication through management REST API with username/password
        :param rest_username:
        :param rest_password:
        """
        self.logger.info("REST Authenticating")

        data = {'username': rest_username,
                'password': rest_password}
        if self.two_factor_auth:
            data['two_factor_auth_phase'] = 0

        response = self.json_query(uri=urljoin(NEW_REST_API_BASE_URL, 'authenticate'),
                                   method='POST',
                                   data=data,
                                   authenticate=False)
        if response.get('2fa_required'):
            raise ManagementAPIError("2FA required but no ClientManagement API support for it.")

        token = response['access_token']
        self.set_token(token)
        self.logger.info("REST token obtained and set")

    @rest_auto_reconnect()
    def _query(self, uri, method="GET", data=None, params=None, authenticate=True, files=None, follow_redirects=False,
               user_headers=None, ignore_errors=False, **kwargs):
        if params is None:
            params = {}

        self.logger.debug("%s %s%s", method, uri, ('' if not params
                                                   else '?' + '&'.join("%s=%s" % (key, value)
                                                                       for key, value in params.items())))

        method_func = {"GET": self._requests_session.get,
                       "POST": self._requests_session.post,
                       "PUT": self._requests_session.put,
                       "PATCH": self._requests_session.patch,
                       "DELETE": self._requests_session.delete}[method]

        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.0; WOW64; rv:24.0) Gecko/20100101 Firefox/24.0',
                   'content-type': 'application/json' if files is None else None}

        if not self.use_scripts_api:
            # Rest requests without Guardicore-UI header will be proxied to script-rest-servers
            headers['Client-Type'] = 'Guardicore-UI'

        if user_headers is not None:
            headers.update(user_headers)

        auth = JWTAuth(self.token) if (authenticate and self.rest_auth_enabled) else None
        try:
            response = method_func(urljoin(self.http_server_root, uri), data=data, headers=headers,
                                   params=params, auth=auth, files=files, **kwargs)
            if follow_redirects and response.status_code == 406:
                response = self._query(uri=response.headers['Location'], method=method, data=data,
                                       params=params, authenticate=authenticate, files=files)
        except requests.exceptions.RequestException as e:
            six.raise_from(ManagementAPIError("Error while handling %s request for uri %s" % (method, uri)), e)

        if self._keep_last_response:
            self.last_response = response

        if ignore_errors:
            return response

        if response.status_code == codes.FORBIDDEN:  # This is a potential authorization error
            raise RESTAuthenticationError(response)

        if response.status_code != codes.OK:
            try:
                json_obj = json.loads(response.content)
            except JSONDecodeError:
                json_obj = response.content

            logging.error("Server error: %s" % (repr(json_obj)))
            raise ManagementAPIError("Server error: %s" % (repr(json_obj)))

        return response

    def json_query(self, uri, method="GET", data=None, return_json=True, params=None, authenticate=True, files=None,
                   convert_data_to_json=True, follow_redirects=False, user_headers=None, ignore_errors=False, **kwargs):
        if data is not None and convert_data_to_json:
            data = self.json_encoder.encode(data)

        response = self._query(uri=uri, method=method, data=data,
                               params=params, authenticate=authenticate, files=files,
                               follow_redirects=follow_redirects, user_headers=user_headers,
                               ignore_errors=ignore_errors, **kwargs)

        try:
            if ignore_errors:
                return response

            if not return_json:
                return response.content

            json_obj = json.loads(response.content)
            if isinstance(json_obj, dict) and "code" in json_obj and 0 != json_obj["code"]:
                raise ManagementAPIError("Error: %s" % (json_obj["message"],))

            return json_obj
        except ValueError as exc:
            raise ManagementAPIError("Error reading server response: %s :: [%s]" % (str(exc), response.content))

    def download_file(self, uri, download_dir_path, **kwargs):
        downloaded_file_size = 0
        os.makedirs(download_dir_path, exist_ok=True)

        r = self._query(urljoin(self.http_server_root, uri),
                        stream=True, verify=False, authenticate=False,
                        **kwargs)

        content_data = r.headers['content-disposition']
        filename = content_data.split('filename=')[-1]
        download_file_path = os.path.join(download_dir_path, filename)
        with open(download_file_path, 'wb') as outfile:
            for chunk in r.iter_content(chunk_size=self.CHUNK_SIZE):
                if chunk:  # filter out keep-alive new chunks
                    downloaded_file_size += outfile.write(chunk)
        return download_file_path, downloaded_file_size

    def get_compressed_streamed_data(self, uri, **kwargs):
        r = self._query(urljoin(self.http_server_root, uri),
                        stream=True, verify=False, authenticate=False,
                        **kwargs)
        return self.handle_compressed_stream(r)

    @classmethod
    def handle_compressed_stream(cls, response):
        buf = bytearray()
        if isinstance(response, bytes):
            buf.extend(response)
        else:
            for chunk in response.iter_content(chunk_size=cls.CHUNK_SIZE):
                if chunk:
                    buf.extend(chunk)

        decompressed = gzip.decompress(buf)
        return decompressed.decode('utf-8')
