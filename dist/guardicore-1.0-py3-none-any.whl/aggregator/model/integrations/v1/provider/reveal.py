from __future__ import annotations
import datetime
from enum import Enum
from typing import List, Optional, Union

from pydantic import BaseModel, Field, field_serializer, model_serializer, ValidationError

from common.py.events import IPVersion, IPProtocol
from common.py.events.mitigation.network import EnforcementMode, AgentMatchingVerdict, ConnectionEventType
from ..common.inventory import InventoryItem


class ProcessInfo(BaseModel):
    process_name: str = Field(
        ..., alias='process-name', description='Name of the process.'
    )
    image_path: Optional[str] = Field(
        None, alias='image-path', description='Path to the executable of the process.'
    )
    cmdline: Optional[List[str]] = Field(
        None, description='Command line arguments used for the process.'
    )


class Verdict(Enum):
    ALLOW = 'allow'
    ALERT = 'alert'
    BLOCK = 'block'


class EnforcementInfo(BaseModel):
    rule_id: Optional[str] = Field(default='default', alias='rule-id')
    rule_name: Optional[str] = Field(None, alias='rule-name')
    connector_dst_rule_id: Optional[str] = Field(None, alias='connector-dst-rule-id')
    connector_src_rule_id: Optional[str] = Field(None, alias='connector-src-rule-id')
    verdict: Verdict = Field(None, alias='verdict')
    revision: Optional[int] = Field(None, alias='policy-revision')
    dc_inventory_revision: Optional[int] = Field(None, alias='dc-inventory-revision')

    @model_serializer(mode='wrap')
    def serialize_model(self, handler):
        # If rule_id is empty, UI will display "RUL- ".
        # We want to try fill it with something, with the following priority:
        if not self.rule_id:
            if self.connector_src_rule_id:
                self.rule_id = self.connector_src_rule_id
            elif self.connector_dst_rule_id:
                self.rule_id = self.connector_dst_rule_id
            elif self.rule_name:
                self.rule_id = self.rule_name
            else:
                self.rule_id = "default"
        return handler(self)


    @field_serializer('verdict')  # Added to base model
    @classmethod
    def serialize_enforcement_info(cls, v: Verdict) -> AgentMatchingVerdict:
        return {Verdict.BLOCK: AgentMatchingVerdict.BLOCK,
                Verdict.ALLOW: AgentMatchingVerdict.ALLOW,
                Verdict.ALERT: AgentMatchingVerdict.ALERT}.get(v)


class Type(Enum):
    SNAT = 'snat'
    DNAT = 'dnat'
    SNAT_AND_DNAT = 'snat_and_dnat'


class NatInfo(BaseModel):
    source_ip: str = Field(..., alias='source-ip', description='NAT source IP address.')
    dest_ip: str = Field(
        ..., alias='dest-ip', description='NAT destination IP address.'
    )
    dest_port: int = Field(..., alias='dest-port', description='NAT destination port.')
    type: Type = Field(..., description='Type of NAT.')


class ReportingEntity(BaseModel):
    uuid: str = Field(
        ...,
        description='Unique identifier for the reporting entity such as CloudApp id',
    )
    type: str = Field(..., description='Type of the reporting entity such as CloudApp')


class Direction(Enum):
    OUTBOUND = 'outbound'
    INBOUND = 'inbound'
    BI_DIRECTIONAL = 'bi-directional'
    OUTBOUND_ONLY = 'outbound-only'


class EventType(Enum):
    SUCCESSFUL = 'successful'
    FAILED = 'failed'
    REDIRECTED = 'redirected'


class IpProtocol(Enum):
    TCP = 'tcp'
    UDP = 'udp'
    ICMP = 'icmp'


class IpVersion(Enum):
    IPV4 = 'ipv4'
    IPV6 = 'ipv6'


class EnforcementState(Enum):
    REVEAL_ONLY = 'reveal-only'
    MONITORING = 'monitoring'
    ENFORCING = 'enforcing'


class ConnectionInfo(BaseModel):

    direction: Union[Direction, None] = Field(
        ...,
        alias='direction',
        exclude=True,  # Changed from base - we don't report direction, we concatenate it with event_type
        description='Indicates the direction of the network event; bi-directional is reported for two-sided connection;'
                    ' outbound-only - Destination is PaaS resource behind a private endpoint. ',
    )
    # Changed from base model: instead of just EventType, we later convert it to ConnectionEventType
    event_type: Union[EventType, ConnectionEventType] = Field(
        ...,
        alias='event-type',
        description='Type of network event that occurred; redirected is used for honeypot',
    )
    source_ip: str = Field(
        ..., alias='source-ip', description='Source IP address of the network event.'
    )
    destination_ip: str = Field(
        ..., alias='dest-ip', description='Destination IP address of the network event.'
    )
    destination_port: int = Field(
        ...,
        alias='dest-port',
        description='Destination port number for the network event.',
    )
    ip_protocol: IpProtocol = Field(
        ..., alias='ip-protocol', description='IP protocol used in the network event.'
    )
    ip_version: IpVersion = Field(
        ..., alias='ip-version', description='IP version used in the network event.'
    )
    enforcement_state: EnforcementState = Field(
        ...,
        alias='enforcement-state',
        description="Specifies the enforcement level for a network event: 'monitoring' for policy evaluation but"
                    " allows traffic, and 'reveal only' for data reporting without policy evaluation."
    )
    # Change from base model: changed name from enforcement-info to just enforcement
    enforcement: Optional[EnforcementInfo] = Field(
        None,
        alias='enforcement-info',
        description='Additional enforcement information.',
    )
    nat_info: Optional[NatInfo] = Field(
        None,
        alias='nat-info',
        description='Information about Network Address Translation.',
    )
    source_process_info: Optional[ProcessInfo] = Field(
        None,
        alias='source-process-info',
        description='Information about the source process involved in the network event.',
    )
    dest_process_info: Optional[ProcessInfo] = Field(
        None,
        alias='dest-process-info',
        description='Information about the destination process involved in the network event.',
    )
    # Change from base model: source-inventory-item -> source_inventory_item_info
    source_inventory_item_info: Optional[InventoryItem] = Field(
        None,
        alias='source-inventory-item',
        description='Inventory information for the source in the network event.',
    )
    # Change from base model: dest-inventory-item -> destination_inventory_item_info
    destination_inventory_item_info: Optional[InventoryItem] = Field(
        None,
        alias='dest-inventory-item',
        description='Inventory information for the destination in the network event.',
    )
    source_username: Optional[str] = Field(
        None,
        alias='source-username',
        description='Username associated with the source in the network event.',
    )
    dest_username: Optional[str] = Field(
        None,
        alias='dest-username',
        description='Username associated with the destination in the network event.',
    )
    dest_domain: Optional[str] = Field(
        None,
        alias='dest-domain',
        description='Domain associated with the destination in the network event (FQDN)',
    )
    # Change from base model: start-time -> bucket_start_time
    bucket_start_time: int = Field(
        ...,
        validation_alias='start-time',
        description='Start time of the network event.** for aggregated events (epoch in seconds)',
    )
    # Change from base model: end-time -> bucket_end_time
    bucket_end_time: int = Field(
        ...,
        validation_alias='end-time',
        description='End time of the network event.** for aggregated events (epoch in seconds)',
    )
    count: int = Field(..., description='Number of occurrences of the network event.')
    reporting_entity: ReportingEntity = Field(
        ...,
        alias='reporting-entity',
        description='Entity that reported the network event.',
        exclude=True  # Change from base model: we're excluding this from the dumped json
    )

    # Added to base model: Config
    class Config:
        extra = 'ignore'  # Ignore reported fields not mentioned in model
        use_enum_values = True

    # Added to base model: check no double process info and convert event_type & direction to ConnectionEventType
    @model_serializer(mode='wrap')
    def serialize_model(self, handler):
        if self.source_process_info and self.dest_process_info:
            raise ValidationError("source process info and dest process info can't co-exist")
        self.event_type = {
                (EventType.SUCCESSFUL.value, Direction.OUTBOUND.value): ConnectionEventType.NewSuccessOutgoingConnection,
                (EventType.SUCCESSFUL.value, Direction.INBOUND.value): ConnectionEventType.NewSuccessIncomingConnection,
                (EventType.SUCCESSFUL.value, Direction.BI_DIRECTIONAL.value): ConnectionEventType.NewSuccessMatchedConnection,
                (EventType.SUCCESSFUL.value, Direction.OUTBOUND_ONLY.value): ConnectionEventType.NewSuccessOutgoingConnection,
                (EventType.FAILED.value, Direction.OUTBOUND.value): ConnectionEventType.NewFailedOutgoingConnection,
                (EventType.FAILED.value, Direction.INBOUND.value): ConnectionEventType.NewFailedIncomingConnection,
                (EventType.FAILED.value, Direction.BI_DIRECTIONAL.value): ConnectionEventType.NewFailedMatchedConnection,
                (EventType.FAILED.value, Direction.OUTBOUND_ONLY.value): ConnectionEventType.NewFailedOutgoingConnection,
            }.get((self.event_type, self.direction))
        return handler(self)

    # Added to base model: field serializers
    @field_serializer('bucket_start_time', "bucket_end_time")
    @classmethod
    def serialize_time(cls, v: int) -> datetime.datetime:
        return datetime.datetime.fromtimestamp(v)

    @field_serializer('ip_version')
    @classmethod
    def serialize_ip_version(cls, v: IpVersion) -> Union[IPVersion, None]:
        return {IpVersion.IPV4.value: IPVersion.IPv4, IpVersion.IPV6.value: IPVersion.IPv6}.get(v)

    @field_serializer('ip_protocol')
    @classmethod
    def serialize_ip_protocol(cls, v: IpProtocol) -> Union[IPProtocol, None]:
        return {IpProtocol.TCP.value: IPProtocol.Tcp, IpProtocol.UDP.value: IPProtocol.Udp}.get(v)

    @field_serializer('enforcement_state')
    @classmethod
    def serialize_enforcement_state(cls, v: EnforcementState) -> Union[EnforcementMode, None]:
        return {EnforcementState.REVEAL_ONLY.value: EnforcementMode.RevealOnly,
                EnforcementState.MONITORING.value: EnforcementMode.Monitoring,
                EnforcementState.ENFORCING.value: EnforcementMode.Enforcing}.get(v)
