
import os
from enum import Enum

from eventlet.green import socket, select
from common import logger
from common.component_service import ComponentService
from common.py.network.comm_strategy import CommunicationStrategy, JsonCommunicationStrategy
from common.py.network.unix_sender import MAX_SO_RECV_SIZE, SimpleNetDictSender
from common.service import ServiceState
from common.py.model.exceptions import GuardicoreException

__author__ = 'Eddie'

LOG = logger.get_logger(module_name=__name__)

MAX_CLIENT_SOCKETS = 100


class SocketType(Enum):
    Server = "server"
    Client = "client"


class NetDictTransport(ComponentService):
    """
    A class for initializing a unix socket server for 'communication_strategy' type communication.
    or connecting to one, sending information over the socket and receiving responses.
    """

    SOCKET_ACCEPT_TIMEOUT = 0.5

    def __init__(self, path, sock_type=SocketType.Server, cb=None, communication_strategy=JsonCommunicationStrategy,
                 max_client_sockets=MAX_CLIENT_SOCKETS, max_recv=MAX_SO_RECV_SIZE):
        super(NetDictTransport, self).__init__(name='unix-queue')

        assert issubclass(communication_strategy, CommunicationStrategy)

        self._communication_strategy = communication_strategy
        self._path = path
        self._sock = None
        self._cb = cb
        self._srv_job = None
        self._sock_type = sock_type
        self._max_recv = max_recv
        self._accept_socket_index = 0

    def _connect(self):
        self._sock.connect(self._path)

    def _listen(self):
        if os.path.exists(self._path):
            os.unlink(self._path)
        else:
            socket_dir = os.path.dirname(self._path)
            if not os.path.isdir(socket_dir):
                os.makedirs(socket_dir)

        self._sock.bind(self._path)
        self._sock.listen(100)

    def initialize(self):
        super(NetDictTransport, self).initialize()
        self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET)

        # If the socket type is server bind to the given path and start listening.
        if self._sock_type == SocketType.Server:
            self._listen()
        # If socket type is clint connect o the given address.
        elif self._sock_type == SocketType.Client:
            self._connect()
        else:
            raise TypeError("Unknown socket type \"%s\"" % self._sock_type)

    def verify(self):
        pass

    def fileno(self):
        return self._sock.fileno()

    def start(self):
        super(NetDictTransport, self).start()

        # If Socket type is client we don't need to run any job until explicitly asked to send data.
        if self._sock_type == SocketType.Server:
            # Start accepting and serving clients.
            self._srv_job = self._run_job(name='unix-ctrl-srv', func=self._handle_clients)

    def cleanup(self):
        super(NetDictTransport, self).cleanup()

        if os.path.exists(self._path):
            os.unlink(self._path)

        if self._srv_job:
            self._stop_job(self._srv_job)
            self._srv_job = None

        if self._sock:
            self._sock.close()
            self._sock = None

    def _handle_clients(self):
        try:
            while ServiceState.Started == self.get_state():
                if select.select([self._sock], [], [], 0.2)[0]:
                    self._accept_socket_index += 1
                    self._run_job(name='unix-socket-reader-%d' % self._accept_socket_index,
                                  func=self._handle_single_client)
            LOG.debug("Out of unix-queue handling entry (service-state: %s)", self.get_state().name)
        except (KeyboardInterrupt, SystemExit):
            pass
        except Exception:
            LOG.exception("Error handling clients on unix queue")

    def _handle_single_client(self, timeout=3.3):
        if self._sock is None:
            raise GuardicoreException("Failed reading data from '%s': %s socket was not initialized", self._path, self.__class__.__name__)

        sock, _ = self._sock.accept()

        while ServiceState.Started == self.get_state():
            if not self._read_info_from_socket(sock, timeout):
                break
        sock.close()

    def _read_info_from_socket(self, sock, timeout=3.3):
        rlist, _, _ = select.select([sock], [], [], timeout)
        if not rlist:
            return True

        try:
            data = sock.recv(self._max_recv)
        except socket.error:
            LOG.warning("Socket error reading data off unix transport, socket_path: %s", self._path)
            return False

        if not data:
            LOG.warning("No data from unix transport, socket_path: %s", self._path)
            return False

        try:
            # Decode data received from the socket according to communication strategy.
            data_obj = self._communication_strategy.prepare_after_receive(data)
        except GuardicoreException as exc:
            LOG.warning("Error reading command off unix socket: %s", exc)
            return False

        if self._cb:
            # Run given call back on the data and send back the response.
            ret_obj = self._cb(data_obj)

            try:
                if ret_obj:
                    sock.sendall(self._communication_strategy.prepare_for_send(ret_obj))
            except socket.error as exc:
                LOG.error("Failed sending reply: %s", exc)
                return False

        return True

    def send_data(self, data, response_expected, max_recv=MAX_SO_RECV_SIZE):
        if self._sock is None:
            raise GuardicoreException("Failed sending data on '%s': %s socket was not initialized", self._path, self.__class__.__name__)

        try:
            # Send data to the server socket.
            self._sock.sendall(self._communication_strategy.prepare_for_send(data))
        except socket.error as exc:
            # If send failed try to reopen the socket and resend the data.

            LOG.error("Failed sending on '%s': %s", self._path, exc)

            self._sock.close()
            self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET)
            self._connect()

            try:
                self._sock.sendall(self._communication_strategy.prepare_for_send(data))
            except socket.error as exc:
                LOG.error("Failed sending on '%s' after reconnect attempt: %s", self._path, exc)
                return None

        if not response_expected:
            return None

        unpacked_response = None
        try:
            response = self._sock.recv(max_recv)
            unpacked_response = self._communication_strategy.prepare_after_receive(response)
        except socket.timeout:
            LOG.error("Response is empty (timeout)")
        finally:
            return unpacked_response


class NetSingleDictTransport(NetDictTransport, SimpleNetDictSender):
    """
    Subclass of 'NetDictTransport' for reopening a socket for each piece of data and closing it after a message was sent.
    """
    def __init__(self, path, cb=None, communication_strategy=JsonCommunicationStrategy):
        super(NetSingleDictTransport, self).__init__(path, sock_type=SocketType.Server, cb=cb,
                                                     communication_strategy=communication_strategy)

    def _handle_clients(self):
        while ServiceState.Started == self.get_state():
            rlist, _, _ = select.select([self._sock], [], [], 0.4)
            if not rlist:
                continue
            client_sock, _ = self._sock.accept()

            try:
                # for each accepted socket handle data and then close the accepted socket.
                self._read_info_from_socket(client_sock)
            except:
                LOG.exception("Error while handling client on '%s' unix transport", self._path)
            finally:
                client_sock.close()
