

# This function merges all non conflicted valies from from_dict to updated_dict, and puts all
# conflicted values in the same path on the conflict_dict
def recursive_update_dict_with_conflicts(updated_dict, from_dict, conflict_dict, path=''):
    for key, value in from_dict.items():
        if isinstance(value, dict):
            new_conflict_dict = conflict_dict.setdefault('properties', {}).setdefault(key, {})
            new_path = '%s.%s' % (path, key)
            recursive_update_dict_with_conflicts(updated_dict.setdefault(key, {}), value, new_conflict_dict, new_path)
        else:
            if key in updated_dict and key in from_dict and updated_dict[key] != from_dict[key]:
                conflict_dict.setdefault('properties', {}).setdefault(key, {})['conflict'] = '%s.%s' % (path, key)
                del updated_dict[key]
            elif key not in conflict_dict:
                updated_dict[key] = value
