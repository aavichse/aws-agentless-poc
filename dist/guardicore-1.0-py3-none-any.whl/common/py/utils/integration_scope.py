from enum import Enum


class IntegrationScope(Enum):
    PLATFORM = 'Platform'
    AZURE_SUBSCRIPTION = 'Azure subscription'
    AZURE_SUBSCRIPTION_ID = 'Azure subscription id'
    AZURE_REGION = 'Azure region'
    AZURE_RESOURCE_TYPE = 'Azure resource type'
    AZURE_RESOURCE_GROUP = 'Azure resource group'
    AZURE_SUBNET = 'Azure subnet'
    AZURE_VNET = 'Azure VNet'
    AZURE_SERVICE_TAG = 'Azure service tag'

    @classmethod
    def values(cls):
        return [value.value for value in cls.__members__.values()]

    @classmethod
    def azure_keys(cls):
        return [cls.AZURE_SUBSCRIPTION,
                cls.AZURE_REGION,
                cls.AZURE_VNET,
                cls.AZURE_RESOURCE_GROUP,
                cls.AZURE_RESOURCE_TYPE,
                cls.AZURE_SUBNET,
                cls.AZURE_SUBSCRIPTION_ID,
                cls.AZURE_SERVICE_TAG]

    @classmethod
    def azure_label_keys(cls):
        label_keys = cls.azure_keys()
        label_keys.append(cls.PLATFORM)
        label_keys.remove(cls.AZURE_SUBSCRIPTION)

        return label_keys

    @classmethod
    def metadata_keys(cls):
        return [cls.AZURE_SUBSCRIPTION,
                cls.AZURE_REGION,
                cls.AZURE_VNET,
                cls.AZURE_RESOURCE_GROUP,
                cls.AZURE_RESOURCE_TYPE,
                cls.AZURE_SUBNET]

    @classmethod
    def get_integration_from_key(cls, key):
        if cls(key) in cls.azure_keys():
            return 'azure'
        else:
            return 'unknown integration key'
