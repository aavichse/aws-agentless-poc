import sys

from eventlet import Timeout
from eventlet.event import Event
from eventlet.greenthread import getcurrent
from eventlet.hubs import get_hub
from eventlet.queue import Waiter

_NONE = object()


class Full(Exception):
    pass


class Empty(Exception):
    pass


class LightSet(object):
    """
    This is a variant of set that behaves similarly to :class:`eventlet.queue.LightQueue` only
    the underlying data structure is set
    """

    def __init__(self, maxsize=None):
        if maxsize is None or maxsize < 0:
            self.maxsize = None
        else:
            self.maxsize = maxsize
        self.getters = set()
        self.putters = set()
        self._event_unlock = None
        self.set = set()

    def remove(self, item):
        return self.set.remove(item)

    def discard(self, item):
        return self.set.discard(item)

    def clear(self):
        self.set.clear()
        
    def _pop(self):
        return self.set.pop()

    def _add(self, item):
        self.set.add(item)

    def __repr__(self):
        return '<%s at %s %s>' % (type(self).__name__, hex(id(self)), self._format())

    def __str__(self):
        return '<%s %s>' % (type(self).__name__, self._format())

    def _format(self):
        result = ''
        if self.maxsize:
            result += 'maxsize=%r' % (self.maxsize,)
        if self.set:
            result += ' set=%r' % self.set
        if self.getters:
            result += ' getters[%s]' % len(self.getters)
        if self.putters:
            result += ' putters[%s]' % len(self.putters)
        if self._event_unlock is not None:
            result += ' unlocking'
        return result

    def size(self):
        return len(self.set)

    def resize(self, size):
        """Resizes the set's maximum size.

        If the size is increased, and there are putters waiting, they may be woken up."""
        if self.maxsize is not None and (size is None or size > self.maxsize):
            # Maybe wake some stuff up
            self._schedule_unlock()
        self.maxsize = size

    def putting(self):
        """
        Returns the number of greenthreads that are blocked waiting to add items into the set.
        """
        return len(self.putters)

    def getting(self):
        """
        Returns the number of greenthreads that are blocked waiting on an empty set.
        """
        return len(self.getters)

    def empty(self):
        """
        Return ``True`` if the set is empty, ``False`` otherwise.
        """
        return not self.size()

    def full(self):
        """
        Return ``True`` if the set is full, ``False`` otherwise.
        """
        return self.maxsize is not None and self.size() >= self.maxsize

    def add(self, item, block=True, timeout=None):
        """
         Add an item into the set.
        If optional arg *block* is true and *timeout* is ``None`` (the default),
        block if necessary until a free slot is available. If *timeout* is
        a positive number, it blocks at most *timeout* seconds and raises
        the :class:`Full` exception if no free slot was available within that time.
        Otherwise (*block* is false), put an item on the set if a free slot
        is immediately available, else raise the :class:`Full` exception (*timeout*
        is ignored in that case).
        """
        if self.maxsize is None or self.size() < self.maxsize:
            # there's a free slot, put an item right away
            self._add(item)
            if self.getters:
                self._schedule_unlock()
        elif not block and get_hub().greenlet is getcurrent():
            while self.getters:
                getter = self.getters.pop()
                if getter:
                    self._add(item)
                    item = self._pop()
                    getter.switch(item)
                    return
            raise Full
        elif block:
            waiter = ItemWaiter(item)
            self.putters.add(waiter)
            timeout = Timeout(timeout, Full)
            try:
                if self.getters:
                    self._schedule_unlock()
                result = waiter.wait()
                assert result is waiter, "Invalid switch into Set.add: %r" % (result,)
                if waiter.item is not _NONE:
                    self._add(item)
            finally:
                timeout.cancel()
                self.putters.discard(waiter)
        else:
            raise Full

    def add_nowait(self, item):
        """
        Add an item into the set without blocking.

        Only add the item if a free slot is immediately available.
        Otherwise raise the :class:`Full` exception.
        """
        self.add(item, False)

    def pop(self, block=True, timeout=None):
        """
        Remove and return an arbitrary item from the set.
        If optional args *block* is true and *timeout* is ``None`` (the default),
        block if necessary until an item is available. If *timeout* is a positive number,
        it blocks at most *timeout* seconds and raises the :class:`Empty` exception
        if no item was available within that time. Otherwise (*block* is false), return
        an item if one is immediately available, else raise the :class:`Empty` exception
        (*timeout* is ignored in that case).
        """
        if self.size():
            if self.putters:
                self._schedule_unlock()
            return self._pop()
        elif not block and get_hub().greenlet is getcurrent():
            # special case to make get_nowait() runnable in the mainloop greenlet
            # there are no items in the set; try to fix the situation by unlocking putters
            while self.putters:
                putter = self.putters.pop()
                if putter:
                    putter.switch(putter)
                    if self.size():
                        return self._pop()
            raise Empty
        elif block:
            waiter = Waiter()
            timeout = Timeout(timeout, Empty)
            try:
                self.getters.add(waiter)
                if self.putters:
                    self._schedule_unlock()
                return waiter.wait()
            finally:
                self.getters.discard(waiter)
                timeout.cancel()
        else:
            raise Empty

    def pop_nowait(self):
        """
        Remove and return an arbitrary item from the set without blocking.
        Only get an item if one is immediately available. Otherwise
        raise the :class:`Empty` exception.
        """
        return self.pop(False)

    def _unlock(self):
        try:
            while True:
                if self.size() and self.getters:
                    getter = self.getters.pop()
                    if getter:
                        try:
                            item = self._pop()
                        except:
                            getter.throw(*sys.exc_info())
                        else:
                            getter.switch(item)
                elif self.putters and self.getters:
                    putter = self.putters.pop()
                    if putter:
                        getter = self.getters.pop()
                        if getter:
                            item = putter.item
                            # this makes greenlet calling add() not to call _add() again
                            putter.item = _NONE
                            self._add(item)
                            item = self._pop()
                            getter.switch(item)
                            putter.switch(putter)
                        else:
                            self.putters.add(putter)
                elif self.putters and (self.getters or
                                       self.maxsize is None or
                                       self.size() < self.maxsize):
                    putter = self.putters.pop()
                    putter.switch(putter)
                else:
                    break
        finally:
            self._event_unlock = None

    def _schedule_unlock(self):
        if self._event_unlock is None:
            self._event_unlock = get_hub().schedule_call_global(0, self._unlock)


class ItemWaiter(Waiter):
    __slots__ = ['item']

    def __init__(self, item):
        Waiter.__init__(self)
        self.item = item


class Set(LightSet):
    """
    This is a variant of set that behaves similarly to :class:`eventlet.queue.Queue` only
    the underlying data structure is set
    """

    def __init__(self, maxsize=None):
        LightSet.__init__(self, maxsize)
        self.unfinished_tasks = 0
        self._cond = Event()

    def _format(self):
        result = LightSet._format(self)
        if self.unfinished_tasks:
            result += ' tasks=%s _cond=%s' % (self.unfinished_tasks, self._cond)
        return result

    def _add(self, item):
        LightSet._add(self, item)
        self._add_bookkeeping()

    def _add_bookkeeping(self):
        self.unfinished_tasks += 1
        if self._cond.ready():
            self._cond.reset()

    def task_done(self):
        """
        Indicate that a formerly added task is complete. Used by set consumer threads.
        For each :meth:`get <Set.pop>` used to fetch a task, a subsequent call to
        :meth:`task_done` tells the set that the processing on the task is complete.

        If a :meth:`join` is currently blocking, it will resume when all items have been processed
        (meaning that a :meth:`task_done` call was received for every item that had been
        :meth:`put <Set.add>` into the set).

        Raises a :exc:`ValueError` if called more times than there were items placed in the set.
        """

        if self.unfinished_tasks <= 0:
            raise ValueError('task_done() called too many times')
        self.unfinished_tasks -= 1
        if self.unfinished_tasks == 0:
            self._cond.send(None)

    def join(self):
        """
        Block until all items in the set have been gotten and processed.
        The count of unfinished tasks goes up whenever an item is added to the set.
        The count goes down whenever a consumer thread calls :meth:`task_done` to indicate
        that the item was retrieved and all work on it is complete. When the count of
        unfinished tasks drops to zero, :meth:`join` unblocks.
        """
        if self.unfinished_tasks > 0:
            self._cond.wait()
