import datetime
import logging
import socket
import ssl

import pytz
import six
from enum import Enum
from logging.handlers import SysLogHandler
from tempfile import NamedTemporaryFile

from common.py.data_export.exporters.syslog_datetime import DatetimeFormatter, SyslogTimestampFormat, TimeField

Lock = None
try:
    import gevent.lock
    Lock = gevent.lock.Semaphore
except ImportError:
    pass

try:
    import eventlet.semaphore
    Lock = eventlet.semaphore.Semaphore
except ImportError:
    pass

from common.logger import get_logger
from common.py.model.exceptions import CriticalConfigException
from common.py.utils.config import cfg
from common.py.utils.config.types import Port, List, String
from common.py.utils.network import is_ip_address


LOGGER = get_logger()


class SyslogType(Enum):
    EVENTS_SYSLOG = 'Events Syslog Exporter'
    NETWORK_LOG_SYSLOG = 'Network Log Syslog Exporter'


class SyslogFormatDisplayName(Enum):
    CEF = 'Legacy CEF'
    ARCSIGHT_CEF = 'CEF'

    @classmethod
    def get_value_from_syslog_format(cls, syslog_format):
        return cls[syslog_format.name].value if syslog_format.name in cls.__members__ else syslog_format.value


class SyslogFormat(Enum):
    NATIVE = 'Native'
    CEF = 'CEF'
    RFC_5424 = 'RFC 5424'
    ARCSIGHT_CEF = 'ArcSight CEF'

    @classmethod
    def from_syslog_format_display_name_value(cls, display_name_value):
        display_name = SyslogFormatDisplayName._value2member_map_.get(display_name_value)
        return cls[display_name.name] if display_name else cls(display_name_value)


class SyslogTimezone:
    DEFAULT_TZ = '(UTC+0000) UTC'
    ITEMS = {tz: 'UTC{diff}'.format(diff=datetime.datetime.now(pytz.timezone(tz)).strftime('%z')) for tz in
             pytz.common_timezones_set if not tz == 'GMT'}

    @classmethod
    def get_options(cls):
        """
        Returns a sorted list of timezones and their offsets.
        The list is sorted by the UTC offset
        Partial Example: ['(UTC-1100) Pacific/Midway', ..., '(UTC-0300) America/Argentina/Cordoba', ...,
                          '(UTC+0000) UTC', ..., '(UTC+0200) Asia/Jerusalem', ..., '(UTC+1000) Pacific/Port_Moresby']
        """
        ordered_keys = sorted(cls.ITEMS, key=lambda x: (int(cls.ITEMS[x].replace('UTC', '')), x))
        return sorted(['({}) {}'.format(cls.ITEMS[key], key) for key in ordered_keys], key=lambda x: '+' in x)

    @classmethod
    def from_syslog_timezone_display_name_to_value(cls, display_name_value):
        return display_name_value.split(' ')[1]


MAX_SYSLOG_UDP_MESSAGE_LEN = 1420
MAX_SYSLOG_TCP_MESSAGE_LEN = 16384  # same value as  QRadar having for  max syslog message length
MAX_SYSLOG_TAGS_LEN = 500
MAX_DESCRIPTION_LEN = 800

SYSLOG_PROTO_TO_SOCKTYPE = {
    'UDP': socket.SOCK_DGRAM,
    'TCP': socket.SOCK_STREAM
}

DEFAULT_DELIMITER = '\n'


# Base Syslog Options:
BASE_SYSLOG_GROUP = 'base_syslog_exporter'

base_syslog_opts = [
    cfg.StrOpt('id'),
    cfg.StrOpt('name'),
    cfg.StrOpt('syslog_type'),
    cfg.StrOpt('syslog_host',
               default=None,
               required=False,
               help='IP address or hostname of syslog server'),
    cfg.Opt('syslog_port',
            default=logging.handlers.SYSLOG_UDP_PORT,
            required=True,
            help='Port number of syslog server',
            type=Port()),
    cfg.IntOpt('incidents_syslog_facility',
               default=logging.handlers.SysLogHandler.LOG_USER,
               required=True),
    cfg.StrOpt('syslog_protocol',
               default='UDP',
               choices=['TCP', 'UDP'],
               required=True),
    cfg.Opt('syslog_format', default=SyslogFormat.NATIVE.value,
            type=String(unicode=False, choices=[
                 SyslogFormatDisplayName.get_value_from_syslog_format(log_format) for log_format in SyslogFormat
            ]),
            required=True),
    cfg.ExtendedOpt('rfc_5424_structured_data',
                    default=[],
                    required=False,
                    # In aggregator (python2), the items are str (and surrounded with quotes) due to OsloSecret encoding
                    type=List(item_type=String(unicode=six.PY3, quotes=six.PY2), bounds=True),
                    multi_line_text=True,
                    secret=True),
    cfg.StrOpt('display_hostname', default='Guardicore', required=True,
               help='The hostname that will be emitted in the host field of CEF / RFC 5424 exports'),
    cfg.IntOpt('max_syslog_tcp_message_len', default=MAX_SYSLOG_TCP_MESSAGE_LEN,
               help='truncate every syslog TCP message which exceeded the length of max_syslog_tcp_message_len'),
    cfg.IntOpt('max_syslog_udp_message_len', default=MAX_SYSLOG_UDP_MESSAGE_LEN,
               help='truncate every syslog UDP message which exceeded the length of max_syslog_udp_message_len'),
    cfg.IntOpt('max_description_len', default=MAX_DESCRIPTION_LEN),
    cfg.IntOpt('max_syslog_tags_len', default=MAX_SYSLOG_TAGS_LEN),
    cfg.BoolOpt('use_tls',
                default=False,
                required=True),
    cfg.BoolOpt('perform_server_verification',
                default=True,
                required=False),
    cfg.ExtendedOpt('server_certificate_chain',
                    default=[],
                    required=False,
                    type=List(item_type=String(unicode=True), bounds=True),
                    multi_line_text=True),
    cfg.ExtendedOpt('client_combined_certificate',
                    default=[],
                    required=False,
                    # In aggregator (python 2), the items are str (surrounded with quotes) due to OsloSecret encoding
                    type=List(item_type=String(unicode=six.PY3, quotes=six.PY2), bounds=True),
                    multi_line_text=True,
                    secret=True),
    cfg.Opt('timestamp_format',
            default=SyslogTimestampFormat.ISO8601_MINUTES.value,
            type=String(unicode=False, choices=[
                    SyslogTimestampFormat.timestamp_format_name(log_format)
                    for log_format in SyslogTimestampFormat
                ])),
    cfg.Opt('time_zone', default=SyslogTimezone.DEFAULT_TZ,
            type=String(unicode=False, choices=SyslogTimezone.get_options()),
            required=True),
    cfg.BoolOpt('export_through_aggregators',
                default=False,
                required=True,
                help='Tunnel exporting via aggregators'),

]


class BaseSyslogExporter(object):
    """
    Base class that holds all common Syslog methods
    """
    def __init__(self, conf, syslog_id, is_test_connection=False):
        self.id = syslog_id
        self.conf = conf
        self.is_test_connection = is_test_connection

        self.logger = get_logger()
        self.syslog_handler = None
        self.syslog_logger = None  # Override by subclasses
        self.syslog_handler_init_lock = Lock()
        self.timezone = pytz.timezone(SyslogTimezone.from_syslog_timezone_display_name_to_value(self.conf.base_syslog_exporter.time_zone))
        self.timestamp_format = self.conf.base_syslog_exporter.timestamp_format

    def close_syslog_exporter(self):
        self._close_handler()

    @property
    def type(self):
        return self.conf.base_syslog_exporter.syslog_type

    def test_connection(self, entry):
        entry['id'] = 'Test'
        entry['description'] = 'Test successful'

        details = dict(request=entry.get('path'),
                       act=entry.get('title'),
                       suser=entry.get('username'),
                       msg=entry.get('description'),
                       src=entry.get('remote_addr'))

        if self.conf.base_syslog_exporter.syslog_format == SyslogFormat.ARCSIGHT_CEF.value:
            start_time = self.get_formatted_time_from_date(entry.get('time'), TimeField.CEF_START)

            message = self._prepare_test_connection_cef_message(details=dict(start=start_time,
                                                                             dvc=entry.get('remote_addr'),
                                                                             dvchost='N/A',
                                                                             act=entry.get('title')))
        elif self.conf.base_syslog_exporter.syslog_format == SyslogFormat.CEF.value:
            message = self._prepare_test_connection_cef_message(details)
        elif self.conf.base_syslog_exporter.syslog_format == SyslogFormat.RFC_5424.value:
            message = self._prepare_rfc_5424_message(message_type='Audit',
                                                     message_function=self._prepare_test_connection_text_message,
                                                     message_function_args=[details])
        else:
            message = self._prepare_test_connection_text_message(details)
        self._export_message(message)

    # ******* Exporting methods: *******

    def _export_message(self, message):
        self._prepare_handler()
        self.syslog_logger.critical(message)

    # ******* Message preparing methods: *******

    def _prepare_rfc_5424_message(self, message_type, message_function, message_function_args):
        message = message_function(*message_function_args, delimiter=';')
        rfc_5424_structured_data = \
            BaseSyslogExporter.sanitize_empty_lists(self.conf.base_syslog_exporter.rfc_5424_structured_data)
        structured_data = '[' + ']['.join(rfc_5424_structured_data) + ']' if rfc_5424_structured_data else '-'

        timestamp = self.get_formatted_time_from_date(datetime.datetime.utcnow(), TimeField.RFC5424_HEADER)

        return "{version} {timestamp} {hostname} {app_name} {procid} {msgid} {structured_data} {message}".format(
            version=1,  # Syslog protocol version (See RFC 5424)
            timestamp=timestamp,
            hostname=self.conf.base_syslog_exporter.display_hostname,
            app_name="Guardicore-Centra",
            procid="-",  # Syslog NILVALUE (See RFC 5424)
            msgid=message_type,
            structured_data=structured_data,
            message=message)

    def _prepare_test_connection_cef_message(self, details):
        cef_exporter = self._get_cef_exporter(device_event_class_id='Test connection',
                                              name='Test connection', severity='Unknown',
                                              extensions=details)

        now_timestamp = self.get_formatted_time_from_date(datetime.datetime.utcnow(), TimeField.CEF_HEADER)

        message = cef_exporter.create_cef_message(
            display_hostname=self.conf.base_syslog_exporter.display_hostname,
            now_timestamp=now_timestamp)

        return self._limit_mgs_length(message, self.get_max_syslog_message_len())

    @classmethod
    def _prepare_test_connection_text_message(cls, details, delimiter='\n'):
        details['delimiter'] = delimiter
        return "New test connection entry reported by the Guardicore Security Suite{delimiter}{delimiter}" \
               "Username: {suser}{delimiter}" \
               "IP Address: {src}{delimiter}{delimiter}" \
               "Title: {act}{delimiter}{delimiter}" \
               "Description: {msg}".format(**details)

    def get_max_syslog_message_len(self):
        if self.conf.base_syslog_exporter.syslog_protocol == 'TCP':
            return self.conf.base_syslog_exporter.max_syslog_tcp_message_len
        else:
            return self.conf.base_syslog_exporter.max_syslog_udp_message_len

    # ******* Internal utils methods: *******

    def _close_handler(self):
        if self.syslog_handler is not None:
            self.syslog_logger.removeHandler(self.syslog_handler)
            self.syslog_handler.close()

    def _is_syslog_params_changed(self, host, port, facility, socktype):
        return self.syslog_handler is None or self.syslog_handler.address != (host, port) or \
               self.syslog_handler.facility != facility or self.syslog_handler.socktype != socktype

    def _prepare_handler(self):
        self.syslog_logger.disabled = False
        host = self.conf.base_syslog_exporter.syslog_host
        port = self.conf.base_syslog_exporter.syslog_port
        facility = self.conf.base_syslog_exporter.incidents_syslog_facility
        socktype = SYSLOG_PROTO_TO_SOCKTYPE[self.conf.base_syslog_exporter.syslog_protocol]

        # Adding multiple handlers to logger results in duplicate messages to syslog backend
        # GC-42881
        # https://stackoverflow.com/questions/7173033/duplicate-log-output-when-using-python-logging-module
        # We don't want to lock right away, performance-wise, so need to do double check here
        # Most of the time we will do only check here instead of lock + check, balance of probabilities
        if self._is_syslog_params_changed(host, port, facility, socktype):
            with self.syslog_handler_init_lock:
                if not self._is_syslog_params_changed(host, port, facility, socktype):
                    return

                # Syslog parameters have changes; re-initialize syslog handler
                self._close_handler()
                try:
                    self.syslog_handler = ExtendedSysLogHandler(
                        address=(host, port),
                        facility=facility,
                        socktype=socktype,
                        use_tls=self.conf.base_syslog_exporter.use_tls,
                        perform_server_verification=self.conf.base_syslog_exporter.perform_server_verification,
                        server_certificate_chain=self.conf.base_syslog_exporter.server_certificate_chain,
                        client_combined_certificate=self.conf.base_syslog_exporter.client_combined_certificate,
                        is_test_connection=self.is_test_connection)
                    self.syslog_logger.addHandler(self.syslog_handler)
                except TimeoutError:
                    LOGGER.exception("Error while trying to connect to syslog server (%s, %s)", host, port)

    def _is_syslog_defined(self):
        host = self.conf.base_syslog_exporter.syslog_host
        port = self.conf.base_syslog_exporter.syslog_port
        return host and port

    @staticmethod
    def _get_cef_exporter(version=None, device_event_class_id=None, name=None, severity=None, extensions=None):
        # import the CEF exporter only if needed since memory footprint of this import is ~12M
        from common.py.data_export.cef_export_utils import CefMessageExporter
        return CefMessageExporter(version=version,
                                  device_event_class_id=device_event_class_id,
                                  name=name, severity=severity,
                                  extensions=extensions)

    @classmethod
    def _limit_mgs_length(cls, msg, max_len):
        if len(msg) > max_len:
            msg = msg[:max_len] + '...<truncated>'
        return msg

    @staticmethod
    def sanitize_empty_lists(input_list):
        if input_list is None:
            return None

        # GC-39680: when getting the list for test connectivity from the UI, empty list is reported as [null]
        elif not input_list or (len(input_list) == 1 and input_list[0] is None):
            return []
        return input_list

    def get_formatted_time_from_date(self, datetime_record, time_field=None):
        return DatetimeFormatter(time_field=time_field).get_timestamp_from_date(
            self.timestamp_format, datetime_record, self.timezone)


class ExtendedSysLogHandler(SysLogHandler):
    """
    Overriding SysLogHandler due to GC-10957 (Syslog over TCP does not recover from disconnections) -
    on disconnections SysLogHandler does not recover and does not report of the error in any informative way
    (except writing an error to stderr which we don't capture).
    So, on errors in sendall (TCP version), we attempt to reconnect (and will attempt again next time if it doesn't work).
    Note to future developers: I removed the unix socket support to make this simpler, see logging.handlers.SysLogHandler
     for reference on syslog over unit sockets.

    In addition, this class supports exporting over TLS
    """

    def __init__(self, address, facility, socktype, use_tls=False,
                 perform_server_verification=True, server_certificate_chain=None, client_combined_certificate=None,
                 is_test_connection=False):
        super(ExtendedSysLogHandler, self).__init__(address=address, facility=facility, socktype=socktype)

        self.is_test_connection = is_test_connection
        self.use_tls = use_tls
        self.perform_server_verification = perform_server_verification
        self.server_certificate_chain = BaseSyslogExporter.sanitize_empty_lists(server_certificate_chain) or []
        self.client_combined_certificate = BaseSyslogExporter.sanitize_empty_lists(client_combined_certificate) or []
        if self.use_tls:
            self._wrap_socket()

    def _wrap_socket(self):
        if self.socktype != socket.SOCK_STREAM:
            raise CriticalConfigException("If TLS is used, protocol should be TCP (got socktype: %d)", self.socktype)

        host = self.address[0]
        host_is_ip = is_ip_address(host if isinstance(host, six.text_type) else six.u(host))
        if self.perform_server_verification and not self.server_certificate_chain and host_is_ip:
            raise CriticalConfigException("Cannot perform server verification if host is an IP address and no server CA"
                                          " certificates chain was given")

        LOGGER.info("Wrapping connection to Syslog server %s in TLS", self.address)
        server_hostname = None
        context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)

        if self.perform_server_verification:
            LOGGER.debug("Server verification required")
            context.verify_mode = ssl.CERT_REQUIRED
            if not host_is_ip:
                LOGGER.debug("Verify server hostname matches '%s'", host)
                context.check_hostname = True
                server_hostname = host
        else:
            LOGGER.debug("Server verification not required")
            context.verify_mode = ssl.CERT_NONE

        if self.server_certificate_chain:
            LOGGER.debug("Loading server CA certificates")
            with NamedTemporaryFile(delete=True) as ca_file:
                ca_file.write(six.b(self._prepare_ca_certificates_chunk(self.server_certificate_chain,
                                                                        self.is_test_connection)))
                ca_file.flush()
                context.load_verify_locations(cafile=ca_file.name)
        else:
            LOGGER.debug("Loading default CAs")
            context.load_default_certs()

        if self.client_combined_certificate:
            LOGGER.debug("Loading client certificates")
            with NamedTemporaryFile(delete=True) as client_certs_file:
                client_certs_file.write(six.b("\n".join(self.client_combined_certificate)))
                client_certs_file.flush()
                context.load_cert_chain(certfile=client_certs_file.name)

        ssl_socket = context.wrap_socket(self.socket, server_hostname=server_hostname)
        self.socket = ssl_socket

    def emit(self, record):
        """
        Emit a record.

        The record is formatted, and then sent to the syslog server. If
        exception information is present, it is NOT sent to the server.
        """
        msg = self.format(record) + '\n'
        """
        We need to convert record level to lowercase, maybe this will
        change in the future.
        """
        prio = b'<%d>' % self.encodePriority(self.facility,
                                             self.mapPriority(record.levelname))

        # Message is a string. Convert to bytes as required by RFC 5424
        msg = msg.encode('utf-8')
        msg = prio + msg

        try:
            if self.socktype == socket.SOCK_DGRAM:
                self.socket.sendto(msg, self.address)
            else:
                try:
                    self.socket.sendall(msg)
                except socket.error:
                    if self.is_test_connection:
                        raise

                    # ~~~~~ GC-10957 ~~~~~~
                    # On errors when sending data over TCP socket, close the socket and attempt to reconnect.
                    # If the reconnection failed, next time a message is reported a BrokenPipe error will probably occur
                    # (since the socket is closed) - worry not, this chunk of code will be called again
                    # and will trigger another reconnection attempt.
                    LOGGER.exception("Error occurred during socket.sendall - trying to reconnect to %s (socktype: %s)",
                                     self.address, self.socktype)
                    self.socket.close()
                    self.socket = socket.socket(socket.AF_INET, self.socktype)
                    self.socket.connect(self.address)
                    if self.use_tls:
                        self._wrap_socket()
                    self.socket.sendall(msg)
        except (KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            # Report to global logger (not using self.handleError which will just drop something to stderr which
            # is practically the same as reporting to /dev/null)
            LOGGER.exception("Failed exporting to syslog at %s (socktype: %s)", self.address, self.socktype)
            if self.is_test_connection:
                raise

    def close(self):
        """
        Closes the socket.
        """
        self.acquire()
        try:
            self.socket.close()
        finally:
            self.release()
        logging.Handler.close(self)

    @classmethod
    def _prepare_ca_certificates_chunk(cls, server_certificate_chain, is_test_connection):
        if is_test_connection or not server_certificate_chain[0].startswith("'"):
            ca_certificates_chunk = server_certificate_chain
        else:
            ca_certificates_chunk = [cert[1:-1] for cert in server_certificate_chain]

        return "\n".join(ca_certificates_chunk)
