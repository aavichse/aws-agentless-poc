from __future__ import print_function

import os
import stat
import sys
if not sys.platform.startswith('win'):
    import fcntl
else:
    import common.py.utils.linux.fcntl_stubs as fcntl

import socket
import signal
import subprocess
import threading
import traceback
from common.py.model.exceptions import ExceptionTimeout
from common.logger import get_logger
from common.py.utils.config import six
from common.py.utils.generic import check_output_independent, _build_cmd, EXEC_DEBUG

LOG = get_logger(module_name=__name__)


def check_call(cmd, root_helper=None, addl_env=None, shell=False):
    cmd, env = _build_cmd(cmd, root_helper, addl_env)

    if EXEC_DEBUG:
        print("Call execution:", cmd)

    # execute the subprocess
    process = subprocess.Popen(cmd,
                               shell=shell,
                               stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE,
                               env=env)

    # read all stdout/stderr data
    unused_stdout, unused_stderr = process.communicate()

    if EXEC_DEBUG:
        print("Call execution returned:", cmd)

    # get the process return code
    return not process.poll()


def check_output(cmd, root_helper=None, addl_env=None, process_input=None,
                 merge_stderr=False, run_as_root=False, subprocess_to_use=subprocess,
                 close_fds=False):
    if run_as_root:
        root_helper = 'sudo'
    return check_output_independent(cmd, root_helper=root_helper,
                                    addl_env=addl_env,
                                    process_input=process_input,
                                    merge_stderr=merge_stderr,
                                    subprocess_to_use=subprocess_to_use,
                                    close_fds=close_fds)


def execute_with_timeout(cmd, timeout, stdin=None):
    """execute_with_timeout(cmd, timeout, stdin=None) -> (exit code, stdout)
    
    Execute cmd command (a tuple of arguments) with a given timeout. Send stdin
    if to process if stdin given. If timeout is reached without execution is
    finished (-1, None) is returned. Else, the (exit code, stdout) is returned.
    """

    def _timeout_handler(signum, frame):
        raise ExceptionTimeout(timeout, "")

    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    signal.signal(signal.SIGALRM, _timeout_handler)
    signal.alarm(timeout)

    try:
        # wait for the process to finish
        stdout, unused_stderr = process.communicate(input=stdin)

        # reset the alarm
        signal.alarm(0)
    except ExceptionTimeout:
        try:
            process.terminate()
        except:
            pass

        return -1, None

    return process.poll(), stdout


def async_call_process(cmd, output=None, root_helper=None, addl_env=None, cwd=None):
    cmd, env = _build_cmd(cmd, root_helper, addl_env)

    if EXEC_DEBUG:
        print("Call execution:", cmd)

    # execute the subprocess
    process = subprocess.Popen(cmd,
                               shell=False,
                               stdout=output if output else subprocess.PIPE,
                               stderr=output if output else subprocess.PIPE,
                               env=env,
                               cwd=cwd)
    return process


def _async_check_call_thread(cmd, output=None, root_helper=None, addl_env=None):
    cmd, env = _build_cmd(cmd, root_helper, addl_env)

    if EXEC_DEBUG:
        print("Call execution:", cmd)

    # execute the subprocess
    process = subprocess.Popen(cmd,
                               shell=False,
                               stdout=output if output else subprocess.PIPE,
                               stderr=output if output else subprocess.PIPE,
                               env=env)

    # read all stdout/stderr data
    unused_stdout, unused_stderr = process.communicate()

    if EXEC_DEBUG:
        print("Call execution returned:", cmd)

    # get the process return code
    return not process.poll()


def async_check_call_with_strace(cmd, output):
    actual_cmd = ["strace", "-v"] + cmd
    threading.Thread(target=_async_check_call_thread, kwargs={'cmd': actual_cmd, 'output': output}).start()


def make_fd_close_on_exec(fd):
    """make_fd_close_on_exec(fd)

    Mark a file descriptor to be closed upon forking.
    """

    fcntl.fcntl(fd, fcntl.F_SETFD, fcntl.FD_CLOEXEC)


def make_file_close_on_exec(file_obj):
    """make_file_close_on_exec(file_obj)

    Mark a file object to be closed upon forking.
    """

    if getattr(file_obj, "fileno", None) is None:
        raise AttributeError("File object doesn't have a fileno() method")

    return make_fd_close_on_exec(file_obj.fileno())


def get_free_space(path="/"):
    stat = os.statvfs(path)
    return stat.f_frsize * stat.f_bavail


def verify_enough_space(path, min_disk_space_bytes):
    free_space_bytes = get_free_space(path)

    if free_space_bytes < min_disk_space_bytes:
        LOG.warn("Not enough free space (required: %d bytes, available: %d bytes)",
                 min_disk_space_bytes,
                 free_space_bytes)

        return False

    return True


def get_hostname():
    return socket.gethostname()


def get_uptime_string():
    return check_output(["uptime"])


class save_and_reraise_exception(object):
    """Save current exception, run some code and then re-raise.
    In some cases the exception context can be cleared, resulting in None
    being attempted to be re-raised after an exception handler is run. This
    can happen when eventlet switches greenthreads or when running an
    exception handler, code raises and catches an exception. In both
    cases the exception context will be cleared.
    To work around this, we save the exception state, run handler code, and
    then re-raise the original exception. If another exception occurs, the
    saved exception is logged and the new exception is re-raised.
    In some cases the caller may not want to re-raise the exception, and
    for those circumstances this context provides a reraise flag that
    can be used to suppress the exception.  For example::
      except Exception:
          with save_and_reraise_exception() as ctxt:
              decide_if_need_reraise()
              if not should_be_reraised:
                  ctxt.reraise = False
    If another exception occurs and reraise flag is False,
    the saved exception will not be logged.
    If the caller wants to raise new exception during exception handling
    he/she sets reraise to False initially with an ability to set it back to
    True if needed::
      except Exception:
          with save_and_reraise_exception(reraise=False) as ctxt:
              [if statements to determine whether to raise a new exception]
              # Not raising a new exception, so reraise
              ctxt.reraise = True
    """

    def __init__(self, reraise=True, logger=None):
        self.reraise = reraise

    def __enter__(self):
        self.type_, self.value, self.tb, = sys.exc_info()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            if self.reraise:
                LOG.error('Original exception being dropped: %s',
                          traceback.format_exception(self.type_,
                                                     self.value,
                                                     self.tb))
            return False
        if self.reraise:
            six.reraise(self.type_, self.value, self.tb)


def validate_script_pre_run(script_path):
    # chmod +x
    script_stat = os.stat(script_path)
    os.chmod(script_path, script_stat.st_mode | stat.S_IEXEC)

    # dos2unix
    script_data = os.linesep.join([line.strip() for line in open(script_path, "r")])
    open(script_path, "wb").write(script_data)

    return script_path


def env_flag(env_name):
    """env_flag(env_name) -> bool

    Load an environment variable flag with True value being either '1', 'true',
    'on' or 'yes' with insensitive casing."""
    return os.getenv(env_name, "0").lower() in ("1", "true", "yes", "on")
