from collections import OrderedDict
from six import add_metaclass, iteritems, itervalues

__author__ = 'Eddie'


def _is_descriptor(obj):
    """Returns True if obj is a descriptor, False otherwise."""
    return (
            hasattr(obj, '__get__') or
            hasattr(obj, '__set__') or
            hasattr(obj, '__delete__'))


class EnumMeta(type):
    @classmethod
    def __prepare__(metacls, cls, bases):
        return OrderedDict()

    def __new__(metacls, cls, bases, classdict):
        enum_class = super(EnumMeta, metacls).__new__(metacls, cls, bases, classdict)
        # name->value map
        enum_class._member_map_ = OrderedDict()
        # Reverse value->name map for hashable values.
        enum_class._value2member_map_ = {}

        for name, value in iteritems(classdict):
            if not name.startswith('_') and not _is_descriptor(value):
                member = enum_class.__new__(enum_class, value)
                member.name = name
                member.value = value
                # name and value are not expected to change, so we can cache __repr__ and __hash__.
                member._repr = '<%s.%s: %r>' % (enum_class.__name__, name, value)
                member._hash = hash(name)

                member.__init__()

                setattr(enum_class, name, member)
                enum_class._member_map_[name] = member
                try:
                    # This may fail if value is not hashable. We can't add the value
                    # to the map, and by-value lookups for this value will be linear.
                    enum_class._value2member_map_[value] = member
                except TypeError:
                    pass
        return enum_class

    @property
    def __members__(cls):
        """Returns a mapping of member name->value.

        This mapping lists all enum members, including aliases. Note that this
        is a copy of the internal mapping.

        """
        return cls._member_map_.copy()

    def __call__(cls, value):
        # For lookups like Color(Color.red)
        if isinstance(value, cls):
            return value
        # by-value search for a matching enum member
        # see if it's in the reverse mapping (for hashable values)
        try:
            return cls._value2member_map_[value]
        except (KeyError, TypeError):
            # not there, now do long search -- O(n) behavior
            for member in itervalues(cls._member_map_):
                if member.value == value:
                    return member
        raise ValueError("%s is not a valid %s" % (value, cls.__name__))

    def __getitem__(cls, name):
        return cls._member_map_[name]

    def __iter__(cls):
        return (v for v in itervalues(cls._member_map_))

    def __reversed__(cls):
        return reversed([v for v in cls])

    def __len__(cls):
        return len(cls._member_map_)


class DynamicEnum(object):
    def __new__(cls, value, members):
        bases = (Enum,)
        return EnumMeta.__new__(EnumMeta, value, bases, members)

@add_metaclass(EnumMeta)
class Enum(object):

    def __repr__(self):
        return self._repr  # cache of `'<%s.%s: %r>' % (self.__class__.__name__, self.name, self.value)`

    def __new__(cls, value):
        # At first glance this look very confusing. but we implement this stub so
        # later we can call __new__ with the given value. Want to know why? look at
        # IntEnum.__new__ implementation.
        return super(Enum, cls).__new__(cls)

    def __str__(self):
        return '%s.%s' % (self.__class__.__name__, self.name)

    def __hash__(self):
        return self._hash  # cache of `hash(self.name)`

    # def __format__(self, format_spec):
    #     return str.__format__(str(self), format_spec)

    def __reduce_ex__(self, proto):
        return self.__class__, (self.value,)


class IntEnum(Enum, int):
    def __new__(cls, value):
        # we implement this so the int we create as the value of this enum
        # will be initialized with the appropriate value. It is done so the lines
        # >>> class Foo(IntEnum):
        #            bar  = 1
        # >>> "%d" % Foo.bar
        # "1" # - otherwise it would return 0.
        return super(Enum, cls).__new__(cls, value)

    def __eq__(self, other):
        try:
            return self.value == other.value
        except AttributeError:
            return self.value == other

    def __ne__(self, other):
        try:
            return self.value != other.value
        except AttributeError:
            return self.value != other

    def __and__(self, other):
        try:
            return self.value & other.value
        except AttributeError:
            return self.value & other

    def __int__(self):
        return self.value

    def __cmp__(self, other):
        try:
            return int.__cmp__(self.value, other.value)
        except AttributeError:
            return int.__cmp__(self.value, other)

    def __lt__(self, other):
        try:
            return self.value < other.value
        except AttributeError:
            return self.value < other

    def __gt__(self, other):
        try:
            return self.value > other.value
        except AttributeError:
            return self.value > other

    def __le__(self, other):
        try:
            return self.value <= other.value
        except AttributeError:
            return self.value <= other

    def __ge__(self, other):
        try:
            return self.value >= other.value
        except AttributeError:
            return self.value >= other

    def __hash__(self):
        return self.value

    def __bool__(self):
        return bool(self.value)

    # __nonzero__ is the name in python2
    __nonzero__ = __bool__
