from enum import IntEnum


class TransformableEnum(IntEnum):
    @classmethod
    def from_key_or_value(cls, key_or_value, upper=True):
        """
        Get the enum from key or value
        :param key_or_value: int or string
        :param upper: Look for upper key
        :return: TransformableEnum
        """
        if isinstance(key_or_value, int):
            return cls(key_or_value)

        key_or_value = key_or_value.upper() if upper else key_or_value
        return cls[key_or_value]

    @classmethod
    def from_key(cls, key, upper=True):
        """
        Get the enum from key
        :param key: string
        :param upper: Look for upper key
        :return: TransformableEnum
        """
        enum_key = key.upper() if upper else key
        return cls[enum_key]

    @classmethod
    def from_value(cls, value):
        """
        Get the enum from value
        :param value: int
        :return: TransformableEnum
        """
        return cls(value)
