
import time
from functools import wraps
from threading import current_thread

from common.logger import get_logger
from common.py.utils.linux.general import env_flag

LOG = get_logger(module_name=__name__)


def time_it(timeout=0, log_function=LOG.warn):
    def decorator(f):
        @wraps(f)
        def execute_timed(*args, **kwargs):
            start_time = time.time()

            try:
                return f(*args, **kwargs)
            finally:
                run_time = time.time() - start_time
                if run_time > timeout:
                    thread_name = current_thread().getName()
                    log_function("Function %s in thread '%s' took longer than expected (%s > %s)", f, thread_name,
                                 run_time, timeout)

        return execute_timed

    return decorator


WARN_ON_PERF = env_flag('WARN_ON_PERF')


class TimeIt(object):
    def __init__(self, title, timeout):
        self.title = title
        self.timeout = timeout
        self.start_time = None
        self.run_time = None

    def __enter__(self):
        if not WARN_ON_PERF:
            return

        self.start_time = time.time()

    def __exit__(self, exc_type, exc_val, exc_tb):
        if not WARN_ON_PERF:
            return

        self.run_time = time.time() - self.start_time
        thread_name = current_thread().getName()

        if self.timeout < self.run_time:
            LOG.warning("Action '%s' in thread '%s' took longer than expected (%s > %s)", self.title, thread_name,
                     self.run_time, self.timeout)
