import eventlet
import threading
from common.py.utils.linux.multiprocess_sync import EventletLockManager, ThreadLockManager


class HermeticLock(object):
    def __init__(self, lock_name, use_eventlet=True):
        self._intra_proc_lock = eventlet.semaphore.Semaphore(1) if use_eventlet else threading.Semaphore(1)
        if use_eventlet:
            self._inter_proc_lock = EventletLockManager().get_lock(lock_name, base_path="/var/run/honeypot")
        else:
            self._inter_proc_lock = ThreadLockManager().get_lock(lock_name, base_path="/var/run/honeypot")
        self._use_eventlet = use_eventlet

    def acquire(self):
        self._intra_proc_lock.acquire()
        self._inter_proc_lock.acquire()

    def release(self):
        self._inter_proc_lock.release()
        self._intra_proc_lock.release()

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()


class LockGroup(object):
    def __init__(self, locks):
        self._locks = locks

    def acquire(self):
        for lock in self._locks:
            lock.acquire()

    def release(self):
        for lock in self._locks:
            lock.release()

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()
