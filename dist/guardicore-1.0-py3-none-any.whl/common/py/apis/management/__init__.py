
UNKNOWN_API_VERSION = 'unknown'
UNKNOWN_KERNEL_VERSION = 'unknown'


class ManagementAPIError(Exception):
    pass


class RPCTimeoutError(ManagementAPIError):
    def __init__(self, rpc_func_name):
        super(RPCTimeoutError, self).__init__("Timeout during RPC call %s" % rpc_func_name)
