import posixpath

from enum import IntEnum

__author__ = 'Izi'


class MonicoreCommandType(IntEnum):
    Start = 1
    Stop = 2
    Restart = 3
    Status = 4
    Reload = 5
    Reconnect = 6
    Remove = 7
    Upgrade = 8
    DifferentialPatch = 9
    RootFsUpgrade = 10

class MonicoreUpgradeType(IntEnum):
    FullUpgrade = 1
    DifferentialPatch = 2


MONICORE_LIB_PATH = '/var/lib/monicore'
MONICORE_RUN_PATH = '/var/run/monicore'
MONICORE_LOG_PATH = '/var/log/monicore'
MONICORE_CTRL_SOCK = posixpath.join(MONICORE_RUN_PATH, 'monicore.sock')
MONICORE_STATUS_SOCK = posixpath.join(MONICORE_RUN_PATH, 'monicore-status.sock')
MONICORE_VOLUME = 'monicore-vol'
