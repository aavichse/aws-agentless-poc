from datetime import datetime, timedelta
import calendar

import pytz

DATETIME_FORMATS = (
    '%Y-%m-%dT%H:%M:%S.%fZ',  # RFC-3339
    '%Y-%m-%dT%H:%M:%S.%f',  # ISO-8601
    '%Y-%m-%dT%H:%M:%S',  # ISO-8601 without milliseconds
    '%a, %d %b %Y %H:%M:%S +%f'  # RFC-2822
)


def round_time(dt, interval, lower=True):
    """
    Round a datetime timestamp to the closest (lower) interval.
    :param dt: datetime timestamp
    :param interval: datetime timedelta interval
    :param lower: if True, round to lower interval. Otherwise, round to upper.
    :return: rounded time
    """
    total_seconds = (dt - datetime.min).total_seconds()
    round_seconds = (total_seconds // interval.total_seconds()) * interval.total_seconds()

    rounded = datetime.min + timedelta(seconds=round_seconds)
    if lower or dt == rounded:
        return rounded
    else:
        return rounded + interval


def get_start_of_next_day(current_time):
    return round_time(current_time + timedelta(days=1), timedelta(days=1), lower=True)


def date_to_timestamp(obj):
    # calendar.timegm is like time.mktime for utc input
    return int(calendar.timegm(obj.timetuple()) * 1000 + obj.microsecond / 1000)


def millisec_timestamp_floor(timestamp_secs):
    return int(timestamp_secs / 1000) * 1000


def timestamp_to_date(ts):
    """
    :param ts: in milliseconds
    :return: datetime object
    """
    if ts is None:
        return None
    return datetime.utcfromtimestamp(ts / 1000)


def timestamp_seconds_to_date(ts):
    """
    :param ts: in seconds
    :return: datetime object
    """
    if ts is None:
        return None

    return datetime.fromtimestamp(ts, tz=pytz.timezone('UTC'))


def js_to_unix_timestamp(ts):
    if ts is None:
        return None
    return int(ts / 1000)


def date_to_iso_timestamp_without_seconds(datetime_record):
    """Convert timestamp to string output with format yyyy-MM-ddTHH:mmZ"""
    return datetime_record.strftime("%Y-%m-%dT%H:%MZ")


def get_influx_timestamp_for_interval(interval):
    now_rounded = round_time(datetime.utcnow(), interval)
    now_timestamp = date_to_timestamp(now_rounded)

    # use influx syntax
    return get_influx_timestamp_from_timestamp(now_timestamp)


def get_influx_timestamp_from_timestamp(interval_timestamp):
    # use influx syntax
    return str(interval_timestamp) + 'ms'


def elastic_date_to_timestamp(d):
    if isinstance(d, datetime):
        return d

    if isinstance(d, float):
        return int(d)

    if isinstance(d, int):
        return d
    return date_to_timestamp(datetime.strptime(d.split('.')[0], '%Y-%m-%dT%H:%M:%S'))


def datetime_range(start, end, step=timedelta(days=1)):
    current = start
    while current < end:
        yield current
        current += step


def convert_str_to_date(time_field):
    """
    >>> convert_str_to_date('2019-02-13T17:26:09.028769Z')
    datetime(2019, 2, 13, 17, 26, 9, 28769)
    >>> convert_str_to_date('2019-02-13T17:26:09.028769')
    datetime(2019, 2, 13, 17, 26, 9, 28769)
    >>> convert_str_to_date('2019-02-13T17:26:09')
    datetime(2019, 2, 13, 17, 26, 9)
    >>> convert_str_to_date('Fri, 15 May 2009 17:58:28 +0000')
    datetime(2009, 5, 15, 17, 58, 28)
    >>> convert_str_to_date('1550072348')
    datetime(1970, 1, 18, 22, 34, 32, 348000)
    >>> convert_str_to_date(1550072348)
    datetime(1970, 1, 18, 22, 34, 32, 348000)
    >>> convert_str_to_date('17:26:09 2019-02-13')
    """
    if isinstance(time_field, str):
        if time_field.isdigit():
            time_field = float(time_field)
        else:
            for datetime_format in DATETIME_FORMATS:
                try:
                    return datetime.strptime(time_field, datetime_format)
                except ValueError:
                    pass
    if not isinstance(time_field, (int, float)):
        return

    return timestamp_to_date(time_field)


def calc_time_left_for_operation_in_seconds(timeout_value):
    """
    Calculates the amount of time left for the operation in seconds
    :param timeout_value: when will the operation be complete
    :return: the seconds left until completion
    """
    estimated_completion_seconds = int((timeout_value - datetime.utcnow()).total_seconds())
    return max(estimated_completion_seconds, 0)


def convert_datetime_to_milliseconds(datetime):
    """
    :param datetime: time in datetime
    :return: time in milliseconds (int)
    """
    return int(datetime.timestamp()) * 1000
