from enum import IntEnum


class LabelCriterionOperation(IntEnum):
    EQUALS = 0
    STARTSWITH = 1
    ENDSWITH = 2
    CONTAINS = 3
    WILDCARDS = 4
    SUBNET = 5
    # Not used in management, only used when deriving DC inventory for the agents
    REGEX = 6
    RANGE = 7
    NOT_EQUALS = 8
