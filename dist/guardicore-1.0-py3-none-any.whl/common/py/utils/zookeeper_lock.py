import logging
import os

from enum import Enum

import six
from kazoo.exceptions import LockTimeout

from common.deployment.util.zk_client import ZooKeeperClientHandler
from common.logger import get_logger


class LockType(str, Enum):
    READ_ONLY = "read_only"  # this process and other process will be available to read from this path
    WRITE_ONLY = "write_only"  # only this process will be available to write to this path

    @classmethod
    def has_value(cls, value):
        return value in cls._value2member_map_


class ZooKeeperLock(object):
    def __init__(self, lock_type, lock_path, value="", wait_to_lock_timeout=60 * 5, remove_lock_file=False):
        if not LockType.has_value(lock_type):
            raise TypeError("Lock type %s is not valid")
        self._lock_type = lock_type
        self._lock_path = lock_path
        self._value = value
        self.logger = get_logger(__name__)
        self.logger.setLevel(logging.DEBUG)
        self._wait_to_lock_timeout = wait_to_lock_timeout
        self._zk_client = ZooKeeperClientHandler(self.logger)
        self._lock = None
        self.lock_status = False
        self.remove_lock_file = remove_lock_file

    @property
    def zk_client(self):
        return self._zk_client

    def is_locked(self):
        if self._lock:
            return self._lock.is_acquired
        return False

    def _create_lock_file(self, run_over=False):
        if self._zk_client.zk.exists(self._lock_path):
            if not run_over:
                return
            self.logger.info("Found exists node %s, deleting it.")
            self._zk_client.zk.delete(self._lock_path)
        self.logger.info("Creating node %s with data %s" % (self._lock_path, self._value))
        self._zk_client.zk.create(self._lock_path, value=six.binary_type(self._value))

    def _connect_to_zookeeper(self):
        if not self._zk_client.is_connected():
            self.logger.info("Connecting to ZooKeeper")
            self._zk_client.connect_to_zk()
        if not self._zk_client.is_connected():
            self.logger.error("Failed to connect to ZooKeeper")

    def lock(self):
        try:
            self._connect_to_zookeeper()

            lock_base_path = os.path.dirname(self._lock_path)
            self.logger.info("Ensure base lock path exists: %s" % lock_base_path)
            self._zk_client.zk.ensure_path(lock_base_path)

            if self._lock_type == LockType.WRITE_ONLY.value:
                self.logger.info("generating WRITE lock")
                self._create_lock_file()
                self._lock = self._zk_client.zk.WriteLock(self._lock_path)
            elif self._lock_type == LockType.READ_ONLY.value:
                self.logger.info("generating READ lock")
                self._lock = self._zk_client.zk.ReadLock(self._lock_path)
            else:
                self.logger.info("generating FULL lock")
                self._lock = self._zk_client.zk.Lock(self._lock_path)

            try:
                self.logger.info("Trying to lock path %s" % self._lock_path)
                self._lock.acquire(timeout=self._wait_to_lock_timeout)
            except LockTimeout:
                self.logger.error("Failed to lock path %s" % self._lock_path)
                return False
        except Exception as e:
            self.logger.error("Failed to lock %s, with the error: %s" % (self._lock_path, e.message))
            return False

        self.logger.info("Successfully locked %s" % self._lock_path)
        self.lock_status = True
        return True

    def remove_lock(self):
        self.logger.info("Releasing lock on %s" % self._lock_path)
        if self._lock:
            self._lock.release()
            if self.remove_lock_file and self.lock_status:
                self.logger.info("Removing lock file %s" % self._lock_path)
                self._zk_client.zk.delete(self._lock_path)

    def __enter__(self):
        self.logger.info("Starting to lock %s" % self._lock_path)
        self.lock()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.logger.info("Start exit lock %s" % self._lock_path)
        self.remove_lock()
        self._zk_client.clean_up()
