from enum import IntEnum

import attr


class AgentMigrationStatus(IntEnum):
    PENDING = 1
    STARTED = 2
    SUCCESS = 3
    ERROR = 4
    SKIPPED = 5
    NOT_SUPPORTED = 6


@attr.s()
class AgentMigrationReport:
    job_id = attr.ib(type=str)
    agent_id = attr.ib(type=str)
    migration_status = attr.ib(type=AgentMigrationStatus)
    error = attr.ib(type=str)
