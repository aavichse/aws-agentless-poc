"""
Stubs for linux's fcntl module. 
"""

LOCK_EX = 0
LOCK_NB = 0
LOCK_UN = 0
F_SETFD = 0
FD_CLOEXEC = 0


def flock(*args, **kwargs):
    pass


def fcntl(*args, **kwargs):
    pass
