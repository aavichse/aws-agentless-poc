import threading
import gevent

from gevent.lock import BoundedSemaphore
from gevent import Timeout
from gevent.event import Event

from common import logger


LOG = logger.get_logger(module_name=__name__)


class TimeoutBoundedSemaphore(BoundedSemaphore):
    def __init__(self, *args, **kwargs):
        super(TimeoutBoundedSemaphore, self).__init__(*args, **kwargs)
        self._owner = None

    def __call__(self, *args, **kwargs):
        me = threading.current_thread().name
        try:
            acquired = self.acquire(**kwargs)
            if not acquired:
                raise Timeout()
        except Timeout:
            LOG.error("Lock is held by %s", self._owner)
            raise
        self._owner = me
        return self

    def __enter__(self):
        return self


def spawn_wait_started(g_routine, *args, **kwargs):
    on_started = Event()

    def _internal_routine(g_routine, *args, **kwargs):
        on_started.set()
        return g_routine(*args, **kwargs)

    g = gevent.spawn(_internal_routine, g_routine, *args, **kwargs)
    on_started.wait(timeout=10)
    return g
