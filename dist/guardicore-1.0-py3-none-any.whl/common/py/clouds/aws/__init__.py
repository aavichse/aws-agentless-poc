from enum import IntEnum
from common.py.clouds import common_opts, label_opts
from common.py.utils.config.oslo_config import types
from common.py.utils.config import cfg
from common.py.utils.config.types import Structure


class AwsAuthenticationMethod(IntEnum):
    InternalAws = 1
    GuardicoreCredentials = 2
    CustomerCredentials = 3


AwsAuthenticationMethodDescriptions = {AwsAuthenticationMethod.InternalAws: 'EC2 IAM Role',
                                       AwsAuthenticationMethod.GuardicoreCredentials: 'Guardicore delegate access',
                                       AwsAuthenticationMethod.CustomerCredentials: 'Customer credentials'}

aws_opts = [
               cfg.StrOpt('authentication_method',
                          default=AwsAuthenticationMethodDescriptions[AwsAuthenticationMethod.CustomerCredentials],
                          choices=list(AwsAuthenticationMethodDescriptions.values()),
                          help="<b>EC2 IAM Role:</b> Aggregators deployed in AWS will use their IAM role to authenticate with AWS; no credentials needed. Optional field: a different role ARN to assume.<br>"
                               "<b>Guardicore delegate access:</b> In SaaS environments, Centra assumes a role from the Guardicore AWS account. Required fields: External ID and Role ARN <br>"
                               "<b>Customer credentials:</b> use customer keys. Required fields: AWS access key ID and secret access key. Optional field: a role ARN to assume."),
               cfg.StrOpt('access_key_id', default=None, secret=True,
                          help="Required only if \"Customer credentials\" is used as the authentication method"),
               cfg.StrOpt('secret_access_key', default=None, secret=True,
                          help="Required only if \"Customer credentials\" is used as the authentication method"),
               cfg.StrOpt('region_name', choices=sorted(['us-east-1', 'us-west-2', 'us-west-1', 'eu-west-1',
                                                         'eu-central-1', 'ap-southeast-1', 'ap-southeast-2',
                                                         'ap-northeast-1', 'sa-east-1', 'us-east-2', 'ca-central-1',
                                                         'eu-west-2', 'eu-west-3', 'eu-north-1', 'ap-northeast-2',
                                                         'af-south-1', 'ap-east-1', 'ap-south-2', 'ap-south-1',
                                                         'ap-southeast-3', 'ap-northeast-3', 'eu-south-1', 'eu-south-2',
                                                         'eu-central-2', 'me-south-1', 'me-central-1',
                                                         'us-gov-east-1', 'us-gov-west-1'])),

               cfg.StrOpt('role_arn', default=None, help="The Amazon Resource Name (ARN) of the role to assume"),
               cfg.StrOpt('external_id', default=None,
                          help="A unique identifier that might be required when you assume a role in another account; "
                               "required only if \"Guardicore delegate access\" is used as the authentication method."),
               cfg.BoolOpt('enable_vpc_flow_logs', default=False,
                           help="Whether to enable or disable VPC flow orchestration provider"),
               cfg.Opt('log_group_name', default=[],
                       type=types.List(item_type=types.String(unicode=True), bounds=True),
                       help="Enter VPC Flow log group names to collect, leave empty for all"),
               cfg.IntOpt('prior_days_time_frame', help="How many days back to read existing VPC flow logs.",
                          default=0),
               cfg.IntOpt('interval_period', help="Interval (in seconds) to check for new events ", default=30),
               cfg.IntOpt('number_of_log_groups_limit', help="Maximum numbner of collected log groups", default=50),
               cfg.IntOpt('number_of_streams_limit', help="Maximum number of streams per log group", default=50),
               cfg.IntOpt('stream_events_limit',
                          help="Maximum number of events to retrieve from each log stream on each attempt",
                          default=500),
               cfg.IntOpt('interval_limit',
                          help="Maximum ammount of seconds to allow event retrieval from all streams in one attempt",
                          default=10),
               cfg.StrOpt('socket_name', help="Socket name to communicate with the visibility agent",
                          default="/var/run/aggregator/dp_visibility.sock"),
               cfg.Opt('filter_aws_instances_by_tags', default=[],
                       type=types.List(item_type=types.String(quotes=True), bounds=True),
                       help='Filter AWS instances by specific tags, for demo usage only. key:value pairs'),
           ] + common_opts + label_opts

AWS_AUTH_STRUCTURE = Structure(aws_opts)

aws_obstructed_opts = [cfg.StrOpt('gc_aws_access_key_id'),
                       cfg.StrOpt('gc_aws_secret_access_key', secret=True),
                       ]
AWS_AUTH_OPTS = [cfg.IntOpt('update_timeout_seconds',
                            default=10 * 60,
                            help="AWS update timeout in seconds")]


def register_opts():
    cfg.CONF.register_opt(cfg.Opt('aws_configuration', type=AWS_AUTH_STRUCTURE), group="orchestration")
    cfg.CONF.register_opts(opts=AWS_AUTH_OPTS, group="aws_auth")
