from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional, Union
from uuid import UUID

from pydantic import BaseModel, Field, RootModel, field_validator

from common.py.utils.cloud_app.cloud_app import CloudAppOperationMode
from ..common.common import Connector


class Name(Enum):
    AZURE_ONBOARDING = 'AzureOnboarding'
    MISCELLANEOUS = 'miscellaneous'


class OperationMode(Enum):
    VISIBILITY = 'visibility'
    ENFORCEMENT = 'enforcement'


class OnboardConfig(BaseModel):
    operation_mode: OperationMode = Field(..., alias='operation-mode')
    auto_discovery: Optional[bool] = Field(False, alias='auto-discovery')
    revision: Optional[int] = None

    @field_validator('operation_mode', mode="before")
    @staticmethod
    def transform_operation_mode(operation_mode: str) -> OperationMode:
        if operation_mode == CloudAppOperationMode.REVEAL_ONLY.value:
            return OperationMode.VISIBILITY
        if operation_mode == CloudAppOperationMode.REVEAL_AND_ENFORCEMENT.value:
            return OperationMode.ENFORCEMENT
        return operation_mode



class Scope(Enum):
    MANAGEMENT_GROUP = 'management_group'
    SUBSCRIPTION = 'subscription'


class AzureSubscriptionsFilter(BaseModel):
    scope: Scope
    values: List[str] = Field(
        ...,
        examples=[
            [
                '/providers/Microsoft.Management/managementGroups/EnggMgmtGroupID',
                '/providers/Microsoft.Management/managementGroups/ProdGroupID',
            ]
        ],
    )


class StatusRequest(BaseModel):
    detailed_status: Optional[AzureSubscriptionsFilter] = Field(
        None, alias='detailed-status'
    )


class Status(Enum):
    COMPLETED = 'completed'
    IN_PROGRESS = 'in_progress'
    NOT_ONBOARDED = 'not_onboarded'
    FAILED = 'failed'
    PARTIAL = 'partial'


class AzureSubscriptionsStatus(RootModel[List[Dict[str, Status]]]):
    root: List[Dict[str, Status]] = Field(
        ...,
        examples=[
            [
                {'87bd8fcb-0e02-4d5f-83e6-e045c63dd4': 'completed'},
                {'97bd8fcb-0e02-4d5f-83e6-e045c63dd4': 'in_progress'},
            ]
        ],
    )

    def __getattr__(self, attr: str):
        return getattr(self.root, attr)

    def __iter__(self):
        for item in self.root:
            yield item


class AzureOnboarding(BaseModel):
    subscriptions: AzureSubscriptionsFilter


class Step1(BaseModel):
    step: Optional[str] = None
    status: Optional[Status] = None


class StatusResponse(BaseModel):
    overall_status: Status = Field(..., alias='overall-status')
    steps: Optional[List[Step1]] = None
    detailed_status: Optional[AzureSubscriptionsStatus] = Field(
        None, alias='detailed-status'
    )


class Step(BaseModel):
    name: Name
    action: Union[AzureOnboarding, Dict[str, Any]]


class Onboard(BaseModel):
    connector_type: Connector = Field(..., alias='connector-type')
    component_id: UUID = Field(..., alias='component-id')
    general: OnboardConfig
    steps: List[Step]
