from enum import IntEnum

import attr

from common.py.apis import AgentComponentType
from common.py.events.attrs import Dictable, dict_attr, string_attr

__author__ = 'Eddie'


class ComponentState(IntEnum):
    On = 1
    Monitor = 2
    Off = 3


class ModuleState(IntEnum):
    Unset = 1
    Enabled = 2
    MetricsOnly = 3  # only for enforcement and its filtered out by other modules
    Disabled = 4

def ModuleStateNormalized(enum_value):
    if enum_value == ModuleState.MetricsOnly:
        return ModuleState.Enabled
    return enum_value

class EnforcementMode(IntEnum):
    Unset = 0
    RevealOnly = 1
    Monitoring = 2
    Enforcing = 3
    Unused4 = 4
    MetricsOnly = 5

class DomainDiscoveryMode(IntEnum):
    NLA = 0
    DNS = 1
    Both = 2

class WindowsFirewallMode(IntEnum):
    CoexistWithWindowsFirewall = 0
    CoexistWithWindowsFirewallExceptForImplicitAllows = 1
    OverrideWindowsFirewallExceptForDefaultAllow = 2
    OverrideWindowsFirewall = 3


class DriverVerbosity(IntEnum):
    NotVerbose = 0
    FileLogOnly = 1
    FileLogAndOsLog = 2


class DriverLogLevel(IntEnum):
    Info = 0
    Debug = 1
    ExtraDebug = 2


class DriverLogTarget(IntEnum):
    FileLogOnly = 0
    FileLogAndOsLog = 1


class RedirectionMode(IntEnum):
    Unset = 0
    Enabled = 1
    Disabled = 2


class LinkLocalTrafficReportingMode(IntEnum):
    AllowTraffic = 0
    BlockTraffic = 1
    ReportAddresses = 2


AGENT_STATE_ENUM_MAP = {'on': ComponentState.On,
                        'monitor': ComponentState.Monitor,
                        'off': ComponentState.Off}


class EncryptionStatus(IntEnum):
    Enabled = 1
    Disabled = 2
    RunningWithErrors = 3


class AgentStatusFlagType(IntEnum):
    PollingMode = 2
    OutdatedPolicy = 3
    OutdatedConfiguration = 4
    NoRevealReceived = 5  # No reveal from aggregator to management
    HighDropRate = 6
    AgentMissing = 7
    PartialPolicy = 8  # not in use
    EnforcementPaused = 9
    NoRevealReported = 10  # No reveal from agent to aggregator
    RevealOffline = 11
    EnforcementOffline = 12
    RevealModuleError = 13
    EnforcementModuleError = 14
    DetectionModuleError = 15
    DeceptionModuleError = 16
    ControllerModuleError = 17
    NoResourceLimits = 18
    MemoryLimitReached = 19
    RevealMemoryLimitReached = 20
    EnforcementMemoryLimitReached = 21
    DetectionMemoryLimitReached = 22
    DeceptionMemoryLimitReached = 23
    ControllerMemoryLimitReached = 24
    LimitedPolicy = 25
    EnforcementModeRevealOnly = 26
    EnforcementModeMonitoring = 27
    ConfigurationPartiallyApplied = 28
    EnforcementMissingKO = 29
    DeceptionMissingKO = 30
    DeprecatedAgentFlagUsed = 31
    DeceptionRedirectionChannelError = 32
    DeceptionLimitedCapabilities = 33
    SecuritySoftwareDetected = 34
    PartiallySupportedInstallation = 35
    DNSSecurityOutdated = 36
    OrchestrationError = 37
    HighPerformanceHWProperties = 38
    PartialRevealReported = 39
    EnforcementMetricsOnlyMode = 40
    SyslogServerRestartFailure = 41
    RevealDisabled = 42
    OperationRequestFailed = 43
    RevealAgentWarning = 44
    RevealAgentError = 45
    K8sCniNotSupported = 46
    K8sEnforcementDisabled = 47
    ConflictingNetworkInterfaceDetected = 48
    CertificateAboutToExpire = 49
    K8sEnforcementOffline = 50
    AgentUninstalled = 51
    AssetShutdown = 52
    AgentStopped = 53
    CloudAppNoConnectivity = 54
    CloudAppOnBoardingFailed = 55
    OutdatedUserIdentityPolicy = 56
    AccessModuleError = 57
    AccessMemoryLimitReached = 58
    AccessModuleBrokerDisconnected = 59
    ApiVersionMismatch = 60
    EncryptionError = 61
    EncryptionSetupError = 62
    EncryptionUpdateError = 63


# The mapping is used to disable flags from modules that are stopped/disabled
AGENT_COMPONENT_FLAGS_MAPPING = {
    AgentComponentType.DECEPTION_AGENT: [AgentStatusFlagType.DeceptionModuleError.value,
                                         AgentStatusFlagType.DeceptionMemoryLimitReached.value,
                                         AgentStatusFlagType.DeceptionMissingKO.value,
                                         AgentStatusFlagType.DeceptionRedirectionChannelError.value,
                                         AgentStatusFlagType.DeceptionLimitedCapabilities.value],
}
MISSING_AGENT_FLAGS = [AgentStatusFlagType.AgentMissing,
                       AgentStatusFlagType.AgentUninstalled,
                       AgentStatusFlagType.AssetShutdown,
                       AgentStatusFlagType.AgentStopped]

@attr.s
class InstallationProfileConfiguration(Dictable):
    name = string_attr()
    configuration = dict_attr()
