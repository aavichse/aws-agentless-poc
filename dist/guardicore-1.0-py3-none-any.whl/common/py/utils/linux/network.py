
import os
import re
from netaddr import IPAddress, AddrFormatError
from common.py.model.exceptions import GuardicoreException

DNS_CONFIG_FILE = "/etc/resolv.conf"
NAMESERVER_RE = re.compile("^nameserver\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$")


def fetch_dns_ips(dns_config_file=DNS_CONFIG_FILE):
    """ fetch_dns_ips(dns_config_file=DNS_CONFIG_FILE) -> []

    :param dns_config_file: the DNS configuration file (default is /etc/resolv.conf)
    :return: list of configured DNS server IP addresses
    """

    if not os.path.exists(dns_config_file):
        raise GuardicoreException("Couldn't find DNS configuration file '%s'", dns_config_file)

    name_server_addresses = set()
    for line in open(dns_config_file, "r"):
        m = NAMESERVER_RE.match(line.strip())
        if m is None:
            continue

        try:
            ip_addr = IPAddress(m.group(1))
        except AddrFormatError:
            continue

        name_server_addresses.add(str(ip_addr))

    return list(name_server_addresses)
