import collections


class CaseInsensitiveDict(collections.MutableMapping):
    def __init__(self, d=None):
        if d is None:
            d = {}

        self._d = dict(d)
        self._s = dict((k.lower(), k) for k in self._d)

    def __contains__(self, key):
        return key.lower() in self._s

    def __len__(self):
        return len(self._d)

    def __iter__(self):
        return iter(self._d)

    def __getitem__(self, key):
        return self._d[self._s[key.lower()]]

    def __setitem__(self, key, value):
        key_lower = key.lower()

        if self.__contains__(key):
            d_k = self._s.pop(key_lower)
            self._d.pop(d_k)

        self._d[key] = value
        self._s[key_lower] = key

    def __delitem__(self, key):
        d_k = self._s.pop(key.lower())
        self._d.pop(d_k)

    def actual_case(self, key):
        return self._s.get(key.lower())


class CaseInsensitiveDefaultDict(CaseInsensitiveDict):
    def __init__(self, default_factory, *args, **kwargs):
        super(CaseInsensitiveDefaultDict, self).__init__(*args, **kwargs)

        if not hasattr(default_factory, '__call__'):
            raise TypeError('first argument must be callable')

        self._default_factory = default_factory

    def __getitem__(self, key):
        try:
            return super(CaseInsensitiveDefaultDict, self).__getitem__(key)
        except KeyError:
            return self._default_factory()


class CaseInsensitiveSet(collections.MutableSet):
    def __init__(self, d=None):
        if d is None:
            d = {}

        self._d = set(d)
        self._s = dict((k.lower(), k) for k in self._d)

    def __contains__(self, key):
        return key.lower() in self._s

    def __iter__(self):
        return iter(self._d)

    def __len__(self):
        return len(self._d)

    def add(self, value):
        value_lower = value.lower()

        if self.__contains__(value):
            d_k = self._s.pop(value_lower)
            self._d.discard(d_k)

        self._d.add(value)
        self._s[value_lower] = value

    def discard(self, value):
        d_k = self._s.pop(value.lower())
        self._d.discard(d_k)

    def actual_case(self, value):
        return self._s.get(value.lower())
