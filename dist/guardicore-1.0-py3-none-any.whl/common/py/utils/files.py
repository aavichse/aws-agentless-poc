import datetime
import os
import time
import shutil

from common.logger import get_logger

LOGGER = get_logger()


def generate_backup_path(path):

    return "{}_{}".format(path, datetime.datetime.now().strftime('%Y%m%d%H%M%S'))


def backup_file_to_same_dir(full_path):
    """
    Backs up the file/directory. For example: /etc/guardicore/guardicore_setup.conf will be backed up to something like
    /etc/guardicore/guardicore_setup.conf_20190601123421
    :return: The path of the backup
    """
    backup_path = generate_backup_path(full_path)
    if os.path.isfile(full_path):
        shutil.copy(full_path, backup_path)
    elif os.path.isdir(full_path):
        shutil.copytree(full_path, backup_path)
    else:
        raise Exception("{} does not exist".format(full_path))

    LOGGER.info("Successfully backed {} to {}".format(full_path, backup_path))
    return backup_path


def wait_for_file(file_path, timeout=60):
    """
    Wait for a file to be created at the given path for a specified timeout period.

    :param file_path: the path to the file to wait for.
    :param timeout: the timeout period in seconds.
    """
    start_time = time.time()
    while not os.path.exists(file_path):
        time.sleep(1)
        elapsed_time = time.time() - start_time
        if elapsed_time > timeout:
            raise TimeoutError("Timed out waiting for file: {}".format(file_path))
