from common.py.clouds import common_opts, label_opts
from common.py.utils.config import cfg
from common.py.utils.config.oslo_config import types
from common.py.utils.config.types import Port, Structure

__author__ = 'Eddi'

# vsphere specific configurations
vsphere_opts = [cfg.StrOpt('auth_host', help="vSphere server IP address"),
                cfg.Opt('auth_port', default=443, help="vSphere server authentication port",
                        type=Port()),
                cfg.StrOpt('admin_user', help="vSphere server username"),
                cfg.StrOpt('admin_password', secret=True, help="vSphere server password"),
                cfg.Opt('vsphere_clusters', default=[],
                        type=types.List(item_type=types.String(unicode=True), bounds=True),
                        help="Limit orchestration collection to selected set of vSphere clusters"),
                cfg.IntOpt('number_of_ignored_updates', default=10,
                           help='Number of consecutive updates with missing ips to ignore. 0=ignore none',
                           custom_warning="Do not change this value unless you know what you are doing"),
                cfg.BoolOpt('use_vm_hostname',
                            help="Use the VM hostname, not the VM name. This option is only available if VMWare Tools are installed.",
                            default=False)
                ] + common_opts + label_opts
VSPHERE_AUTH_STRUCTURE = Structure(vsphere_opts)

VSPHERE_AUTH_OPTS = [cfg.IntOpt('update_timeout_seconds',
                                default=10 * 60,
                                help="VSphere update timeout in seconds")]
VSPHERE_TAG_MANAGER_OPTS = [cfg.IntOpt('vms_chunk_size',
                                       default=1000,
                                       help="Default vms chunk size for vSphere tags manager")]


def register_opts():
    cfg.CONF.register_opt(cfg.Opt('vsphere_configuration', type=VSPHERE_AUTH_STRUCTURE), group="orchestration")

    cfg.CONF.register_opts(opts=VSPHERE_AUTH_OPTS, group="vsphere_auth")
    cfg.CONF.register_opts(opts=VSPHERE_TAG_MANAGER_OPTS, group="vsphere_tag_manager")
