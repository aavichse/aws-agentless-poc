from enum import Enum
from common.py.apis import IntegrationType
from common.py.integrations.azure import AzureControlClient, AzureProxyClient, AzureInventoryProcessor
from common.py.integrations.packetfence import PFControlClient, PFProxyClient
from common.py.integrations.azure.config import azure_cloud_app_opts
from common.py.integrations.packetfence.config import pf_opts
from common.py.utils.cloud_app.cloud_app import CloudAppType
from aggregator.model.integrations import IntegrationModelsException, DEFAULT_VERSION
from common.logger import get_logger

LOG = get_logger(module_name=__name__)

INTEGRATION_TYPE_TO_CONF_OPTS = {
    IntegrationType.Cloud: azure_cloud_app_opts,
    IntegrationType.PACKETFENCE: pf_opts
}


class IntegrationClientFactoryEntity(Enum):
    CONTROL_CLIENT = "control"
    PROXY_CLIENT = "proxy"
    INVENTORY_P = "inventory_p"


INTEGRATION_TYPE_TO_CLS = {
    IntegrationType.Cloud.value: {
        CloudAppType.AZURE.value: {IntegrationClientFactoryEntity.CONTROL_CLIENT: AzureControlClient,
                                   IntegrationClientFactoryEntity.PROXY_CLIENT: AzureProxyClient,
                                   IntegrationClientFactoryEntity.INVENTORY_P: AzureInventoryProcessor}
    },
    IntegrationType.PACKETFENCE.value: {
        IntegrationClientFactoryEntity.CONTROL_CLIENT: PFControlClient,
        IntegrationClientFactoryEntity.PROXY_CLIENT: PFProxyClient
    }
}


class IntegrationClientFactory:
    @classmethod
    def get_control_client_cls(cls, conf):
        return cls._get_client_cls(IntegrationClientFactoryEntity.CONTROL_CLIENT, conf)

    @classmethod
    def get_control_client(cls, conf):
        client_cls = cls._get_client_cls(IntegrationClientFactoryEntity.CONTROL_CLIENT, conf)
        try:
            client = client_cls.from_config(getattr(conf, conf.integration.type))
        except IntegrationModelsException as exc:
            cause = "Error instantiating integration client (type={type}): {err}".format(type=conf.integration.type, err=str(exc))
            LOG.exception(cause)
            client = client_cls.from_config(getattr(conf, conf.integration.type), DEFAULT_VERSION)
        client.connect_timeout = conf.integration.connect_timeout
        client.read_timeout = conf.integration.read_timeout
        return client

    @classmethod
    def get_proxy_client_cls(cls, conf):
        return cls._get_client_cls(IntegrationClientFactoryEntity.PROXY_CLIENT, conf)

    @classmethod
    def get_inventory_processor_cls(cls, conf):
        return cls._get_client_cls(IntegrationClientFactoryEntity.INVENTORY_P, conf)

    @classmethod
    def _get_client_cls(cls, entity, conf):
        if conf.integration.type == IntegrationType.Cloud.value:
            cloud_type = getattr(conf, conf.integration.type).cloud_app_type
            client_cls = INTEGRATION_TYPE_TO_CLS[conf.integration.type][cloud_type][entity]
            return client_cls
        return INTEGRATION_TYPE_TO_CLS[conf.integration.type][entity]
