#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import print_function

import os
import sys
import dialog
import textwrap
import subprocess

import ipaddress
import six
from collections import namedtuple, OrderedDict
from common.logger import get_logger
from common.py.utils.config import cfg
from common.py.utils.linux.ip_lib import IPWrapper, DeviceType
from common.py.utils.oslo_secret_decoder import OsloSecret
from common.py.utils.setup_wizard.model import NavigateBack, PasswordWeak, PasswordInvalid, Skip, NetworkAddressMode, \
    DeploymentMode
from common.py.utils.setup_wizard.setup_utilities import LOGGER_NAME, setup_utilities

__author__ = 'uri'

# disable logging to screen
cfg.CONF.set_override(name='log_to_screen',
                      group='log',
                      override=False)

tw = textwrap.TextWrapper(width=78,
                          break_long_words=False,
                          break_on_hyphens=True)

MultipleChoiceOpt = namedtuple('MultipleChoiceOpt', ['name', 'description', 'is_selected'])

NORMAL_WIDTH = 70
BACK_BUTTON_LABEL = 'Back'
DIALOG_CONF_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dialogrc.conf")

ALLOWED_SERVICE = """# Provide a list of IP addresses that will be allowed to
# connect to this machine over {service}.
# The addresses should be separated by new lines and can include subnet
# mask length (CIDR), as in the following example: 10.0.1.87/24
# For allowing all addresses to connect over {service} add: 0.0.0.0/0
# If no address or subnet has been entered, connection
# over {service} will not be available.
#
{suggested_subnets_str}

"""

FQDN_ADDRESSES = """# Provide a list of FQDN addresses that will be added
# to the TLS Certificate DNS names.
# The FQDN should be separated by new lines and consist
# of two parts: the hostname and the domain name.
# Example: myhostname.mydomainname.edu
#

"""

NAT_ADDRESSES = """# Provide a list of Agent-facing addresses that will be added to 
# the Agent certificate.
# The addresses should be seperated by new lines.
# Example: 192.0.2.1
#

"""

LOG = get_logger(module_name=LOGGER_NAME)


class SetupDialog(object):
    """
    Setup Dialog base class which is also a wrapper class for dialog.Dialog.
    This class is producing methods in a way that automatically spawns a "confirm quit"
    dialog box if the user presses the Escape key or chooses the Cancel button, and
    then re-displays the original widget if the user doesn't actually want to quit.

    methods with prefix "general" can appear anywhere
    methods with prefix "collect" are in configuration collecting step
    methods with prefix "install" are in installation step
    """

    def __init__(self, component_name, setup_command, setup_username="root"):
        """
        SetupDialog constructor
        :param component_name: a string with the Guardicore Component name for display
        """
        if not component_name:
            component_name = "Component"
        self.component_name = component_name
        self.setup_command = setup_command
        self.setup_username = setup_username
        self.dlg = dialog.Dialog(dialog="dialog", DIALOGRC=DIALOG_CONF_PATH)
        self.max_lines = None
        self.max_cols = None
        self.min_rows = None
        self.min_cols = None
        self.term_rows = None
        self.term_cols = None
        self.backend_version = None
        self.is_initialized = False

    def set_title(self):
        try:
            title = "Guardicore - %s Setup" % self.component_name
            self.dlg.set_background_title(title)
            dimensions = self.dlg.maxsize(backtitle=title)
            if not dimensions:
                self.min_rows, self.min_cols = 0, 0
                self.is_initialized = False
            else:
                self.max_lines, self.max_cols = dimensions
                # Warn if the terminal is smaller than this size
                self.min_rows, self.min_cols = 24, 80
                self.term_rows, self.term_cols, self.backend_version = self.get_term_size_and_backend_version()
                self.is_initialized = True
        except Exception as e:
            LOG.warning("Failed changing title: %s", str(e))

    def get_term_size_and_backend_version(self):
        """
        a function that returns the terminal size and the backend version
        """
        # Avoid running '<backend> --print-version' every time we need the version
        backend_version = self.dlg.cached_backend_version
        if not backend_version:
            print((tw.fill(
                "Unable to retrieve the version of the dialog-like backend. "
                "Not running cdialog?") + "\nPress Enter to continue."))
            six.moves.input()

        term_rows, term_cols = self.dlg.maxsize(use_persistent_args=False)
        if term_rows < self.min_rows or term_cols < self.min_cols:
            print((tw.fill(textwrap.dedent("""\
                                          Your terminal has less than {0} rows or less than {1} columns;
                                          you may experience problems with the setup application."""
                                           .format(self.min_rows, self.min_cols))) + "\nPress Enter to continue."))
            six.moves.input()

        return term_rows, term_cols, backend_version

    def check_exit_request(self, code, ignore_cancel=False):
        if code == self.CANCEL and ignore_cancel:
            # Ignore the Cancel button, i.e., don't interpret it as an exit
            # request; instead, let the caller handle CANCEL himself.
            return True

        if code in (self.CANCEL, self.ESC):
            button_name = {self.CANCEL: "Cancel", self.ESC: "Escape"}
            msg = "You pressed {0} in the last dialog box.\n\n" \
                  "Do you want to exit the setup?".format(button_name[code])
            # 'self.dlg' instead of 'self' here, because we want to use the
            # original yesno() method from the Dialog class instead of the
            # decorated method returned by self.__getattr__().
            if self.dlg.yesno(msg, width=NORMAL_WIDTH, height=8) == self.OK:
                self.clear_screen()
                sys.exit(1)
            else:  # "No" button chosen, or ESC pressed
                return False  # in the "confirm quit" dialog
        else:
            return True

    def widget_loop(self, method):
        """
        Decorator to handle eventual exit requests from a Dialog widget.

        method -- a dialog.Dialog method that returns either a Dialog
                  exit code, or a sequence whose first element is a
                  Dialog exit code (cf. the docstring of the Dialog
                  class in dialog.py)

        Return a wrapper function that behaves exactly like 'method',
        except for the following point:

          If the Dialog exit code obtained from 'method' is CANCEL or
          ESC (attributes of dialog.Dialog), a "confirm quit" dialog
          is spawned; depending on the user choice, either the
          program exits or 'method' is called again, with the same
          arguments and same handling of the exit status. In other
          words, the wrapper function builds a loop around 'method'.

        The above condition on 'method' is satisfied for all
        dialog.Dialog widget-producing methods. More formally, these
        are the methods defined with the @widget decorator in
        dialog.py, i.e., that have an "is_widget" attribute set to
        True.
        """

        # One might want to use @functools.wraps here, but since the wrapper
        # function is very likely to be used only once and then
        # garbage-collected, this would uselessly add a little overhead inside
        # __getattr__(), where widget_loop() is called.
        def wrapper(*args, **kwargs):
            res = None
            while True:
                res = method(*args, **kwargs)

                if hasattr(method, "retval_is_code") and getattr(method, "retval_is_code"):
                    code = res
                else:
                    code = res[0]

                if self.check_exit_request(code):
                    break
            return res

        return wrapper

    def __getattr__(self, name):
        # This is where the "magic" of this class originates from.
        # Please refer to the module and self.widget_loop()
        # docstrings if you want to understand the why and the how.
        obj = getattr(self.dlg, name)
        if hasattr(obj, "is_widget") and getattr(obj, "is_widget"):
            return self.widget_loop(obj)
        else:
            return obj

    def clear_screen(self):
        """
        a method that clears the screen
        """
        program = "clear"

        try:
            p = subprocess.Popen([program], shell=False, stdout=None, stderr=None, close_fds=True)
            code = p.wait()
        except os.error as e:
            self.msgbox("Unable to execute program '%s': %s." % (program, e.strerror), title="Error")
            return False

        if code > 0:
            msg = "Program %s returned exit status %d." % (program, code)
        elif code < 0:
            msg = "Program %s was terminated by signal %d." % (program, -code)
        else:
            return True

        self.msgbox(msg)
        return False

    def reset_shell(self):
        """
        a method that resets the shell
        """
        program = "reset"

        try:
            p = subprocess.Popen([program], shell=False, stdout=None, stderr=None, close_fds=True)
            code = p.wait()
        except os.error as e:
            self.msgbox("Unable to execute program '%s': %s." % (program, e.strerror), title="Error")
            return False

        if code > 0:
            msg = "Program %s returned exit status %d." % (program, code)
        elif code < 0:
            msg = "Program %s was terminated by signal %d." % (program, -code)
        else:
            return True

        self.msgbox(msg)
        return False

    def _yesno(self, *args, **kwargs):
        """
        Convenience wrapper around dialog.Dialog.yesno().
        Return the same exit code as would return dialog.Dialog.yesno(), except for ESC which is handled as in
        the rest of the demo, i.e. make it spawn the "confirm quit" dialog
        """
        # self.yesno() automatically spawns the "confirm quit" dialog if ESC or
        # the "No" button is pressed, because of self.__getattr__(). Therefore,
        # we have to use self.dlg.yesno() here and call
        # self.check_exit_request() manually.
        code = None
        while True:
            code = self.dlg.yesno(*args, **kwargs)
            # If code == self.CANCEL, it means the "No" button was chosen;
            # don't interpret this as a wish to quit the program!
            if self.check_exit_request(code, ignore_cancel=True):
                break

        return code

    def YesNoBack(self, cancel_label="No", ok_label="Yes", *args, **kwargs):
        ret_val = self._yesno(cancel_label=cancel_label,
                              ok_label=ok_label,
                              extra_button=True,
                              extra_label=BACK_BUTTON_LABEL,
                              *args, **kwargs)
        if ret_val == self.dlg.EXTRA:
            raise NavigateBack
        return ret_val == self.dlg.OK

    def Yesno(self, *args, **kwargs):
        """
        Convenience wrapper around dialog.Dialog.yesno().
        Return True if "Yes" was chosen, False if "No" was chosen
        """
        return self._yesno(*args, **kwargs) == self.dlg.OK

    def Form(self, fields, return_as_tuple=False, **kwargs):
        """
        Convenience wrapper around dialog.Dialog.form().
        :param fields: dict of fields for the form
        :param return_as_tuple: return as tuple object if True or a dict if False
        :param kwargs: additional dialog arguments
        :return: (dialog return code, a dict with keys and returned answers from the user)
        """
        if not fields:
            raise EnvironmentError("Can't run form with empty fields")

        max_field_name = max(len(field_name) for field_name in fields.keys())
        elements = []
        keys = []
        index = 1
        for key, default_value in fields.items():
            elements.append((key, index, 1, default_value, index, max_field_name + 2, 100, 0))
            keys.append(key)
            index += 1

        code, values = self.dlg.form(elements=elements,
                                     width=NORMAL_WIDTH,
                                     **kwargs)
        if return_as_tuple:
            final_values = zip(keys, values)
        else:
            final_values = dict(zip(keys, values))

        return code, final_values

    ###################################
    # "general" methods section
    ###################################

    def general_display_error(self, error_message, text=None):
        """
        a method that disaplays an error message to the user
        :param error_message: error message to display
        """
        title = "Error"
        if not text:
            text = "\nThere was an error in the setup process:\n\n%s" % error_message

        self.dlg.msgbox(text=text,
                        title=title,
                        width=NORMAL_WIDTH,
                        height=16)

    def general_confirm_to_proceed(self, text, title):
        """
        a method that asks from the user for permission to proceed
        """

        if not title:
            title = "Confirm To Proceed"

        if not text:
            text = "\nConfirm to proceed to the next step"
        else:
            if not text.startswith("\n"):
                text = "\n%s" % text

        return self.Yesno(title=title,
                          text=text,
                          width=NORMAL_WIDTH,
                          height=8)

    def general_greetings(self, dry_mode):
        """
        a method that displays a generic greetings message
        """
        text = "\nThe Setup Wizard will help you configure your {component}.\n" \
               "At any time you can go back to the previous screen or cancel.\n\n"
        height = 8
        if dry_mode:
            text += "Running in Dry Mode - no changes will be made to the machine."
            height += 1

        self.dlg.msgbox(text.format(component=self.component_name),
                        width=NORMAL_WIDTH,
                        height=height,
                        title="Welcome to Guardicore Setup Utility")

    def general_password_set(self):
        """
        a method that asks the user if he agrees to change root password and disable admin user
        """
        return self.Yesno(text="\nNew '{username}' user password will be set and 'admin' user will be disabled.\n\n"
                               "Click Yes to continue or No to exit.".format(username=self.setup_username),
                          title="Set {username} Password".format(username=self.setup_username.capitalize()),
                          width=NORMAL_WIDTH,
                          height=10)

    def general_summary(self, error=None):
        """
        a method that shows a summary screen for the user
        :param error: an error message to show. if None, the summary will be a success screen
        """

        if error:
            text = "\nThere was a problem installing the {component}:\n\n" \
                   "{error}\n\n" \
                   "Try running the setup again with the command '{command}' or contact Guardicore." \
                .format(component=self.component_name,
                        error=error,
                        command=self.setup_command)
            title = "Something Went Wrong"
            height = 18
        else:
            text = "\nSetup completed.\n\n" \
                   "You can run it again at any time with the command '{command}'".format(command=self.setup_command)
            title = "We're Done!"
            height = 8

        if six.PY2:
            text = six.text_type(text, "ascii", errors='ignore')

        self.dlg.msgbox(text=text,
                        title=title,
                        width=NORMAL_WIDTH,
                        height=height)

    def general_msgbox(self, title=None, text=None, height=None):
        """
        a method that shows a generic message box
        :param title: title - empty if None
        :param text: text - empty if None
        :param height: height - a guess if None
        """
        if title is None:
            title = ""
        if text is None:
            text = ""
        if height is None:
            height = 8 + len(text.splitlines())

        self.dlg.msgbox(title=title,
                        text=text,
                        width=NORMAL_WIDTH,
                        height=height)

    ###################################
    # "collect" methods section
    ###################################

    def collect_machine_password(self, min_password_len, password_validity_function):
        """
        this method asks for a password from the user.
        if check_validity is True, the password is verified and checked for validity through "check_password_validity"
        afterwards it's hashed and returned
        """
        password_found = False
        second_password = None
        title = "Password Change"
        while not password_found:
            text = "\nEnter a new {username} user password.\n" \
                   "The password length should be at least {min_length} characters and contain " \
                   "both uppercase and lowercase letters and numbers."
            text = text.format(username=self.setup_username, min_length=min_password_len)
            code, first_password = self.dlg.passwordbox(text=text,
                                                        title=title,
                                                        width=NORMAL_WIDTH,
                                                        height=14,
                                                        insecure=True)
            if code != self.dlg.OK:
                raise NavigateBack

            if password_validity_function:
                try:
                    password_validity_function(first_password)
                except (PasswordWeak, PasswordInvalid) as e:
                    text = "\n%s, Try a new one" % e
                    self.dlg.msgbox(text=text,
                                    title="Error",
                                    width=NORMAL_WIDTH,
                                    height=8)
                    continue

            text = "\nType password again."
            code, second_password = self.dlg.passwordbox(text=text,
                                                         title=title,
                                                         width=NORMAL_WIDTH,
                                                         height=10,
                                                         insecure=True)
            if code != self.dlg.OK:
                raise NavigateBack

            if second_password != first_password:
                self.dlg.msgbox("\nVerification failed, Try again.",
                                title="Error",
                                width=NORMAL_WIDTH,
                                height=8)
                continue
            else:
                password_found = True

        return second_password

    def collect_configure_iptables(self):
        """
        a method that asks the user if he wants to skip the iptables configurations step
        """
        return self.YesNoBack(text="\nYou can choose to skip the iptables configuration step.\n\n"
                                   "The iptables can be applied later with 'gc-cluster-cli iptables_remap'.\n\n"
                                   "Click Yes to configure or No to skip.",
                              title="iptables configurations",
                              width=NORMAL_WIDTH,
                              height=12)

    def collect_reset_input_chain(self):
        """
        a method that asks the user if he wants to reset the existing iptables INPUT chain
        """
        return self.YesNoBack(text="\nYou can choose whether to reset the existing INPUT chain rules.\n\n"
                                   "WARNING: If you choose 'Yes', all rules in the INPUT chain will be cleared.\n\n"
                                   "Click Yes to remove or No to skip.",
                              title="iptables INPUT chain configurations",
                              width=NORMAL_WIDTH,
                              height=12,
                              default_button='extra')

    def collect_ip_address(self, address_to_display, ip_address_validity_function, address_description, title=None,
                           text=None):
        """
        this method asks the user for an ip address
        """
        if not title:
            title = address_description
        ip_set = False
        ip_address = address_to_display
        while not ip_set:
            if not text:
                text = "\nEnter %s IP address:" % address_description
            code, ip_address = self.dlg.inputbox(text=text,
                                                 title=title,
                                                 width=NORMAL_WIDTH,
                                                 height=10,
                                                 init=ip_address or "",
                                                 cancel_label=BACK_BUTTON_LABEL)

            if code == self.dlg.CANCEL:
                raise NavigateBack()

            if ip_address_validity_function is not None:
                is_valid_address = ip_address_validity_function(address=ip_address)
                if not is_valid_address:
                    text = "\nInvalid IP address entered (%s).\n" \
                           "Try again." % ip_address
                    self.dlg.msgbox(text=text,
                                    title="Error",
                                    width=NORMAL_WIDTH,
                                    height=8)
                    continue

            ip_set = True
        return ip_address

    def collect_port(self, title, description, default_port):
        def _validate_port(port):
            try:
                int_port = int(port)
            except ValueError:
                return False
            return 0 < int_port < (2 ** 16)

        return int(self.collect_field(title, description, str(default_port), _validate_port))

    def collect_field(self, title, field_description, value_to_display, validate_field_func=None):
        """
        this method asks the user for a certain field
        """
        field_set = False
        field_value = value_to_display
        while not field_set:
            text = field_description
            code, field_value = self.dlg.inputbox(text=text,
                                                  title=title,
                                                  width=NORMAL_WIDTH,
                                                  height=10,
                                                  init=field_value,
                                                  cancel_label=BACK_BUTTON_LABEL)

            if code == self.dlg.CANCEL:
                raise NavigateBack()

            if validate_field_func is not None:
                is_valid = validate_field_func(field_value)
                if not is_valid:
                    text = "\nInvalid Value (%s).\n" \
                           "Try again." % field_value
                    self.dlg.msgbox(text=text,
                                    title="Error",
                                    width=NORMAL_WIDTH,
                                    height=8)
                    continue
            field_set = True

        return field_value

    def collect_tls_keys_password(self, password_validity_function, init=''):
        """
        this method asks for the guardicore secure communication password for the tls keys
        download from the management server
        """
        return self.collect_password(title="Guardicore Secure Communication Password",
                                     description="the Guardicore Secure Communication Password",
                                     password_validity_function=password_validity_function,
                                     allow_proceed_on_invalid_password=True,
                                     init=init,
                                     show_password=True)

    def collect_password(self, title, description, password_validity_function,
                         allow_proceed_on_invalid_password, init='', show_password=False):
        """
        this method asks for password and confirmation
        """

        def show_password_dialog(text_value, title_value, init_value):
            if show_password:
                return self.dlg.inputbox(text=text_value,
                                         title=title_value,
                                         width=NORMAL_WIDTH,
                                         height=10,
                                         init=init_value,
                                         cancel_label=BACK_BUTTON_LABEL)
            else:
                return self.dlg.passwordbox(text=text_value,
                                            title=title_value,
                                            width=NORMAL_WIDTH,
                                            height=10,
                                            insecure=True,
                                            init=init_value,
                                            cancel_label=BACK_BUTTON_LABEL)

        password_found = False
        second_password = None

        # Decode the password so that the user will never see the encoded password
        init = OsloSecret.decode(init)

        while not password_found:
            text = "\nEnter %s\n" % (description,)
            code, first_password = show_password_dialog(text, title, init)

            if code != self.dlg.OK:
                raise NavigateBack
            try:
                if password_validity_function:
                    password_validity_function(first_password)

            except PasswordWeak as e:
                error_msg = str(e)
                proceed_on_invalid_password = False
                if allow_proceed_on_invalid_password:
                    text = "\n{invalid_reason}, do you still want to proceed?".format(invalid_reason=error_msg)
                    proceed_on_invalid_password = self.Yesno(text=text,
                                                             title=error_msg,
                                                             width=NORMAL_WIDTH,
                                                             height=8)
                if not proceed_on_invalid_password:
                    continue

            except PasswordInvalid as e:
                error_msg = str(e)
                self.dlg.msgbox("\n{invalid_reason}, Try again.".format(invalid_reason=error_msg),
                                title="Error",
                                width=NORMAL_WIDTH,
                                height=8)
                continue

            # There is no need to verify a password which isn't hidden
            if show_password:
                return first_password

            if first_password != init:
                init = ''

            text = "\nEnter the password again for verification."

            code, second_password = show_password_dialog(text, title, init)

            if code != self.dlg.OK:
                raise NavigateBack

            if second_password != first_password:
                self.dlg.msgbox("\nVerification failed, Try again.",
                                title="Error",
                                width=NORMAL_WIDTH,
                                height=8)
                continue
            else:
                password_found = True

        return second_password

    def collect_allowed_ips(self, service_name=None, service_port=None, suggested_subnets=None):
        """
        this method asks for ip addresses that will be allowed to connect to a certain service.
        at least a service name or a service port are needed.
        the method keeps a file in the setup folder with the inserted options for future use.
        :param service_name: service name to display
        :param service_port: port number to display
        :param suggested_subnets: list of suggested "ip/mask" strings
        :return: a list of ip addresses or ip/cidr
        """
        if not service_name and not service_port:
            raise EnvironmentError("Can't collect allowed ips with no service name or service port")
        if service_name and service_port:
            service_display = "%s(%s)" % (service_name, service_port)
        else:
            service_display = service_name if service_name is not None else "port: %s " % service_port

        title = "%s - Allowed IP addresses" % service_display

        suggested_subnets_str = "\n".join(suggested_subnets) if suggested_subnets else "\n"

        temp_service_filename = os.path.join(os.path.dirname(os.path.abspath(__file__)), service_display)
        if os.path.isfile(temp_service_filename):
            os.remove(temp_service_filename)
        with open(temp_service_filename, "w") as fo:
            fo.write(ALLOWED_SERVICE.format(service=service_display, suggested_subnets_str=suggested_subnets_str))

        should_ask_user = True
        addresses = []
        while should_ask_user:
            addresses = []
            should_ask_user = False
            code, result_text = self.dlg.editbox(title=title,
                                                 width=80,
                                                 height=20,
                                                 filepath=temp_service_filename)

            if code != self.dlg.OK:
                raise NavigateBack

            with open(temp_service_filename, 'w') as fo:
                fo.write(result_text)

            result_lines = result_text.split("\n")
            for line in result_lines:
                if not line:
                    continue
                if line.startswith("#"):
                    continue

                try:
                    ipaddress.ip_network(six.text_type(line))
                except Exception:
                    should_ask_user = True
                    text = "\n'%s' is not a valid network address, Try again" % line
                    self.dlg.msgbox(text=text,
                                    title="Invalid network address entered",
                                    width=NORMAL_WIDTH,
                                    height=8)
                    break

                addresses.append(line)

            if not addresses:
                text = "\nNo network addresses entered,\n%s will not be accessible." % service_display
                code = self.dlg.msgbox(text=text,
                                       title="Warning",
                                       width=NORMAL_WIDTH,
                                       height=8,
                                       extra_button=True,
                                       extra_label=BACK_BUTTON_LABEL)

                if code == self.dlg.EXTRA:
                    should_ask_user = True

        return addresses

    def collect_fqdn(self, validate_field_func=None):
        """
        this method asks for fqdn addresses that will be added to the tls certificates.
        the method keeps a file in the setup folder with the inserted options for future use.
        :return: a list of fqdn addresses
        """
        title = "FQDN addresses"
        service_display = "fqdn-testing"
        temp_service_filename = os.path.join(os.path.dirname(os.path.abspath(__file__)), service_display)
        if not os.path.isfile(temp_service_filename):
            with open(temp_service_filename, "w") as fo:
                fo.write(FQDN_ADDRESSES.format(service=service_display))

        should_ask_user = True
        fqdn = []
        while should_ask_user:
            fqdn = []
            should_ask_user = False
            code, result_text = self.dlg.editbox(title=title,
                                                 width=80,
                                                 height=20,
                                                 filepath=temp_service_filename)

            if code != self.dlg.OK:
                raise NavigateBack

            result_lines = result_text.split("\n")
            for line in result_lines:
                if not line:
                    continue
                if line.startswith("#"):
                    continue

                if validate_field_func is not None:
                    is_valid = validate_field_func(line)
                    if not is_valid:
                        text = "\nInvalid Value (%s).\n" \
                               "Try again." % line
                        self.dlg.msgbox(text=text,
                                        title="Error",
                                        width=NORMAL_WIDTH,
                                        height=8)
                        should_ask_user = True
                        continue

                fqdn.append(line)

            if not should_ask_user:
                if not fqdn:
                    text = "\nNo FQDN addresses entered, and will not appear on the certificates."
                    code = self.dlg.msgbox(text=text,
                                           title="Warning",
                                           width=NORMAL_WIDTH,
                                           height=8,
                                           extra_button=True,
                                           extra_label=BACK_BUTTON_LABEL)

                    if code == self.dlg.EXTRA:
                        should_ask_user = True

                with open(temp_service_filename, 'w') as fo:
                    fo.write(result_text)

        return fqdn

    def collect_nat_addresses(self):
        """
        this method asks for nat addresses that will be acting as a device between aggregator to agents.
        the method keeps a file in the setup folder with the inserted options for future use.
        :return: a list of ip addresses
        """
        title = "NAT addresses"
        service_display = "nat-test-1"
        temp_service_filename = os.path.join(os.path.dirname(os.path.abspath(__file__)), service_display)
        if not os.path.isfile(temp_service_filename):
            with open(temp_service_filename, "w") as fo:
                fo.write(NAT_ADDRESSES.format(service=service_display))

        should_ask_user = True
        addresses = []
        while should_ask_user:
            addresses = []
            should_ask_user = False
            code, result_text = self.dlg.editbox(title=title,
                                                 width=80,
                                                 height=20,
                                                 filepath=temp_service_filename)

            if code != self.dlg.OK:
                raise NavigateBack

            result_lines = result_text.split("\n")
            for line in result_lines:
                if not line:
                    continue
                if line.startswith("#"):
                    continue

                try:
                    ipaddress.ip_network(six.text_type(line))
                except Exception:
                    should_ask_user = True
                    text = "\n'%s' is not a valid network address, Try again" % line
                    self.dlg.msgbox(text=text,
                                    title="Invalid network address entered",
                                    width=NORMAL_WIDTH,
                                    height=8)
                    break

                addresses.append(line)

            if not should_ask_user:
                if not addresses:
                    text = "\nNo NAT addresses entered,\n%s will not be configured behind a NAT Device." \
                           % self.component_name
                    code = self.dlg.msgbox(text=text,
                                           title="Warning",
                                           width=NORMAL_WIDTH,
                                           height=8,
                                           extra_button=True,
                                           extra_label=BACK_BUTTON_LABEL)

                    if code == self.dlg.EXTRA:
                        should_ask_user = True

                with open(temp_service_filename, 'w') as fo:
                    fo.write(result_text)

        return addresses

    def collect_addresses(self, title, init_contents="", validation_functions=None):
        """
        this method asks for addresses and validates it
        :param title: title to display
        :param init_contents: list of the initial addreses
        :param validation_functions: list of validation functions to apply on the entered addresses
               a single validation function approval is enough for validating an address
        :return: a list of addresses
        """
        if not validation_functions:
            validation_functions = []
        should_ask_user = True
        addresses = []
        content = init_contents
        while should_ask_user:
            addresses = []
            should_ask_user = False
            code, content = self.dlg.editbox_str(title=title,
                                                 width=80,
                                                 height=20,
                                                 init_contents=content)

            if code != self.dlg.OK:
                raise NavigateBack

            content_lines = content.split("\n")
            for line in content_lines:
                if not line:
                    continue

                if line.startswith("#"):
                    continue

                if not validation_functions:
                    addresses.append(line)
                    continue

                if any([validation_function(line) for validation_function in validation_functions]):
                    addresses.append(line)
                    continue
                else:
                    should_ask_user = True
                    text = "\n'%s' is not a valid address, Try again" % line
                    self.dlg.msgbox(text=text,
                                    title="Invalid address entered",
                                    width=NORMAL_WIDTH,
                                    height=8)
                    break

            if should_ask_user:
                continue

            if not addresses:

                text = "\nAddresses were not supplied\n"
                code = self.dlg.msgbox(text=text,
                                       title="Warning",
                                       width=NORMAL_WIDTH,
                                       height=8,
                                       extra_button=True,
                                       extra_label=BACK_BUTTON_LABEL)

                if code == self.dlg.EXTRA:
                    should_ask_user = True

        return addresses

    def collect_network_interfaces(self, ip_address_validity_function, filtered_out_interfaces=None):
        """
        a function that collects network interfaces data from the user.
        allows to set static or DHCP per interface found on the machine.
        :return: a dict with the collected information
        """
        title = "Network Interfaces Configuration"
        if not filtered_out_interfaces:
            filtered_out_interfaces = []

        local_interfaces = [dev for dev in IPWrapper().get_devices(exclude_loopback=True)
                            if (DeviceType.Physical == dev.get_type() or DeviceType.Bonding == dev.get_type())
                            and dev.link.name not in filtered_out_interfaces]
        if not local_interfaces:
            return {}
        text = "\nWould you like to edit the local network interfaces on this machine (%s found)?" % \
               len(local_interfaces)
        code = self.YesNoBack(text=text,
                              title=title,
                              width=NORMAL_WIDTH,
                              height=8)
        if not code:
            # TODO: This is REALLY bad! Skipping here would return None, skipping each interface returns {}. This creates inconsistency in handling throught installation process.
            raise Skip()

        interfaces = {}
        method_choices = [(item.name, item.value) for item in NetworkAddressMode]

        index = 0
        while index < len(local_interfaces):
            interface = local_interfaces[index]
            interface_name = interface.link.name
            interface_mac = interface.link.address
            interface_network = setup_utilities.get_ovf_env_adapters().get(interface_mac, None)
            if interface_network:
                network_description = "%s - %s (port group: %s)" % (interface_name, interface_mac, interface_network)
            else:
                network_description = "%s - %s" % (interface_name, interface_mac)

            text = "\nChoose your network address assignment method for: \n\n{description}\n\n" \
                   "(Choosing 'Skip' will disable this interface configuration)".format(description=network_description)
            code, choice = self.dlg.menu(text,
                                         title=title,
                                         width=80,
                                         height=15,
                                         choices=method_choices,
                                         help_tags=True,
                                         cancel_label=BACK_BUTTON_LABEL)

            if code != self.dlg.OK:
                if index > 0:
                    index -= 1
                    continue
                else:
                    raise NavigateBack

            if choice == NetworkAddressMode.Skip.name:
                text = "\nSkipping interface {description}".format(description=network_description)
                self.dlg.msgbox(text=text,
                                width=NORMAL_WIDTH,
                                height=7)
                index += 1
                continue

            elif choice == NetworkAddressMode.DHCP.name:
                text = "\nDHCP was selected for {description}".format(description=network_description)
                self.dlg.msgbox(text=text,
                                width=NORMAL_WIDTH,
                                height=7)
                interfaces[interface_name] = NetworkAddressMode.DHCP.name
                index += 1
                continue

            elif choice == NetworkAddressMode.Static.name:
                text = "\nEnter the following parameters for {description}:\n\nMultiple DNS servers can be entered," \
                       " separated by <space>".format(description=network_description)

                fields = OrderedDict([
                    ("IP address", "172.16.100.50"),
                    ("Subnet mask", "255.255.255.0"),
                    ("Default gateway", "172.16.100.1"),
                    ("DNS server", ""),
                    ("Route network", ""),
                    ("Route netmask", ""),
                    ("Route gateway", "")
                ])

                break_loop = False
                while not break_loop:
                    while True:
                        code, new_fields = self.Form(fields=fields,
                                                     text=text,
                                                     title=title,
                                                     height=17)

                        # GC-30988: keep the ordering of the dicts
                        fields.update(new_fields)

                        if code != self.dlg.OK:
                            break_loop = True
                            break

                        was_input_error = False

                        route_gateway = fields["Route gateway"]
                        route_netmask = fields["Route netmask"]
                        route_network = fields["Route network"]

                        if route_network or route_netmask or route_gateway:
                            if route_network:
                                if not ip_address_validity_function(route_network):
                                    text = "\nRoute network - '%s' is not a valid IP address" % route_network
                                    was_input_error = True
                            else:
                                text = "\nRoute network is missing"
                                was_input_error = True

                            if route_netmask:
                                if not ip_address_validity_function(route_netmask):
                                    text = "\nRoute netmask - '%s' is not a valid IP address" % route_netmask
                                    was_input_error = True
                            else:
                                text = "\nRoute netmask is missing"
                                was_input_error = True

                            if route_gateway:
                                if not ip_address_validity_function(route_gateway):
                                    text = "\nRoute gateway - '%s' is not a valid IP address" % route_gateway
                                    was_input_error = True
                            else:
                                text = "\nRoute gateway is missing"
                                was_input_error = True

                        dns_server = fields["DNS server"]
                        if dns_server:
                            for dns_server_address in dns_server.split(" "):
                                if not ip_address_validity_function(dns_server_address):
                                    text = "\nDNS server - '%s' is not a valid IP address" % dns_server_address
                                    was_input_error = True

                        default_gw = fields["Default gateway"]
                        if default_gw:
                            if not ip_address_validity_function(default_gw):
                                text = "\nDefault Gateway - '%s' is not a valid IP address" % default_gw
                                was_input_error = True

                        subnet_mask = fields["Subnet mask"]
                        if not ip_address_validity_function(subnet_mask):
                            text = "\nSubnet mask'%s' is not a valid subnet mask" % subnet_mask
                            was_input_error = True

                        ip_address = fields["IP address"]
                        if not ip_address_validity_function(ip_address):
                            text = "\n'%s' is not a valid IP address" % ip_address
                            was_input_error = True

                        if was_input_error:
                            error_title = "Error"
                            self.dlg.msgbox(text=text,
                                            title=error_title,
                                            width=NORMAL_WIDTH,
                                            height=8)
                            break

                        else:
                            interfaces[interface_name] = fields
                            text = "\nStatic was selected for {description}".format(description=network_description)
                            self.dlg.msgbox(text=text,
                                            width=NORMAL_WIDTH,
                                            height=7)
                            index += 1
                            break_loop = True
                            break

                    if break_loop:
                        continue

        return interfaces

    def collect_network_configuration_by_portgroup(self, ip_address_validity_function, port_groups_names):
        """
        a function that collects network interfaces data from the user by port_groups_names
        allows to set static or DHCP per interface found on the machine.
        :return: a dict with the collected information
        """
        title = "Network Interfaces Configuration"
        interfaces = {}
        method_choices = [(item.name, item.value) for item in NetworkAddressMode]

        index = 0
        while index < len(port_groups_names):
            port_group_name = port_groups_names[index]

            text = "\nChoose your network address assignment method on port group: \n\n%s\n\n" \
                   % port_group_name
            code, choice = self.dlg.menu(text,
                                         title=title,
                                         width=80,
                                         height=13,
                                         choices=method_choices,
                                         help_tags=True,
                                         cancel_label=BACK_BUTTON_LABEL)

            if code != self.dlg.OK:
                if index > 0:
                    index -= 1
                    continue
                else:
                    raise NavigateBack

            if choice == NetworkAddressMode.Skip.name:
                text = "\nSkipping port group %s" % port_group_name
                self.dlg.msgbox(text=text,
                                width=NORMAL_WIDTH,
                                height=7)
                index += 1
                continue

            elif choice == NetworkAddressMode.DHCP.name:
                text = "\nDHCP was selected for %s" % port_group_name
                self.dlg.msgbox(text=text,
                                width=NORMAL_WIDTH,
                                height=7)
                interfaces[port_group_name] = NetworkAddressMode.DHCP.name
                index += 1
                continue

            elif choice == NetworkAddressMode.Static.name:
                text = "\nEnter the following parameters for %s:\n\n" \
                       "1. Multiple DNS servers can be entered, separated by <space>\n" \
                       "2. Subnet should be provided as CIDR" % port_group_name

                fields = OrderedDict([
                    ("Subnet", "192.168.0.0/16"),
                    ("Default gateway", ""),
                    ("DNS server", ""),
                    ("Route network", ""),
                    ("Route netmask", ""),
                    ("Route gateway", "")
                ])

                break_loop = False
                while not break_loop:
                    while True:
                        code, new_fields = self.Form(fields=fields,
                                                     text=text,
                                                     title=title,
                                                     height=17)

                        # GC-30988: keep the ordering of the dicts
                        fields.update(new_fields)

                        if code != self.dlg.OK:
                            break_loop = True
                            break

                        was_input_error = False

                        route_gateway = fields["Route gateway"]
                        route_netmask = fields["Route netmask"]
                        route_network = fields["Route network"]

                        if route_network or route_netmask or route_gateway:
                            if route_network:
                                if not ip_address_validity_function(route_network):
                                    text = "\nRoute network - '%s' is not a valid IP address" % route_network
                                    was_input_error = True
                            else:
                                text = "\nRoute network is missing"
                                was_input_error = True

                            if route_netmask:
                                if not ip_address_validity_function(route_netmask):
                                    text = "\nRoute netmask - '%s' is not a valid IP address" % route_netmask
                                    was_input_error = True
                            else:
                                text = "\nRoute netmask is missing"
                                was_input_error = True

                            if route_gateway:
                                if not ip_address_validity_function(route_gateway):
                                    text = "\nRoute gateway - '%s' is not a valid IP address" % route_gateway
                                    was_input_error = True
                            else:
                                text = "\nRoute gateway is missing"
                                was_input_error = True

                        dns_server = fields["DNS server"]
                        if dns_server:
                            for dns_server_address in dns_server.split(" "):
                                if not ip_address_validity_function(dns_server_address):
                                    text = "\nDNS server - '%s' is not a valid IP address" % dns_server_address
                                    was_input_error = True

                        default_gw = fields["Default gateway"]
                        if default_gw:
                            if not ip_address_validity_function(default_gw):
                                text = "\nDefault Gateway - '%s' is not a valid IP address" % default_gw
                                was_input_error = True

                        subnet_mask = fields["Subnet"]
                        if not ip_address_validity_function(subnet_mask, allow_cidr=True):
                            text = "\nSubnet mask'%s' is not a valid subnet mask" % subnet_mask
                            was_input_error = True

                        if was_input_error:
                            error_title = "Error"
                            self.dlg.msgbox(text=text,
                                            title=error_title,
                                            width=NORMAL_WIDTH,
                                            height=8)
                            break

                        else:
                            interfaces[port_group_name] = fields
                            text = "\nStatic was selected for %s" % port_group_name
                            self.dlg.msgbox(text=text,
                                            width=NORMAL_WIDTH,
                                            height=7)
                            index += 1
                            break_loop = True
                            break

                    if break_loop:
                        continue

        return interfaces

    def collect_single_option(
            self, title, description, options_list, hide_tags=False, default_item=None, height=None, width=None):
        """
        a function that asks the user to mark a certain option
        :return: a tuple with the user selection and a boolean telling if this method should be disable
                 (if there was only a single option)
        """
        if not options_list:
            raise EnvironmentError("Can't select single option from empty options list")
        if 1 == len(options_list):
            selected_option_name = options_list[0][0]
            LOG.info("One option only (%s)- skipping collection task" % selected_option_name)
            return selected_option_name, True

        if not default_item:
            default_item_title = options_list[0][1]
        else:
            default_item_title = False
            for item_name, item_title in options_list:
                if item_name == default_item:
                    default_item_title = item_title
                    break
            if not default_item_title:
                LOG.warning("Default item wasn't found: %s" % default_item)

        text = "\n%s" % (description,)

        if not height:
            height = 8 + len(options_list)

        if not width:
            width = NORMAL_WIDTH

        display_options_list = options_list[:]
        if hide_tags:
            display_options_list = [(item[1], '') for item in display_options_list]
        code, selected_option_name = self.dlg.menu(title=title,
                                                   text=text,
                                                   choices=display_options_list,
                                                   height=height,
                                                   width=width,
                                                   default_item=default_item_title,
                                                   cancel_label=BACK_BUTTON_LABEL)

        if code != self.dlg.OK:
            raise NavigateBack

        if hide_tags:
            for item_tag, item_desc in options_list:
                if selected_option_name == item_desc:
                    selected_option_name = item_tag
                    break

        return selected_option_name, False

    @staticmethod
    def generate_enriched_interfaces_list(interfaces_list=None):
        if not interfaces_list:
            interfaces_list = setup_utilities.get_interfaces_list()

        enriched_interfaces_list = []
        for interface_name, interface_mac in interfaces_list:
            interface_network = setup_utilities.get_ovf_env_adapters().get(interface_mac, None)

            if interface_network:
                network_description = "%s (port group: %s)" % (interface_mac, interface_network)
                enriched_interfaces_list.append((interface_name, network_description))
            else:
                enriched_interfaces_list.append((interface_name, interface_mac))

        return enriched_interfaces_list

    def collect_mark_specific_interface(self, mark_name, interfaces_list=None, default_item=None):
        """
        a function that asks the user to mark a certain network interface as the 'mark_name'
        :return: a tuple with marked interface and boolean "should be disabled"
        """
        enriched_interfaces_list = self.generate_enriched_interfaces_list(interfaces_list)

        title = mark_name
        description = "Select a network interface as the '%s':" % mark_name
        return self.collect_single_option(title, description, enriched_interfaces_list, default_item)

    def collect_multiple_interfaces(self, mark_name, interfaces_list=None):
        if not interfaces_list:
            interfaces_list = []

        enriched_interfaces_list = self.generate_enriched_interfaces_list()

        title = mark_name
        description = "Select network interfaces to use as '%s':" % mark_name
        return self.collect_multiple_options(title, description,
                                             [MultipleChoiceOpt(name=interface_name, description=description,
                                                                is_selected=True if interface_name in interfaces_list else False)
                                              for interface_name, description in
                                              enriched_interfaces_list])

    def collect_multiple_options(self, title, description, options_list):
        """
        a function that asks the user to mark multiple options
        :arg options_list: list of MultipleChoiceOpt or triples of options
        :return: list of marked items (items are instances of MultipleChoiceOpt)
        """
        if not options_list:
            return []

        text = "\n%s\n\nUse the <spacebar> to mark:" % description
        code, chosen_interfaces = self.dlg.checklist(title=title,
                                                     text=text,
                                                     width=10 + NORMAL_WIDTH,
                                                     choices=options_list,
                                                     height=10 + len(options_list),
                                                     cancel_label=BACK_BUTTON_LABEL)
        if code != self.dlg.OK:
            raise NavigateBack

        returned_opts = []
        for opt in options_list:
            if isinstance(opt, MultipleChoiceOpt):
                multiple_choice_opt = opt
            else:
                # convert tuple to namedtuple
                multiple_choice_opt = MultipleChoiceOpt(*opt)
            is_selected = multiple_choice_opt.name in chosen_interfaces
            returned_opts.append(MultipleChoiceOpt(name=multiple_choice_opt.name,
                                                   description=multiple_choice_opt.description,
                                                   is_selected=is_selected))
        return returned_opts

    def collect_deployment_mode(self, default_item=None):
        """
        a function that asks the user the deployment method - SaaS or On premise
        :param default_item: the item that will be selected by default on the screen. The first item if None
        :return name of DeploymentMode member
        """
        title = "Select Deployment Mode"
        text = "\nSelect the deployment mode:"

        choices = [(item.name, item.value) for item in DeploymentMode]

        if not default_item:
            default_item = choices[0][0]

        code, chosen_item = self.dlg.menu(title=title,
                                          text=text,
                                          choices=choices,
                                          default_item=default_item,
                                          height=8 + len(DeploymentMode),
                                          width=NORMAL_WIDTH)

        if code != self.dlg.OK:
            raise NavigateBack

        return chosen_item

    def collect_select_from_list(self, choices, title="", text="", height=None, default_item=None):
        """
        a generic function that collects one option from list
        :param choices: list of tuples with (choice_names and choice_description)
        :param title: title for the window
        :param text: text in the window
        :param height: height of window ('None' will adapt itself to the content by number of choices)
        :param default_item: the item that will be selected by default on the screen. The first item if None
        :return: name of selected choice
        """
        if not height:
            height = 8 + len(choices)

        if not default_item:
            default_item = choices[0][0]

        code, chosen_item = self.dlg.menu(title=title,
                                          text=text,
                                          choices=choices,
                                          default_item=default_item,
                                          height=height,
                                          width=NORMAL_WIDTH,
                                          cancel_label="Continue")
        if code != self.dlg.OK:
            return code
        return chosen_item

    ###################################
    # "install" methods section
    ###################################

    def install_start_installation(self):
        title = "%s Is Being Installed, Please Wait" % self.component_name
        self.dlg.gauge_start(text="",
                             title=title,
                             width=NORMAL_WIDTH)

    def install_step_update(self, percentage, description):
        if not description.startswith("\n"):
            description = "\n%s" % description
        self.dlg.gauge_update(percent=percentage,
                              text=description,
                              update_text=True)
