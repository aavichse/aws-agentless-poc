from functools import wraps

import monotonic
import msal
import requests

from common.logger import get_logger

LOG = get_logger()

AUTH_URL = 'https://login.microsoftonline.com/'
BASE_ENDPOINT = 'https://graph.microsoft.com/v1.0/'
SCOPES = ["https://graph.microsoft.com/.default"]
ODATA_NEXT_LINK = '@odata.nextLink'
ODATA_DELTA_LINK = '@odata.deltaLink'
ODATA_TYPE = '@odata.type'
USER_ODATA_TYPE = '#microsoft.graph.user'
GROUP_ODATA_TYPE = '#microsoft.graph.group'

RETURN_FIELD_ID = 'id'
RETURN_FIELD_GROUPS = 'groups'
RETURN_FIELD_GROUPS_MEMBERS = 'groups_members'

REQUEST_ERROR = 'Could not connect'
MAX_RESULTS_PER_PAGE = 999

MS_ATTR_SID = 'securityIdentifier'
MS_ATTR_MEMBERS_DELTA = 'members@delta'


def handle_token_error(func):
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        if "error" in self._access_token:
            return {"error": self._access_token["error"]}
        return func(self, *args, **kwargs)

    return wrapper


class MSAPI:
    def __init__(self, application_id, application_key, tenant_id, fetch_nested_group_members):
        self._client_id = application_id
        self._client_secret = application_key
        self._tenant_id = tenant_id
        self._fetch_nested_group_members = fetch_nested_group_members
        self._access_token = None
        self._connect()

    def _connect(self):
        try:
            app = msal.ConfidentialClientApplication(
                client_id=self._client_id,
                client_credential=self._client_secret,
                authority=AUTH_URL + self._tenant_id)

            self._access_token = app.acquire_token_for_client(scopes=SCOPES)
        except ValueError:
            self._access_token = {"error": "Couldn't connect to active directory, please check your credentials."}

    def refresh_access_token(self):
        self._connect()

    @handle_token_error
    def get_groups(self, groups_filter=None, is_health_check=False, results_per_page=MAX_RESULTS_PER_PAGE):
        return_field = RETURN_FIELD_GROUPS
        endpoint = BASE_ENDPOINT + return_field
        if groups_filter:
            # Using select in order to fetch required attributes only
            endpoint = endpoint + ('?$select=' + ",".join(groups_filter))

        headers = self._make_headers()
        try:
            response = requests.get(endpoint, headers=headers, params={"$top": results_per_page}).json()
            if 'error' in response:
                return response
            return_data = {return_field: response.get('value', [])}
        except requests.exceptions.RequestException:
            return {'error': REQUEST_ERROR}

        if is_health_check:
            return return_data

        return self._make_paginated_request(response, return_data, headers, return_field)

    @handle_token_error
    def get_deleted_groups(self):
        endpoint = BASE_ENDPOINT + 'directory/deletedItems/microsoft.graph.group'
        headers = self._make_headers()

        try:
            response = requests.get(endpoint, headers=headers)
        except requests.exceptions.RequestException:
            return {'error': REQUEST_ERROR}

        return response.json()

    @handle_token_error
    def get_group_members(self, group_ids, results_per_page=MAX_RESULTS_PER_PAGE):
        return_field = RETURN_FIELD_GROUPS_MEMBERS
        headers = self._make_headers()

        filter_clause = " or ".join("id eq '%s'" % id_ for id_ in group_ids)
        # delta request is used because it returns all results in chunks by 250 group members,
        # ordinary /groups request returns only 20 results
        endpoint = BASE_ENDPOINT + "groups/delta?$filter={}&$expand=members($select=id)".format(filter_clause)

        start_time = monotonic.monotonic()
        try:
            response = requests.get(endpoint, headers=headers, params={"$top": results_per_page}).json()
            end_time = monotonic.monotonic()
            LOG.debug("get_group_members request finished in {:.2f} seconds".format(end_time - start_time))

            if 'error' in response:
                return response
            values = response.get('value', [])
            LOG.debug("Received {} {} from Entra ID".format(len(values), return_field))
            return_data = {value[MS_ATTR_SID]: value.get(MS_ATTR_MEMBERS_DELTA, [])
                           for value in values if MS_ATTR_SID in value}
        except requests.exceptions.RequestException:
            return {'error': REQUEST_ERROR}
        return self._make_paginated_request(response, return_data, headers, return_field)

    @handle_token_error
    def get_group_members_delta(self, delta_link, results_per_page=MAX_RESULTS_PER_PAGE):
        return_field = RETURN_FIELD_GROUPS
        endpoint = delta_link if delta_link else BASE_ENDPOINT + "groups/delta?$deltatoken=latest"
        headers = self._make_headers()
        headers["Prefer"] = "return=minimal"

        start_time = monotonic.monotonic()
        try:
            response = requests.get(endpoint, headers=headers, params={"$top": results_per_page}).json()
            end_time = monotonic.monotonic()
            LOG.debug("get_group_members_delta request finished in {:.2f} seconds".format(end_time - start_time))
            if 'error' in response:
                return response
            values = response.get('value', [])
            LOG.debug("Received {} {} from Entra ID".format(len(values), return_field))
            return_data = {return_field: values}
        except requests.exceptions.RequestException:
            return {'error': REQUEST_ERROR}

        return self._make_paginated_request(response, return_data, headers, return_field, get_delta=True)

    def _make_headers(self):
        return {
            "Authorization": "Bearer " + self._access_token['access_token'],
            "Content-Type": "application/json"
        }

    @staticmethod
    def _make_paginated_request(response, return_data, headers, return_field, get_delta=False):
        try:
            page_number = 0
            while ODATA_NEXT_LINK in response:
                start_time = monotonic.monotonic()
                response = requests.get(response[ODATA_NEXT_LINK], headers=headers).json()
                end_time = monotonic.monotonic()
                LOG.debug("Pagination page {} request finished in {:.2f} seconds".format(page_number,
                                                                                         end_time - start_time))
                if 'error' in response:
                    return response
                values = response.get('value', [])
                LOG.debug("Received {} {} from Entra ID".format(len(values), return_field))
                if return_field == RETURN_FIELD_GROUPS_MEMBERS:
                    for value in values:
                        if MS_ATTR_SID in value and MS_ATTR_MEMBERS_DELTA in value:
                            return_data[value.get(MS_ATTR_SID)].extend(value[MS_ATTR_MEMBERS_DELTA])
                else:
                    return_data[return_field].extend(values)
                page_number += 1
        except requests.exceptions.RequestException:
            return {'error': REQUEST_ERROR}

        if get_delta and ODATA_DELTA_LINK in response:
            return_data['delta_link'] = response[ODATA_DELTA_LINK]

        return return_data
