import re
import six


def camel_case_to_snake_case(name):
    s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()


def camel_case_to_kebab_case(name):
    s1 = re.sub('(.)([A-Z][a-z]+)', r'\1-\2', name)
    return re.sub('([a-z0-9])([A-Z])', r'\1-\2', s1).lower()


def to_bytes(data):
    if isinstance(data, six.string_types) and not isinstance(data, bytes):
        return bytes(data, "utf-8") if six.PY3 else bytes(data)
    return data


def nativestr(x):
    if six.PY3:
        return x if isinstance(x, str) else x.decode('utf-8')
    else:
        return x if isinstance(x, str) else x.encode('utf-8')


def safe_strip(x, chars=None):
    """
    Safe version of str.strip(chars).
    If  'x' argument is None, returns None, otherwise returns the result of x.strip(chars)
    """
    if x is None:
        return None

    return x.strip(chars)
