from common.py.apis import DEFAULT_RABBITMQ_USERNAME, DEFAULT_RABBITMQ_PASSWORD, REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT, \
    ComponentType, AggregatorType, RPCExchange, RPCMessage, MessagePriority
from common.py.apis.management import UNKNOWN_API_VERSION
from common.py.apis.management.aggregating_system_component import AggregatorBaseComponentManagementAPI
from common.logger import get_logger
from common.py.orchestration.orchestration_type import OrchestrationType

LOG = get_logger(module_name=__name__)

__author__ = 'Sagy'

# note: if you change this format you should change it also in the asset UI
ORCHESTRATION_REVISION_ID_FORMAT = '%y%m%d%H%M%S'


class AggregatorManagementAPI(AggregatorBaseComponentManagementAPI):
    COMPONENT_TYPE = ComponentType.AGGREGATOR
    AD_ORCHESTRATIONS = [OrchestrationType.ACTIVE_DIRECTORY.value, OrchestrationType.AZURE_AD_GRAPH.value]

    def __init__(self, management_hosts, aggregator_id, version=UNKNOWN_API_VERSION,
                 user=DEFAULT_RABBITMQ_USERNAME, password=DEFAULT_RABBITMQ_PASSWORD, aggregator_details=None,
                 configuration_schema=None, associated_mgmt_configuration=None,
                 aggregator_type=AggregatorType.COLLECTOR, aggregator_features=None, collector_type=None,
                 anonymous=False, exchange=RPCExchange.AGGREGATOR_EXCHANGE_NAME, **kwargs):
        component_id = self.COMPONENT_TYPE.prefix + aggregator_id
        component_details = aggregator_details if aggregator_details is not None else {}
        component_details.update(dict(associated_mgmt_configuration=associated_mgmt_configuration,
                                      management_hosts=management_hosts))

        super(AggregatorManagementAPI, self).__init__(management_hosts=management_hosts,
                                                      user=user,
                                                      password=password,
                                                      version=version,
                                                      exchange=exchange,
                                                      component_id=component_id,
                                                      agent_id=aggregator_id,
                                                      aggregator_type=aggregator_type,
                                                      aggregator_features=aggregator_features,
                                                      collector_type=collector_type,
                                                      component_details=component_details,
                                                      heartbeat=REMOTE_COMPONENTS_RABBITMQ_HEARTBEAT,
                                                      configuration_schema=configuration_schema,
                                                      aggregator_configuration_schema=configuration_schema,
                                                      anonymous=anonymous, **kwargs)

    def add_notify_aggregators_list_changed_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.Aggregator.AGGREGATOR_NOTIFY_AGGREGTORS_LIST_CHANGE,
                                    lambda message: callback_func(aggregators_list=message['aggregators_list'],
                                                                  revision=message.get('revision', 0)))

    def add_clear_nginx_cache_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.Aggregator.AGGREGATOR_CLEAR_NGINX_CACHE,
                                    lambda message: callback_func())

    def add_connect_aggregator_debug_callback(self, callback_func):
        """
        Calls callback_func that should open a debug connection for the aggregator
        :param callback_func: this will be called once the appropriate message is received.
        """

        def _callback(message):
            if message['component_id'] == self.component_id:
                callback_func(file_path=message['file_path'])
            else:
                LOG.warning("Dropping aggregator debug session request with invalid component ID: %s", message)

        self.rabbitapi.add_callback(RPCMessage.Aggregator.AGGREGATOR_DEBUG_CONNECT, _callback)

    def add_connect_aggregator_agents_sdk_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.Aggregator.AGGREGATOR_AGENT_SDK_CONNECT, callback_func)

    def get_orchestration_configuration(self):
        return self.rabbitapi.call_management_rpc(RPCMessage.Aggregator.AGGREGATOR_GET_ORCHESTRATION_DETAILS,
                                                  exchange=RPCExchange.ORCHESTRATION_EXCHANGE_NAME,
                                                  blocking=True)

    def report_orchestration_update(self, orchestration_type, orchestration_id, report_data, revision_id):
        """
        Sends an orchestration report to management
        Report data is formatted using the following schema :
            {
                OrchestrationEntityType.value: OrchestrationEntityReport,
                OrchestrationEntityType.value: OrchestrationEntityReport,
            }
        for each orchestration object (vm, host etc.) we should have:
           - id -> the orchestration related ID (e.g. 'moref' fot VMs in vSphere)
        :param orchestration_type: name of the orchestration driver
        :param orchestration_id: orchestration driver id
        :param report_data: the orchestration data to report to management
        :param revision_id: each orchestration update message is part of a revision
        :return:
        """
        if orchestration_type in self.AD_ORCHESTRATIONS:
            self.rabbitapi.call_management_rpc(RPCMessage.ActiveDirectory.REPORT_ACTIVE_DIRECTORY_UPDATE,
                                               exchange=RPCExchange.ACTIVE_DIRECTORY_EXCHANGE_NAME,
                                               orchestration_type=orchestration_type,
                                               orchestration_id=orchestration_id,
                                               report_data=report_data,
                                               revision_id=revision_id)

        else:
            self.rabbitapi.call_management_rpc(RPCMessage.Orchestration.REPORT_AGGREGATOR_ORCHESTRATION_UPDATE,
                                               exchange=RPCExchange.ORCHESTRATION_EXCHANGE_NAME,
                                               orchestration_type=orchestration_type,
                                               orchestration_id=orchestration_id,
                                               report_data=report_data,
                                               revision_id=revision_id)

    def get_all_active_directory_groups(self, orchestration_id):
        return self.rabbitapi.call_management_rpc(
            RPCMessage.ActiveDirectory.GET_ALL_ACTIVE_DIRECTORY_GROUPS,
            exchange=RPCExchange.ACTIVE_DIRECTORY_EXCHANGE_NAME,
            orchestration_id=orchestration_id,
            blocking=True
        )

    def add_management_user_groups_changed_callback(self, callback_func):
        self.rabbitapi.add_callback(
            RPCMessage.Aggregator.AGGREGATOR_NOTIFY_ORCHESTRATION_USER_GROUPS_WITH_AZURE_AD_CHANGED,
            lambda message: callback_func())

    def get_user_group_mapping_feature_configuration(self):
        return self.rabbitapi.call_management_rpc(
            RPCMessage.Orchestration.USER_GROUP_MAPPING_MESSAGE_TYPE,
            exchange=RPCExchange.ORCHESTRATION_EXCHANGE_NAME,
            blocking=True
        )

    def add_notify_user_group_mapping_feature_changed_callback(self, callback_func, initial_call=False,
                                                               initial_call_func=None):
        self.rabbitapi.add_callback(
            RPCMessage.Orchestration.USER_GROUP_MAPPING_MESSAGE_TYPE,
            lambda message: callback_func(configuration=message['configuration']),
            initial_call=initial_call,
            initial_call_func=initial_call_func
        )

    def get_entra_id_to_mgmt_full_sync_interval_configuration(self):
        return self.rabbitapi.call_management_rpc(
            RPCMessage.Orchestration.ENTRA_ID_TO_MGMT_FULL_SYNC_INTERVAL_MESSAGE_TYPE,
            exchange=RPCExchange.ORCHESTRATION_EXCHANGE_NAME,
            blocking=True
        )

    def add_notify_entra_id_to_mgmt_full_sync_interval_changed_callback(self, callback_func, initial_call=False,
                                                                        initial_call_func=None):
        self.rabbitapi.add_callback(
            RPCMessage.Orchestration.ENTRA_ID_TO_MGMT_FULL_SYNC_INTERVAL_MESSAGE_TYPE,
            lambda message: callback_func(configuration=message['configuration']),
            initial_call=initial_call,
            initial_call_func=initial_call_func
        )

    def report_agent_events(self, events):
        """
        Sends agent status events to management
        Using the following schema :
            {
                'report_time': <timestamp>
                'aggregated': [
                    {
                        'vm_uuid': <agent_association_key>
                        'source': <reporter_ip>
                        'hostname': <reporter_hostname>
                    },
                    ...
                ],
                'origin': <origin_of_event>
                'message': <message>
                'severity': <agent_event_severity>
            }
        :param events: the events of the schema above
        note: report_time should be of type long/int, a result of:
        >> datetime.utcnow().timestamp()
        """
        self.rabbitapi.call_management_rpc(RPCMessage.Aggregator.AGGREGATOR_REPORT_AGENT_EVENT_RPC_FUNC_NAME,
                                           exchange=RPCExchange.AGENT_EVENT_EXCHANGE_NAME,
                                           events=events)

    def report_agent_uninstall_event(self, cn_name, origin):
        event = {
            "cert_client_cn_name": cn_name,
            "origin": origin if origin else self.component_id
        }
        self.rabbitapi.call_management_rpc(
            RPCMessage.Aggregator.AGGREGATOR_REPORT_AGENT_UNINSTALL_EVENT_RPC_FUNC_NAME,
            exchange=RPCExchange.AGENT_EVENT_EXCHANGE_NAME,
            event=event)

    def add_integration_connectivity_test_callback(self, callback_func):
        self.rabbitapi.add_callback(
            message_type=RPCMessage.Integrations.TEST_CONNECT,
            callback_func=lambda message: callback_func(
                integration_type=message["integration_type"],  # IntegrationType
                integration_info=message["integration_info"],  # cluster_id, api_version, cloud_app_type
                connection_info=message["connection_info"],  # eg. manifest in CloudApp
                correlation_id=message['correlation_id']
            )
        )

    def report_integration_healthcheck_result(self, correlation_id, component_type, details, result, error):
        self.rabbitapi.call_management_rpc(RPCMessage.Integrations.CONNECT_RESULT,
                                           exchange=RPCExchange.ORCHESTRATION_EXCHANGE_NAME,
                                           priority=MessagePriority.BLOCKING_MESSAGE_PRIORITY,
                                           correlation_id=correlation_id,
                                           component_type=component_type,
                                           details=details,
                                           result=result,
                                           error=error)

    def report_orchestration_connectivity_status(self, status_report_data):
        """
        Sends an orchestration status report to management
        Using the following schema :
            {
                '<orchestration id>': {
                    'connectivity-status': <OrchestrationProviderStatus>
                    'error-msg' : <str> # Optional
                }
                <id>: {
                    ...
                }
            }
            <driver-n>: {
                ...
            }
        :param status_report_data: the orchestration data to report to management
        :return:
        """
        return self.rabbitapi.call_management_rpc(RPCMessage.Orchestration.REPORT_AGGREGATOR_ORCHESTRATION_CONNECTIVITY,
                                                  exchange=RPCExchange.ORCHESTRATION_EXCHANGE_NAME,
                                                  component_id=self.component_id,
                                                  report_data=status_report_data)

    def add_notify_orchestration_configuration_change_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.Aggregator.AGGREGATOR_NOTIFY_ORCHESTRATION_CONFIGURATION_CHANGE,
                                    lambda message: callback_func(orchestration_config=message['orchestration_config']))

    def add_run_bloodhound_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.Aggregator.AGGREGATOR_RUN_BLOODHOUND,
                                    lambda message: callback_func(bloodhound_config=message['bloodhound_config']))

    def report_bloodhound_status(self, status_report_data):
        return self.rabbitapi.call_management_rpc(
            RPCMessage.Aggregator.AGGREGATOR_REPORT_BLOODHOUND_STATUS,
            bloodhound_status_reports=status_report_data)

    def add_abort_bloodhound_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.Aggregator.AGGREGATOR_ABORT_BLOODHOUND,
                                    lambda message: callback_func())

    def add_delete_bloodhound_callback(self, callback_func):
        self.rabbitapi.add_callback(RPCMessage.Aggregator.AGGREGATOR_DELETE_BLOODHOUND,
                                    lambda message: callback_func(bloodhound_config=message))

    def add_orchestration_connectivity_test_callback(self, callback_func):
        """
        the callback method should have arguments:
        correlation_id - result should contain that id to return (used by us)
        orchestration_type: vsphere, etc...
        orchestration_details - taken from the schema e.g: common/py/clouds/vsphere/__init__.py -
                keys = [auth_host, auth_port, admin_user, admin_password]
        """
        self.rabbitapi.add_callback(RPCMessage.Aggregator.AGGREGATOR_ORCHESTRATION_CONNECTIVITY_TEST,
                                    lambda message: callback_func(
                                        correlation_id=message['correlation_id'],
                                        orchestration_type=message['orchestration_type'],
                                        orchestration_cluster_id=message['orchestration_cluster_id'],
                                        orchestration_details=message['orchestration_details']))

    def report_orchestration_connectivity_test_result(self, correlation_id, result, error=None):
        """result should be of type ConnectionTestResult"""
        return self.rabbitapi.call_management_rpc(
            RPCMessage.Aggregator.AGGREGATOR_REPORT_ORCHESTRATION_CONNECTIVITY_TEST_RESULT,
            exchange=RPCExchange.ORCHESTRATION_EXCHANGE_NAME,
            priority=MessagePriority.BLOCKING_MESSAGE_PRIORITY, blocking=True,
            correlation_id=correlation_id, result=result, error=error)

    def get_agents_installation_password(self):
        return self.rabbitapi.call_management_rpc(
            RPCMessage.Aggregator.AGGREGATOR_GET_AGENTS_INSTALLATION_PASSWORD_RPC_FUNC_NAME,
            blocking=True)

    def get_zookeeper_ids(self, component_ids, timeout_sec=None):
        return self.rabbitapi.call_management_rpc(RPCMessage.Aggregator.AGGREGATOR_GET_ZOOKEEPER_ID,
                                                  component_ids=component_ids,
                                                  reporting_component=self.component_id,
                                                  timeout_sec=timeout_sec,
                                                  blocking=True)
