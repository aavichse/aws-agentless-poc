import os

EXPORTERS_PATH = os.path.dirname(__file__)
EXPORTERS_PACKAGE = __name__
