from enum import IntEnum


class CloudProvider(IntEnum):
    OnPremise = 0
    Aws = 1
    Azure = 2
    Oracle = 3
    OpenStack = 4
    GCP = 5
