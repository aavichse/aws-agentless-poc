import re
from itertools import chain
from common.py.integrations.base import InventoryProcessor
from common.py.utils.integration_scope import IntegrationScope
from common.py.orchestration.orchestration_type import OrchestrationType
from common.py.integrations.azure import AzureControlClient
from common.logger import get_logger

LOG = get_logger(module_name=__name__)

AZURE_DEFAULT_LABEL = ('Platform', 'Azure')
SERVICE_TAG_PREFIX = "ServiceTag."


class AzureInventoryProcessor(InventoryProcessor):
    ENTITY_SUPPORTED_TYPES = ['VM', 'MS']

    def __init__(self, config, models):
        super(AzureInventoryProcessor, self).__init__(config, models)
        self._subscription_id_to_name_map = {}
        self._label_blacklist = None

    @property
    def name(self):
        return self._config.cloud.name if self._config else self._config.cloud.cloud_app_type.capitalize()

    @property
    def id(self):
        return self._config.cloud.orchestration_id if self._config else "0"

    @property
    def type(self):
        return OrchestrationType.CLOUD_APP_AZURE.value

    def start(self):
        super(AzureInventoryProcessor, self).start()
        self._config.listen_for_changes("aggregator.inventory_plugin.azure_label_blacklist",
                                        self._on_configuration_change)
        try:
            self._label_blacklist = re.compile('|'.join(self._config.aggregator.inventory_plugin.azure_label_blacklist))
        except re.error as e:
            LOG.warning("Failed to compile label blacklist: %s", e.msg)
            self._label_blacklist = None
        self._subscription_id_to_name_map = self._build_subscription_map()
        LOG.debug("Azure Cloud inventory processor has been started")

    def _on_configuration_change(self, config_name, old_value, new_value):
        try:
            LOG.info("Update label blacklist %s ", new_value)
            self._label_blacklist = re.compile('|'.join(new_value))
        except re.error as e:
            LOG.warning("Failed to compile label blacklist:  %s", e.msg)
            self._label_blacklist = None

    # Currently cloud app report subscription id , but for end user we would like to show the name.
    # In the future, we may change this so that cloud app will send both
    def _build_subscription_map(self):
        try:
            api_client = AzureControlClient.from_config(getattr(self._config, 'cloud'))
            subscriptions = api_client.subscriptions()
            if not subscriptions:
                LOG.warning("Failed to build subscriptions map")
                return {}
            return {str(sub.id): sub.name for sub in subscriptions}
        except Exception as e:
            LOG.error("Cannot build subscriptions map. (exec=%s)", e)
            return {}

    def get_labels_and_metadata(self, asset, nics):
        scope_info = self._prepare_azure_scope_info(asset, nics)

        metadata = super(AzureInventoryProcessor, self)._create_metadata(asset)
        metadata += tuple(scope_info)

        labels = self._get_asset_labels(asset)

        return labels, metadata

    def _get_asset_labels(self, asset):
        cloud_labels = super(AzureInventoryProcessor, self)._create_labels(asset)
        if cloud_labels and self._label_blacklist:
            org_labels_count = len(cloud_labels)
            cloud_labels = {item for item in cloud_labels if not self._label_blacklist.search(item[0])}
            if org_labels_count != len(cloud_labels) and self._config.integration.trace_inventory_reports:
                LOG.debug("asset %s: blacklist labels were removed", asset.external_ids[0])
        return cloud_labels

    def _prepare_azure_scope_info(self, asset, nics):
        """
        Preparing tuples of IntegrationScope items relevant for Azure.
        These tuples will be translated to Scope Labels on mgmt
        """
        scope_info = list({(IntegrationScope.PLATFORM.value, 'Azure')})
        scope_info.append((IntegrationScope.AZURE_RESOURCE_TYPE.value, asset.entity_type if asset.entity_type else 'Unknown'))

        # azure network: vnet and subnets
        networks_info = set(chain.from_iterable(((IntegrationScope.AZURE_VNET.value, nic.cloud_network.split('/')[-1]),
                                                 (IntegrationScope.AZURE_SUBNET.value, nic.network_id.split('/')[-1]))
                                                for nic in nics if not nic.is_cloud_public))
        scope_info.extend(networks_info)

        # azure service tags
        if str(asset.entity_type).startswith(SERVICE_TAG_PREFIX):
            scope_info.append((IntegrationScope.AZURE_SERVICE_TAG.value, str(asset.entity_type)[len(SERVICE_TAG_PREFIX):]))

        # azure topology: subscription, region etc
        azure_topology = getattr(asset.entity_data, 'network_topology', None)
        if azure_topology:
            if azure_topology.resource_group:
                scope_info.append((IntegrationScope.AZURE_RESOURCE_GROUP.value, azure_topology.resource_group))
            if azure_topology.region:
                scope_info.append((IntegrationScope.AZURE_REGION.value, azure_topology.region))
            if azure_topology.subscription:
                scope_info.append((IntegrationScope.AZURE_SUBSCRIPTION_ID.value, azure_topology.subscription))
                scope_info.append((IntegrationScope.AZURE_SUBSCRIPTION.value,
                                      self._subscription_id_to_name_map.get(azure_topology.subscription, azure_topology.subscription)))
        return scope_info

    def is_supported(self, asset):
        """
        :return: Return True if the entity data type is known to the processor or if ServiceTag is prefix
        in asset.entity_type
        """
        if isinstance(asset.entity_data, dict) and asset.entity_type and 'ServiceTag' in asset.entity_type:
            return True
        return super(AzureInventoryProcessor, self).is_supported(asset)


