import os

import attr
from enum import Enum

from common.logger import get_logger

OS_RELEASE_PATH = '/etc/os-release'
OS_RELEASE_ID_KEY = 'ID'
OS_RELEASE_VERSION_KEY = 'VERSION'

LOG = get_logger(module_name=__name__)


class LinuxDistro(Enum):
    UBUNTU = 'ubuntu'
    RHEL = 'rhel'
    ALPINE = 'alpine'

    def __str__(self):
        return self.value

    @staticmethod
    def from_str(distro):
        return DISTRO_MAP.get(distro)


DISTRO_MAP = {str(distro): distro for distro in LinuxDistro}


def get_linux_distro(os_release_path=OS_RELEASE_PATH):
    """
    Get Linux distro and version based on os-release ID and VERSION variables
    NB: when the code is running from container /etc on the host must be mapped
    to the container and set as os_release_path otherwise the container os will be returned

    :param os_release_path:
    :return: LinuxDistro, version str
    """
    if not os.path.exists(os_release_path):
        LOG.warn("Failed to read %s. File not found", os_release_path)
        return None, None

    try:
        with open(os_release_path, 'r') as fp:
            os_release = fp.read()
            os_release_map = dict(token.replace('"', '').split('=') for token in os_release.split('\n') if '=' in token)
            if OS_RELEASE_ID_KEY not in os_release_map:
                LOG.warn("Failed to find %s in %s", os_release_path)
                return None, None

            distro = LinuxDistro.from_str(os_release_map[OS_RELEASE_ID_KEY])
            version = os_release_map.get(OS_RELEASE_VERSION_KEY)
            LOG.debug("Found Linux distro: %s version: %s in %s", distro, version, os_release_path)
            return distro, version
    except (IOError, OSError):
        LOG.exception("Failed to read %s", os_release_path)

    return None, None


class PackageType(Enum):
    DEB = 'deb'
    RPM = 'rpm'
    PIP = 'pip'

    def __str__(self):
        return self.value


class NetworkManager(Enum):
    Interfaces = 'interfaces'
    NetworkManager = 'network_manager'
    Netplan = 'netplan'


@attr.s
class OSConfig(object):
    id = attr.ib()
    version = attr.ib()
    version_id = attr.ib()
    pretty_name = attr.ib()

    package_manager = attr.ib()
    network_manager = attr.ib()
    network_interfaces = attr.ib()
    dependency_file = attr.ib()


# Note: When adding a new OS with Netplan network manager add it to `management/docker_deploy/bootstrap/bootstrapper.py`
Ubuntu14 = OSConfig(id=LinuxDistro.UBUNTU, version="14.04.5 LTS, Trusty Tahr", pretty_name='Ubuntu 14.04.5 LTS',
                    version_id="14.04",
                    package_manager=PackageType.DEB,
                    network_manager=NetworkManager.Interfaces,
                    network_interfaces=('eth0', 'eth1'),
                    dependency_file='essential_debs.json')
Ubuntu16 = OSConfig(id=LinuxDistro.UBUNTU, version="16.04.2 LTS (Xenial Xerus)", pretty_name='Ubuntu 16.04.2 LTS',
                    version_id="16.04",
                    package_manager=PackageType.DEB,
                    network_manager=NetworkManager.Interfaces,
                    network_interfaces=('eth0', 'eth1'),
                    dependency_file='essential_debs.json')
Ubuntu18_04_2 = OSConfig(id=LinuxDistro.UBUNTU, version="18.04.2 LTS (Bionic Beaver)", pretty_name='Ubuntu 18.04.2 LTS',
                         version_id="18.04",
                         package_manager=PackageType.DEB,
                         network_manager=NetworkManager.Netplan,
                         network_interfaces=('ens160', 'ens192'),
                         dependency_file='essential_debs_1804.json')
Ubuntu18_04_3 = OSConfig(id=LinuxDistro.UBUNTU, version="18.04.3 LTS (Bionic Beaver)", pretty_name='Ubuntu 18.04.3 LTS',
                         version_id="18.04",
                         package_manager=PackageType.DEB,
                         network_manager=NetworkManager.Netplan,
                         network_interfaces=('ens160', 'ens192'),
                         dependency_file='essential_debs_1804.json')
Ubuntu18_04_6 = OSConfig(id=LinuxDistro.UBUNTU, version="18.04.6 LTS (Bionic Beaver)", pretty_name='Ubuntu 18.04.6 LTS',
                         version_id="18.04",
                         package_manager=PackageType.DEB,
                         network_manager=NetworkManager.Netplan,
                         network_interfaces=('ens160', 'ens192'),
                         dependency_file='essential_debs_1804.json')
Ubuntu22_04_2 = OSConfig(id=LinuxDistro.UBUNTU, version="22.04.2 LTS (Jammy Jellyfish)", pretty_name='Ubuntu 22.04.2 LTS',
                         version_id="22.04",
                         package_manager=PackageType.DEB,
                         network_manager=NetworkManager.Netplan,
                         network_interfaces=('ens160', 'ens192'),
                         dependency_file='essential_debs_2204.json')
RHEL74 = OSConfig(id=LinuxDistro.RHEL, version="7.4 (Maipo)", pretty_name='Red Hat Enterprise Linux',
                  package_manager=PackageType.RPM,
                  version_id="7.4",
                  network_manager=NetworkManager.NetworkManager,
                  network_interfaces=('ens160', 'ens192'),
                  dependency_file='essential_rpms.json')
RHEL76 = OSConfig(id=LinuxDistro.RHEL, version="7.6 (Maipo)", pretty_name='Red Hat Enterprise Linux',
                  version_id="7.6",
                  package_manager=PackageType.RPM,
                  network_manager=NetworkManager.NetworkManager,
                  network_interfaces=('ens160', 'ens192'),
                  dependency_file='essential_rpms.json')

Ubuntu18 = Ubuntu18_04_2  # yah, I know. Blame Shasho.

ID_VERSION_MAP = {(config.id, config.version): config
                  for config in [Ubuntu14, Ubuntu16, Ubuntu18_04_2, Ubuntu18_04_3, Ubuntu18_04_6, Ubuntu22_04_2, RHEL74, RHEL76]}

JENKINS_OS_MAP = {
    'ubuntu_14_04': Ubuntu14,
    'ubuntu_16_04': Ubuntu16,
    'ubuntu_18_04_2': Ubuntu18_04_2,  # yah, I know. Blame Shasho.
    'ubuntu_18_04_3': Ubuntu18_04_3,  # yah, I know. Blame Shasho.
    'ubuntu_18_04_6': Ubuntu18_04_6,  # yah, he knows. Blame Shasho.
    'ubuntu_18_04': Ubuntu18_04_3,  # yah, I know. Blame Shasho.
    'ubuntu_22_04_2': Ubuntu22_04_2,  # yah, I know. Blame Shasho.
    'ubuntu_22_04': Ubuntu22_04_2,  # yah, I know. Blame Shasho.
    'redhat_7_4': RHEL74,
    'redhat_7_5': RHEL76,  # yah, I know. Blame Shasho.
}
