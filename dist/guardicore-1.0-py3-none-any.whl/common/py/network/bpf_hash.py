from math import ceil, log, pow
from common.py.network.bpf import BPF, EmptyBpf


IP_V4_ONLY_BPF = (BPF('((ip[0] & 0xf0)>>4)') == 4)

ARP_IPV4_ONLY_BPF = (BPF('(arp[5] & 0xff)') == 4)


def split_bpf_to_n_l3_symmetric(n=4):
    """
    Yields set of bpfs that can split l3 traffice(ip or arp filter) - into several disjointed groups of
     packets, in such way that packets for same sessions(ip1<->ip2) will always go to the same filter.
    """

    for bpf_index in xrange(n):
        yield ((IP_V4_ONLY_BPF & hash_to_bucket(hash_expression=l3_ipv4_hash(),
                                                number_of_bpfs=n,
                                                bpf_index=bpf_index)) |
               (ARP_IPV4_ONLY_BPF & hash_to_bucket(hash_expression=l3_arp_hash(),
                                                   number_of_bpfs=n,
                                                   bpf_index=bpf_index)))


def l3_ipv4_hash():
    return (
        # hash src ip ( stored at ip[12] .. ip[15]
        BPF('(ip[15] & 0xff)') +
        # hash dst ip ( stored at ip[16] .. ip[19]
        BPF('(ip[19] & 0xff)')
    )


def l3_arp_hash():
    return (
        # match arp ipv4 src ( address stored at arp[14] .. arp[17]
        BPF('(arp[17] & 0xff)') +

        # match arp ipv4 dst ( address stored at arp[24] .. arp[27]
        BPF('(arp[27] & 0xff)')
    )


def hash_to_bucket(hash_expression, number_of_bpfs, bpf_index):
    nearest_power_of_2 = int(pow(2, ceil(log(number_of_bpfs) / log(2))))
    if nearest_power_of_2 > 32:
        raise RuntimeError("More than 32 parts is not supported. got %d", number_of_bpfs)

    result_bpf = EmptyBpf()
    for hash_value in xrange(nearest_power_of_2):
        if hash_value % number_of_bpfs == bpf_index:
            result_bpf |= BPF("( ({hash_expression}) & ({mod}) = ({result}) )"
                              .format(hash_expression=str(hash_expression),
                                      mod=(nearest_power_of_2 - 1),
                                      result=hash_value))
    return result_bpf
