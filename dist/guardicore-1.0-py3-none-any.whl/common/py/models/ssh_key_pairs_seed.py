import random
import sys
from collections import namedtuple

from mongoengine import IntField, StringField

from common.gc_document import GCDynamicDocument
from common.logger import get_logger

LOG = get_logger(module_name=__name__)

DEFAULT_HPVM_SSH_KEY_PAIRS_POOL_SIZE = 256


KeyPair = namedtuple('KeyPair', 'private public')


class SshKeyPairsSeed(GCDynamicDocument):
    meta = {
        'ordering': [],
    }

    sequence_number = IntField(required=True, primary_key=True)
    seed = StringField(required=True)

    @classmethod
    def generate_ssh_key_pairs_seeds(cls, required_pool_size):
        LOG.debug("Generating %d new ssh key pairs seeds", required_pool_size)

        random_seeds = ['{:x}'.format(x) for x in random.sample(range(sys.maxsize),
                                                                required_pool_size)]
        for index, seed in enumerate(random_seeds):
            cls(sequence_number=index,
                seed=seed).save()
