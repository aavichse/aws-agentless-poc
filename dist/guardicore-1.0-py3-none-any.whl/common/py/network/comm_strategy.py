import json
from common import logger
from common.py.utils.str import to_bytes
from common.py.apis.rabbitutils import RabbitMsgJSONEncoder, RabbitMsgJSONDecoder
from common.py.model.exceptions import GuardicoreException
LOG = logger.get_logger(module_name=__name__)


class CommunicationStrategy(object):
    @classmethod
    def prepare_for_send(cls, data_dict):
        raise NotImplementedError()

    @classmethod
    def prepare_after_receive(cls, data):
        raise NotImplementedError()


class JsonCommunicationStrategy(CommunicationStrategy):
    @classmethod
    def prepare_for_send(cls, data_dict):
        try:
            result = json.dumps(data_dict, cls=RabbitMsgJSONEncoder)
            return to_bytes(result)
        except GuardicoreException as e:
            LOG.exception("Failed to dump json data(%s)", data_dict)
            raise GuardicoreException("Can't dump json data,error: %s", e)

    @classmethod
    def prepare_after_receive(cls, data):
        try:
            return json.loads(data, cls=RabbitMsgJSONDecoder)
        except (TypeError, ValueError) as e:
            LOG.exception("Failed to load json data(%s),error: %s ", data, e)
            raise GuardicoreException("Can't load input data from JSON,error")
