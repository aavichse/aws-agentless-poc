from enum import IntEnum

from common.py.clouds import common_opts, label_opts
from common.py.utils.config import cfg
from common.py.utils.config.types import Structure
from common.py.utils.config.oslo_config import types

__author__ = 'Izi'


class FullPortPullStrategy(IntEnum):
    AllAtOnce = 1
    AllPulledServersInBulk = 2


class DifferentialPortPullStrategy(IntEnum):
    AllAtOnce = 1
    AllPulledServersInBulk = 2
    NewServersOnlyInBulk = 3
    NoPull = 4


DEFAULT_PORTS_PULL_BULK_SIZE = 50

# openstack specific configurations
base_openstack_opts = [cfg.StrOpt('user', help="OpenStack server username", default="admin"),
                       cfg.StrOpt('password', secret=True, help="OpenStack server password"),
                       cfg.StrOpt('api_authentication_endpoint', help="API authentication endpoint"),
                       cfg.StrOpt('user_domain_name', help="User Domain Name", default="Default"),
                       cfg.StrOpt('user_domain_id', help="User Domain ID", default=None),
                       cfg.Opt('projects_list', default=[],
                               type=types.List(item_type=types.String(unicode=True, quotes=True), bounds=True),
                               help='A list of projects, delimited by new lines. Each project can be either project-id '
                                    'or project-name@project-domain. Leave empty to fetch all projects list '
                                    'automatically (require user with appropriate permissions)'),
                       cfg.BoolOpt('fetch_project_properties', default=False,
                                   help="Import project's properties as labels"),
                       cfg.BoolOpt('fetch_hosts', default=True, help='Mark this to fetch hosts'),
                       cfg.BoolOpt('fetch_users', default=True, help='Mark this to fetch VMs users'),
                       cfg.BoolOpt('fetch_flavors', default=True, help='Mark this to fetch VMs flavors'),
                       cfg.BoolOpt('fetch_images', default=True, help='Mark this to fetch VMs images'),
                       cfg.StrOpt('full_port_pull_strategy',
                                  default=FullPortPullStrategy.AllAtOnce.name,
                                  choices=list(FullPortPullStrategy.__members__.keys()),
                                  help='Strategy for full port pull<br>'
                                       '<b>AllAtOnce:</b> Pull all ports at once<br>'
                                       '<b>AllPulledServersInBulk:</b> Pull ports for all pulled servers, in bulk'),
                       cfg.StrOpt('differential_port_pull_strategy',
                                  default=DifferentialPortPullStrategy.AllAtOnce.name,
                                  choices=list(DifferentialPortPullStrategy.__members__.keys()),
                                  help='Strategy for differential port pull<br>'
                                       '<b>AllAtOnce:</b> Pull all ports at once<br>'
                                       '<b>AllPulledServersInBulk:</b> Pull ports for all pulled servers, in bulk<br>'
                                       '<b>NewServersOnlyInBulk:</b> Pull ports for new pulled servers only, in bulk<br>'
                                       '<b>NoPull:</b> Do not pull ports differentially<br>'),
                       cfg.IntOpt('ports_pull_bulk_size', default=DEFAULT_PORTS_PULL_BULK_SIZE,
                                  help='How many ports to pull in each bulk. Relevant only for '
                                       '<b>AllPulledServersInBulk</b> and <b>NewServersOnlyInBulk</b> modes.<br>'
                                       '0: fallback to default (%d)' % DEFAULT_PORTS_PULL_BULK_SIZE),
                       cfg.IntOpt('interval_between_ports_pulls',
                                  help='Sleep interval between per-server ports pulls (in milliseconds)',
                                  default=0),
                       cfg.IntOpt('servers_pull_bulk_size', default=0,
                                  help='How many servers to pull in each bulk. Relevant for all modes.<br>'
                                       '0: pull all servers at once'),
                       cfg.IntOpt('interval_between_server_pulls',
                                  help='Sleep interval between servers bulk pull (in milliseconds)',
                                  default=0),
                       cfg.StrOpt('keystone_version', help="Identity Protocol Version", default='3'),
                       cfg.StrOpt('keystone_endpoint', help="Identity Endpoint Type or URL override", default=None),
                       cfg.StrOpt('nova_version', help="Compute Protocol Version", default='2.1'),
                       cfg.StrOpt('nova_endpoint', help="Compute Endpoint Type or URL override", default=None),
                       cfg.StrOpt('neutron_endpoint', help="Networking Endpoint Type or URL override", default=None),
                       ] + common_opts + label_opts

openstack_opts = base_openstack_opts + common_opts + label_opts

OPENSTACK_AUTH_STRUCTURE = Structure(openstack_opts)

OPENSTACK_AUTH_OPTS = []


def register_opts():
    cfg.CONF.register_opt(cfg.Opt('openstack_configuration', type=OPENSTACK_AUTH_STRUCTURE), group="orchestration")
