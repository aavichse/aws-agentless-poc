from common.py.integrations.packetfence.control_client import PFControlClient
from common.py.integrations.packetfence.proxy_client import PFProxyClient
