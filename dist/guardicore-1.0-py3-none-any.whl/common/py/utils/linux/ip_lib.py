# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2012 OpenStack Foundation
# All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import os
import netaddr
from enum import IntEnum
from common.py.utils.linux.general import check_output, check_call
import itertools

LOOPBACK_DEVNAME = 'lo'
# NOTE(ethuleau): depend of the version of iproute2, the vlan
# interface details vary.
VLAN_AND_TUN_INTERFACE_DETAIL = ['vlan protocol 802.1q',
                                 'vlan protocol 802.1Q',
                                 'vlan id',
                                 'gretap',
                                 'gre',
                                 'vxlan']

FORCE_ROOT = True


class LinuxMode(IntEnum):
    Standard = 1
    Alpine = 2


class SubProcessBase(object):
    def __init__(self, root_helper=None, namespace=None, running_as_root=False):
        self.running_as_root = running_as_root
        self.root_helper = root_helper
        self.namespace = namespace
        self.force_root = FORCE_ROOT

    def _run(self, options, command, args):
        if self.namespace:
            return self._as_root(options, command, args)
        elif self.force_root:
            # Force use of the root helper to ensure that commands
            # will execute in dom0 when running under XenServer/XCP.
            return self._execute(options, command, args, self.root_helper)
        else:
            return self._execute(options, command, args)

    def _as_root(self, options, command, args, use_root_namespace=False):
        if not self.running_as_root and not self.root_helper:
            raise Exception("Sudo required")

        namespace = self.namespace if not use_root_namespace else None

        return self._execute(options,
                             command,
                             args,
                             self.root_helper,
                             namespace)

    @classmethod
    def _execute(cls, options, command, args, root_helper=None,
                 namespace=None):
        opt_list = ['-%s' % o for o in options]
        if namespace:
            ip_cmd = ['ip', 'netns', 'exec', namespace, 'ip']
        else:
            ip_cmd = ['ip']
        return check_output(ip_cmd + opt_list + [command] + list(args),
                            root_helper=root_helper)


class IPWrapper(SubProcessBase):
    ALPINE_RELEASE_FILE_PATH = "/etc/os-release"

    def __init__(self, root_helper=None, namespace=None, running_as_root=False):
        super(IPWrapper, self).__init__(root_helper=root_helper,
                                        namespace=namespace,
                                        running_as_root=running_as_root)
        self.linux_mode = IPWrapper._get_linux_mode()
        self.netns = IpNetnsCommand(self)

    @staticmethod
    def _get_linux_mode():
        try:
            if os.path.isfile(IPWrapper.ALPINE_RELEASE_FILE_PATH) and \
                    "ID=alpine" in open(IPWrapper.ALPINE_RELEASE_FILE_PATH, "r").read():
                return LinuxMode.Alpine
        except:
            pass
        return LinuxMode.Standard

    def device(self, name):
        return IPDevice(name, self.root_helper, self.namespace, self.running_as_root)

    def _get_ip_cmd_flags(self):
        if self.linux_mode == LinuxMode.Standard:
            return ["o", "d"]
        return ["o"]

    def get_devices(self, exclude_loopback=False):
        retval = []
        output = self._execute(self._get_ip_cmd_flags(), 'link', ('list',),
                               self.root_helper, self.namespace)
        for line in output.split('\n'):
            if '<' not in line:
                continue
            tokens = line.split(' ', 2)
            if len(tokens) == 3:
                if -1 != tokens[1].find('@'):
                    name = tokens[1].rpartition('@')[0].strip()
                else:
                    name = tokens[1].rpartition(':')[0].strip()

                if exclude_loopback and name == LOOPBACK_DEVNAME:
                    continue

                retval.append(IPDevice(name,
                                       self.root_helper,
                                       self.namespace,
                                       self.running_as_root,
                                       linux_mode=self.linux_mode))
        return retval

    def get_device_by_index(self, index):
        output = self._execute(self._get_ip_cmd_flags(), 'link', ('list',),
                               self.root_helper, self.namespace)
        filtered_lines = [line for line in output.split('\n') if '<' in line and int(line.split(':', 1)[0]) == index]
        if len(filtered_lines) != 1:
            return None
        index_line = filtered_lines[0]
        if '<' not in index_line:
            return None
        tokens = index_line.split(' ', 2)
        if len(tokens) == 3:
            if any(v in tokens[2] for v in VLAN_AND_TUN_INTERFACE_DETAIL):
                delimiter = '@'
            else:
                delimiter = ':'
            name = tokens[1].rpartition(delimiter)[0].strip()

            return IPDevice(name, self.root_helper, self.namespace)
        return None

    def get_ip_route(self, remote_ip):
        output = self._run('', 'route', ('get', remote_ip))
        line = output.split('\n')[0].strip()
        if 'dev' not in line:
            return None, None
        parts = line.split()
        current_part = 1
        if parts[current_part] != 'dev':
            current_part += 2
        connect_interface = parts[current_part + 1]
        current_part += 2
        if parts[current_part] != 'src':
            return None, None
        connect_ip = parts[current_part + 1]
        return connect_interface, connect_ip

    def add_tuntap(self, name, mode='tap'):
        self._as_root('', 'tuntap', ('add', name, 'mode', mode))
        return IPDevice(name, self.root_helper, self.namespace, self.running_as_root)

    def add_dummy(self, name):
        self._as_root('', 'link', ('add', name, 'type', 'dummy'))
        return IPDevice(name, self.root_helper, self.namespace, self.running_as_root)

    def add_veth(self, name1, name2, namespace2=None):
        args = ['add', name1, 'type', 'veth', 'peer', 'name', name2]

        if namespace2 is None:
            namespace2 = self.namespace
        else:
            self.ensure_namespace(namespace2)
            args += ['netns', namespace2]

        self._as_root('', 'link', tuple(args))

        return (IPDevice(name1, self.root_helper, self.namespace, self.running_as_root),
                IPDevice(name2, self.root_helper, namespace2, self.running_as_root))

    def ensure_namespace(self, name):
        if not self.netns.exists(name):
            ip = self.netns.add(name)
            lo = ip.device(LOOPBACK_DEVNAME)
            lo.link.set_up()
        else:
            ip = IPWrapper(self.root_helper, name, self.running_as_root)
        return ip

    def namespace_is_empty(self):
        return not self.get_devices(exclude_loopback=True)

    def garbage_collect_namespace(self):
        """Conditionally destroy the namespace if it is empty."""
        if self.namespace and self.netns.exists(self.namespace):
            if self.namespace_is_empty():
                self.netns.delete(self.namespace)
                return True
        return False

    def add_device_to_namespace(self, device):
        if self.namespace:
            device.link.set_netns(self.namespace)

    def add_vxlan(self, name, vni, group=None, remote=None, dev=None, ttl=None, tos=None,
                  local=None, port=None, proxy=False):
        cmd = ['add', name, 'type', 'vxlan', 'id', vni]
        if group:
            cmd.extend(['group', group])
        if remote:
            cmd.extend(['remote', remote])
        if dev:
            cmd.extend(['dev', dev])
        if ttl:
            cmd.extend(['ttl', ttl])
        if tos:
            cmd.extend(['tos', tos])
        if local:
            cmd.extend(['local', local])
        if proxy:
            cmd.append('proxy')
        # tuple: min,max
        if port and len(port) == 2:
            cmd.extend(['port', port[0], port[1]])
        elif port:
            raise Exception("Network Vxlan port range error (vxlan_range=%d)" % (port,))
        self._as_root('', 'link', cmd)
        return (IPDevice(name, self.root_helper, self.namespace, self.running_as_root))

    def add_gre(self, name, remote_ip, key=None):
        cmd = ['add', name, 'type', 'gretap', 'remote', remote_ip]

        if key is not None:
            cmd.extend(['key', key])
        self._as_root('', 'link', cmd)

        return IPDevice(name, self.root_helper, self.namespace, self.running_as_root)

    @classmethod
    def get_namespaces(cls, root_helper):
        output = cls._execute('', 'netns', ('list',), root_helper=root_helper)
        return [l.strip() for l in output.split('\n')]


class DeviceType(IntEnum):
    Loopback = 0
    Physical = 1
    Virtual = 2
    Bridge = 3
    OVSBrdige = 4
    Bonding = 5
    Unknown = 6


class IPDevice(SubProcessBase):
    def __init__(self, name, root_helper=None, namespace=None, running_as_root=False, linux_mode=LinuxMode.Standard):
        super(IPDevice, self).__init__(root_helper=root_helper,
                                       namespace=namespace,
                                       running_as_root=running_as_root)
        self.name = name
        self.linux_mode = linux_mode
        self.link = IpLinkCommand(self, linux_mode=linux_mode)
        self.addr = IpAddrCommand(self, linux_mode=linux_mode)
        self.route = IpRouteCommand(self, linux_mode=linux_mode)

    def __repr__(self):
        return "<IPDevice %s type=%s>" % (self.name, self.get_type().name)

    def get_type(self):
        device_class_dir_content = os.listdir(os.path.join("/sys/class/net", self.name))
        if "device" in device_class_dir_content:
            return DeviceType.Physical

        if "bridge" in device_class_dir_content:
            return DeviceType.Bridge

        if "bonding" in device_class_dir_content:
            return DeviceType.Bonding

        type_file_path = os.path.join("/sys/class/net", self.name, "type")

        if os.path.isfile(type_file_path) and 772 == int(open(type_file_path, "rb").read().strip()):
            return DeviceType.Loopback

        if self.name in os.listdir(os.path.join("/sys/devices/virtual/net")):
            return DeviceType.Virtual

        return DeviceType.Unknown

    def __eq__(self, other):
        return (other is not None and self.name == other.name
                and self.namespace == other.namespace)

    def __str__(self):
        return "name=%s, state=%s, " % (self.name, self.link.state)


class IpCommandBase(object):
    COMMAND = ''

    def __init__(self, parent, linux_mode=LinuxMode.Standard):
        self._parent = parent
        self.linux_mode = linux_mode

    def _run(self, *args, **kwargs):
        return self._parent._run(kwargs.get('options', []), self.COMMAND, args)

    def _as_root(self, *args, **kwargs):
        return self._parent._as_root(kwargs.get('options', []),
                                     self.COMMAND,
                                     args,
                                     kwargs.get('use_root_namespace', False))


class IpDeviceCommandBase(IpCommandBase):
    @property
    def name(self):
        return self._parent.name


class IpLinkCommand(IpDeviceCommandBase):
    COMMAND = 'link'

    def set_address(self, mac_address):
        self._as_root('set', self.name, 'address', mac_address)

    def set_mtu(self, mtu_size):
        self._as_root('set', self.name, 'mtu', mtu_size)

    def set_up(self):
        self._as_root('set', self.name, 'up')

    def set_down(self):
        self._as_root('set', self.name, 'down')

    def set_netns(self, namespace):
        self._as_root('set', self.name, 'netns', namespace)
        self._parent.namespace = namespace

    def set_name(self, name):
        self._as_root('set', self.name, 'name', name)
        self._parent.name = name

    def set_alias(self, alias_name):
        self._as_root('set', self.name, 'alias', alias_name)

    def delete(self):
        self._as_root('delete', self.name)

    @property
    def address(self):
        return self.attributes.get('link/ether')

    @property
    def state(self):
        return self.attributes.get('state')

    @property
    def mtu(self):
        return self.attributes.get('mtu')

    @property
    def qdisc(self):
        return self.attributes.get('qdisc')

    @property
    def qlen(self):
        return self.attributes.get('qlen')

    @property
    def alias(self):
        return self.attributes.get('alias')

    @property
    def remote(self):
        return self.attributes.get('remote')

    @property
    def type(self):
        return self.attributes.get('type')

    @property
    def index(self):
        return int(self.attributes.get('index'))

    @property
    def attributes(self):
        return self._parse_line(self._run('show', self.name,
                                          options='od' if self.linux_mode == LinuxMode.Standard else "o"))

    def _parse_line(self, value):
        if not value:
            return {}

        device_name, settings = value.replace("\\", '\n').split('>', 1)
        setting_lines = [line for line in settings.split('\n') if line]
        verbose_settings = setting_lines[-1].split()
        tokens = list(itertools.chain(*[line.split() for line in setting_lines[:-1]]))
        if len(setting_lines) > 2:
            device_type = verbose_settings[0]
            tokens.extend(verbose_settings[1:])
        else:
            device_type = 'physical'
            tokens.extend(verbose_settings)
        keys = tokens[::2]
        values = [int(v) if v.isdigit() else v for v in tokens[1::2]]

        retval = dict(zip(keys, values))
        retval['index'] = device_name.split(':', 1)[0]
        retval['type'] = device_type
        return retval


class IpAddrCommand(IpDeviceCommandBase):
    COMMAND = 'addr'

    def add(self, ip_version, cidr, broadcast, scope='global'):
        self._as_root('add',
                      cidr,
                      'brd',
                      broadcast,
                      'scope',
                      scope,
                      'dev',
                      self.name,
                      options=[ip_version])

    def delete(self, ip_version, cidr):
        self._as_root('del',
                      cidr,
                      'dev',
                      self.name,
                      options=[ip_version])

    def flush(self):
        self._as_root('flush', self.name)

    def list(self, scope=None, to=None, filters=None):
        if filters is None:
            filters = []

        retval = []

        if scope:
            filters += ['scope', scope]
        if to:
            filters += ['to', to]

        for line in self._run('show', self.name, *filters).split('\n'):
            line = line.strip()
            if not line.startswith('inet'):
                continue
            parts = line.split()
            if parts[0] == 'inet6':
                version = 6
                scope = parts[3]
                broadcast = '::'
            else:
                version = 4
                if parts[2] == 'brd':
                    broadcast = parts[3]
                    scope = parts[5]
                else:
                    # sometimes output of 'ip a' might look like:
                    # inet 192.168.100.100/24 scope global eth0
                    # and broadcast needs to be calculated from CIDR
                    broadcast = str(netaddr.IPNetwork(parts[1]).broadcast)
                    scope = parts[3]

            retval.append(dict(cidr=parts[1],
                               broadcast=broadcast,
                               scope=scope,
                               ip_version=version,
                               dynamic=('dynamic' == parts[-1])))
        return retval


class IpRouteCommand(IpDeviceCommandBase):
    COMMAND = 'route'

    def add_gateway(self, gateway, metric=None, table=None):
        args = ['replace', 'default', 'via', gateway]
        if metric:
            args += ['metric', metric]
        args += ['dev', self.name]
        if table:
            args += ['table', table]
        self._as_root(*args)

    def delete_gateway(self, gateway):
        self._as_root('del',
                      'default',
                      'via',
                      gateway,
                      'dev',
                      self.name)

    def list_onlink_routes(self):
        def iterate_routes():
            output = self._run('list', 'dev', self.name, 'scope', 'link')
            for line in output.split('\n'):
                line = line.strip()
                if line and not line.count('src'):
                    yield line

        return [x for x in iterate_routes()]

    def add_onlink_route(self, cidr):
        self._as_root('replace', cidr, 'dev', self.name, 'scope', 'link')

    def delete_onlink_route(self, cidr):
        self._as_root('del', cidr, 'dev', self.name, 'scope', 'link')

    def get_gateway(self, scope=None, filters=None):
        if filters is None:
            filters = []

        retval = None

        if scope:
            filters += ['scope', scope]

        route_list_lines = self._run('list', 'dev', self.name,
                                     *filters).split('\n')
        default_route_line = next((x.strip() for x in
                                   route_list_lines if
                                   x.strip().startswith('default')), None)
        if default_route_line:
            gateway_index = 2
            parts = default_route_line.split()
            retval = dict(gateway=parts[gateway_index])
            if 'metric' in parts:
                metric_index = parts.index('metric') + 1
                retval.update(metric=int(parts[metric_index]))

        return retval

    def pullup_route(self, interface_name):
        """Ensures that the route entry for the interface is before all
        others on the same subnet.
        """
        device_list = []
        device_route_list_lines = self._run('list', 'proto', 'kernel',
                                            'dev', interface_name).split('\n')
        for device_route_line in device_route_list_lines:
            try:
                subnet = device_route_line.split()[0]
            except Exception:
                continue
            subnet_route_list_lines = self._run('list', 'proto', 'kernel',
                                                'match', subnet).split('\n')
            for subnet_route_line in subnet_route_list_lines:
                i = iter(subnet_route_line.split())
                while i.next() != 'dev':
                    pass
                device = i.next()
                try:
                    while (i.next() != 'src'):
                        pass
                    src = i.next()
                except Exception:
                    src = ''
                if device != interface_name:
                    device_list.append((device, src))
                else:
                    break

            for (device, src) in device_list:
                self._as_root('del', subnet, 'dev', device)
                if src != '':
                    self._as_root('append', subnet, 'proto', 'kernel',
                                  'src', src, 'dev', device)
                else:
                    self._as_root('append', subnet, 'proto', 'kernel',
                                  'dev', device)

    def list_routes_raw(self, scope=None):
        filters = []

        if scope:
            filters += ['scope', scope]

        return self._run('list', 'dev', self.name, *filters).strip().split('\n')

    def add_route_raw(self, route):
        args = ['replace', ] + route.strip().strip().split() + ['dev', self.name]
        self._as_root(*args)

    def del_route_raw(self, route):
        args = ['del', ] + route.strip().strip().split() + ['dev', self.name]
        self._as_root(*args)

    def add_route(self, cidr, ip, table=None):
        args = ['replace', cidr, 'via', ip, 'dev', self.name]
        if table:
            args += ['table', table]
        self._as_root(*args)

    def delete_route(self, cidr, ip, table=None):
        args = ['del', cidr, 'via', ip, 'dev', self.name]
        if table:
            args += ['table', table]
        self._as_root(*args)


class IpNetnsCommand(IpCommandBase):
    COMMAND = 'netns'

    def add(self, name):
        self._as_root('add', name, use_root_namespace=True)
        return IPWrapper(self._parent.root_helper, name, running_as_root=self._parent.running_as_root)

    def delete(self, name):
        self._as_root('delete', name, use_root_namespace=True)

    def execute(self, cmds, addl_env=None, check_exit_code=True):
        if not self._parent.root_helper:
            raise Exception("Sudo required")
        elif not self._parent.namespace:
            raise Exception('No namespace defined for parent')
        else:
            env_params = []
            if addl_env:
                env_params = (['cloud_env'] +
                              ['%s=%s' % pair for pair in addl_env.items()])
            return check_output(
                ['ip', 'netns', 'exec', self._parent.namespace] +
                env_params + list(cmds),
                root_helper=self._parent.root_helper)

    def exists(self, name):
        output = self._as_root('list', options='o', use_root_namespace=True)

        for line in output.split('\n'):
            if name == line.strip():
                return True
        return False


class IpVeth(object):
    def __init__(self, veth1, veth2):
        self.veth1 = veth1
        self.veth2 = veth2

    def __repr__(self):
        return "<IpVeth veth1=%r veth2=%r>" % (self.veth1, self.veth2)

    def up(self):
        self.veth1.link.set_up()
        self.veth2.link.set_up()

    @staticmethod
    def ensure_cleanup(veth1_name, veth2_name, veth1_namespace=None, veth2_namespace=None, root_helper="sudo"):
        if device_exists(veth1_name, root_helper=root_helper, namespace=veth1_namespace):
            dev = IPDevice(veth1_name, root_helper=root_helper, namespace=veth1_namespace)
            dev.link.set_down()
            dev.link.delete()

        if device_exists(veth2_name, root_helper=root_helper, namespace=veth2_namespace):
            dev = IPDevice(veth2_name, root_helper=root_helper, namespace=veth2_namespace)
            dev.link.set_down()
            dev.link.delete()

    def delete(self):
        if device_exists(self.veth1.name, root_helper=self.veth1.root_helper):
            self.veth1.link.set_down()
            self.veth1.link.delete()

        if device_exists(self.veth2.name, root_helper=self.veth2.root_helper):
            self.veth1.link.set_down()
            self.veth1.link.delete()

    @property
    def name1(self):
        return self.veth1.name

    @property
    def name2(self):
        return self.veth2.name

    @property
    def namespace1(self):
        return self.veth1.namespace

    @property
    def namespace2(self):
        return self.veth2.namespace

    @staticmethod
    def create_veth(ipwrapper, name1, name2, namespace2=None):
        veth1, veth2 = ipwrapper.add_veth(name1=name1, name2=name2, namespace2=namespace2)
        return IpVeth(veth1=veth1, veth2=veth2)


def get_routing_table():
    routing_table = open("/proc/net/route", "rb").readlines()
    routing_table_header = routing_table[0].strip().split("\t")
    return map(lambda route: dict(zip(routing_table_header, route.strip().split("\t"))), routing_table[1:])


def get_default_gw_interface():
    routing_table = get_routing_table()
    gateway_interface = [route["Iface"] for route in routing_table if route["Destination"] == "00000000"]
    if 0 == len(gateway_interface):
        return None

    return gateway_interface[0]


def device_exists(device_name, root_helper=None, namespace=None):
    """Check if Ethernet device exists."""
    return check_call(['ip', 'link', 'show', 'dev', device_name], root_helper=root_helper)


def clear_arp_cache(root_helper=None):
    return check_call(["ip", "neigh", "flush", "all"], root_helper=root_helper)


def create_pair_of_veths(interface_name, peer_interface_name, mtu_size=None):
    """
    Create veth and its peer and bring the interfaces up.
    If mtu_size is given, set both mtu sizes to be the given size.

    :param interface_name: The veth name.
    :param peer_interface_name: The veth peer name.
    :param mtu_size: The requested mtu to set both interface to.
    :return:
    """
    ip = IPWrapper(running_as_root=True)

    # Check if device not exit.
    if not device_exists(interface_name):
        interface_dev, peer_dev = ip.add_veth(interface_name,
                                              peer_interface_name)

    # Check if its peer device exists. there is hidden assumption
    # here that the interfaces are infect peers. but this is strong enough for
    # our need.
    elif device_exists(peer_interface_name):
        interface_dev = ip.device(interface_name)
        peer_dev = ip.device(peer_interface_name)

    # One of them exists and the other don't. This is clearly not what the poet
    # intended (!) - (since they surly not peers!)
    else:
        raise RuntimeError("interface %s exists but %s don't" % (interface_name,
                                                                 peer_interface_name))

    if mtu_size:
        interface_dev.link.set_mtu(mtu_size)
        peer_dev.link.set_mtu(mtu_size)

    interface_dev.link.set_up()
    peer_dev.link.set_up()

    return interface_dev, peer_dev


def set_interface_offload(interface_name, tx_offload=False, rx_offlong=True, root_helper=None):
    return check_call(["ethtool", "--offload", interface_name,
                       "tx", "on" if tx_offload else "off",
                       "rx", "on" if rx_offlong else "off"],
                      root_helper=root_helper)


def change_default_keepalive_sysctl(tcp_keepalive_time, tcp_keepalive_intvl, tcp_keepalive_probes):
    config = [('/proc/sys/net/ipv4/tcp_keepalive_time', tcp_keepalive_time),
              ('/proc/sys/net/ipv4/tcp_keepalive_intvl', tcp_keepalive_intvl),
              ('/proc/sys/net/ipv4/tcp_keepalive_probes', tcp_keepalive_probes)]

    for conf_path, value in config:
        with open(conf_path, 'wb') as conf:
            conf.write(str(value))
