
import sys
import time
import eventlet
import traceback
from eventlet.semaphore import Semaphore
from enum import IntEnum
from common.logger import get_logger
from common.py.model.exceptions import ExceptionTimeout
from common.py.utils.eventlet import spawn_named

__author__ = 'itamar'

LOG = get_logger(module_name=__name__)


class JobState(IntEnum):
    Waiting = 0
    Running = 1
    Done = 2
    Error = 3


class JobPool(object):
    class _PassthroughSemaphore(object):
        def acquire(self):
            pass

        def release(self):
            pass

    def __init__(self, name=None, concurrent_runs=None, verbose=True):
        assert concurrent_runs is None or concurrent_runs > 0

        if not name:
            caller_code = getattr(sys._getframe(1), "f_code", None)
            name = "pool-unknown" if not caller_code else "pool-" + getattr(caller_code, "co_name", "unknown")

        self.name = name
        self.verbose = verbose
        self.spawns = []
        self.concurrent_semaphore = JobPool._PassthroughSemaphore() \
                                    if concurrent_runs is None \
                                    else Semaphore(value=concurrent_runs)
        self.done_jobs_queue = eventlet.queue.Queue()

        if self.verbose:
            LOG.debug("New job pool %s is created", self.name)

    def __repr__(self):
        return "<JobPool %s (%d jobs: %d live, %d waiting, %d done, %d error)>" \
               % (self.name, len(self.spawns), len(self.get_running_jobs()),
                  len(self.get_waiting_jobs()), len(self.get_done_jobs()),
                  len(self.get_error_jobs()))

    def __len__(self):
        return len(self.spawns)

    def spawn(self, context, func, *args, **kwargs):
        """spawn(context, func, *args, **kwargs) -> greenthread object

        Spawn a green thread with a given function entry for a given context.
        The context object is returned paired to this spawn for all other
        methods of the pool.
        """

        return self.spawn_named(context, None, func, *args, **kwargs)

    def spawn_named(self, context, name, func, *args, **kwargs):
        """spawn_named(self, context, name, func, *args, **kwargs) -> greenlet object

        Same as spawn() but you can pass name to the spawn.
        """

        def _spawn_wrapper(spawn_info):
            self.concurrent_semaphore.acquire()

            spawn_info['state'] = JobState.Running
            try:
                ret = spawn_info['func'](*spawn_info['args'],
                                         **spawn_info['kwargs'])

                spawn_info['state'] = JobState.Done

                return ret
            except:
                spawn_info['state'] = JobState.Error
                raise
            finally:
                self.done_jobs_queue.put(spawn_info)
                self.concurrent_semaphore.release()

        spawn_info = {'spawn': None,
                      'state': JobState.Waiting,
                      'context': context,
                      'func': func,
                      'args': args,
                      'kwargs': kwargs,
                      }

        if name:
            spawn_info['spawn'] = spawn_named(name, _spawn_wrapper, spawn_info)
        else:
            spawn_info['spawn'] = eventlet.spawn(_spawn_wrapper, spawn_info)

        self.spawns.append(spawn_info)

        return spawn_info['spawn']

    def cleanup(self, propagate_error=False):
        """cleanup(propagate_error=False)

        Wait over all spawns and raise exception or log errors according to
        propagate_error. In any case, when cleanup is returned, all spawns are
        waited on. First exception is raised and the rest are logged as
        warnings.
        """

        spawns, self.spawns = self.spawns[::], []

        for i in range(len(spawns)):
            spawn_info = spawns[i]

            # cancel waiting spawns
            if spawn_info['state'] in (JobState.Waiting, JobState.Running):
                spawn_info['spawn'].cancel()
                continue

            try:
                spawn_info['spawn'].wait()
            except Exception as exc:
                LOG.warn("Error in job pool %s during cleanup for %r (%s):\n%s",
                         self.name, spawn_info['context'], exc,
                         traceback.format_exc())

                if propagate_error:
                    # wait for the rest of the spawns in the pool
                    for j in range(i + 1, len(spawns)):
                        spawn_info = spawns[j]
                        try:
                            spawn_info['spawn'].wait()
                        except:
                            LOG.warn("Error in job pool %s during cleanup for %r (%s):\n%s",
                                     self.name, spawn_info['context'], exc,
                                     traceback.format_exc())

                    # propagate the exception
                    raise

    def is_empty(self):
        """is_empty() -> bool

        Return True if no spawns are left in the pool.
        """

        return 0 == len(self.spawns)

    def is_non_ready_jobs(self):
        """is_non_ready_jobs()

        Return True if there are non-ready jobs (either in running state or
        waiting to be running).
        """

        return 0 != len(self.get_jobs(JobState.Waiting, JobState.Running))

    def get_jobs(self, *job_states):
        """get_jobs(*job_states)

        Get all (context,spawn) pairs matching given states.
        """

        if not job_states:
            job_states = (JobState.Waiting, JobState.Done, JobState.Error,
                          JobState.Running)

        return [(spawn_info['context'], spawn_info['spawn'])
                for spawn_info in self.spawns
                if spawn_info['state'] in job_states]

    def get_waiting_jobs(self):
        """get_waiting_jobs()

        Get all (context,spawn) pairs matching waiting jobs (spawned but not
        yet executed).
        """
        return self.get_jobs(JobState.Waiting)

    def get_running_jobs(self):
        """get_running_jobs()

        Get all (context,spawn) pairs matching running jobs.
        """
        return self.get_jobs(JobState.Running)

    def get_error_jobs(self):
        """get_error_jobs()

        Get all (context,spawn) pairs matching jobs ended with an error.
        """
        return self.get_jobs(JobState.Error)

    def get_done_jobs(self):
        """get_done_jobs()

        Get all (context,spawn) pairs matching jobs which finished
        successfully.
        """
        return self.get_jobs(JobState.Done)

    def wait_next(self, block=True, timeout=None):
        """wait_next(block=True, timeout=None) -> (context, spawn)

        Wait for the next finished job spawn. If block is False, return None in
        case no jobs are done in the moment of calling this method. If block is
        True, block until another job is done. If timeout isn't None, and block
        is True, block for timeout seconds and raise ExceptionTimeout() in case
        no job is available after timeout seconds.
        """

        try:
            spawn_info = self.done_jobs_queue.get(block=block, timeout=timeout)
        except eventlet.queue.Empty:
            if block is False:
                return (None, None)

            raise ExceptionTimeout(timeout,
                                   "No job is done after timeout in pool %s",
                                   self.name)

        return spawn_info['context'], spawn_info['spawn']

    def wait_all(self, cleanup=False, propagate_error=False, propagate_break=False, timeout=None, silent_kill=False):
        """wait_all(self, cleanup=False, propagate_error=False,
                    propagate_break=False, timeout=None, silent_kill=False) -> list of (context, spawn) pairs

        Wait for all jobs in the pool to be over. If clean is True, wait on the
        jobs and raise/log the exceptions according to propagate_error. if silent_kill is True, don't report
        to logs when waiting breaks by an exception.
        """

        assert cleanup or not propagate_error, "propagate_error cannot be True when no cleanup is set"

        if self.verbose:
            LOG.debug("Waiting for job pool %s to finish (cleanup=%s, propagate_error=%s, propagate_break=%s,"
                      " timeout=%r)", self.name, cleanup, propagate_error, propagate_break, timeout)

        try:
            ready_spawns = set()
            start_time = time.time()
            while self.is_non_ready_jobs():
                if timeout is not None:
                    time_elapsed = time.time() - start_time
                    wait_next_timeout = max(0, timeout - time_elapsed)
                else:
                    wait_next_timeout = None

                ready_spawns.add(self.wait_next(timeout=wait_next_timeout))
        except KeyboardInterrupt:
            if silent_kill:
                return

            if self.verbose:
                LOG.warn("Keyboard interrupt while waiting on job pool %r", self)

            if propagate_break:
                running_jobs = self._raise_exception_in_running_jobs()
            else:
                running_jobs = self.get_running_jobs()

            if self.verbose:
                LOG.warn("Waiting jobs are: %r", self.get_waiting_jobs())
                LOG.warn("Running jobs are: %r", running_jobs)
            raise
        except ExceptionTimeout:
            if silent_kill:
                return

            if self.verbose:
                LOG.warn("Timeout while waiting on job pool %r", self.name)

            if propagate_break:
                running_jobs = self._raise_exception_in_running_jobs(exception_cls=ExceptionTimeout)
            else:
                running_jobs = self.get_running_jobs()

            if self.verbose:
                LOG.warn("Waiting jobs are: %r", self.get_waiting_jobs())
                LOG.warn("Running jobs are: %r", running_jobs)

            raise
        except Exception as exc:
            if self.verbose:
                LOG.warn("Exception while waiting on job pool %r: %s", self, exc)
                LOG.warn("Waiting jobs are: %r", self.get_waiting_jobs())
                LOG.warn("Running jobs are: %r", self.get_running_jobs())
            raise
        finally:
            if cleanup:
                try:
                    self.cleanup(propagate_error=propagate_error)
                except KeyboardInterrupt:
                    if propagate_break:
                        raise
                except Exception:
                    if propagate_error:
                        raise

        return ready_spawns

    def _raise_exception_in_running_jobs(self, exception_cls=KeyboardInterrupt,
                                         running_jobs=None):
        """_raise_exception_in_running_jobs(exception_cls=KeyboardInterrupt,
                                            running_jobs=None)

        Kill and raise exceptions in all running jobs.
        """

        if running_jobs is None:
            running_jobs = self.get_running_jobs()

        for context, spawn in running_jobs:
            try:
                spawn.kill(exception_cls)
            except (KeyboardInterrupt, SystemExit, Exception) as exc:
                if self.verbose:
                    LOG.warn("Spawn %s [%s] in pool %s received %s (%s):\n%s", spawn, context, self.name,
                             exc.__class__.__name__, exc, traceback.format_exc())

        return running_jobs