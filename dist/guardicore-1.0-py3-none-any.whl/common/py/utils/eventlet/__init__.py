from six import PY2
import eventlet
import eventlet.hubs
from eventlet.event import Event
from eventlet.green.threading import current_thread
from eventlet.greenpool import GreenPool

from common.logger import get_logger
from common.py.model.exceptions import GuardicoreException
from common.singleton import Singleton


LOG = get_logger(module_name=__name__)
VERBOSE = False


def spawn(func, *args, **kwargs):
    """spawn(func, *args, **kwargs) -> greenthread

    Spawn a regular green-thread
    """

    return eventlet.spawn(func, *args, **kwargs)


def _spawn_named_internal(name, spawn_func, func, *args, **kwargs):
    """_spawn_named_internal(name, spawn_func, func, *args, **kwargs) -> greenthread

    Spawn a green-thread and set its name before execution starts
    """

    def _bootstrap(name, func, args, kwargs):
        current_thread().setName(name)
        current = eventlet.getcurrent()
        current._name = name
        current._func = func

        try:
            # we print the id of current to get unique id for spawns executions
            if VERBOSE:
                LOG.debug("Start new named spawn: %s (%d)", name, id(current))
            return func(*args, **kwargs)
        finally:
            if VERBOSE:
                LOG.debug("Named spawn exit: %s (%d)", name, id(current))

    _bootstrap.__name__ = getattr(func, '__name__', _bootstrap.__name__)
    return spawn_func(_bootstrap, name, func, args, kwargs)


def _spawn_wait_named_internal(name, spawn_func, func, *args, **kwargs):
    """_spawn_wait_named_internal(name, spawn_func, func, *args, **kwargs) -> greenthread

    Spawn a green-thread with name sets and return only after spawn start its first execution.
    """

    def _bootstrap(name, ready_event, func, args, kwargs):
        current_thread().setName(name)
        current = eventlet.getcurrent()
        current._name = name
        current._func = func

        ready_event.send()

        try:
            # we print the id of current to get unique id for spawns executions
            if VERBOSE:
                LOG.debug("Start new named spawn: %s (%d)", name, id(current))
            return func(*args, **kwargs)
        finally:
            if VERBOSE:
                LOG.debug("Named spawn exit: %s (%d)", name, id(current))

    ready_event = Event()

    _bootstrap.__name__ = getattr(func, '__name__', _bootstrap.__name__)
    spawn_thread = spawn_func(_bootstrap, name, ready_event, func, args, kwargs)

    ready_event.wait()
    return spawn_thread


def spawn_named(name, func, *args, **kwargs):
    """spawn_named(name, func, *args, **kwargs) -> greenthread

    Spawn a green-thread and set its name before execution starts
    """

    return _spawn_named_internal(name, eventlet.spawn, func, *args, **kwargs)


def spawn_wait_named(name, func, *args, **kwargs):
    """spawn_wait_named(name, func, *args, **kwargs) -> greenthread

    Spawn a green-thread with name sets and return only after spawn start its first execution.
    """
    return _spawn_wait_named_internal(name, eventlet.spawn, func, *args, **kwargs)


class PoolSizeException(GuardicoreException):
    def __init__(self, *args):
        super(PoolSizeException, self).__init__("Failed to spawn new thread from GreenPool. Pool size exceeded", *args)


class NamedGreenPool(GreenPool):
    def spawn_wait_named(self, name, func, *args, **kwargs):
        if self.free() <= 0:
            raise PoolSizeException()

        return _spawn_wait_named_internal(name, self.spawn, func, *args, **kwargs)

    def spawn_named(self, name, func, *args, **kwargs):
        if self.free() <= 0:
            raise PoolSizeException()

        return _spawn_named_internal(name, self.spawn, func, *args, **kwargs)


class TimeoutEvent(Event):
    def wait(self, timeout=None):
        if timeout is not None:
            return eventlet.timeout.with_timeout(timeout, super(TimeoutEvent, self).wait)
        return super(TimeoutEvent, self).wait()
