from common.py.collection.control.client import EndpointDownError, ControlClientError
from common.py.collection.control.client.component_client import AggregatorComponentControlClient


class AgentsServerComponentControlClient(AggregatorComponentControlClient):
    def get_agent_info(self, agent_uuid):
        """get_agent_info(agent_uuid) -> dict

        Read information details for an agent.

        :param agent_uuid: UUID of the agent to read.
        :type agent_uuid: string
        :return dict
        """

        return self.call("/agents-server/agents/" + agent_uuid + "/info")

    def get_agent_age(self, agent_uuid):
        """get_agent_age(agent_uuid) -> float

        Get agent current age.

        :param agent_uuid: UUID of the agent to query.
        :type agent_uuid: string
        :return float
        """

        return self.call("/agents-server/agents/" + agent_uuid + "/age")

    def call_agent(self, agent_uuid, cmd, read_timeout=60.0, **kwargs):
        """call_agent(agent_uuid, cmd, **kwargs) -> dict

        Call a specific command in the agent and return its reply

        :param agent_uuid: UUID of the agent to call.
        :type agent_uuid: string
        :param cmd: name of the command to call.
        :type cmd: string
        :param read_timeout: Optional, timeout in seconds to wait for agent/server
        mutual response. Default is 60.0 seconds.
        :type read_timeout: float
        :param kwargs: Optional, arguments to pass to the call
        :type kwargs: dict
        :return dict
        """

        return self.call("/agents-server/agents/" + agent_uuid + "/call", method="POST",
                         json={'cmd': cmd, 'args': kwargs}, read_timeout=read_timeout)

    def kill_agent(self, agent_uuid):
        """kill_agent(agent_uuid)

        Kill an agent with a specific UUID

        :param agent_uuid: UUID of the agent to call.
        :type agent_uuid: string
        """

        return self.call("/agents-server/agents/" + agent_uuid + "/action", method="POST", json={'action': "kill"})

    def ping_agent(self, agent_uuid):
        """ping_agent(agent_uuid)

        Ping an agent with a specific UUID

        :param agent_uuid: UUID of the agent to call.
        :type agent_uuid: string
        """

        return self.call("/agents-server/agents/" + agent_uuid + "/action", method="POST", json={'action': "ping"})

    def get_state(self, **kwargs):
        """get_state(**kwargs) -> bool

        Get the agents server state

        :return True if enabled or False if disabled
        """

        return self.call("/agents-server/state", method="GET", **kwargs)

    def set_state(self, new_state, **kwargs):
        """set_state(new_state, **kwargs)

        Set the agents server state

        :param new_state: True to enable or False to disable the agents server
        """

        self.call("/agents-server/state", method="POST", json={'enable': new_state}, **kwargs)

    def list_agents(self):
        """list_agents() -> [dict, ...]

        List all agents currently active in the server.

        :return list of dicts
        """

        return self.call("/agents-server/agents/list", method="GET")

    def count_agents(self):
        """count_agents() -> int(agents)

        count all agents currently active in the server.

        :return int
        """
        try:
            return self.call("/agents-server/agents/count", method="GET")
        except (ControlClientError, EndpointDownError):
            return 0

    def get_agent_conf(self, agent_name, agent_type=None):
        if agent_type:
            return self.call("/agents-config/agents/{}/{}/config".format(agent_name, agent_type), method="GET")
        return self.call("/agents-config/agents/{}/config".format(agent_name), method="GET")

    def get_agent_profile(self, agent_name):
        return self.call("/agents-config/agents/{}/profile".format(agent_name))

    def get_profiles_list(self):
        return self.call("/agents-config/profiles/list")

    def get_profile_config(self, profile_name):
        return self.call("/agents-config/profile_config/{}".format(profile_name))

    def get_agents_with_profile(self, profile_name):
        return self.call("/agents-config/profile_agents/{}".format(profile_name))

    def get_machine_details(self):
        return self.call("/machine-details-plugin/recent_details")

    def get_agent_alive(self):
        return self.call("/agent-alive-plugin/recent_details")

    def get_single_agent_alive(self, uuid):
        return self.call("/agent-alive-plugin/agent_recent_details", json={"agent_uuid": uuid})

    def get_connections_history(self):
        return self.call("agents-server/connections_history", method="GET")

    def get_disconnection_ages_distributions(self):
        return self.call("agents-server/disconnections_age_distribution", method="GET")
