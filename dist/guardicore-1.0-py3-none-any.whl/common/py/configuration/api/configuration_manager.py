"""
Created on Jul 8, 2014

@author: itamar
"""
from six import add_metaclass
from common.singleton import Singleton
from common.py.configuration.api import ConfigInterface
from common.py.model.exceptions import MissingConfigException


@add_metaclass(Singleton)
class ConfigurationManager(ConfigInterface):
    """
    Memory stored non-persistent configuration
    """

    def __init__(self, clear_db=True):
        super(ConfigurationManager, self).__init__()
        
        self._config_records = {}
        self._state_record = None
        
    def write_config_records(self, **kwargs):
        super(ConfigurationManager, self).write_config_records(**kwargs)
        
        self._config_records.update(kwargs)

    def write_state_record(self, state):
        super(ConfigurationManager, self).write_state_record(state)

        self._state_record = state

    def read_config_records(self):
        return self._config_records

    def get_config_record(self, name):
        value = self._config_records.get(name, None)
        if value is None:
            raise MissingConfigException(name)
        return value

    def __getattr__(self, item):
        return self.get_config_record(item)

    def read_state_record(self):
        return self._state_record
