def split_by_condition(l, condition):
    match = []
    not_match = []

    for i in l:
        if condition(i):
            match.append(i)
        else:
            not_match.append(i)

    return match, not_match


def flatten_list(lst):
    output_lst = []
    for item in lst:
        if isinstance(item, list):
            output_lst += flatten_list(item)
        else:
            output_lst.append(item)
    return output_lst