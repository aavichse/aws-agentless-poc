from enum import Enum

import attr

from common.py.apis import ComponentType
from common.py.events.attrs import Dictable
from common.py.model.exceptions import GuardicoreException

DEFAULT_CLUSTER_ID = "default"
DEFAULT_ZOOKEEPER_ID = 0
INVALID_ZOOKEEPER_ID = -1
MAX_ZOOKEEPER_ID = 255

ENFORCEMENT_GRPC_SPECIAL_ID = "grpc"


class AggregatorComponent(Enum):
    Datapath = "datapath"
    Mitigation = "mitigation"
    RevealReporter = "reveal_reporter"
    PacketCapture = "packet_capture"
    GuestInstaller = "guest_installer"
    EnforcementServer = "enforcement"
    DetectionAgentsServer = "detection"
    ControllerServer = "controller"
    OrchestrationAdapter = "orchestration"
    ExporterAdapter = "exporter"
    ClusterManager = "cluster_mgr"
    NetworkDBSync = "network_db_sync"
    DebugSessionService = "debug_session_srv"
    GenericScript = "script"
    DCInventory = "datacenter_inventory"
    VpcFlowCollector = "vpc_flow_logs"
    IntegrationController = "integration_controller"
    ProxyServer = "proxy_server"


    @property
    def component_type(self):
        AGGREGATOR_COMPONENT_TO_COMPONENT_TYPE_MAPPING = {
            AggregatorComponent.Mitigation: ComponentType.MITIGATION_AGENT,
            AggregatorComponent.Datapath: ComponentType.DATAPATH,
            AggregatorComponent.EnforcementServer: ComponentType.ENFORCEMENT_SERVER,
            AggregatorComponent.DetectionAgentsServer: ComponentType.DETECTION_AGENTS_SERVER,
            AggregatorComponent.ControllerServer: ComponentType.CONTROLLER_SERVER,
            AggregatorComponent.ProxyServer: ComponentType.PROXY_SERVER
        }

        return AGGREGATOR_COMPONENT_TO_COMPONENT_TYPE_MAPPING.get(self, ComponentType.AGGREGATOR)


class AggregatorCategory(Enum):
    Aggregator = 1
    Collector = 2
    Other = 10


@attr.s(frozen=True)
class AggregatorType(Dictable):
    title = attr.ib()
    short_name = attr.ib()
    display_name = attr.ib()
    category = attr.ib()
    unique_features = attr.ib()
    is_available_in_wizard = attr.ib()
    config_component_name = attr.ib()


@attr.s(frozen=True)
class AggregatorFeature(Dictable):
    title = attr.ib()
    display_name = attr.ib()
    configuration_name = attr.ib()
    relevant_components = attr.ib()
    is_available_in_wizard = attr.ib()
    description = attr.ib(default="")
    help_msg = attr.ib(default=None)
    is_restart_needed = attr.ib(default=False)
    must_select = attr.ib(default=False)


class AggregatorFeatures(Enum):
    RevealAgentsServer = AggregatorFeature(title='RevealAgentsServer',
                                           display_name='Reveal Agents Server',
                                           configuration_name='reveal_agents_server',
                                           relevant_components=[AggregatorComponent.Mitigation,
                                                                AggregatorComponent.GuestInstaller],
                                           is_available_in_wizard=False,
                                           description="Support Reveal agents",
                                           help_msg="Support Reveal agents in the aggregator",
                                           is_restart_needed=True)

    DeceptionAgentsServer = AggregatorFeature(title='DeceptionAgentsServer',
                                              display_name='Deception Agents Server',
                                              configuration_name='deception_agents_server',
                                              relevant_components=[AggregatorComponent.Datapath,
                                                                   AggregatorComponent.GuestInstaller],
                                              is_available_in_wizard=False,
                                              description="Support Deception agents",
                                              help_msg="Support Deception agents in the aggregator",
                                              is_restart_needed=True)

    EnforcementAgentsServer = AggregatorFeature(title='EnforcementAgentsServer',
                                                display_name="Enforcement Agents Server",
                                                configuration_name="enforcement_agents_server",
                                                relevant_components=[AggregatorComponent.EnforcementServer,
                                                                     AggregatorComponent.GuestInstaller],
                                                is_available_in_wizard=False,
                                                description="Support Enforcement agents",
                                                help_msg="Support Enforcement agents in the aggregator",
                                                is_restart_needed=True)

    EnforcementGRPCAgentsServer = AggregatorFeature(title='EnforcementGRPCAgentsServer',
                                                    display_name="Enforcement gRPC Agents Server",
                                                    configuration_name="enforcement_grpc_agents_server",
                                                    relevant_components=[AggregatorComponent.EnforcementServer,
                                                                         AggregatorComponent.GuestInstaller],
                                                    is_available_in_wizard=False,
                                                    description="Support Enforcement gRPC agents",
                                                    help_msg="Support Enforcement gRPC agents in the aggregator",
                                                    is_restart_needed=True)

    DetectionAgentsServer = AggregatorFeature(title='DetectionAgentsServer',
                                              display_name="Detection Agents Server",
                                              configuration_name="detection_agents_server",
                                              relevant_components=[AggregatorComponent.DetectionAgentsServer,
                                                                   AggregatorComponent.GuestInstaller],
                                              is_available_in_wizard=False,
                                              description="Support Detection agents",
                                              help_msg="Support Detection agents in the aggregator",
                                              is_restart_needed=True)

    RevealDatapathVisibility = AggregatorFeature(title='RevealDatapathVisibility',
                                                 display_name="Reveal Datapath (Layer-4) Visibility",
                                                 configuration_name="reveal_datapath_visibility",
                                                 relevant_components=[AggregatorComponent.Datapath],
                                                 is_available_in_wizard=False,
                                                 description="Support Layer-4 visibility reporting",
                                                 help_msg="Support Layer-4 visibility reporting for collectors",
                                                 is_restart_needed=True)

    ClusterZooKeeper = AggregatorFeature(title='ClusterZooKeeper',
                                         display_name="Cluster ZooKeeper",
                                         configuration_name="cluster_zookeeper",
                                         relevant_components=[AggregatorComponent.ClusterManager],
                                         is_available_in_wizard=True,
                                         description="ZooKeeper quorum member",
                                         help_msg="Mark this aggregator as a permanent ZooKeeper quorum member")

    ClusterOrchestrationServicesHost = AggregatorFeature(title='ClusterOrchestrationServicesHost',
                                                         display_name="Cluster Orchestration Services Host",
                                                         configuration_name="cluster_orchestration",
                                                         relevant_components=[AggregatorComponent.ClusterManager],
                                                         is_available_in_wizard=True,
                                                         description="Orchestration services host",
                                                         help_msg="Mark this aggregator as a permanent Orchestration "
                                                                  "member, denouncing all unmarked peers")

    ClusterExporterServicesHost = AggregatorFeature(title='ClusterExporterServicesHost',
                                                    display_name="Cluster Exporter Services Host",
                                                    configuration_name="cluster_exporter",
                                                    relevant_components=[AggregatorComponent.ClusterManager],
                                                    is_available_in_wizard=True,
                                                    description="Exporters services host",
                                                    help_msg="Mark this aggregator as a permanent exporter member, "
                                                             "denouncing all unmarked peers")

    AgentsLoadBalancer = AggregatorFeature(title='AgentsLoadBalancer',
                                           display_name="Agents Load Balancer",
                                           configuration_name="agents_load_balancer",
                                           relevant_components=[AggregatorComponent.ClusterManager],
                                           is_available_in_wizard=False,
                                           description="load-sharing of agents between aggregators in the cluster",
                                           help_msg="Support load-sharing of agents between agents communicating with "
                                                    "this aggregator and other aggregators in the cluster")

    RevealIPFlowVisibility = AggregatorFeature(title='RevealIPFlowVisibility',
                                               display_name="Reveal IP flow (Layer-4) Visibility",
                                               configuration_name="reveal_ipflow_visibility",
                                               relevant_components=[],
                                               is_available_in_wizard=False,
                                               must_select=True,
                                               description="Report IP flow visibility",
                                               help_msg="Support reporting of IP flow visibility through this collector",
                                               is_restart_needed=True)

    IPFIXF5Support = AggregatorFeature(title='IPFIXF5Support',
                                       display_name="F5 support in IP flow (Layer-4) Visibility",
                                       configuration_name="reveal_ipfix_f5_support",
                                       relevant_components=[],
                                       is_available_in_wizard=False,
                                       description="Report F5 IPFIX visibility",
                                       help_msg="Support reporting of F5 IPFIX visibility through this collector",
                                       is_restart_needed=True)

    LegacyDeception = AggregatorFeature(title='LegacyDeception',
                                        display_name="Legacy Deception Support",
                                        configuration_name="legacy_deception",
                                        relevant_components=[],
                                        is_available_in_wizard=False,
                                        description="Old-Style deception used by collectors and aggregators "
                                                    "supporting pre v36 agents",
                                        help_msg="Old-Style deception used by collectors and aggregators "
                                                 "supporting pre v36 agents. This option can be changed only from "
                                                 "the Setup Wizard and must be coordinated between all cluster members")

    InventoryApiOrchestration = AggregatorFeature(title='InventoryApiOrchestration',
                                                  display_name="Inventory API Orchestration Support",
                                                  configuration_name="inventory_api_orchestration",
                                                  relevant_components=[AggregatorComponent.ClusterManager],
                                                  is_available_in_wizard=False,
                                                  description="Enable Inventory API orchestration."
                                                              " Will be enabled by cluster-mgr when Inventory API"
                                                              " orchestration is configured",
                                                  help_msg="Enable Inventory API orchestration. Will be enabled by "
                                                           "cluster-mgr when Inventory API orchestration is configured")

    RevealAS400Visibility = AggregatorFeature(title='RevealAS400Visibility',
                                              display_name="Reveal AS400 (Layer-4) Visibility",
                                              configuration_name="reveal_as400_visibility",
                                              relevant_components=[AggregatorComponent.ClusterManager,
                                                                   AggregatorComponent.Mitigation,
                                                                   AggregatorComponent.EnforcementServer,
                                                                   AggregatorComponent.DCInventory,
                                                                   AggregatorComponent.OrchestrationAdapter],
                                              is_available_in_wizard=True,
                                              description="Report AS400 (Layer-4) visibility",
                                              help_msg="Support reporting of AS400 visibility through this collector",
                                              is_restart_needed=True)

    IntegrationEnforcement = AggregatorFeature(title='IntegrationEnforcement',
                                                 display_name="Integration Enforcement Server",
                                                 configuration_name="integration_enforcement",
                                                 relevant_components=[AggregatorComponent.ClusterManager,
                                                                      AggregatorComponent.EnforcementServer,
                                                                      AggregatorComponent.DCInventory],
                                                 is_available_in_wizard=False,
                                                 description="Enforcement server for integration services",
                                                 help_msg="Support enforcement for integration services",
                                                 is_restart_needed=True)

    IntegrationController = AggregatorFeature(title='IntegrationController',
                                              display_name="Integration Controller",
                                              configuration_name="integration_controller",
                                              relevant_components=[AggregatorComponent.IntegrationController,
                                                                   AggregatorComponent.ClusterManager],
                                              is_available_in_wizard=False,
                                              description="Controller module for the integration service",
                                              help_msg="Support controller for integration service",
                                              is_restart_needed=True)

    ProxyServer = AggregatorFeature(title='ProxyServer',
                                    display_name="Proxy Server",
                                    configuration_name="proxy_server",
                                    relevant_components=[AggregatorComponent.ProxyServer,
                                                         AggregatorComponent.IntegrationController,
                                                         AggregatorComponent.ClusterManager],
                                    is_available_in_wizard=False,
                                    description="Data-proxy between an outside source and Centra",
                                    help_msg="Support communication for an outside source and Centra",
                                    is_restart_needed=True)


FEATURES_CONFIG_MAP = {}
for feature_name, feature_object in AggregatorFeatures.__members__.items():
    FEATURES_CONFIG_MAP[feature_object.value.configuration_name] = feature_object


def get_aggregator_feature_by_config_name(configuration_name):
    global FEATURES_CONFIG_MAP
    aggregator_feature = FEATURES_CONFIG_MAP.get(configuration_name, None)
    if aggregator_feature is None:
        raise GuardicoreException("Unknown configuration name for aggregator feature: %s", configuration_name)
    return aggregator_feature


BASIC_FEATURES = [
    AggregatorFeatures.ClusterZooKeeper,
    AggregatorFeatures.ClusterOrchestrationServicesHost,
    AggregatorFeatures.ClusterExporterServicesHost
]


class AggregatorTypes(Enum):
    # important note: any change to config_component_name must be reflected in
    # common/ansible/pull/config_skeleton/pull_config.sh on `component_mode_map`

    Aggregator = AggregatorType(
        title='Aggregator',
        short_name='Aggregator',
        display_name='Agents Aggregator',
        category=AggregatorCategory.Aggregator,
        is_available_in_wizard=True,
        unique_features=[AggregatorFeatures.RevealAgentsServer,
                         AggregatorFeatures.DeceptionAgentsServer,
                         AggregatorFeatures.EnforcementAgentsServer,
                         AggregatorFeatures.DetectionAgentsServer,
                         AggregatorFeatures.AgentsLoadBalancer,
                         AggregatorFeatures.LegacyDeception],
        config_component_name='aggregator'
    )

    EsxCollector = AggregatorType(
        title='EsxCollector',
        short_name='ESX',
        display_name='ESX Collector',
        category=AggregatorCategory.Collector,
        is_available_in_wizard=True,
        unique_features=[AggregatorFeatures.RevealDatapathVisibility,
                         AggregatorFeatures.LegacyDeception],
        config_component_name='esx_collector'
    )

    SpanCollector = AggregatorType(
        title='SpanCollector',
        short_name='Span',
        display_name='Span Collector',
        category=AggregatorCategory.Collector,
        is_available_in_wizard=True,
        unique_features=[AggregatorFeatures.RevealDatapathVisibility,
                         AggregatorFeatures.LegacyDeception],
        config_component_name='span_collector'
    )

    VpcFlowCollector = AggregatorType(
        title='VpcFlowCollector',
        short_name='AwsVPCFlows',
        display_name='AWS VPC Flow Logs Collector',
        category=AggregatorCategory.Collector,
        is_available_in_wizard=False,
        unique_features=[AggregatorFeatures.RevealDatapathVisibility],
        config_component_name='vpc_flow_collector'
    )

    IPFlowCollector = AggregatorType(
        title='IPFlowCollector',
        short_name='IPFlows',
        display_name='IP Flow Collector',
        category=AggregatorCategory.Collector,
        is_available_in_wizard=True,
        unique_features=[AggregatorFeatures.RevealIPFlowVisibility,
                         AggregatorFeatures.IPFIXF5Support],
        config_component_name='ipflow_collector'
    )

    AS400Collector = AggregatorType(
        title='AS400Collector',
        short_name='AS400',
        display_name='AS400 Collector',
        category=AggregatorCategory.Collector,
        is_available_in_wizard=True,
        unique_features=[AggregatorFeatures.RevealAgentsServer,
                         AggregatorFeatures.EnforcementAgentsServer],
        config_component_name='as400_collector'
    )

    CloudCollector = AggregatorType(
        title='CloudCollector',
        short_name='Cloud',
        display_name='Cloud Collector',
        category=AggregatorCategory.Collector,
        is_available_in_wizard=True,
        unique_features=[AggregatorFeatures.IntegrationController,
                         AggregatorFeatures.ProxyServer,
                         AggregatorFeatures.IntegrationEnforcement],
        config_component_name='cloud_collector'
    )

    PFCollector = AggregatorType(
        title='PFCollector',
        short_name='PF',
        display_name='PF Collector',
        category=AggregatorCategory.Collector,
        is_available_in_wizard=True,
        unique_features=[AggregatorFeatures.IntegrationController,
                         AggregatorFeatures.ProxyServer,
                         AggregatorFeatures.IntegrationEnforcement],
        config_component_name='pf_collector'
    )
