import ipaddress
from posixpath import normpath
import six
from mongoengine import IntField, StringField, EmbeddedDocument, BooleanField
from mongoengine.base import BaseField
from mongoengine.connection import get_db
from six import string_types

from common.logger import get_logger
from common.py.utils.consts import MAX_PORT_NUM

__author__ = 'Amit'

LOGGER = get_logger(module_name=__name__)

MONGO_MAX_INT_VALUE = 0x7FFFFFFFFFFFFFFF

# collation strength 2 performs comparisons up to secondary differences, such as diacritics.
DEFAULT_COLLATION = {'locale': 'en', 'strength': 2}


class PortField(IntField):
    def __init__(self, **kwargs):
        super(PortField, self).__init__(min_value=0, max_value=MAX_PORT_NUM, **kwargs)


class PortRange(EmbeddedDocument):
    start = PortField()
    end = PortField()

    def to_tuple(self):
        return self.start, self.end

    def to_dict(self):
        return {"start": self.start, "end": self.end}

    def __hash__(self):
        return hash((self.start, self.end))

class IPField(StringField):
    def __init__(self, *args, **kwargs):
        super(IPField, self).__init__(*args, **kwargs)

    def validate(self, value):
        try:
            ipaddress.ip_address(six.text_type(value))
        except ValueError as e:
            self.error('IPField only accepts IP Addresses: %s' % e)


class IPNetworkField(StringField):
    def __init__(self, *args, **kwargs):
        super(IPNetworkField, self).__init__(*args, **kwargs)

    def validate(self, value):
        if value == '':
            return
        try:
            ipaddress.ip_network(six.text_type(value))
        except ValueError as e:
            self.error('IPvNetwork only accepts IP Networks: %s' % e)


class EnumFieldType(BaseField):
    def __init__(self, enum_type, *args, **kwargs):
        super(EnumFieldType, self).__init__(*args, **kwargs)
        self.enum_type = enum_type

    def prepare_query_value(self, op, value):
        if value is None:
            return value
        if isinstance(value, self.enum_type):
            return value.value

    def to_mongo(self, value):
        if isinstance(value, self.enum_type):
            return value.value

    def to_python(self, value):
        try:
            # try to convert by enum value
            return self.enum_type(value)
        except ValueError:
            try:
                # try to convert by enum value name
                return self.enum_type[value]
            except KeyError:
                # incompatible value, just return it as is
                return value

    def validate(self, value):
        if not isinstance(value, self.enum_type):
            enum_name = self.enum_type.__name__
            enum_values = ['.'.join([enum_name, value]) for value in self.enum_type._member_names_]
            self.error('EnumField only accepts valid %s values: %s' % (enum_name, enum_values))


class EnumField(EnumFieldType, StringField):
    """
    A class for Enum fields. DB stores the value.
    """

    def __init__(self, *args, **kwargs):
        super(EnumField, self).__init__(*args, **kwargs)


class IntEnumField(EnumFieldType, IntField):
    """
    A class for IntEnum fields. DB stores the value.
    """

    def __init__(self, *args, **kwargs):
        super(IntEnumField, self).__init__(*args, **kwargs)


class StringBytesField(StringField):
    def prepare_query_value(self, op, value):
        if not isinstance(value, six.string_types):
            return super(StringBytesField, self).prepare_query_value(op, value.decode('utf8'))
        return super(StringBytesField, self).prepare_query_value(op, value)


class NullableStringField(StringField):
    """
    Variant of StringField that's allowed to be null (None).
    """

    def __init__(self, *args, **kwargs):
        super(NullableStringField, self).__init__(*args, null=True, **kwargs)

    def validate(self, value):
        if value is None:
            return

        super(NullableStringField, self).validate(value)


class CaseSensitiveString(EmbeddedDocument):
    meta = {'allow_inheritance': True}

    string = StringField(required=True)
    case_sensitive = BooleanField(required=True, default=True)

    def __init__(self, *args, **kwargs):
        self._auto_id_field = False
        super(CaseSensitiveString, self).__init__(*args, **kwargs)

        self.capitalize = self.string.capitalize
        self.center = self.string.center
        self.count = self.string.count
        self.expandtabs = self.string.expandtabs
        self.find = self.string.find
        self.format = self.string.format
        self.index = self.string.index
        self.isalnum = self.string.isalnum
        self.isalpha = self.string.isalpha
        self.isdigit = self.string.isdigit
        self.islower = self.string.islower
        self.isspace = self.string.isspace
        self.istitle = self.string.istitle
        self.isupper = self.string.isupper
        self.join = self.string.join
        self.ljust = self.string.ljust
        self.lower = self.string.lower
        self.lstrip = self.string.lstrip
        self.partition = self.string.partition
        self.replace = self.string.replace
        self.rfind = self.string.rfind
        self.rindex = self.string.rindex
        self.rjust = self.string.rjust
        self.rpartition = self.string.rpartition
        self.rsplit = self.string.rsplit
        self.rstrip = self.string.rstrip
        self.split = self.string.split
        self.splitlines = self.string.splitlines
        self.strip = self.string.strip
        self.swapcase = self.string.swapcase
        self.title = self.string.title
        self.upper = self.string.upper
        self.translate = self.string.translate
        self.zfill = self.string.zfill

    def __add__(self, y):
        return self.string.__add__(y)

    def __contains__(self, y):
        return self.string.__contains__(y)

    def __getitem__(self, y):
        return self.string.__getitem__(y)

    def __getslice__(self, i, j):
        return self.string.__getslice__(i, j)

    def __ge__(self, y):
        return self.string.__ge__(y)

    def __gt__(self, y):
        return self.string.__gt__(y)

    def __len__(self):
        return self.string.__len__()

    def __le__(self, y):
        return self.string.__le__(y)

    def __lt__(self, y):
        return str.__lt__(self.string, y.string)

    def __mod__(self, y):
        return self.string.__mod__(y)

    def __mul__(self, n):
        return self.string.__mul__(n)

    def __rmod__(self, y):
        return self.string.__rmod__(y)

    def __rmul__(self, n):
        return self.string.__rmul__(n)

    def __eq__(self, other):
        if isinstance(other, type(self)):
            if self.case_sensitive or other.case_sensitive:
                return self.string == other.string
            else:
                return self.string.lower() == other.string.lower()
        elif isinstance(other, string_types):
            if self.case_sensitive:
                return self.string == other
            else:
                return self.string.lower() == other.lower()

        return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        if self.case_sensitive:
            return hash((self.string, self.case_sensitive))
        else:
            return hash((self.string.lower(), self.case_sensitive))

    def __str__(self):
        return self.string

    def to_string(self):
        return self.string if self.case_sensitive else self.string.lower()

    def startswith(self, string, *args, **kwargs):
        if self.case_sensitive:
            return self.string.startswith(string, *args, **kwargs)
        else:
            return self.string.lower().startswith(string.lower(), *args, **kwargs)

    def endswith(self, string, *args, **kwargs):
        if self.case_sensitive:
            return self.string.endswith(string, *args, **kwargs)
        else:
            return self.string.lower().endswith(string.lower(), *args, **kwargs)


class Path(CaseSensitiveString):
    WINDOWS_INVALID_FILE_CHARS = ('\x00', '\x01', '\x02', '\x03', '\x04', '\x05', '\x06', '\x07', '\x08', '\t', '\n',
                                  '\x0b', '\x0c', '\r', '\x0e', '\x0f', '\x10', '\x11', '\x12', '\x13', '\x14', '\x15',
                                  '\x16', '\x17', '\x18', '\x19', '\x1a', '\x1b', '\x1c', '\x1d', '\x1e', '\x1f', '/',
                                  '*', '?', '"', '<', '>', '|')
    LINUX_INVALID_FILE_CHARS = ('\x00',)

    sep = StringField(required=True)  # path separator

    def basename(self):
        return self.string.rsplit(self.sep, 1)[-1]

    def dirname(self):
        if self.sep not in self.string or self.string.strip() == self.sep:
            return ''

        return self.string.rsplit(self.sep, 1)[0] or self.sep

    def dirname_path(self):
        dirname = self.dirname()
        if not dirname:
            return None

        return self.__class__(string=dirname, case_sensitive=self.case_sensitive, sep=self.sep)

    @classmethod
    def windows(cls, path):
        path = "".join([char for char in path if char not in cls.WINDOWS_INVALID_FILE_CHARS])
        return cls(string=path, case_sensitive=False, sep='\\')

    @classmethod
    def linux(cls, path):
        path = "".join([char for char in path if char not in cls.LINUX_INVALID_FILE_CHARS])
        return cls(string=path, case_sensitive=True, sep='/')

    @classmethod
    def windows_on_linux(cls, path):
        path = "".join([char for char in path if char not in cls.LINUX_INVALID_FILE_CHARS])
        return cls(string=path, case_sensitive=False, sep='/')

    @staticmethod
    def normalize_windows_path_name(path_name):
        if path_name.startswith("\\\\?\\"):  # Extended-length path
            return path_name[4:].lower()

        if path_name.startswith("\\??\\"):  # Native API: Ignore leading '\??\'
            path_name = path_name[4:]

        if path_name.lower().startswith("\\globalroot"):  # Native API: Ignore leading '\GlobalRoot'
            path_name = path_name[11:]

        if path_name.lower().startswith("\\systemroot"):  # Native API: Replace '\SystemRoot' with system root
            path_name = "c:\\windows" + path_name[11:]

        if path_name.lower().startswith("\\windows"):  # Native API: Replace '\Windows' with system root
            path_name = "c:\\windows" + path_name[8:]

        return path_name.lower()

    @staticmethod
    def normalize_linux_path_name(path_name):
        # Use posix's path normalization function
        normalized_path = normpath(path_name)

        # Remove double initial slash
        if normalized_path.startswith("//"):
            normalized_path = "/" + normalized_path[2:]

        return normalized_path

    def export(self):
        return {'path': self.string, 'sep': self.sep, 'case_sensitive': self.case_sensitive}


class Username(CaseSensitiveString):
    @classmethod
    def windows(cls, username):
        return cls(string=username, case_sensitive=False)

    @classmethod
    def linux(cls, username):
        return cls(string=username, case_sensitive=True)


def ensure_gridfs_indexes(file_field):
    db = get_db(file_field.db_alias)

    # To support GridFS: https://docs.mongodb.com/manual/core/gridfs/
    db["{}.chunks".format(file_field.collection_name)].create_index([('files_id', 1), ('n', 1)], unique=True)
    db["{}.files".format(file_field.collection_name)].create_index([('filename', 1), ('uploadDate', 1)])


def port_ranges_from_list(port_ranges):
    ranges = [PortRange(start=port_range['start'], end=port_range['end'])
              for port_range in port_ranges]
    return sorted(ranges, key=lambda pr: pr.start)
