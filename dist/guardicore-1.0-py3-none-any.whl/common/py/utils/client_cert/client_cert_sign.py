
import os
import six

from common.logger import get_logger
from werkzeug.exceptions import BadRequest

try:
    from eventlet.green import OpenSSL
except ImportError:
    import OpenSSL


LOG = get_logger(module_name=__name__)

CSR_VERIFICATION_EXT_OID = '1.3.6.1.4.1.311.20.2'
CSR_VERIFICATION_EXT_VALUE = 'gc-agent'


def load_certificate_file(cert_path):
    with open(cert_path) as f:
        cert_data = f.read()
        return OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, cert_data)


def load_private_key_file(key_path, passphrase=""):
    with open(key_path) as f:
        key_data = f.read()
        return OpenSSL.crypto.load_privatekey(OpenSSL.crypto.FILETYPE_PEM, key_data, passphrase.encode("ascii"))


def verify_csr_extension(req):
    crypto_obj = req.to_cryptography()
    special_extension_exists = False
    for extension in crypto_obj.extensions:
        if (extension.oid.dotted_string == CSR_VERIFICATION_EXT_OID and
                CSR_VERIFICATION_EXT_VALUE in str(extension.value.value)):
            special_extension_exists = True
            break

    if special_extension_exists is False:
        msg = "The certificate signing request is rejected due to missing keyUsage certificate extension"
        LOG.warning(msg)
        raise BadRequest(msg)


def sign_csr(req, ca_cert, ca_key, support_csr_verification=False, subject_cn_prefix=""):
    subject = req.get_subject()
    agent_cn = subject_cn_prefix + subject.CN
    LOG.debug("about to sign agent request: %s", agent_cn)
    # verify csr extension has special keyUsage, otherwise don't sign csr. See GC-57254
    if support_csr_verification:
        verify_csr_extension(req)

    if 64 < len(agent_cn):
        LOG.warn("Agent CN might be too long: %s (%d chars)", agent_cn, len(agent_cn))

    cert = OpenSSL.crypto.X509()
    cert.set_version(2)
    cert.set_serial_number(1)
    cert.gmtime_adj_notBefore(-14 * 24 * 60 * 60)
    cert.gmtime_adj_notAfter(2 * 365 * 24 * 60 * 60)
    cert.set_issuer(ca_cert.get_subject())
    cert.set_pubkey(req.get_pubkey())

    subject.CN = agent_cn
    cert.set_subject(subject)
    cert.sign(ca_key, "sha256")
    LOG.info("agent request signed successfully: %s", agent_cn)
    return OpenSSL.crypto.dump_certificate(OpenSSL.crypto.FILETYPE_PEM, cert)


def generate_new_client_credentials(ca_cert, ca_key):
    if six.PY2:
        client_id = os.urandom(8).encode("hex")
    else:
        client_id = os.urandom(8).hex()

    certificate_subject = dict(C="IL", ST="Israel", L="Tel Aviv", O="Guardicore", CN=client_id)
    pkey = OpenSSL.crypto.PKey()
    pkey.generate_key(OpenSSL.crypto.TYPE_RSA, 2048)
    req = OpenSSL.crypto.X509Req()
    subj = req.get_subject()

    for key, value in certificate_subject.items():
        setattr(subj, key, value)
    req.set_pubkey(pkey)
    req.sign(pkey, "sha256")
    cert = sign_csr(req, ca_cert, ca_key)
    key = OpenSSL.crypto.dump_privatekey(OpenSSL.crypto.FILETYPE_PEM, pkey)
    return cert, key
