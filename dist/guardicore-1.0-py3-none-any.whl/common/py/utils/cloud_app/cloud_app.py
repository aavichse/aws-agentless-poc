from enum import Enum

import attr

from common.py.utils.attr_base import AttrBase


class CloudAppOperationMode(Enum):
    REVEAL_ONLY = 'reveal'
    REVEAL_AND_ENFORCEMENT = 'reveal_and_enforcement'


class AzureCloudAppCoverageMode(Enum):
    SUBSCRIPTIONS = 'subscriptions'
    MANAGEMENT_GROUPS = 'management_groups'


class CloudAppType(Enum):
    AZURE = 'azure'

    @classmethod
    def values(cls):
        return [cls.AZURE.value]


@attr.s
class CloudAppSetupConfig(AttrBase):
    name = attr.ib(type=str)
    cloud_app_type = attr.ib(type=str)
    operation_mode = attr.ib(type=str)
    cluster_id = attr.ib(type=str)
    orchestration_id = attr.ib(type=str)

    @classmethod
    def from_dict(cls, data):
        return cls(**data)


@attr.s
class AzureCloudAppSetupConfig(CloudAppSetupConfig):
    manifest = attr.ib(type=dict)
    coverage_mode = attr.ib(type=str)
    auto_discover_subscriptions = attr.ib(type=bool)
    subscription_list = attr.ib(type=list, default=attr.Factory(list))
    management_group_list = attr.ib(type=list, default=attr.Factory(list))
    api_version = attr.ib(type=str, default='')

    @classmethod
    def from_dict(cls, data):
        return cls(**data)
