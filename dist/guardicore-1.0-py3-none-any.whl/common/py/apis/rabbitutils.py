import json
import zlib

import six

from common.logger import get_logger
from common.py.utils.encoding.json.json_convert import encode_objects, decode_objects

LOG = get_logger(module_name=__name__)

JSON_ENCODING = 'json'
PLAIN_ENCODING = 'plain'
COMPRESS_MIN_SIZE = 4096


class RabbitMsgJSONEncoder(json.JSONEncoder):
    def iterencode(self, o, *args, **kwargs):
        o = encode_objects(o)
        return super(RabbitMsgJSONEncoder, self).iterencode(o, *args, **kwargs)


class RabbitMsgJSONDecoder(json.JSONDecoder):
    def decode(self, obj, *args, **kwargs):
        obj = super(RabbitMsgJSONDecoder, self).decode(obj, *args, **kwargs)
        return decode_objects(obj)


def encode_compressed_by_size(body, encoding):
    encoded_message = encode_message(body, encoding)
    if len(encoded_message) > COMPRESS_MIN_SIZE:
        try:
            return zlib.compress(six.b(encoded_message)), True
        except Exception:
            LOG.exception("Failed compressing %d bytes of JSON: %s", len(encoded_message), body)
    return encoded_message, False


def encode_message(body, encoding):
    return {
        JSON_ENCODING: lambda: json.dumps(body, cls=RabbitMsgJSONEncoder),
        PLAIN_ENCODING: lambda: body,
    }.get(encoding)()


def _decode_message(body, encoding, compressed):
    body = body if six.PY3 else str(body)
    if compressed:
        body = zlib.decompress(body)
    return {
        JSON_ENCODING: lambda: json.loads(body, cls=RabbitMsgJSONDecoder),
        PLAIN_ENCODING: lambda: body,
    }.get(encoding)()


def decode_message(body, encoding=None, compressed=False):
    try:
        if encoding is not None:
            return _decode_message(body, encoding, compressed=compressed), encoding
        else:
            return _decode_message(body, JSON_ENCODING, compressed=compressed), JSON_ENCODING
    except Exception as exc:
        LOG.error("Error decoding %s message (%s):\n%r", encoding, exc, body)
        raise


def build_message_body(rpc_func_name, msg_encoding=JSON_ENCODING, **kwargs):
    """
    :return: (message_body, compressed) tuple
    """
    message_body = (rpc_func_name, kwargs)
    return encode_compressed_by_size(message_body, msg_encoding)
