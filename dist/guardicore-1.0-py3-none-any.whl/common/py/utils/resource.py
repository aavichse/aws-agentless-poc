import os
import re
import yaml
import json
import ast
import hashlib
from six import string_types

__author__ = 'Amit'

DEFAULT_RESOURCES_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../resources'))


RESOURCE_FILES_CACHE = {}


class ResourceError(Exception):
    pass

def get_file_digest_and_content(resources_file_path):
    if not os.path.isfile(resources_file_path):
        raise ResourceError('Resource file not found in path %s' % resources_file_path)

    with open(resources_file_path, 'rb') as f:
        hash_md5 = hashlib.md5()
        content = f.read()
        hash_md5.update(content)
        digest = hash_md5.hexdigest()
        return digest, content

def read_resource(resource_file_key, resource_key=None, resources_dir=DEFAULT_RESOURCES_DIR, ignore_cached_version=False):
    r"""
    Read a resource file \ a string resource from a resource file.
    :param resource_file_key: resource file key
    :param resource_key: resource key (in the resource file). If None - resource file content is returned.
    :param resources_dir: directory path from which to import the resources.
    :param ignore_cached_version : ignore version that was saved in cache.
           (unless hash digest did not change)
    :return: resource file context \ resource key content as read from file
    """
    if isinstance(resource_file_key, string_types):
        resource_file_key = [resource_file_key]

    resource_file_key_str = os.path.join(*resource_file_key)
    resources_file_path = os.path.join(resources_dir, '%s.yaml' % resource_file_key_str)

    if resource_file_key_str not in RESOURCE_FILES_CACHE:
        digest, content = get_file_digest_and_content(resources_file_path)
        RESOURCE_FILES_CACHE[resource_file_key_str] = (digest, yaml.safe_load(content.decode('utf-8')))
    else:
        if ignore_cached_version:
            # check digest changed before re-loading yaml
            digest, _ = RESOURCE_FILES_CACHE[resource_file_key_str]
            new_digest, content = get_file_digest_and_content(resources_file_path)
            if digest != new_digest:
                RESOURCE_FILES_CACHE[resource_file_key_str] = (new_digest, yaml.safe_load(content.decode('utf-8')))

    _, resource_file = RESOURCE_FILES_CACHE[resource_file_key_str]
    if not resource_file:
        raise ResourceError('Error loading resource file %s' % (resource_file,))

    if resource_key is None:
        return resource_file

    if resource_key not in resource_file:
        raise ResourceError('Resource %s was not found in resource file %s' % (resource_key, resource_file))
    return resource_file[resource_key]


def clear_resource_cache():
    """
    Clear the resource cache.
    """
    RESOURCE_FILES_CACHE.clear()


def format_template(template_string, template_args):
    # TODO: move to a more general place, allow escaping templates, verify all template args are properly replaced
    formatted_string = template_string
    if template_args is not None:
        for template_key, template_arg in template_args.items():
            formatted_string = formatted_string.replace('[%s]' % template_key, str(template_arg))

    return formatted_string


def template_parts(template_string, template_args):
    """
    >>> template_parts(
    ... 'This [word] [action] and [action2] of the {type:superlative,arg1:[val1],[arg2]:val2|[superlative] templating engine} of us.',
    ... {'word': 'is', 'action': '{test}, {test2}', 'action2': '{test3}', 'superlative': 'wonderful', 'val1': 'something', 'arg2': 'exciting'})
    [{'type': 'text', 'value': 'This '}, {'type': 'text', 'value': 'is'}, {'type': 'text', 'value': ' '}, \
{'type': 'expression', 'value': 'test'}, {'type': 'text', 'value': ', '}, \
{'type': 'expression', 'value': 'test2'}, {'type': 'text', 'value': ' and '}, \
{'type': 'expression', 'value': 'test3'}, {'type': 'text', 'value': ' of the '}, \
{'arg1': 'something', 'exciting': 'val2', 'type': 'superlative', 'value': 'wonderful templating engine'}, \
{'type': 'text', 'value': ' of us.'}]

    Note the reason for steps order is that if [values] are replaced first
    special characters such as '{', '}', '|' will cause problems and result
    in badly displayed strings.
    """
    # Step 1 - divide to parts
    # string_parts = re.split("({.*?})", template_string)

    def divide_into_parts(template_string):
        string_parts = split_dicts(template_string)
        parts = []
        for string_part in string_parts:
            if string_part.startswith('{') and string_part.endswith('}'):
                if '|' in string_part:
                    types_string, value = string_part[1:-1].split('|')
                    types = {'value': value}
                    types.update(dict(s.split(':', 1)[:2] for s in re.findall('(.+?:.+?)(?:,|$)', types_string)))
                    parts.append(types)
                    if types['type'] == 'dict':
                        types['value'] = json.dumps(ast.literal_eval(types['value']))
                else:
                    parts.append({'type': 'expression', 'value': string_part[1:-1]})
            elif string_part != '':
                parts.append({'type': 'text', 'value': string_part})

        return parts

    parts = divide_into_parts(template_string=template_string)

    # Step 2 - replace [values] in parts
    replaced_parts = []
    template_args = template_args if template_args else {}
    for part in parts:
        skip_appending = False
        for template_key, template_arg in template_args.items():
            brackets_template_key = '[%s]' % template_key

            # Only for simple [argument], not inside an expression
            if brackets_template_key == part.get('value', None) and part.get('type', None) == 'text' and \
                    isinstance(template_arg, string_types):
                template_arg_parts = divide_into_parts(template_arg)
                for template_arg_part in template_arg_parts:
                    template_arg_part = {key: value for key, value in template_arg_part.items()}
                    replaced_parts.append(template_arg_part)
                skip_appending = True
                break

            for key in part:
                part[key] = part[key].replace(brackets_template_key, str(template_arg))
                if brackets_template_key in key:
                    new_key = key.replace(brackets_template_key, str(template_arg))
                    part[new_key] = part.pop(key)
        if not skip_appending:
            replaced_parts.append(part)

    return replaced_parts


def deconstruct_template(template, arguments):
    """Transforms a template + arguments to a plain text string"""
    if arguments is not None:
        for template_key, template_arg in arguments.items():
            template = template.replace('[%s]' % template_key, str(template_arg))
    def handle_match(matchobj):
        g = matchobj.group(1)
        if '|' in g:
            return g[g.find('|')+1:]
        return g
    return re.sub('{(.*?)}', handle_match, template)


def split_dicts(args):
    parts = []
    temp = ''
    curly_counter = 0
    square_counter = 0
    for arg in args:
        if temp and '{' not in temp and ('{' == arg or '[' == arg):
            parts.append(temp)
            temp = ''
        if arg == '{':
            curly_counter += 1
        elif arg == '[':
            square_counter += 1
        elif curly_counter != 0 or square_counter != 0:
            if arg in ('}', ']'):
                if arg == ']':
                    square_counter -= 1
                else:
                    curly_counter -= 1
                if square_counter == 0 and curly_counter == 0:
                    parts.append(temp + arg)
                    temp = ''
                    continue
        temp += arg
    if temp:
        parts.append(temp)
    return parts


if __name__ == '__main__':
    import doctest
    doctest.testmod()
