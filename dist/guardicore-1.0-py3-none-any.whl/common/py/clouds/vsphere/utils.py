import time
from functools import wraps
from common.logger import get_logger

LOG = get_logger()


def reconnect_function(exceptions, reconnect=None, raise_others=False, max_retries=2, retry_timeout=10):
    """
    returns a reconnect_on_fault function with the relevant exceptions
    """
    def reconnect_on_fault(func):
        """
        Decorator for functions which access the vSphere API.
        Tries to reconnect on vSphere errors (e.g. session authentication timeout, etc).
        """

        @wraps(func)
        def decorated(client, *args, **kwargs):
            counter = 0

            while counter < max_retries:
                try:
                    return func(client, *args, **kwargs)
                except exceptions as e:
                    if counter == max_retries:
                        raise
                    counter += 1
                    LOG.warning("Could not connect due to exception: %s. Retrying %s/%s",
                                e, counter, max_retries)

                    if reconnect:
                        client.connect(reconnect=True)
                    else:
                        client.connect()
                    time.sleep(retry_timeout)
                except Exception as e:
                    if raise_others:
                        raise
                    counter += 1
                    time.sleep(retry_timeout)
                    LOG.warning('Failed to execute %s - got `%s`, Retrying %s/%s', func, e, counter, max_retries)

        return decorated
    return reconnect_on_fault
