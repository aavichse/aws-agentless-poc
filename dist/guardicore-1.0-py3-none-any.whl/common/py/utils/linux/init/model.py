from enum import Enum

from common.py.model.fastenum import IntEnum


class InitSystemType(IntEnum):
    SYSTEMD = 0
    SYSV = 1
    UPSATRT = 3
    UNKNOWN = 4


class InitServiceStatus(IntEnum):
    STARTING = 0
    RUNNING = 1
    STOPPED = 2
    FAIL_START = 3
    FAIL_STOP = 4
    NOT_FOUND = 5
    UNKNOWN = 6


class InitServiceEvent(IntEnum):
    START = 1
    STOP = 2


class UpstartJobState(Enum):
    """
    From http://upstart.ubuntu.com/cookbook/#job-states
    """

    #  initial state
    WAITING = 'waiting'
    # job is about to start
    STARTING = 'starting'
    # job is having its AppArmor security policy loaded
    SECURITY = 'security'
    # running pre-start section
    PRE_START = 'pre-start'
    # about to run script or exec section
    SPAWNED = 'spawned'
    #  running post-start section
    POST_START = 'post-start'
    #  interim state set after post-start section processed denoting job is running
    RUNNING = 'running'
    #  running pre-stop section
    PRE_STOP = 'pre-stop'
    # interim state set after pre-stop section processed.
    STOPPING = 'stopping'
    # job is about to be stopped
    KILLED = 'killed'
    #  running post-stop section
    POST_STOP = 'post-stop'

    def __str__(self):
        return self.value

    @staticmethod
    def from_str(state):
        return UPSATRT_STATE_MAP.get(state)


UPSATRT_STATE_MAP = {str(state): state for state in UpstartJobState}


class SystemdUnitActiveState(Enum):
    """
    ActiveState contains a state value that reflects whether the unit is currently active or not
    From https://www.freedesktop.org/wiki/Software/systemd/dbus
    """

    # unit is active
    ACTIVE = 'active'
    # unit is active and currently reloading its configuration
    RELOADING = 'reloading'
    # unit is inactive
    INACTIVE = 'inactive'
    # unit is inactive and the previous run was not successful
    FAILED = 'failed'
    # unit has previously been inactive but is currently in the process of entering an active state
    ACTIVATING = 'activating'
    # unit is currently in the process of deactivation
    DEACTIVATING = 'deactivating'

    def __str__(self):
        return self.value

    @staticmethod
    def from_str(state):
        return SYSYEMD_ACTIVE_STATE_MAP.get(state)


SYSYEMD_ACTIVE_STATE_MAP = {str(state): state for state in SystemdUnitActiveState}


class SystemdServiceUnitSubState(Enum):
    """
    SubState encodes fine-grained states that are unit-type-specific

    systemctl --state=help
      -> Available service unit substates
    """

    DEAD = 'dead'
    PRE_START = 'start-pre'
    START = 'start'
    POST_START = 'start-post'
    RUNNING = 'running'
    EXITED = 'exited'
    RELOAD = 'reload'
    STOP = 'stop'
    STOP_SIGABRT = 'stop-sigabrt'
    STOP_SIGTERM = 'stop-sigterm'
    STOP_SIGKILL = 'stop-sigkill'
    POST_STOP = 'stop-post'
    FINAL_SIGTERM = 'final-sigterm'
    FINAL_SIGKILL = 'final-sigkill'
    FAILED = 'failed'
    AUTO_RESTART = 'auto-restart'

    def __str__(self):
        return self.value

    @staticmethod
    def from_str(state):
        return SYSYEMD_SERVICE_SUB_STATE_MAP.get(state)


SYSYEMD_SERVICE_SUB_STATE_MAP = {str(state): state for state in SystemdServiceUnitSubState}


class SystemdJobMode(Enum):
    """
    When queuing a new job, this option controls how to deal with already queued jobs
    From https://www.freedesktop.org/software/systemd/man/systemctl.html#--job-mode=
    """

    # if a requested operation conflicts with a pending job it cause the operation to fail
    FAIL = 'fail'
    # if a requested operation conflicts with a pending job, any conflicting pending job will be replaced
    REPLACE = 'replace'
    # operate like "replace", but also mark the new jobs as irreversible
    # This prevents future conflicting transactions from replacing these jobs
    REPLACE_IRREVERSIBLY = 'replace-irreversibly'
    # only valid for start operations and causes all other units to be stopped when the specified unit is started
    ISOLATE = 'isolate'
    # will cause all queued jobs to be canceled when the new job is enqueued
    FLUSH = 'flush'
    # then all unit dependencies are ignored for this new job and the operation is executed immediately
    IGNORE_DEPENDENCIES = 'ignore-dependencies'
    # is similar to "ignore-dependencies", but only causes the requirement dependencies to be ignored
    # the ordering dependencies will still be honored
    IGNORE_REQUIREMENTS = 'ignore-requirements'

    def __str__(self):
        return self.value
