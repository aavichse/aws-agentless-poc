import inspect
import sys

from common.py.utils.gc_named_lock import gc_named_lock


class Singleton(type):
    _singletons = {}

    def __call__(cls, *args, **kwargs):
        if not getattr(cls, "_instances", None):
            cls._instances = {}

        key = Singleton._make_key(cls)
        if key not in cls._instances:
            with gc_named_lock(key):
                if key not in cls._instances:
                    instance = super(Singleton, cls).__call__(*args, **kwargs)
                    Singleton._singletons[key] = cls._instances[key] = instance

        if '_singleton_instance_args' in vars(cls._instances[key]):
            singlton_instance_args = getattr(cls._instances[key], '_singleton_instance_args', None)
            if singlton_instance_args is not None:
                singlton_instance_args.append(dict(args=args, kwargs=kwargs))

        return cls._instances[key]

    @staticmethod
    def get_instance_by_key(key):
        return Singleton._singletons.get(key)
    
    @staticmethod
    def list_active_singletons():
        return list(Singleton._singletons.values())

    @staticmethod
    def is_singleton_instance_created(cls):
        key = Singleton._make_key(cls)

        return key in Singleton._singletons
    
    @staticmethod
    def get_singleton_instance(cls):
        key = Singleton._make_key(cls)

        if key not in Singleton._singletons:
            raise KeyError("Class %s not found in active singletons list" % (cls, ))

        return Singleton._singletons[key]
    
    @staticmethod
    def reset_singleton(cls):
        cls._instances = {}
        
        key = Singleton._make_key(cls)
        return Singleton._singletons.pop(key, None)
    
    @staticmethod
    def reset_all_singletons(excludes=None):
        if excludes is None:
            excludes = []

        if type(excludes) not in (list, tuple):
            raise TypeError("Invalid type for excludes list, should be either list to tuple")
        
        # iterate all non-excluded active instances
        for cls_name, cls, instance in [(cls_name, instance.__class__, instance)
                                        for cls_name, instance in Singleton._singletons.items()
                                        if all([not isinstance(instance, exclude) for exclude in excludes])]:
            if not getattr(instance, "_instances", None):
                raise Exception("FATAL: singleton class %r without _instances" % (cls_name, ))
            
            # reset instance singleton
            cls._instances = {}
        
        Singleton._singletons = {}
    
    @staticmethod
    def _make_key(cls):
        try:
            return "%s.%s" % (inspect.getmodule(cls).__name__, cls.__name__)
        except TypeError:
            # This is probably because the class wasn't defined in a file (maybe in interpreter shell?)
            if not hasattr(sys.modules.get(cls.__module__), __file__):
                # Fallback to class name key only
                return cls.__name__
            raise
    
    instance = __call__
