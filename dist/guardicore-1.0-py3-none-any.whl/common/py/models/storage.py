import hashlib
import os
import subprocess
import uuid
import json
import shutil
from functools import wraps

from collections import defaultdict

import mongoengine.connection
import six
from mongoengine import StringField, FileField, UUIDField, DictField, EmbeddedDocumentField, IntField
from mongoengine.connection import get_db
from mongoengine.context_managers import switch_db

from common.gc_document import GCDynamicDocument
from common.py.model.system import OperatingSystem, FsEntityType
from common.logger import get_logger, PasswordMaskingFormatter
from enum import Enum
from common.py.utils.config import cfg
from common.py.utils.mongo import IntEnumField, Path
from common.py.utils.hash import get_hash

# You should thank MongoEngine team for this (MongoEngineConnectionError -> ConnectionFailure in 0.19.0)
try:
    from mongoengine import ConnectionFailure as MongoEngineConnectionError
except:
    from mongoengine import MongoEngineConnectionError

__author__ = 'Lior'

mongodb_opts = [
    cfg.IntOpt('repair_db_min_file_size',
               default=2 ** 30,  # 4 GB
               required=True,
               help='Minimal DB file size for db repair operations'),
    cfg.FloatOpt('repair_db_max_used_fraction',
                 default=0.2,  # 2 GB
                 required=True,
                 help='Maximal used fraction (data size / DB size) for db repair operations')
]

cfg.CONF.register_opts(mongodb_opts, "mongodb")

DEFAULT_CONTENT_TYPE = 'application/octet-stream'
DEFAULT_REPLICA_LOCATION = '/tmp/replica'
DEFAULT_MONGODUMP_LIMIT = 1000

LOCAL_STORAGE_DB_NAME = 'guardicore_local_storage'
REPLICATED_STORAGE_DB_NAME = 'guardicore_replicated_storage'

AUTH_DB = 'admin'

LOGGER = get_logger()


class StorageException(Exception):
    pass


class StorageStatus(Enum):
    OK = 'ok'
    DO_REPAIR = 'needs repairing'
    REPAIR_LOW_DISK_SPACE = 'needs repairing, but disk space is too low'


def assert_connected(f):
    @wraps(f)
    def wrapper(self, *args, **kwargs):
        if self.connection is None:
            raise StorageException("PersistentStorage not connected; connect before performing operations")
        return f(self, *args, **kwargs)

    return wrapper


def alias_db(document_class):
    def decorator(f):
        @wraps(f)
        def decorated(self, *args, **kwargs):
            alias = kwargs.pop('alias', mongoengine.DEFAULT_CONNECTION_NAME)

            alias_with_id = self.get_unique_alias(alias)
            if alias_with_id not in self.aliases:
                raise StorageException('Unregistered alias \'%s\' used' % alias)

            with switch_db(document_class, alias_with_id):
                return f(self, *args, alias=alias, **kwargs)

        return decorated

    return decorator


def alias_file_db():
    def decorator(f):
        @wraps(f)
        def decorated(self, *args, **kwargs):
            alias = kwargs.pop('alias', mongoengine.DEFAULT_CONNECTION_NAME)
            document_class = self.get_document_class(alias)

            return f(self, *args, alias=alias, document_class=document_class, **kwargs)

        return decorated

    return decorator


class FileAbstract(GCDynamicDocument):
    meta = {
        'indexes': ['file'],
        'abstract': True
    }

    file_id = UUIDField(required=True, default=uuid.uuid4, primary_key=True)
    file_name = StringField(required=True)
    content_type = StringField(required=False)
    file = FileField(required=False)
    metadata = DictField(required=False)

    def set_content(self, file_obj, deduplicate=False):
        """
        Set the file content given file_obj (string or file-like object).
        If an identical gridfs file already exists (by md5 hash and content type),
        the file is attached to the existing file to prevent duplicated content.
        """
        self.file.put(file_obj)

    def delete_content(self):
        """
        Delete the file content. Only deletes the actual gridfs file from the DB if no other file points to it.
        :return:
        """
        if self.__class__.objects(file=self.file.grid_id).count() == 1:
            # only delete the GridFS file if no other files point to it
            self.file.delete()

        self.file = None

    def replace_content(self, gridfs_file):
        self.delete_content()
        self.file.get(gridfs_file._id)


class FileLocalHoneypot(FileAbstract):
    pass


class FileRepMgmt(FileAbstract):
    pass


class SPDisk(GCDynamicDocument):
    id = StringField(required=True, primary_key=True, default=lambda: str(uuid.uuid4()))
    path = StringField(required=True)
    os = IntEnumField(enum_type=OperatingSystem, required=True)
    hash = StringField(required=True)


class SPFile(GCDynamicDocument):
    meta = {'indexes': ['search_path', 'hash', 'disk_id']}

    path = EmbeddedDocumentField(Path, required=True)
    search_path = StringField(required=True)  # Used for lookup -- populated in __init__
    entity_type = IntEnumField(enum_type=FsEntityType, required=True)
    size = IntField(required=True)
    hash = StringField(required=True)

    disk_id = StringField()
    stat = DictField()

    def __init__(self, path, search_path=None, *args, **kwargs):
        super(SPFile, self).__init__(path=path, search_path=search_path or path.to_string(), *args, **kwargs)

    @staticmethod
    def prepare_query(path=None, **query):
        if path is not None:
            query['search_path'] = path.to_string()
        return query


class PersistentStorageMetaclass(type):
    _connections = {}

    def _check_mongoengine_default_connection(cls, persistent_storage):
        try:
            mongoengine.connection.get_connection()
        except MongoEngineConnectionError:
            # hack; mongoengine must have a default connection (even though we don't need one)
            mongoengine.register_connection(name=persistent_storage.default_db,
                                            alias=mongoengine.DEFAULT_CONNECTION_NAME,
                                            **persistent_storage.connection_args)

    def __call__(cls, default_db, replica_set_name=None, aliases=None, hosts=None, port=27017,
                 authentication_enabled=False, authentication_source=AUTH_DB, user=None, password=None,
                 ssl=False, ssl_client_cert_path=None, ssl_ca_cert_path=None,
                 ssl_match_hostname=False, has_admin_privileges=False, is_mock=False):
        if not hosts:
            hosts = [os.environ.get("UT_MONGO_HOST") or '127.0.0.1']
        hosts_str = ','.join(hosts)
        if (hosts_str, port) not in cls._connections:
            p = super(PersistentStorageMetaclass, cls).__call__(default_db=default_db,
                                                                replica_set_name=replica_set_name,
                                                                aliases=aliases,
                                                                hosts=hosts,
                                                                port=port,
                                                                authentication_enabled=authentication_enabled,
                                                                authentication_source=authentication_source,
                                                                user=user,
                                                                password=password,
                                                                ssl=ssl,
                                                                ssl_client_cert_path=ssl_client_cert_path,
                                                                ssl_ca_cert_path=ssl_ca_cert_path,
                                                                ssl_match_hostname=ssl_match_hostname,
                                                                has_admin_privileges=has_admin_privileges,
                                                                is_mock=is_mock)
            p.connect()
            cls._connections[(hosts_str, port)] = p
            cls._check_mongoengine_default_connection(p)
            return p

        # connection already exists
        p = cls._connections[(hosts_str, port)]
        if p.default_db != default_db:
            p.default_db = default_db

        if aliases is not None:
            for alias_name, db_name in aliases.items():
                p.register_alias(alias_name, db_name)

        return p


@six.add_metaclass(PersistentStorageMetaclass)
class PersistentStorage(object):
    def __init__(self, default_db, replica_set_name=None, aliases=None, hosts=None, port=27017,
                 authentication_enabled=False, authentication_source=AUTH_DB, user=None, password=None, ssl=False,
                 ssl_client_cert_path=None, ssl_ca_cert_path=None, ssl_match_hostname=False,
                 has_admin_privileges=False, is_mock=False):
        """
        :param default_db: default db name
        :param replica_set_name: Name of the replica set. None if no replica set.
        :param aliases: dict of {alias_name: db_name} for each alternative db on the connection.
            The aliases can later be used on any file method on the storage, by passing alias=<alias> as an argument.
            As a result, the file operations will be executed on the db pointed to by the given alias (as
            registered on __init__).
        :param port: port to connect to the db
        :param authentication_enabled: True to enable mongodb authentication
        :param authentication_source: is authentication is enabled, authentication users info is taken from this db
        :param user: if authentication is enabled, username used for authentication
        :param password: if authentication is enabled, password used for authentication
        :param ssl: if True, use tls connection to mongodb server
        """
        self.default_db = default_db
        self.replica_set_name = replica_set_name
        self.hosts = hosts if hosts else ['127.0.0.1']
        self.port = port
        self.auth_enabled = authentication_enabled
        self.authentication_source = authentication_source
        self.user = user
        self.password = password
        self.ssl = ssl
        self.ssl_client_cert_path = ssl_client_cert_path
        self.ssl_ca_cert_path = ssl_ca_cert_path
        self.ssl_match_hostname = ssl_match_hostname

        host_uri = self.get_host_uri(hosts=hosts, port=port, authentication_enabled=authentication_enabled,
                                     authentication_source=authentication_source, user=user, password=password,
                                     default_db=default_db)

        self.connection_args = dict(host=host_uri,
                                    port=port,
                                    ssl=ssl,
                                    is_mock=is_mock)

        if self.auth_enabled:
            self.connection_args.update(dict(username=self.user,
                                             password=self.password,
                                             authentication_source=authentication_source))

        if ssl:
            self.connection_args.update(dict(ssl=True,
                                             ssl_certfile=ssl_client_cert_path,
                                             ssl_ca_certs=ssl_ca_cert_path,
                                             ssl_match_hostname=ssl_match_hostname))

        self.connection = None
        self.aliases = {}

        self._has_admin_privileges = has_admin_privileges

        self.register_alias(mongoengine.DEFAULT_CONNECTION_NAME, self.default_db)
        if aliases is not None:
            for alias_name, db_name in aliases.items():
                self.register_alias(alias_name, db_name)

    @staticmethod
    def get_host_uri(hosts=None, port=27017, authentication_enabled=False,
                     authentication_source=AUTH_DB, user=None, password=None, default_db=None):
        if not hosts:
            hosts = ['127.0.0.1']

        # TODO - this won't work with HPVM - we don't support HPVM with an active replica set
        if authentication_enabled:
            uri_format = "mongodb://{user}:{password}@{hosts}/?authSource={authentication_source}"
        else:
            uri_format = "mongodb://{hosts}/{default_db}"

        hosts = ','.join(['{}:{}'.format(host, port) for host in hosts])
        host_uri = uri_format.format(user=user,
                                     password=password,
                                     hosts=hosts,
                                     port=port,
                                     authentication_source=authentication_source,
                                     default_db=default_db)

        return host_uri

    def get_document_class(self, alias):
        alias_with_id = self.get_unique_alias(alias)
        db_name = self.aliases[alias_with_id]

        if self.user == 'gc_hpvm':
            document_class = FileLocalHoneypot if db_name == LOCAL_STORAGE_DB_NAME else FileRepMgmt
        elif self.user in ['root', 'gc_mgmt']:
            document_class = FileRepMgmt
        else:
            raise StorageException('Unexpected username %s' % (self.user,))

        document_class.db_alias = alias_with_id
        if alias_with_id not in self.aliases:
            raise StorageException('Unregistered alias \'%s\' used' % alias)
        document_class._meta["db_alias"] = alias_with_id

        return document_class

    def get_unique_alias(self, alias):
        """
        Add unique connection id (id(self)) to the alias, to prevent alias collision between
        different connectiosn.
        :param alias: original alias name
        :return: new alias name
        """
        return alias + "_" + str(id(self))

    def connect(self):
        """
        Connect to mongodb instance.
        :return: None
        """
        self.connection = mongoengine.connect(alias=self.get_unique_alias(mongoengine.DEFAULT_CONNECTION_NAME),
                                              # due to a bug in mongoenine, have to provide connection settings here too
                                              # (even though the alias is already registered!)
                                              db=self.default_db,
                                              **self.connection_args)
        # run a simple server info query to check connection & credentials
        self.connection.server_info()

        if self._has_admin_privileges:
            # run a privileged query to make sure we have the right credentials
            self.connection.database_names()

    def disconnect(self):
        """
        Disconnect from DB.
        After this operation, the connection cannot be used (unless a call to "connect" has been issued).
        :return: None
        """
        self.connection.disconnect()
        self.connection = None

    def register_alias(self, alias_name, db_name):
        """
        Register an alias for a db on this connection
        :param alias_name: alias name
        :param db_name: db name
        :return: None
        """
        alias_with_id = self.get_unique_alias(alias_name)
        if alias_with_id in self.aliases and self.aliases[alias_with_id] != db_name:
            raise StorageException('Duplicate alias \'%s\' used (registered dbs %s, %s)' % (alias_name,
                                                                                            self.aliases[alias_name],
                                                                                            db_name))

        mongoengine.register_connection(alias=alias_with_id, name=db_name,
                                        **self.connection_args)

        self.aliases[alias_with_id] = db_name

    @assert_connected
    def _get_pymongo_db(self, alias=mongoengine.DEFAULT_CONNECTION_NAME):
        """
        Get the pymongo db object associated with the given alias.
        :param alias: db alias
        :return: pymongo db object
        """
        return self.connection[self.aliases[self.get_unique_alias(alias)]]

    @assert_connected
    @alias_file_db()
    def save_file(self, file_name, file_obj, document_class, content_type=DEFAULT_CONTENT_TYPE, metadata=None,
                  deduplicate=False, alias=mongoengine.DEFAULT_CONNECTION_NAME):
        """
        Save file to (aliased) db.
        :param file_name: The saved file name
        :param file_obj: an opened file like object
        :param content_type: a valid MIME type
        :param alias: db alias to save to ('default' for default alias)
        :return: the saved file ID
        """
        document_class.file.db_alias = self.get_unique_alias(alias)
        db_file = document_class(file_name=file_name, metadata=metadata or {},
                                 content_type=content_type)
        db_file.set_content(file_obj)
        db_file.save()
        if deduplicate:
            self.deduplicate(db_file, alias=alias)

        return str(db_file.file_id)

    @assert_connected
    @alias_file_db()
    def create_file(self, file_name, document_class, metadata=None,
                    alias=mongoengine.DEFAULT_CONNECTION_NAME):
        """
        Create a file in the db, without saving actual file content. File content is later saved using
            set_file_content.
        :param file_name: The saved file name
        :param metadata: file metadata
        :param alias: db alias to save to ('default' for default alias)
        :return: the new file id
        """
        db_file = document_class(file_name=file_name, metadata=metadata or {})
        db_file.save()

        return str(db_file.file_id)

    @assert_connected
    @alias_file_db()
    def set_file_content(self, file_id, data, document_class, content_type=DEFAULT_CONTENT_TYPE, metadata=None,
                         deduplicate=False, alias=mongoengine.DEFAULT_CONNECTION_NAME):
        """
        Set the content on a file created using create_file.
        :param file_id: file id, as returned by create_file.
        :param data: the content to save
        :param content_type: a valid MIME type
        :param metadata: file metadata (appended to existing metadata)
        :param alias: db alias to save to ('default' for default alias)
        :return: the saved file ID
        """
        document_class.file.db_alias = self.get_unique_alias(alias)
        try:
            db_file = document_class.objects(file_id=file_id).get()
        except document_class.DoesNotExist:
            raise StorageException('File id %s not found' % file_id)

        if metadata is not None:
            db_file.metadata.update(metadata)

        db_file.content_type = content_type
        if deduplicate:
            md5 = hashlib.md5(data).hexdigest()
            pymongo_db = self._get_pymongo_db(alias=alias)
            identical_gridfs_file = list(pymongo_db.fs.files.find(dict(md5=md5), {'_id': 1}).limit(1))

            if identical_gridfs_file:
                found_id = identical_gridfs_file[0]['_id']
                db_file.file.get(found_id)
                db_file.file._mark_as_changed()
            else:
                db_file.set_content(data)
        else:
            db_file.set_content(data)

        db_file.save()

    @assert_connected
    @alias_file_db()
    def deduplicate(self, db_file, document_class, alias=mongoengine.DEFAULT_CONNECTION_NAME):
        # manually ensure creation of md5 index in the gridfs
        db = get_db(self.get_unique_alias(alias))
        db[db_file.file.collection_name + '.files'].ensure_index('md5')

        original_alias = document_class.file.db_alias
        document_class.file.db_alias = self.get_unique_alias(alias)
        try:
            identical_gridfs_files = db_file.file.fs.find({'md5': db_file.file.md5})
            if identical_gridfs_files.count() <= 1:
                return

            # point older files to the new file
            for identical_gridfs_file in identical_gridfs_files:
                if identical_gridfs_file._id == db_file.file.grid_id:
                    continue

                for identical_db_file in document_class.objects(file=identical_gridfs_file._id):
                    identical_db_file.replace_content(db_file.file)
                    identical_db_file.save()
        finally:
            document_class.file.db_alias = original_alias

    @assert_connected
    @alias_file_db()
    def delete_file(self, document_class, alias=mongoengine.DEFAULT_CONNECTION_NAME, **kwargs):
        """
        Deletes a specific file according to file ID, or other parameters
        :param kwargs: search parameters
        :return: None
        """
        document_class.file.db_alias = self.get_unique_alias(alias)
        # hack; otherwise, mongoengine saves the files themselves in the default connection, not the alias one
        for f in document_class.objects(**kwargs):
            f.delete_content()
            f.delete()

    @assert_connected
    @alias_file_db()
    def delete_multiple_files(self, file_ids, alias=mongoengine.DEFAULT_CONNECTION_NAME, document_class=None):
        """
        Deletes multiple files by their file IDs
        :param file_ids: list of file ids
        :return: None
        """
        source_pymongo_db = self._get_pymongo_db(alias=alias)
        collection_name = document_class._meta['collection']
        files = source_pymongo_db[collection_name].find(dict(_id={"$in": file_ids}), {'_id': 0, "file": 1})
        grid_file_ids = [file['file'] for file in files if 'file' in file]

        # only delete the GridFS file if no other files point to it
        pipeline = [{"$match": {"file": {"$in": grid_file_ids}}},
                    {"$group": {"_id": "$file", "count": {"$sum": 1}}},
                    {"$match": {"count": {"$eq": 1}}}]
        files_aggregation = source_pymongo_db[collection_name].aggregate(pipeline)
        files_to_delete_ids = [f['_id'] for f in files_aggregation]
        LOGGER.debug('Found %s file contents that can be deleted', len(files_to_delete_ids))
        if files_to_delete_ids:
            source_pymongo_db.fs.files.delete_many(dict(_id={"$in": files_to_delete_ids}))
            source_pymongo_db.fs.chunks.delete_many(dict(files_id={"$in": files_to_delete_ids}))
        source_pymongo_db[collection_name].delete_many(dict(_id={"$in": file_ids}))

    @assert_connected
    @alias_file_db()
    def clear_files(self, document_class, alias=mongoengine.DEFAULT_CONNECTION_NAME):
        """
        Clears all the files in the storage.
        """
        # first, have to manually clear the gridfs
        db = get_db(self.get_unique_alias(alias))
        for gridfs_collection_name_suffix in ["chunks", "files"]:
            db[document_class.file.collection_name + "." + gridfs_collection_name_suffix].drop()

        # clear the files collection
        document_class.drop_collection()

    @assert_connected
    @alias_file_db()
    def get_files_raw(self, alias=mongoengine.DEFAULT_CONNECTION_NAME, limit=None, document_class=None, filters=None):
        """
        Retrieves files according to various criteria.
        :param filters: criteria to match file according to
        :return: a list of File objects. use File.file to access file, or File.X for other metadata (see doctest)
        """
        source_pymongo_db = self._get_pymongo_db(alias=alias)
        collection_name = document_class._meta['collection']

        if filters is None:
            filters = {}

        return list(source_pymongo_db[collection_name].find(filters).limit(limit) if limit else source_pymongo_db[collection_name].find(filters))

    @assert_connected
    @alias_file_db()
    def get_files(self, document_class, alias=mongoengine.DEFAULT_CONNECTION_NAME, limit=None, **kwargs):
        """
        Retrieves files according to various criteria.
        :param kwargs: criteria to match file according to
        :return: a list of File objects. use File.file to access file, or File.X for other metadata (see doctest)
        """
        document_class.file.db_alias = self.get_unique_alias(alias)
        # hack; otherwise, mongoengine saves the files themselves in the default connection, not the alias one
        return list(document_class.objects(**kwargs).limit(limit) if limit else document_class.objects(**kwargs))

    @assert_connected
    @alias_file_db()
    def count_files(self, document_class, alias=mongoengine.DEFAULT_CONNECTION_NAME, **kwargs):
        """
        Retrieves file count according to various criteria
        :param kwargs:
        :return: file count
        """
        document_class.file.db_alias = self.get_unique_alias(alias)
        # hack; otherwise, mongoengine saves the files themselves in the default connection, not the alias one
        return document_class.objects(**kwargs).count()

    @assert_connected
    @alias_file_db()
    def copy_files_to_remote_db(self, destination_connection, document_class, delete_after_copy=False,
                                deduplicate=False, alias=mongoengine.DEFAULT_CONNECTION_NAME, filters=None,
                                limit=DEFAULT_MONGODUMP_LIMIT):
        """
        Move files to a different db on a different mongo instance.
        :param destination_connection: The DB to move files into (PersistentStorage instance)
        :param delete_after_copy: should the storage delete the source files after copying them
        :param filters: filters (as keyword arguments) for copied files. If not provided, all files will be copied.
        :param limit: maximal number of files to copy
        :return: True if files were copied
        """
        source_pymongo_db = self._get_pymongo_db(alias=alias)
        dest_pymongo_db = destination_connection._get_pymongo_db()
        collection_name = document_class._meta['collection']

        copied_collections = ['fs.chunks', 'fs.files', collection_name]
        copied_ids = {collection_name: [] for collection_name in copied_collections}
        found_md5s = {}  # md5 hash -> file id
        updated_file_ids = {}

        if filters is None:
            filters = {}

        files_to_copy = self.get_files_raw(alias=alias, limit=limit, filters=filters)
        file_ids = [f['_id'] for f in files_to_copy]
        if not file_ids:
            LOGGER.info("Found no files to copy")
            return False

        LOGGER.info("Found %d files", len(file_ids))

        # The next code is crafted specifically to optimize file transfers

        found_files = dest_pymongo_db.file_rep_mgmt.find(dict(_id={"$in": file_ids}), {"_id": 1})
        found_file_ids = {f['_id'] for f in found_files}
        missing_files = set(file_ids) - found_file_ids
        for f_id in found_file_ids:
            # don't remove from file_ids - it still needs to be deleted.
            LOGGER.debug('Skipping file %s - found in remote db', f_id)

        missing_files_file_ids = [f['file'] for f in files_to_copy if f['_id'] in missing_files]
        copied_ids[collection_name] += missing_files_file_ids

        gridfs_id_to_files = defaultdict(list)
        for f in files_to_copy:
            gridfs_id_to_files[f['file']].append(f)

        gridfs_file_ids = {file_id for file_id in missing_files_file_ids if file_id is not None}
        found_gridfs_files = list(source_pymongo_db.fs.files.find(dict(_id={"$in": list(gridfs_file_ids)}), {'md5': 1}))
        missing_gridfs_files = gridfs_file_ids - {grid_f['_id'] for grid_f in found_gridfs_files}
        for grid_f in missing_gridfs_files:
            # don't remove from file_ids - it still needs to be deleted.
            LOGGER.info('Skipping files %s - gridfs file %s not found in source gridfs',
                        [f['_id'] for f in gridfs_id_to_files[grid_f]],
                        grid_f)

        if deduplicate:
            # search for an identical file, first in the destination DB and then in the list of copied files.
            md5s_to_file_ids = defaultdict(list)
            for grid_f in found_gridfs_files:
                md5s_to_file_ids[grid_f['md5']].extend(gridfs_id_to_files[grid_f['_id']])
            matching_dest_gridfs_files = dest_pymongo_db.fs.files.find(dict(md5={"$in": md5s_to_file_ids.keys()}),
                                                                              {'md5': 1})
            for matching_gridfs in matching_dest_gridfs_files:
                files = md5s_to_file_ids[matching_gridfs['md5']]
                for f in files:
                    updated_file_ids[f['_id']] = matching_gridfs['_id']

            for gridfs_md5, files in md5s_to_file_ids.items():
                for file in files:
                    if file['_id'] in updated_file_ids:
                        continue
                    matching_source_gridfs_file_id = found_md5s.get(gridfs_md5)
                    if matching_source_gridfs_file_id is not None:
                        updated_file_ids[file['_id']] = matching_source_gridfs_file_id
                    else:
                        found_md5s[gridfs_md5] = file['file']

        new_gridfs = [grid_f for grid_f in found_gridfs_files if gridfs_id_to_files[grid_f['_id']][0]['_id'] not in updated_file_ids]
        copied_ids['fs.files'].extend([gridfs['_id'] for gridfs in new_gridfs])
        copied_ids['fs.chunks'].extend([chunk['_id'] for chunk in
                                        source_pymongo_db.fs.chunks.find(dict(files_id={"$in": copied_ids['fs.files']}),
                                                                         {'_id': 1})])

        LOGGER.info("Copying %d files", len(copied_ids['fs.files']))
        self._copy_collections(destination_connection, copied_ids, copied_collections, source_pymongo_db)

        LOGGER.info("Updating %d files", len(updated_file_ids))
        for file_id, new_grid_id in updated_file_ids.items():

            dest_pymongo_db.file_rep_mgmt.update({'_id': file_id}, {'$set': {'file': new_grid_id}})

        if delete_after_copy:
            LOGGER.info('Deleting %d files', len(file_ids))
            self.delete_multiple_files(file_ids)

        LOGGER.info('Finished cloning %d files', len(file_ids))
        return True

    @assert_connected
    @alias_db(SPDisk)
    def create_s_p_disk(self, disk_path, operating_system, overwrite=False, alias=mongoengine.DEFAULT_CONNECTION_NAME):
        uuid_path = disk_path + '.uuid'
        if os.path.exists(uuid_path):
            with open(uuid_path) as fh:
                disk_hash = json.load(fh)['hash']
        else:
            # No UUID file -- calculating hash manually
            LOGGER.info('UUID file missing - calculating disk hash')
            disk_hash = get_hash(disk_path)

        if overwrite:
            self.delete_s_p_disk(path=disk_path, alias=alias)
            self.delete_s_p_disk(hash=disk_hash, alias=alias)
        else:
            if self.count_s_p_disk(hash=disk_hash, alias=alias) != 0:
                raise StorageException("Disk already registered. Use overwrite flag to reintroduce disk.")
            elif self.count_s_p_disk(path=disk_path, alias=alias) != 0:
                LOGGER.warning("Path already registered. This might create duplicate records. "
                               "Use overwrite flag to clear existing records.")

        return SPDisk(path=disk_path, os=operating_system, hash=disk_hash).save().id

    @assert_connected
    @alias_db(SPDisk)
    def count_s_p_disk(self, alias=mongoengine.DEFAULT_CONNECTION_NAME, **filters):
        pymongo_db = self._get_pymongo_db(alias=alias)
        return pymongo_db.s_p_disk.count(filters)

    @assert_connected
    @alias_db(SPDisk)
    def get_s_p_disk(self, alias=mongoengine.DEFAULT_CONNECTION_NAME, **filters):
        return SPDisk.objects(**filters)

    @assert_connected
    @alias_db(SPDisk)
    def delete_s_p_disk(self, alias=mongoengine.DEFAULT_CONNECTION_NAME, **filters):
        disks = SPDisk.objects(**filters)
        self.delete_s_p_file(alias=alias, disk_id__in=[disk.id for disk in disks])
        disks.delete()

    @assert_connected
    @alias_db(SPFile)
    def create_s_p_file(self, alias=mongoengine.DEFAULT_CONNECTION_NAME, **kwargs):
        return SPFile(**kwargs).save()

    @assert_connected
    @alias_db(SPFile)
    def delete_s_p_file(self, alias=mongoengine.DEFAULT_CONNECTION_NAME, **filters):
        return SPFile.objects(**SPFile.prepare_query(**filters)).delete()

    @assert_connected
    @alias_db(SPFile)
    def create_s_p_files_son(self, files, alias=mongoengine.DEFAULT_CONNECTION_NAME):
        db = get_db(self.get_unique_alias(alias))
        db[SPFile._get_collection_name()].insert(files)

    @assert_connected
    @alias_db(SPFile)
    def get_s_p_file(self, alias=mongoengine.DEFAULT_CONNECTION_NAME, **filters):
        return SPFile.objects(**SPFile.prepare_query(**filters))

    @assert_connected
    @alias_db(SPFile)
    @alias_db(SPDisk)
    def copy_disks_to_remote_db(self, destination_connection, alias=mongoengine.DEFAULT_CONNECTION_NAME, **filters):
        source_hashes = {d.hash for d in self.get_s_p_disk()}
        destination_hashs = {d.hash for d in destination_connection.get_s_p_disk()}

        # Purge outdated disks
        destination_connection.delete_s_p_disk(hash__in=list(destination_hashs - source_hashes))
        LOGGER.info("Found %d disks to be purged", len(destination_hashs - source_hashes))

        # Copy new disks
        disks_to_sync = self.get_s_p_disk(alias=alias, hash__in=list(source_hashes - destination_hashs), **filters)
        files_to_sync = self.get_s_p_file(alias=alias, disk_id__in=[disk.id for disk in disks_to_sync])
        LOGGER.info("Found %d disks and %d files to be copied", disks_to_sync.count(), files_to_sync.count())

        copied_collections = [SPDisk._get_collection_name(), SPFile._get_collection_name()]
        copied_ids = {collection_name: list(str(disk.id) for disk in disks_to_sync) for collection_name in
                      copied_collections}

        self._copy_collections(destination_connection, copied_ids, copied_collections,
                               self._get_pymongo_db(alias=alias))

        LOGGER.info('Finished copying disks')

    def _copy_collections(self, destination_connection, copied_ids, copied_collections, source_pymongo_db):
        """
        Copies documents from copied collections from source mongo DB to local DB
        using mongodump and mongorestore
        :param copied_ids:
        :param copied_collections:
        :param source_pymongo_db:
        """
        # We will copy only collections that exist
        collections = source_pymongo_db.collection_names()
        copied_collections = [collection for collection in copied_collections if collection in collections]
        collection_mapping = {'fs.chunks':             {},
                              'file_local_honeypot':   {'key': "file", "target": 'file_rep_mgmt'},
                              'fs.files':              {},
                              's_p_disk':              {},
                              's_p_file':              {'key': "disk_id"}}
        LOGGER.info('Copying collections {collections}'.format(collections=copied_collections))
        copy_count = 0

        for collection_name in copied_collections:
            # execute the mongodump on a remote mongo server
            collection_key = collection_mapping[collection_name].get('key', '_id')
            target_collection = collection_mapping[collection_name].get('target', collection_name)
            collection_copied_ids = copied_ids[collection_name]

            for start_index in range(0, len(collection_copied_ids), DEFAULT_MONGODUMP_LIMIT):
                end_index = min(start_index + DEFAULT_MONGODUMP_LIMIT, len(collection_copied_ids))
                self._export_to_remote_destination(destination_connection, collection_key,
                                                   collection_copied_ids[start_index: end_index], collection_name,
                                                   target_collection)

            copy_count += len(collection_copied_ids)

        LOGGER.info('Copied {count} documents from collections'.format(count=copy_count))

    def _export_to_remote_destination(self, destination_connection, key, value_list, collection,
                                      target_collection_name=None):
        """
        Do an "dump and restore" from the current connection to the destination connection
        :param destination_connection: The target to export the data into
        :param key: the key which will be used to filter the query which will be made on the source db
        :param value_list: the value list which will be used to filter the query at the source db
        :param collection: the relevant collection for dump an restore
        """
        # TODO: We need to avoid multiple dump and restores for each file, it's too much
        # A unique id for the current transaction, we want to separate between transactions to avoid collisions
        export_id = str(uuid.uuid4())
        if not isinstance(destination_connection, PersistentStorage):
            # Hack: destination_connection might be a MongoStorage instance, in which case we need the actual storage instance
            destination_connection = destination_connection.storage

        self._mongodump_local_by_query(key, value_list, collection, export_id=export_id)
        destination_connection._mongorestore(source_collection_name=collection,
                                             target_collection_name=target_collection_name,
                                             source_db_name=self.default_db,
                                             target_db_name=destination_connection.default_db,
                                             export_id=export_id)

    def build_mongodump_command(self, export_id=str(0), db=None, collection=None,
                                dump_target=DEFAULT_REPLICA_LOCATION,
                                query=None, query_file=None):
        """
        create a mongodump command, which connects to a database and dumps a *.bson file with one of it's collections
        """
        if db is None:
            db = self.default_db

        mongo_command = 'mongodump --host {host} --port {port} --db {db} --out {local_target}/{export_id} ' \
                        '--readPreference={read_preference}'

        if collection:
            mongo_command += ' --collection {collection}'

        if query:
            mongo_command += ' --query "{query}"'

        if query_file:
            mongo_command += ' --queryFile "{query_file}"'

        # is the mongo server (local or remote) is authenticated
        if self.auth_enabled:
            mongo_command += ' --username {username} --password {password} --authenticationDatabase {auth_db}'

        hosts_str = self._generate_hosts_str()
        read_preference = self._get_read_preference()
        mongo_command = mongo_command.format(db=db,
                                             local_target=dump_target,
                                             export_id=export_id,
                                             collection=collection,
                                             query=query,
                                             query_file=query_file,
                                             host=hosts_str,
                                             port=self.port,
                                             username=self.user,
                                             password=self.password,
                                             auth_db=self.authentication_source,
                                             read_preference=read_preference)

        return mongo_command

    def build_mongoexport_command(self, db=None, collection=None,
                                  dump_target=DEFAULT_REPLICA_LOCATION,
                                  query=None):
        """
        create a mongoexport command, which export to a database and dumps a *.bson file with one of it's collections
        :param db:
        :param collection:
        :param dump_target:
        :param query:
        :return:
        """
        if db is None:
            db = self.default_db

        mongo_command = 'mongoexport --host {host} --port {port} --db {db} --out {local_target}/{collection}.json'

        if collection:
            mongo_command += ' --collection {collection}'

        if query:
            mongo_command += ' --query "{query}"'

        # is the mongo server (local or remote) is authenticated
        if self.auth_enabled:
            mongo_command += ' --username {username} --password {password} --authenticationDatabase {auth_db}'

        hosts_str = self._generate_hosts_str()
        mongo_command = mongo_command.format(db=db,
                                             local_target=dump_target,
                                             collection=collection,
                                             query=query,
                                             host=hosts_str,
                                             port=self.port,
                                             username=self.user,
                                             password=self.password,
                                             auth_db=self.authentication_source)
        return mongo_command

    def build_mongoimport_command(self, db=None, dump_target=DEFAULT_REPLICA_LOCATION, collection=None, drop=False):
        if db is None:
            db = self.default_db

        mongo_command = 'mongoimport --host {host} --port {port} --db {db} --file {local_target}/{collection}.json'

        if collection:
            mongo_command += ' --collection {collection}'

        if drop:
            mongo_command += ' --drop'

        # is the mongo server (local or remote) is authenticated
        if self.auth_enabled:
            mongo_command += ' --username {username} --password {password} --authenticationDatabase {auth_db}'

        hosts_str = self._generate_hosts_str()
        mongo_command = mongo_command.format(db=db,
                                             local_target=dump_target,
                                             collection=collection,
                                             host=hosts_str,
                                             port=self.port,
                                             username=self.user,
                                             password=self.password,
                                             auth_db=self.authentication_source)
        return mongo_command

    def _mongodump_local_by_query(self, key, value_list, collection, export_id=str(0)):
        """
        mongodumps docs matching a {key : {$in: value_list}} query  a host
        for a given collection
        :param key: the document key by which to query
        :param value_list: the values for which we want to try and match
        :param collection: the collection from which we dump documents
        :param export_id: a unique transaction id
        """
        query = {key: {"$in": value_list}}
        mongo_dump_command = self.build_mongodump_command(export_id=export_id,
                                                          collection=collection).split(' ')
        mongo_dump_command.append('-q')
        query = str(query).replace("'", '"')
        mongo_dump_command.append(query)
        try:
            subprocess.check_call(mongo_dump_command)
        except subprocess.CalledProcessError as ex:
            raise StorageException('Failed dumping files with command {cmd}: {error}'.format(cmd=PasswordMaskingFormatter.mask_passwords(mongo_dump_command),
                                                                                             error=str(ex)))

    def build_mongorestore_command(self, export_id=str(0),
                                   source_collection=None,
                                   target_collection=None,
                                   source_db=None,
                                   target_db=None,
                                   restore_target=DEFAULT_REPLICA_LOCATION,
                                   drop=False):
        """
        create a mongorestore command, which connects to a database and restores a *.bson file into one of it's collections
        """
        mongo_command = 'mongorestore --host {host} --port {port} --db {dst_db}'

        if not source_db:
            source_db = self.default_db
        if not target_db:
            target_db = self.default_db

        if not source_collection:
            source_collection = target_collection

        # is the mongo server (local or remote) is authenticated
        if self.auth_enabled:
            mongo_command += ' --username {username} --password {password} --authenticationDatabase={auth_db}'

        if self.ssl:
            mongo_command += ' --ssl --sslCAFile {ssl_ca_file} --sslPEMKeyFile {ssl_pem_key_file}'

        if target_collection:
            mongo_command += ' --collection {target_collection} {target}/{export_id}/{src_db}/{collection}.bson'
        else:
            mongo_command += ' --dir {target}/{export_id}/{src_db}/'

        hosts_str = self._generate_hosts_str()

        if drop:
            mongo_command += ' --drop'

        mongo_command = mongo_command.format(host=hosts_str,
                                             port=self.port,
                                             dst_db=target_db,
                                             target_collection=target_collection,
                                             target=restore_target,
                                             export_id=export_id,
                                             src_db=source_db,
                                             collection=source_collection,
                                             username=self.user,
                                             password=self.password,
                                             auth_db=self.authentication_source,
                                             ssl_ca_file=self.ssl_ca_cert_path,
                                             ssl_pem_key_file=self.ssl_client_cert_path)

        return mongo_command

    def _mongorestore(self, source_db_name=None, target_db_name=None,
                      source_collection_name=None, target_collection_name=None,
                      export_id=str(0),
                      restore_path=DEFAULT_REPLICA_LOCATION, delete_file=True):
        """
        mongorestores a collection (collection_name) to a remote connection from a given path which mongodump exported
        data to
        :param collection_name: the collection we want to restore the documents into
        :param restore_path: the path of the data that mongodump used for output
        :param export_id: a unique transaction id
        """
        # execute the mongorestore on the local dump
        mongo_restore_command = self.build_mongorestore_command(source_db=source_db_name,
                                                                target_db=target_db_name,
                                                                source_collection=source_collection_name,
                                                                target_collection=target_collection_name,
                                                                restore_target=restore_path,
                                                                export_id=export_id)
        try:
            subprocess.check_call(mongo_restore_command.split(' '))
        except subprocess.CalledProcessError as ex:
            LOGGER.warning('Failed restoring files with command {cmd}: {error}'.format(
                cmd=PasswordMaskingFormatter.mask_passwords(mongo_restore_command),
                error=str(ex)))
            return

        if delete_file:
            shutil.rmtree("{target}/{export_id}".format(target=restore_path, export_id=export_id), ignore_errors=True)

    def _generate_hosts_str(self):
        if self.replica_set_name:
            return "{}/{}".format(self.replica_set_name, ','.join(self.hosts))
        else:
            return ','.join(self.hosts)

    def _get_read_preference(self):
        if self.hosts[1:]:
            return 'secondary'
        else:
            return 'primary'


if __name__ == '__main__':
    import doctest

    doctest.testmod()
