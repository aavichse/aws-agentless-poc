import collections

__author__ = 'Amit'


def recursive_update_dict(updated_dict, from_dict):
    for key, value in from_dict.items():
        if isinstance(value, dict):
            recursive_update_dict(updated_dict.setdefault(key, {}), value)
        else:
            updated_dict[key] = value


class OrderedSet(collections.OrderedDict, collections.MutableSet):
    def update(self, *args, **kwargs):
        if kwargs:
            raise TypeError("update() takes no keyword arguments")

        for s in args:
            for e in s:
                self.add(e)

    def add(self, elem):
        self[elem] = None

    def discard(self, elem):
        self.pop(elem, None)

    def __le__(self, other):
        return all(e in other for e in self)

    def __lt__(self, other):
        return self <= other and self != other

    def __ge__(self, other):
        return all(e in self for e in other)

    def __gt__(self, other):
        return self >= other and self != other

    def __repr__(self):
        return 'OrderedSet([%s])' % (', '.join(map(repr, self.keys())))

    def __str__(self):
        return '{%s}' % (', '.join(map(repr, self.keys())))

    difference = property(lambda self: self.__sub__)
    difference_update = property(lambda self: self.__isub__)
    intersection = property(lambda self: self.__and__)
    intersection_update = property(lambda self: self.__iand__)
    issubset = property(lambda self: self.__le__)
    issuperset = property(lambda self: self.__ge__)
    symmetric_difference = property(lambda self: self.__xor__)
    symmetric_difference_update = property(lambda self: self.__ixor__)
    union = property(lambda self: self.__or__)


def update_nested_key(dict_to_update, path_to_key, value, create_parents=False):
    """
    Updates a nested value in a dict
    :param dict_to_update: The dict itself
    :param path_to_key: A path to the key, will look like ["a", "b", "c"] for ({"a": {"b": {"c": "somevalue"}}}
    :param value: The value
    :param create_parents: Whether to fail or create a key once said key does not exist in the dict
    """
    parents = path_to_key[:-1]
    key = path_to_key[-1]
    relevant_subdict = dict_to_update

    for parent in parents:
        if create_parents:
            relevant_subdict = relevant_subdict.setdefault(parent, {})
        else:
            relevant_subdict = relevant_subdict[parent]
        if not isinstance(relevant_subdict, dict):
            raise TypeError("The value of a parent in key path is {} and not a dict".format(parent))

    relevant_subdict[key] = value
