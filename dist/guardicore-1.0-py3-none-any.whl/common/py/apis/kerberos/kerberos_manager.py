import sys
if sys.platform == 'win32':
    import kerberos_sspi as kerberos
else:
    import kerberos

import attr
from requests.status_codes import codes

from common.logger import get_logger

__author__ = 'Yuval'

LOGGER = get_logger()

NEGOTIATION_HEADER = {'WWW-Authenticate': 'Negotiate'}


@attr.s
class KerberosAuthenticationResponse:
    status_code = attr.ib(type=int)
    token = attr.ib(default=None, type=str)
    user = attr.ib(default=None, type=str)


class KerberosManager:
    def __init__(self):
        self.kerberos_user = None
        self.kerberos_token = None

    @staticmethod
    def _format_kerberos_service_name(host):
        return 'HTTP@{}'.format(host)

    @classmethod
    def get_kerberos_token(cls, host):
        """
        Perform the identification and return the kerberos token
        """
        service_name = cls._format_kerberos_service_name(host)
        __, krb_context = kerberos.authGSSClientInit(service_name)
        kerberos.authGSSClientStep(krb_context, '')
        negotiate_details = kerberos.authGSSClientResponse(krb_context)
        return negotiate_details

    def _gssapi_authenticate(self, token, host):
        """
        Performs GSSAPI Negotiate Authentication
        @param token: GSSAPI Authentication Token
        @type token: str
        @returns gssapi return code or None on failure
        @rtype: int or None
        """
        krb_context = None
        service_name = self._format_kerberos_service_name(host)
        try:
            result, krb_context = kerberos.authGSSServerInit(service_name)
            if result != kerberos.AUTH_GSS_COMPLETE:
                return None
            result = kerberos.authGSSServerStep(krb_context, token)
            if result == kerberos.AUTH_GSS_COMPLETE:
                self.kerberos_token = kerberos.authGSSServerResponse(krb_context)
                self.kerberos_user = kerberos.authGSSServerUserName(krb_context)
                LOGGER.debug('User %s have logged in with kerberos token of %s', self.kerberos_user, self.kerberos_token)
                return result
            elif result == kerberos.AUTH_GSS_CONTINUE:
                return kerberos.AUTH_GSS_CONTINUE
            else:
                return None
        except kerberos.GSSError as error:
            LOGGER.error('Failed to perform the token verification due to %s', error)
            return None
        finally:
            if krb_context:
                kerberos.authGSSServerClean(krb_context)

    @staticmethod
    def _get_token_from_authorization_header(header):
        """
        Extract the token part of the header ("Nagotiate <token>")
        :param header:
        :return:
        """
        return ''.join(header.split()[1:])

    def check_authentication(self, request, host):
        """
        Require that the wrapped view function only be called by users
        authenticated with Kerberos. The view function will have the authenticated
        users principal passed to it as its first argument.
        """
        LOGGER.debug('Checking authorization header for kerberos request')
        header = request.headers.get("Authorization")
        status_code = codes.UNAUTHORIZED
        if header:
            token = self._get_token_from_authorization_header(header)
            LOGGER.debug('Found header with token. Verifying the token against the server')
            result = self._gssapi_authenticate(token, host)
            if result == kerberos.AUTH_GSS_COMPLETE:
                LOGGER.debug('The authenticated user is successfully authenticated')
                status_code = codes.OK
            elif result != kerberos.AUTH_GSS_CONTINUE:
                LOGGER.debug('The authenticated user is forbidden')
                status_code = codes.FORBIDDEN
        return KerberosAuthenticationResponse(status_code=status_code,
                                              user=self.kerberos_user,
                                              token=self.kerberos_token)
