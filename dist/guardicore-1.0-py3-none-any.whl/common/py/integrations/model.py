from enum import Enum


class MsgType(Enum):
    UNKNOWN = "unknown"
    FLOWS = "flows"
    EVENTS = "events"
    INVENTORY = "inventory"
