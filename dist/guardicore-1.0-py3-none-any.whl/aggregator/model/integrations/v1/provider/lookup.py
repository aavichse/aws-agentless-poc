from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class Direction(Enum):
    OUTBOUND = 'outbound'
    INBOUND = 'inbound'


class LookupRequest(BaseModel):
    connection_time: Optional[int] = Field(
        None,
        alias='connection-time',
        description='Start time of the network event.** for aggregated events (epoch in seconds)',
    )
    agent_item_id: Optional[str] = Field(
        None, alias='agent-item-id', description='reporting agent azure resource id'
    )
    agent_mac: str = Field(
        ..., alias='agent-mac', description='reporting agent mac address'
    )
    direction: Optional[Direction] = Field(
        None, description='Indicates the direction of the network event'
    )
    agent_ip: str = Field(..., alias='agent-ip', description='Source IP address.')
    remote_ip: str = Field(
        ..., alias='remote-ip', description='Destination IP address.'
    )
    remote_port: Optional[int] = Field(
        None, alias='remote-port', description='Destination port.'
    )
