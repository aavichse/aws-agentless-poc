'''
Created on Nov 24, 2014

@author: itamar
'''

import time
import struct
from six import StringIO
from common.py.model.exceptions import GuardicoreException

class PcapFormat(object):
    DEFUALT_SNAPLEN = 1520
    PCAP_HEADER_FORMAT = "IHHIIII"
    PCAP_HEADER_LENGTH = struct.calcsize(PCAP_HEADER_FORMAT)
    PCAP_HEADER_FIELDS = ("magic", "major", "minor", "thiszone", "sigfigs", "snaplen", "linktype")
    PCAP_PKT_HEADER_FORMAT = "IIII"
    PCAP_PKT_HEADER_LENGTH = struct.calcsize(PCAP_PKT_HEADER_FORMAT)
    PCAP_HEADER_MAGIC = 0xA1B2C3D4

class PcapWriter(object):
    def __init__(self, fo, snaplen=PcapFormat.DEFUALT_SNAPLEN, linktype=1, flush_dump=False):
        self._file = fo
        self._snaplen = snaplen
        self._linktype = 1
        self._flush_dump = flush_dump
        self._packets_written = 0
        
        self._write_pcap_header()
    
    def __len__(self):
        return self._packets_written
    
    def dump_packet(self, packet, timestamp=None):
        if not timestamp:
            now = time.time()
            timestamp = (int(now), 0) # ToDo: fix
        
        packet_snaplen = min(self._snaplen, len(packet))
        pkt_header = struct.pack(PcapFormat.PCAP_PKT_HEADER_FORMAT,
                                 timestamp[0],
                                 timestamp[1],
                                 packet_snaplen,
                                 len(packet))
        
        self._file.write(pkt_header)
        self._file.write(packet[:packet_snaplen])
        
        if self._flush_dump:
            self.flush()
            
        self._packets_written += 1
    
    def flush(self):
        self._file.flush()
        
    def close(self):
        self._file.close()
        self._file = None
        
    def _write_pcap_header(self):
        pcap_header = struct.pack(PcapFormat.PCAP_HEADER_FORMAT,
                                  PcapFormat.PCAP_HEADER_MAGIC,
                                  2, 4,
                                  0, 0,
                                  self._snaplen,
                                  self._linktype)
        
        self._file.write(pcap_header)
        self._file.flush()
        

class PcapReader(object):
    def __init__(self, fo):
        self._file = fo
        self._header = None
        self._eof = True
    
    def __enter__(self):
        self.start()

        return self

    def __exit__(self, type, value, traceback):
        self.close()
    
    def __iter__(self):
        return self
    
    def start(self):
        pcap_header = struct.unpack(PcapFormat.PCAP_HEADER_FORMAT, self._file.read(PcapFormat.PCAP_HEADER_LENGTH))
        pcap_header = dict(zip(PcapFormat.PCAP_HEADER_FIELDS, pcap_header))
        if (PcapFormat.PCAP_HEADER_MAGIC != pcap_header['magic']) or \
            (2 != pcap_header['major']) or \
            (4 != pcap_header['minor']):
            raise GuardicoreException("Invalid pcap header received by tcpdump: %r", pcap_header)
        
        self._header = pcap_header
        self._eof = False
    
    def fileno(self):
        return self._file.fileno()
    
    def is_eof(self):
        return self._eof
    
    def read_packet(self):
        # read packet header
        pkt_header_data = self._file.read(PcapFormat.PCAP_PKT_HEADER_LENGTH)
        if not pkt_header_data:
            self._eof = True
            return None, None
        
        pkt_header = struct.unpack(PcapFormat.PCAP_PKT_HEADER_FORMAT, pkt_header_data)
        
        packet_info = {'ts': {'tv_sec': pkt_header[0],
                              'tv_usec': pkt_header[1]},
                       'caplen': pkt_header[2],
                       'len': pkt_header[3]}
        
        # read the packet
        packet = self._file.read(packet_info['caplen'])
        
        return packet_info, packet
    next = read_packet
    
    def close(self):
        self._file.close()
        self._file = None


def packets_to_pcap(fo, packets, close_file=True, sort_by_time=True):
    if sort_by_time:
        packets = sorted(packets, cmp=(lambda pkt1, pkt2: (pkt1[0] > pkt2[0])))

    if type(fo) in (str, unicode):
        fo = open(fo, "wb")

    pcap_writer = PcapWriter(fo=fo)
    for ts, pkt in packets:
        ts_sec = int(ts)
        ts_usec = int((ts - int(ts)) * 1000000)
        pcap_writer.dump_packet(packet=pkt, timestamp=(ts_sec, ts_usec))
    pcap_writer.flush()

    if close_file:
        pcap_writer.close()

def packets_to_pcap_raw(packets, sort_by_time=True):
    string_io = StringIO()

    packets_to_pcap(fo=string_io, packets=packets,
                    close_file=False, sort_by_time=sort_by_time)
    pcap_raw = string_io.getvalue()
    string_io.close()

    return pcap_raw