"""
This file contains Pydantic models for the integration enforcement service
In addition to validating a dictionary matching the model, the models has validation logic to process
Guardicore mgmt models as an input. Thus the Policy models can receive 'EnforcementPolicyRule' for example, and Inventory
models can receive 'DCAssetInfo' or Guardicore 'LabelInfo' (see field_validator decorator funcs).
"""
from __future__ import annotations

from enum import Enum
from typing import List, Optional, Union
import attr
from contextvars import ContextVar
from contextlib import contextmanager

from pydantic import BaseModel, Field, ValidationInfo, field_validator, model_validator, AliasChoices
from ..common import common
from common.py.events.visibility.enforcement_policy import EnforcementOrLabels, VisibilityPolicyAction,\
    VisibilityPolicySectionPosition, EnforcementPolicyRuleFilter
from common.py.models.events import ProtocolType
from common.py.events.datacenter_inventory.datacenter_inventory import IntegrationCriteria, DCAssetInfo
from common.py.events.datacenter_inventory.datacenter_inventory import LabelInfo as CentraLabel
from common.py.utils.integration_scope import IntegrationScope


context_rule = ContextVar("context_rule")
@contextmanager
def init_context(value):
    token = context_rule.set(value)
    try:
        yield
    finally:
        context_rule.reset(token)


class ChainName(Enum):
    OVERRIDE_ALLOW = 'override-allow'
    OVERRIDE_ALERT = 'override-alert'
    OVERRIDE_BLOCK = 'override-block'
    ALLOW = 'allow'
    ALERT = 'alert'
    BLOCK = 'block'


class Protocol(Enum):
    TCP = 'tcp'
    UDP = 'udp'
    ICMP = 'icmp'
    ALL = 'all'

    @classmethod
    def code_to_protocol(cls, value: int):
        code_type_map = {
            ProtocolType.TCP.value: Protocol.TCP,
            ProtocolType.UDP.value: Protocol.UDP,
            ProtocolType.ICMP.value: Protocol.ICMP
        }
        return code_type_map.get(value, None)


class Verdict(Enum):
    ALLOW = 'allow'
    BLOCK = 'block'


class CompoundLabel(BaseModel, from_attributes=True, populate_by_name=True):
    include_labels: List[List[str]] = Field(..., alias='include-labels')
    exclude_labels: Optional[List[List[str]]] = Field(None, alias='exclude-labels')

    @field_validator('include_labels', 'exclude_labels', mode="before")
    @classmethod
    def transform(cls, v: Union[EnforcementOrLabels, dict, list], info: ValidationInfo) -> List[List[str]]:
        if isinstance(v, EnforcementOrLabels) or isinstance(v, dict):
            res = list()
            if isinstance(v, EnforcementOrLabels):
                res = [label.and_labels for label in v.or_labels]
            elif isinstance(v, dict):
                res = [label['and_labels'] for label in v['or_labels']]
            if not len(res) and info.field_name == 'exclude_labels':
                return None
            return res
        return v


class PortRangeMatch(BaseModel):
    start: int
    end: int


class ProcessMatch(BaseModel):
    image_path: Optional[str] = Field(None, alias='image-path')
    image_basename: Optional[str] = Field(None, alias='image-basename')


class DomainGroupMatch(BaseModel):
    domain_name: str = Field(..., alias='domain-name')
    sid: str
    gname: str


class Ver(Enum):
    INTEGER_4 = 4
    INTEGER_6 = 6


class IcmpMatch(BaseModel, from_attributes=True, populate_by_name=True):
    ver: Ver = Field(..., validation_alias=AliasChoices('version', 'ver'))
    type: int = Field(..., validation_alias=AliasChoices('icmp_type', 'type'))
    codes: Optional[List[int]] = Field(None, validation_alias=AliasChoices('icmp_codes', 'codes'))

    @field_validator('ver', mode="before")
    @classmethod
    def transform_ver(cls, v: Union[str, Ver]) -> Ver:
        if isinstance(v, str):
            if v == '4':
                return Ver.INTEGER_4
            elif v == '6':
                return Ver.INTEGER_6
        return v



class WinServiceMatch(BaseModel):
    service_name: Optional[str] = Field(None, alias='service-name')
    service_image_names: Optional[List[str]] = Field(None, alias='service-image-names')


class Op(Enum):
    EQUALS = 'equals'
    STARTS_WITH = 'starts-with'
    ENDS_WITH = 'ends-with'
    CONTAINS = 'contains'
    WILDCARDS = 'wildcards'
    REGEX = 'regex'

    @classmethod
    def code_to_op(cls, value: int):
        code_to_enum_map = {
            0: Op.EQUALS,
            1: Op.STARTS_WITH,
            2: Op.ENDS_WITH,
            3: Op.CONTAINS,
            4: Op.WILDCARDS,
            # 5 is missing as we do not have the 'subnet' operation
            6: Op.REGEX
        }
        return code_to_enum_map.get(value, None)


class CriterionType(Enum):
    HOSTNAME = 'hostname'
    SUBSCRIPTION = 'subscription'
    VNET = 'vnet'
    SUBNET = 'subnet'
    REGION = 'region'
    RESOURCE_GROUP = 'resource_group'
    TAG = 'tag'
    PLATFORM = 'platform'
    RESOURCE_TYPE = 'resource_type'
    SERVICE_TAG = 'service_tag'

# TODO not be needed if IntegrationScope will be rewritten without the 'Azure' prefix
CRITERION_TYPE_SCOPE_NAME_TO_ENUM_MAP = {
    'azure': {
        IntegrationScope.PLATFORM.value: CriterionType.PLATFORM,
        IntegrationScope.AZURE_SUBSCRIPTION.value: CriterionType.SUBSCRIPTION,
        IntegrationScope.AZURE_SUBSCRIPTION_ID.value: CriterionType.SUBSCRIPTION,
        IntegrationScope.AZURE_REGION.value:  CriterionType.REGION,
        IntegrationScope.AZURE_RESOURCE_TYPE.value: CriterionType.RESOURCE_TYPE,
        IntegrationScope.AZURE_RESOURCE_GROUP.value: CriterionType.RESOURCE_GROUP,
        IntegrationScope.AZURE_SUBNET.value: CriterionType.SUBNET,
        IntegrationScope.AZURE_VNET.value: CriterionType.VNET,
        IntegrationScope.AZURE_SERVICE_TAG.value: CriterionType.SERVICE_TAG
    }
}


class DCInventoryItem(BaseModel, from_attributes=True, populate_by_name=True):
    item_id: str = Field(..., validation_alias=AliasChoices('asset_id', 'item-id'), serialization_alias='item-id')
    external_id: Optional[str] = Field(None, alias='external-id')
    ip_addresses: Optional[List[str]] = Field(None, alias='ip-addresses')

    @model_validator(mode="wrap")
    @classmethod
    def validate_model(cls, v: Union[DCAssetInfo, dict], handler, info: ValidationInfo):
        context = info.context.get('integration', None) if info.context else None
        if isinstance(v, DCAssetInfo) and context:
            if v.subtype and v.subtype.integration_name.lower() == context:
                new_val = attr.asdict(v)
                new_val['external_id'] = v.subtype.entity_id
                new_val['nics'] = []
                return handler(new_val)
        return handler(v)


class GroupMatch(BaseModel):
    domain_groups: Optional[List[DomainGroupMatch]] = Field(None, alias='domain-groups')
    local_admins: Optional[bool] = Field(None, alias='local-admins')
    local_users: Optional[bool] = Field(None, alias='local-users')


class LabelCriterion(BaseModel, from_attributes=True):
    type: CriterionType = Field(..., validation_alias=AliasChoices('field', 'type'), alias='type')
    op: Op
    argument: str
    resolvable: common.Connector = Field(
        ..., description='determine which connector can resolve criteria matched assets',
        validation_alias=AliasChoices('integration_name', 'resolvable'), serialization_alias='resolvable'
    )

    @field_validator('type', mode="before")
    @classmethod
    def transform_type(cls, v: Union[CriterionType, str], info: ValidationInfo) -> CriterionType:
        context = info.context.get('integration', None) if info.context else None
        if isinstance(v, str) and context:
            if context == 'azure':
                if v in CRITERION_TYPE_SCOPE_NAME_TO_ENUM_MAP[context].keys():
                    return CRITERION_TYPE_SCOPE_NAME_TO_ENUM_MAP[context][v]
                elif v == 'tag':
                    return CriterionType.TAG
        return v

    @field_validator('op', mode="before")
    @classmethod
    def transform_op(cls, v: Union[Op, int]) -> Op:
        if isinstance(v, int):
            return Op.code_to_op(v)
        return v

    @field_validator('resolvable', mode="before")
    @classmethod
    def transform_resolvable(cls, v: Union[common.Connector, str]) -> common.Connector:
        if isinstance(v, str):
            if v.lower() == 'azure':
                return common.Connector.CLOUD_AZURE
            elif v.lower() == 'packet_fence':
                return common.Connector.PACKET_FENCE
        return v


class EntityMatch(BaseModel, from_attributes=True, populate_by_name=True):
    match_labels: Optional[CompoundLabel] = Field(None, validation_alias=AliasChoices('labels', 'match-labels'),alias='match-labels')
    match_multiple_subnets: Optional[List[str]] = Field(None, validation_alias=AliasChoices('subnets', 'match-multiple-subnets'),serialization_alias='match-multiple-subnets')
    match_inventory_items: Optional[List[str]] = Field(None, validation_alias=AliasChoices('asset_ids','match-inventory-items'), serialization_alias='match-inventory-items')
    match_ports: Optional[List[int]] = Field(None, alias='match-ports')
    match_port_ranges: Optional[List[PortRangeMatch]] = Field(None, alias='match-port-ranges')
    match_processes: Optional[List[ProcessMatch]] = Field(None, validation_alias=AliasChoices('processes', 'match-processes'), alias='match-processes')
    match_dns_list: Optional[List[str]] = Field(None, validation_alias=AliasChoices('domains', 'match-dns-list'), alias='match-dns-list')
    match_groups: Optional[GroupMatch] = Field(None, alias='match-groups')
    match_icmp_types: Optional[List[IcmpMatch]] = Field(None, alias='match-icmp-types')
    match_win_services: Optional[List[WinServiceMatch]] = Field(None, validation_alias=AliasChoices('windows_services', 'match-win-services'), alias='match-win-services')
    match_win_any_services: Optional[bool] = Field(None, alias='match-win-any-services')

    @field_validator('match_labels', mode="before")
    @classmethod
    def transform_labels(cls, v: List) -> CompoundLabel:
        if isinstance(v, list):
            if len(v) == 1:
                return v[0]
        return v


class LabelInfo(BaseModel, from_attributes=True, populate_by_name=True):
    label_id: Optional[str] = Field(None, alias='label-id')
    key: Optional[str] = None
    value: Optional[str] = None
    label_criteria: Optional[List[LabelCriterion]] = Field(None, validation_alias=AliasChoices('integration_criteria', 'label-criteria'), alias='label-criteria')
    labeled_items: Optional[List[str]] = Field(
        None,
        validation_alias=AliasChoices('non_integration_vm_ids', 'labeled-items'),
        serialization_alias='labeled-items',
        description='The list of asset ids that belong to this label. Asset ids must exist provider the inventory-items array.',
    )

    @model_validator(mode="wrap")
    @classmethod
    def validate_model(cls, v: Union[CentraLabel, dict], handler, info: ValidationInfo):
        context = info.context.get('integration', None) if info.context else None
        if isinstance(v, CentraLabel) and context:
            # MGMT fill 'non_integration_vm_ids' field only if there is an integration criteria (this is an optimization),
            # therefore on any other case we take the 'vm_ids' field.
            if not v.integration_criteria or not v.integration_criteria[0].criteria or \
                    v.integration_criteria[0].criteria[0].integration_name.lower() != context:
                v.non_integration_vm_ids = v.vm_ids
                v.integration_criteria = None
        return handler(v)

    @field_validator('label_criteria', mode="before")
    @classmethod
    def transform_criteria(cls, v: List) -> List:
        res = list()
        if isinstance(v, List):
            for item in v:
                if isinstance(item, IntegrationCriteria):
                    res.extend(item.criteria)
                elif isinstance(item, dict):
                    if "criteria" in item:
                        res.extend(item['criteria'])
                    else:
                        res.append(item)
            return res
        return v


class PolicyRule(BaseModel, from_attributes=True, populate_by_name=True):
    match_src: EntityMatch = Field(..., validation_alias=AliasChoices('source', 'match-src'), alias='match-src')
    match_dst: EntityMatch = Field(..., validation_alias=AliasChoices('destination', 'match-dst'), alias='match-dst')
    protocols: List[Protocol] = Field(..., validation_alias=AliasChoices('ip_protocols', 'protocols'))
    verdict: Verdict = Field(..., validation_alias=AliasChoices('action', 'verdict'))
    id: str = Field(..., validation_alias=AliasChoices('rule_id', 'id'))

    @model_validator(mode="wrap")
    @classmethod
    def validate_model(cls, v, handler):
        token = context_rule.set(v)
        try:
            return handler(v)
        finally:
            context_rule.reset(token)

    @field_validator('match_dst', mode="wrap")
    @classmethod
    def validate_dst(cls, v: Union[EnforcementPolicyRuleFilter, dict], handler):
        if isinstance(v, EnforcementPolicyRuleFilter):
            rule = context_rule.get()
            if rule.ports or rule.port_ranges or rule.icmp_matches:
                dst = attr.asdict(v)
                if rule.ports:
                    dst['match_ports'] = rule.ports
                if rule.port_ranges:
                    dst['match-port-ranges'] = rule.port_ranges
                if rule.icmp_matches:
                    dst['match-icmp-types'] = rule.icmp_matches
                return handler(dst)
        return handler(v)

    @field_validator('verdict', mode="before")
    @classmethod
    def transform_action(cls, v: Union[VisibilityPolicyAction, dict]) -> str:
        if isinstance(v, VisibilityPolicyAction):
            if v == VisibilityPolicyAction.BLOCK:
                return 'block'
            if v == VisibilityPolicyAction.ALLOW or v == VisibilityPolicyAction.ALERT:
                return 'allow'
        return v

    @field_validator('protocols', mode="before")
    @classmethod
    def transform_protocol(cls, v: List) -> List:
        if isinstance(v, List) and len(v) and isinstance(v[0], int):
            res = [Protocol.code_to_protocol(p) for p in v]  # TODO add the 'all' option
            return res
        return v


class EnforcementPolicyInventory(BaseModel, populate_by_name=True):
    labels: Optional[List[LabelInfo]] = Field(
        None, description='Array of all the labels.'
    )
    inventory_items: Optional[List[DCInventoryItem]] = Field(
        None, alias='inventory-items'
    )
    dc_inventory_revision: int = Field(..., alias='dc-inventory-revision')
    policy_revision: int = Field(..., alias='policy-revision')


class PolicyChain(BaseModel, populate_by_name=True):
    chain_name: ChainName = Field(..., alias='chain-name')
    rules: List[PolicyRule]

    @field_validator('chain_name', mode="before")
    @classmethod
    def transform_chain_name(cls, v: VisibilityPolicySectionPosition) -> ChainName:
        section_name_to_chain_name = {
            VisibilityPolicySectionPosition.OVERRIDE_ALLOW: ChainName.OVERRIDE_ALLOW,
            VisibilityPolicySectionPosition.OVERRIDE_ALERT: ChainName.OVERRIDE_ALERT,
            VisibilityPolicySectionPosition.OVERRIDE_BLOCK: ChainName.OVERRIDE_BLOCK,
            VisibilityPolicySectionPosition.ALLOW: ChainName.ALLOW,
            VisibilityPolicySectionPosition.ALERT: ChainName.ALERT,
            VisibilityPolicySectionPosition.BLOCK: ChainName.BLOCK
        }
        try:
            return section_name_to_chain_name[v]
        except KeyError:
            return v


class EnforcementPolicy(BaseModel, populate_by_name=True):
    policy_rules: Optional[List[PolicyChain]] = Field(None, alias='policy-rules')
    policy_revision: int = Field(..., alias='policy-revision')
    policy_entity: Optional[str] = Field(None, alias='policy-entity')
