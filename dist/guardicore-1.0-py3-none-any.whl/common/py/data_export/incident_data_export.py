from datetime import datetime

from common.logger import get_logger
from common.py.data_export.cef_export_utils import CefMessageExporter, classify_incident
from common.py.events.mitigation.network import ManagementMatchingVerdict
from common.py.models.events import EventSeverity
from common.py.models.incidents import IncidentType, GenericRevealIncidentType
from common.py.utils.datetime_utils import timestamp_to_date, date_to_iso_timestamp_without_seconds, convert_str_to_date

LOGGER = get_logger()
INCIDENT_TO_CEF_SEVERITY_MAP = {
    EventSeverity.High.value: 8,
    EventSeverity.Medium.value: 5,
    EventSeverity.Low.value: 3
}

SLACK_SEVERITY_COLORS = {
    'low': 'warning',
    'medium': 'warning',
    'high': 'danger'
}


class LabelData(object):
    def __init__(self, id, key, value, name, color_index=-1):
        self.id = id
        self.key = key
        self.value = value
        self.name = name
        self.color_index = color_index


class AffectedAssetExtensionData(object):
    def __init__(self, labels, name='N/A', id='N/A', ip='N/A', source=False, destination=False):
        self.labels = labels
        self.name = name
        self.id = id
        self.ip = ip
        self.source = source
        self.destination = destination

    @classmethod
    def from_dict(cls, data):
        return AffectedAssetExtensionData(labels=[LabelData(**label) for label in data['labels']],
                                          name=data['name'],
                                          id=data['id'],
                                          ip=data['ip'],
                                          source=data['source'],
                                          destination=data['destination']
                                          )


class IncidentExtensions(object):
    def __init__(self, time, incident_id, url, incident_tags, affected_assets, summary, reveal_event_data=None):
        if reveal_event_data is None:
            reveal_event_data = {}
        self.time = time
        self.incident_id = incident_id
        self.url = url
        self.incident_tags = incident_tags
        self.affected_assets = affected_assets
        self.summary = summary
        self.reveal_event_data = reveal_event_data

    # according to Micro Focus Security ArcSight Common Event Format v25
    def to_cef_extensions_details(self, display_rule_id, replace_incidents_text):
        cef_assets_details = [dict(
            start=self.time,
            dvc=asset.ip,
            dvchost=asset.name,
            act='ALERTED_BY_MANAGEMENT',
            cs1Label='SecurityEventUUID' if replace_incidents_text else 'IncidentUUID',
            cs1=self.incident_id,
            cs2Label='SecurityEventURI' if replace_incidents_text else 'IncidentURI',
            cs2=self.url,
            cs3Label='SecurityEventTags' if replace_incidents_text else 'IncidentTags',
            cs3=','.join(self.incident_tags),
            cs4Label='AssetId',
            cs4=asset.id,
            cs5Label='AssetLabels',
            cs5=','.join([label.name for label in asset.labels])
        ) for asset in self.affected_assets]

        if display_rule_id:
            rule_id = self.get_rule_id_value()
            for cef_asset_details in cef_assets_details:
                cef_asset_details['cs6Label'] = 'RuleID'
                cef_asset_details['cs6'] = rule_id

        return cef_assets_details

    def get_rule_id_value(self):
        if self.reveal_event_data.get('rule_id'):
            return self.reveal_event_data.get('rule_id')
        return 'No rule'

    def to_legacy_cef_extensions_details(self, incident_name, severity_name, legacy_type, display_rule_id, replace_incidents_text):
        source_labels = set()
        destination_labels = set()
        for affected_asset in self.affected_assets:
            if affected_asset.source and not source_labels:
                source_labels.update([label.name for label in affected_asset.labels])
            if affected_asset.destination and not destination_labels:
                destination_labels.update([label.name for label in affected_asset.labels])

        cef_assets_details = dict(
            start=self.time,
            act=ManagementMatchingVerdict.ALERTED_BY_MANAGEMENT.name,
            cs1Label='SecurityEventUUID' if replace_incidents_text else 'IncidentUUID',
            cs1=self.incident_id,
            cs2Label='SecurityEventURI' if replace_incidents_text else 'IncidentURI',
            cs2=self.url,
            cs3Label='SecurityEventTags' if replace_incidents_text else 'IncidentTags',
            cs3=','.join(self.incident_tags)
        )

        for affected_asset in self.affected_assets:
            if affected_asset.source:
                if legacy_type == IncidentType.HONEYPOT_INCIDENT_TYPE.value:
                    cef_assets_details['src'] = affected_asset.ip
                else:
                    cef_assets_details['src'] = self.reveal_event_data.get('source_ip')
                cef_assets_details['shost'] = affected_asset.name

            elif affected_asset.destination:
                if legacy_type == IncidentType.HONEYPOT_INCIDENT_TYPE.value:
                    cef_assets_details['dst'] = affected_asset.ip
                else:
                    cef_assets_details['dst'] = self.reveal_event_data.get('destination_ip')
                cef_assets_details['dhost'] = affected_asset.name

        if source_labels:
            cef_assets_details['cs4Label'] = 'SourceLabels'
            cef_assets_details['cs4'] = ','.join(source_labels)
        if destination_labels:
            cef_assets_details['cs5Label'] = 'DestinationLabels'
            cef_assets_details['cs5'] = ','.join(destination_labels)

        if legacy_type == IncidentType.NETWORK_VISIBILITY_INCIDENT_TYPE.value:
            cef_assets_details['dpt'] = self.reveal_event_data.get('destination_port')
            cef_assets_details['proto'] = self.reveal_event_data.get('protocol')
            cef_assets_details['dproc'] = self.reveal_event_data.get('destination_process')
            cef_assets_details['sproc'] = self.reveal_event_data.get('source_process')
            if self.reveal_event_data.get('action'):
                cef_assets_details['act'] = self.reveal_event_data.get('action')

        elif legacy_type == IncidentType.HONEYPOT_INCIDENT_TYPE.value:
            cef_assets_details['dpt'] = self.reveal_event_data.get('destination_port')
            cef_assets_details['proto'] = self.reveal_event_data.get('protocol')

        if legacy_type == IncidentType.INTEGRITY_INCIDENT_TYPE.value:
            cef_assets_details['cs6Label'] = 'FileModifiedTime'
            if self.reveal_event_data.get('file_modified_time'):
                cef_assets_details['cs6'] = date_to_iso_timestamp_without_seconds(
                    datetime.fromisoformat(self.reveal_event_data.get('file_modified_time'))
                )
            cef_assets_details['cs7Label'] = 'FileOwnerName'
            cef_assets_details['cs7'] = self.reveal_event_data.get('file_owner_name')

        if display_rule_id:
            rule_id = self.get_rule_id_value()
            cef_assets_details['cs8Label'] = 'RuleID'
            cef_assets_details['cs8'] = rule_id

        cef_assets_details['msg'] = CefMessageExporter.get_incident_cef_message(
            incident_name,
            severity_name,
            legacy_type,
            cef_assets_details.get('src', ''),
            cef_assets_details.get('dst', ''),
            replace_incidents_text
        )

        return cef_assets_details


class GenericIncidentMessage(object):
    def __init__(self, type, description, severity, extensions, display_rule_id=True,
                 replace_incidents_with_security_event=False):
        self.type = type
        self.description = description
        self.severity = severity
        self.extensions = extensions
        self.display_rule_id = display_rule_id
        self.replace_incidents_with_security_event = replace_incidents_with_security_event

    @classmethod
    def from_dict(cls, data):
        return cls(
            type=data['type'],
            description=data['description'],
            severity=data['severity'],
            extensions=IncidentExtensions(
                time=data['extensions']['time'],
                incident_id=data['extensions']['incident_id'],
                url=data['extensions']['url'],
                incident_tags=data['extensions']['incident_tags'],
                affected_assets=[AffectedAssetExtensionData.from_dict(asset) for asset in
                                 data['extensions']['affected_assets']],
                summary=data['extensions']['summary'],
                reveal_event_data=data['extensions']['reveal_event_data']
            )
        )

    def to_cef_details(self):
        return [dict(
            device_event_class_id=self.type,
            name=self.description,
            severity=INCIDENT_TO_CEF_SEVERITY_MAP[self.severity],
            extensions=extensions_details
        ) for extensions_details in self.extensions.to_cef_extensions_details(self.display_rule_id,
                                                                              self.replace_incidents_with_security_event)]

    @staticmethod
    def _to_legacy_incident_type(incident_type):
        incident_to_legacy = {
            GenericRevealIncidentType.POLICY_VIOLATION.value: IncidentType.NETWORK_VISIBILITY_INCIDENT_TYPE.value,
            GenericRevealIncidentType.BAD_REPUTATION.value: IncidentType.NETWORK_VISIBILITY_INCIDENT_TYPE.value,
            IncidentType.LATERAL_MOVEMENT_INCIDENT_TYPE.value: IncidentType.HONEYPOT_INCIDENT_TYPE.value
        }
        return incident_to_legacy.get(incident_type, incident_type)

    def to_legacy_cef_details(self):
        severity_name = EventSeverity(self.severity).name
        legacy_type = self._to_legacy_incident_type(self.type)
        classification_tags = self.extensions.incident_tags.copy()
        if self.type == GenericRevealIncidentType.BAD_REPUTATION.value:
            classification_tags.append('Reputation')
        incident_classifications = classify_incident(self.extensions.incident_id, legacy_type,
                                                     EventSeverity[severity_name].value, classification_tags)
        incident_legacy_title = ','.join(incident_classifications) or 'Not Classified'

        return [dict(
            device_event_class_id=legacy_type + " Security Event" if self.replace_incidents_with_security_event else legacy_type + " Incident",
            name=incident_legacy_title.replace("_", " ").title(),
            severity=severity_name.lower(),
            extensions=self.extensions.to_legacy_cef_extensions_details(incident_legacy_title,
                                                                        severity_name,
                                                                        legacy_type,
                                                                        self.display_rule_id,
                                                                        self.replace_incidents_with_security_event)
        )]

    def to_rfc5424_details(self):
        incident_id = self.extensions.incident_id
        affected_assets = list()
        source_labels = set()
        destination_labels = set()
        for affected_asset in self.extensions.affected_assets:
            asset_id = affected_asset.name if affected_asset.ip == 'N/A' else affected_asset.ip
            if affected_asset.source:
                asset_id = '{} (source)'.format(asset_id)
            elif affected_asset.destination:
                asset_id = '{} (destination)'.format(asset_id)
            affected_assets.append(asset_id)
            source_labels.update([label.name for label in affected_asset.labels if affected_asset.source])
            destination_labels.update([label.name for label in affected_asset.labels if affected_asset.destination])
        labels = list(source_labels)
        destination_labels = list(destination_labels)
        if source_labels:
            labels[0] = 'Source labels: {}'.format(labels[0])
        if destination_labels:
            destination_labels[0] = 'Destination labels: {}'.format(destination_labels[0])
        labels.extend(destination_labels)

        rfc5424_details = dict(
            incident_id=incident_id,
            url=self.extensions.url,
            severity=EventSeverity(self.severity).name.lower(),
            tags=self.extensions.incident_tags,
            summary=self.extensions.summary.replace('\n', ';'),
            description=self.description,
            assets=affected_assets,
            labels=labels,
            start_time=timestamp_to_date(self.extensions.time),
            end_time=timestamp_to_date(self.extensions.time),
        )
        if self.replace_incidents_with_security_event:
            rfc5424_details['security_event_id'] = rfc5424_details.pop('incident_id')

        if self.display_rule_id:
            rfc5424_details['rule_id'] = self.extensions.get_rule_id_value()

        if self.type == IncidentType.INTEGRITY_INCIDENT_TYPE.value:
            rfc5424_details['file_owner_name'] = self.extensions.reveal_event_data.get('file_owner_name')
            if self.extensions.reveal_event_data.get('file_modified_time'):
                rfc5424_details['file_modified_time'] = date_to_iso_timestamp_without_seconds(
                    datetime.fromisoformat(self.extensions.reveal_event_data.get('file_modified_time')))

        # return a List[dict] to fit the interfaced defined by to_cef_messages
        return [rfc5424_details]

    def to_native_details(self):
        incident_id = self.extensions.incident_id
        affected_assets = [affected_asset.name if affected_asset.ip == 'N/A' else affected_asset.ip
                           for affected_asset in self.extensions.affected_assets]
        affected_labels = set()
        for affected_asset in self.extensions.affected_assets:
            affected_labels.update([label.name for label in affected_asset.labels])
        affected_labels = list(affected_labels)

        # return a List[dict] to fit the interfaced defined by to_cef_messages
        native_details_interface = [dict(
            incident_id=incident_id,
            url=self.extensions.url,
            severity=EventSeverity(self.severity).name.lower(),
            tags=self.extensions.incident_tags,
            summary=self.extensions.summary,
            description=self.description,
            assets=affected_assets,
            labels=affected_labels,
            start_time=timestamp_to_date(self.extensions.time),
            end_time=timestamp_to_date(self.extensions.time),
        )]

        if self.replace_incidents_with_security_event:
            for native_details in native_details_interface:
                # poping incide_id to later use the logic in event_syslog._prepare_incident_text_message function
                native_details['security_event_id'] = native_details.pop('incident_id')

        if self.display_rule_id:
            for native_details in native_details_interface:
                rule_id = self.extensions.get_rule_id_value()
                native_details['rule_id'] = rule_id

        return native_details_interface

    def to_email(self):
        email_messages = []
        for details in self.to_native_details():
            email_messages.append(
                'New {severity} severity security incident reported by the Guardicore Security Suite\n\n' \
                'ID: {incident_id}\n' \
                'URL: {incident_url}\n\n' \
                'Description: {description}\n\n' \
                'Severity: {severity}\n' \
                'Start Time: {start_time}\n' \
                'End Time: {end_time}\n\n' \
                'Affected Assets:\n{assets}\n\n' \
                'Tags: {tags}\n\n' \
                'Summary: \n{summary}'.format(incident_id=details['incident_id'],
                                              incident_url=details['url'],
                                              severity=details['severity'],
                                              tags=', '.join(details['tags']),
                                              summary=details['summary'],
                                              description=details['description'],
                                              assets='\n'.join(details['assets']),
                                              start_time=details['start_time'].strftime("%Y-%m-%d %H:%M:%S"),
                                              end_time=details['end_time'].strftime("%Y-%m-%d %H:%M:%S")))
        return email_messages

    def to_slack(self, slack_site_name):
        slack_site_name = 'at'.format(slack_site_name) if slack_site_name else ''
        slack_attachments = []
        for details in self.to_native_details():
            color = SLACK_SEVERITY_COLORS.get(details['severity'], '')
            title = 'New Incident <{url}|INC-{id}> {name}'.format(url=details['url'],
                                                                  id=details['incident_id'][:8],
                                                                  name=slack_site_name)

            slack_attachments.append(dict(
                fallback='New {} severity security incident '
                         'reported by the Guardicore Security Suite.'.format(details['severity']),
                text=title,
                color=color,
                fields=[
                    dict(title='ID', value=details['incident_id'], short=False),
                    dict(title='URL', value=details['url'], short=False),
                    dict(title='Description', value=details['description'], short=False),
                    dict(title='Severity', value=details['severity'].capitalize(), short=False),
                    dict(title='Start Time', value=details['start_time'].strftime('%Y-%m-%d %H:%M:%S'), short=False),
                    dict(title='End Time', value=details['end_time'].strftime('%Y-%m-%d %H:%M:%S'), short=False),
                    dict(title='Affected Assets', value='\n'.join(details['assets']), short=False),
                    dict(title='Tags', value=', '.join(details['tags']), short=False),
                    dict(title='Summary', value=details['summary'], short=False),
                ]
            ))
        return slack_attachments
