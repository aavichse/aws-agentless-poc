import datetime
import logging
import sys

import ldap3
import ldap3.core.exceptions
import ldap3.utils.conv
from enum import Enum
from ldap3.protocol.microsoft import show_deleted_control
from ldap3.utils.log import set_library_log_activation_level, set_library_log_detail_level, EXTENDED, BASIC, ERROR
from ldap3.utils.dn import parse_dn

from common.py.model.exceptions import GuardicoreException

try:
    from gevent import Timeout
    from common.py.utils.gevent.utils import TimeoutBoundedSemaphore
except ImportError:
    from eventlet import Timeout
    TimeoutBoundedSemaphore = None

from common.logger import get_logger
from common.py.utils.config import cfg
from common.py.apis.active_directory.utils import domain_name_to_dn, domain_name_from_dn, is_with_domain_name, \
                                               is_sub_domain_of, split_user_and_domain_name, is_same_domain

__author__ = 'Rony'

LOGGER = get_logger()

TIMED_OUT_ERROR_MESSAGE = 'Operation has timed out'


class ADObjectTypes(Enum):
    User = "person"
    Group = "group"


class LDAPFailedConnection(Exception):
    pass


LDAP_API_OPTS = [
    # Check Point rest server
    cfg.IntOpt('search_timeout_sec', default=40,
               help="Timeout for search operation on ldap"),
    cfg.IntOpt('lock_acquisition_timeout', default=10,
               help="Timeout for ldap acquisition lock")
]
cfg.CONF.register_opts(LDAP_API_OPTS, 'ldapapi')


class LDAPAPI(object):
    DEFAULT_PAGED_SIZE = 500
    ENABLE_CACHE_RESPONSE = True

    def __init__(self, hosts, username, password, domain_name, base_dn=None, use_ssl=True,
                 connect_timeout=None, ldap_operations_hard_timeout=None, client_strategy=ldap3.RESTARTABLE,
                 get_info=ldap3.SCHEMA, lock_class=TimeoutBoundedSemaphore, restartable_retries=None):
        self.connection = None
        self.added = datetime.datetime.utcnow()
        self.domain_name = domain_name
        # e.g. DC=contoso,DC=microsoft,DC=com
        self.base_dn = self._validate_dn(base_dn, domain_name)
        self._connect_timeout = connect_timeout
        self._ldap_operations_hard_timeout = ldap_operations_hard_timeout
        self._client_strategy = client_strategy
        if restartable_retries:
            ldap3.set_config_parameter('RESTARTABLE_TRIES', restartable_retries)
        resp = self.connect(hosts, username, password, use_ssl, connect_timeout=connect_timeout,
                            connect_hard_timeout=ldap_operations_hard_timeout, client_strategy=client_strategy,
                            get_info=get_info)
        self.hosts = hosts
        self.use_ssl = use_ssl
        if resp['status']:
            self.connection = resp['connection']
            self.server_pool = resp['server_pool']
        else:
            raise LDAPFailedConnection(resp['error'])
        if not lock_class:
            raise GuardicoreException("'lock_class' is None")
        self._conn_lock = lock_class(value=1)

    def __del__(self):
        self.disconnect()

    @staticmethod
    def _validate_dn(base_dn, domain_name):
        if not base_dn:
            return domain_name_to_dn(domain_name)

        elements = parse_dn(base_dn, strip=True)
        valid_dn = ''.join(['{}={}{}'.format(attribute_name, value, separator)
                            for attribute_name, value, separator in elements])
        return valid_dn

    @classmethod
    def _run_with_timeout(cls, func, hard_timeout, *args, **kwargs):
        try:
            with Timeout(seconds=hard_timeout):
                return func(*args, **kwargs)
        except Timeout:
            LOGGER.debug("[Active Directory] Operation '%s' has timed out", func.__name__)
            return dict(status=False, error=TIMED_OUT_ERROR_MESSAGE)

    def disconnect(self):
        """
        Disconnects from DC.
        """
        if self.connection is not None:
            LOGGER.debug('[Active Directory] Disconnecting from %s pool of ldap servers', self.hosts)
            with self._conn_lock(timeout=None):
                self._run_with_timeout(self.connection.unbind, hard_timeout=self._ldap_operations_hard_timeout)
            self.connection = None

    def _sam_account_name_with_domain(self, sam_account_name):
        base_dn = self.base_dn
        domain_name = None

        if is_with_domain_name(sam_account_name):
            # Guardicore proprietary psuedo SAM account name: group@domain
            split_domain_name = split_user_and_domain_name(sam_account_name)
            if is_sub_domain_of(split_domain_name[1], self.domain_name):
                sam_account_name, domain_name = split_domain_name
                base_dn = domain_name_to_dn(domain_name)

        return sam_account_name, domain_name, base_dn

    def _get_object_attributes(self, sam_account_name, attributes, generated_attributes=None, object_type=None):
        """
        Fetches attribute values for an object which can have duplicates and return results as list
         (identified by the given sAMAccountName and optional object type).
        :param sam_account_name: Guardicore psuedo sAMAccountName of the object queried for
        :param attributes: List of attributes to fetch
        :param generated_attributes: List of on-the-fly attributes to generate
        :param object_type: Optional object category to filter by
        :return: A list of dicts, each with the attributes (as keys) and their respective values, or empty list if no object was found
        """
        if generated_attributes is None:
            generated_attributes = {}

        sam_account_name, domain_name, base_dn = self._sam_account_name_with_domain(sam_account_name)

        escaped_sam_account_name = ldap3.utils.conv.escape_filter_chars(sam_account_name)

        if object_type is None:
            search_filter = '(sAMAccountName={})'.format(escaped_sam_account_name)
        else:
            search_filter = '(&(sAMAccountName={})(objectCategory={}))'.format(escaped_sam_account_name, object_type)

        with self._conn_lock(timeout=cfg.CONF.ldapapi.lock_acquisition_timeout):
            search_result = \
                self._run_with_timeout(self.connection.search, hard_timeout=self._ldap_operations_hard_timeout,
                                       search_base=base_dn, search_filter=search_filter, attributes=attributes,
                                       time_limit=cfg.CONF.ldapapi.search_timeout_sec)

        if isinstance(search_result, dict) and search_result.get('error') == TIMED_OUT_ERROR_MESSAGE:
            raise LDAPFailedConnection('Search timed out (base=%s, filter=%s, attributes=%r)' %
                                       (self.base_dn, search_filter, attributes))

        if self.connection.result['description'] != 'success':
            raise LDAPFailedConnection('Search error (base=%s, filter=%s, attributes=%r)' %
                                       (self.base_dn, search_filter, attributes))

        all_attributes = []
        for entry in self.connection.response:
            entry_attributes = entry.get('attributes')
            dn = entry.get('dn')
            if not entry_attributes or not dn:
                continue

            sub_domain_name = domain_name_from_dn(entry['dn'])
            if domain_name:
                if not is_same_domain(sub_domain_name, domain_name):
                    continue
                if 'sAMAccountName' in entry_attributes:
                    entry_attributes['sAMAccountName'] += '@{}'.format(sub_domain_name)

            if 'domainName' in generated_attributes:
                entry_attributes['domainName'] = sub_domain_name
            all_attributes.append(entry_attributes)

        return all_attributes

    def _get_object_dn(self, object_sam_account_name, object_type):
        """
        Returns object's distinguished name.
        :param object_sam_account_name: Guardicore psuedo sAMAccountName
        :param object_type: Person or group
        :return: object's distinguished name or None if not found
        """
        sam_account_name, domain_name, base_dn = self._sam_account_name_with_domain(object_sam_account_name)

        search_filter = '(&(sAMAccountName={})(objectCategory={}))'.format(
            ldap3.utils.conv.escape_filter_chars(sam_account_name), object_type)

        with self._conn_lock(timeout=cfg.CONF.ldapapi.lock_acquisition_timeout):
            search_result = \
                self._run_with_timeout(self.connection.search, hard_timeout=self._ldap_operations_hard_timeout,
                                       search_base=base_dn,
                                       search_filter=search_filter,
                                       attributes=[],
                                       time_limit=cfg.CONF.ldapapi.search_timeout_sec)

        if isinstance(search_result, dict) and search_result.get('error') == TIMED_OUT_ERROR_MESSAGE:
            raise LDAPFailedConnection('Search timed out (base=%s, filter=%s)' % (self.base_dn, search_filter))

        if self.connection.result['description'] != 'success':
            raise LDAPFailedConnection('Search error (base=%s, filter=%s)' % (self.base_dn, search_filter))

        for entry in self.connection.response:
            if 'dn' not in self.connection.response[0]:
                continue
            if not domain_name:
                return entry['dn']
            if is_sub_domain_of(domain_name_from_dn(entry['dn']), domain_name):
                return entry['dn']

        return None

    def _is_member_of_groups(self, groups_sids, user_dn, cached_user_response):
        """
        Checks if the given user_dn is a member of at least one of the groups specified by groups_sids
        :param groups_sids: Set of groups's SIDs to check against
        :param user_dn: The DN of the user to check
        :param cached_user_response: Cached response frmo previous search
        :return: True if the user is a member (of any of the given groups), False if not
        """
        is_member = False
        if user_dn in cached_user_response:
            response = cached_user_response[user_dn]
            LOGGER.debug("[Active Directory] response for user: %s already cached", user_dn)
        else:
            search_filter = '(distinguishedname={})'.format(ldap3.utils.conv.escape_filter_chars(user_dn))
            LOGGER.debug("[Active Directory] search_filter: %r", search_filter)
            with self._conn_lock(timeout=cfg.CONF.ldapapi.lock_acquisition_timeout):
                search_result = \
                    self._run_with_timeout(self.connection.search, hard_timeout=self._ldap_operations_hard_timeout,
                                           search_base=user_dn,
                                           search_filter=search_filter,
                                           search_scope=ldap3.BASE,
                                           attributes='tokenGroups',
                                           time_limit=cfg.CONF.ldapapi.search_timeout_sec)

            if isinstance(search_result, dict) and search_result.get('error') == TIMED_OUT_ERROR_MESSAGE:
                raise LDAPFailedConnection('Search timed out (base=%s, filter=%s, attributes=tokenGroups)' %
                                           (self.base_dn, search_filter))

            if self.connection.result['description'] != 'success':
                raise LDAPFailedConnection('Search error (base=%s, filter=%s, attributes=tokenGroups)' %
                                           (self.base_dn, search_filter))

            response = self.connection.response
            if LDAPAPI.ENABLE_CACHE_RESPONSE:
                cached_user_response[user_dn] = response

        for entry in response:
            if 'attributes' in entry:
                is_member = any(ldap3.protocol.formatters.formatters.format_sid(group_sid) in groups_sids
                                for group_sid in entry['attributes'].get('tokenGroups'))

        LOGGER.debug("[Active Directory] user %r is_member: %r of groups_sids: %r", user_dn, is_member, groups_sids)
        return is_member

    @classmethod
    def server_from_host(cls, host, connect_timeout, use_ssl=True, get_info=ldap3.SCHEMA):
        """
        Build a server object for LDAP connection
        :param host: DC's hostname or IP, with or without port (dc.contoso.microsoft.com:443)
        :param use_ssl: Connect via SSL or not
        :param connect_timeout: timeout in seconds for the ldap connect operation
        :param get_info: specifies if the server schema and server specific info must be read
        :return: Server object of the host
        """
        host_port = None
        host_name = host
        if ':' in host:
            host_name, host_port = host.split(':')
            host_port = int(host_port)
        return ldap3.Server(host_name, port=host_port, use_ssl=use_ssl,
                            connect_timeout=connect_timeout, get_info=get_info)

    @classmethod
    def connect(cls, hosts, username, password, use_ssl=True, connect_timeout=None, connect_hard_timeout=None,
                client_strategy=ldap3.RESTARTABLE, get_info=ldap3.SCHEMA):
        return cls._run_with_timeout(cls._connect, hosts=hosts, username=username, password=password,
                                     connect_timeout=connect_timeout, use_ssl=use_ssl, client_strategy=client_strategy,
                                     get_info=get_info, hard_timeout=connect_hard_timeout)

    @classmethod
    def set_ldap_log_level(cls, log_handler=None, log_level=logging.DEBUG):
        """
        Log LDAP messages to stdout or to existing log handler
        :param log_handler: use existing log handler to log ldap3 messages
        :param log_level: ldap3 log level
        :return:
        """
        ldap_logger = logging.getLogger('ldap3')
        if not log_handler:
            log_handler = logging.StreamHandler(sys.stdout)
            log_handler.setLevel(log_level)
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            log_handler.setFormatter(formatter)
        ldap_logger.addHandler(log_handler)
        ldap_logger.setLevel(log_level)
        set_library_log_activation_level(log_level)
        if log_level == logging.DEBUG:
            log_detail_level = EXTENDED
        elif log_level == logging.ERROR:
            log_detail_level = ERROR
        else:
            log_detail_level = BASIC
        set_library_log_detail_level(log_detail_level)

    @classmethod
    def _connect(cls, hosts, username, password, connect_timeout, use_ssl=True, client_strategy=ldap3.RESTARTABLE,
                 get_info=ldap3.SCHEMA):
        """
        Connects to DC using the given credentials
        :param hosts: List of DCs' hostname or IP, with or without port (dc.contoso.microsoft.com:443)
        :param username: Username as principal name (rony@contoso.microsoft.com)
        :param password: Password
        :param use_ssl: Connect via SSL or not
        :param get_info: specifies if the server schema and server specific info must be read
        """
        try:
            server_pool = ldap3.ServerPool(active=3, exhaust=600)
            for host in hosts:
                server = cls.server_from_host(host, connect_timeout=connect_timeout, use_ssl=use_ssl, get_info=get_info)
                server_pool.add(server)
            LOGGER.debug('[Active Directory] Trying to connect to %s pool of ldap server with user %s and strategy %s',
                         hosts, username, client_strategy)
            connection = ldap3.Connection(server=server_pool, user=username, client_strategy=client_strategy,
                                          password=password, read_only=True)
            if not connection.bind():
                LOGGER.error("Connection fail, {}".format(connection.result))
                return dict(status=False, error='Invalid username or password')
            return dict(status=True, connection=connection, server_pool=server_pool)
        except (ldap3.core.exceptions.LDAPMaximumRetriesError, ldap3.core.exceptions.LDAPServerPoolExhaustedError,
                ldap3.core.exceptions.LDAPSocketOpenError) as e:
            LOGGER.error("Connection error")
            LOGGER.exception(e)
            return dict(status=False, error='Server is unreachable')

    def get_registered_sam_account_info(self, sam_account_name, object_type):
        entries_attributes = self._get_object_attributes(sam_account_name,
                                                         attributes=['sAMAccountName', 'objectSid'],
                                                         generated_attributes=['domainName'],
                                                         object_type=object_type)
        return [{'name': entry_attributes.get('sAMAccountName'),
                 'sid': entry_attributes.get('objectSid'),
                 'domain_name': entry_attributes.get('domainName'),
                 } for entry_attributes in entries_attributes]

    def filter_users_in_groups(self, usernames, groups, cached_user_response):
        """
        Filter users that aren't members of any of the given groups from the users list
        :param usernames: Users list (rony@contoso.microsoft.com)
        :param groups: Groups that the users should be members of (dictionary that contains SID)
        :return: Set of users that are members of one of the given groups.
        """
        groups_users = []
        groups_sids = set(group['sid'] for group in groups)

        for user in usernames:
            user_dn = self._get_object_dn(user, ADObjectTypes.User.value)
            if user_dn is not None:
                if self._is_member_of_groups(groups_sids, user_dn, cached_user_response):
                    groups_users.append(user)
            else:
                LOGGER.debug("[Active Directory] user '%r' was not found", user)

        return groups_users

    def validate_group(self, group_sAMAccountName):
        """
        Check if group exists in domain
        :param group_sAMAccountName: Group's sAMAccountName
        :return: True if exists in domain and False otherwise
        """
        return self._get_object_dn(group_sAMAccountName, ADObjectTypes.Group.value) is not None

    def validate_user(self, user_sAMAccountName):
        """
        Check if user exists in domain
        :param user_sAMAccountName: User's sAMAccountName
        :return: True if exists in domain and False otherwise
        """
        return self._get_object_dn(user_sAMAccountName, ADObjectTypes.User.value) is not None

    def get_all_groups(self, attributes=None, paged=True, paged_size=DEFAULT_PAGED_SIZE):
        return self.get_groups(attributes=attributes, paged=paged, paged_size=paged_size)

    def get_groups(self, search_scope=ldap3.SUBTREE, attributes=None, size_limit=0, time_limit=0, paged=False,
                   paged_size=DEFAULT_PAGED_SIZE, usn_changed=None, group_filter=None):
        """
        Preform LDAP search operation with group filter.
        If the operation is about to return long list of entries it's better to use paged search.
        Note that some LDAP servers like MS AD do not honor size_limit and return max 1000 entries in non-paged search
        :param search_scope: SUBTREE, LEVEL or BASE
        :param attributes: list of LDAP attributes
        :param size_limit: max amount of groups
        :param time_limit: maximum search time
        :param paged: set to True to use paged search (RFC2696)
        :param paged_size: amount of entries per page
        :param usn_changed: if provided, filter only groups with uSNChanged attribute >= usn_changed
        :param group_filter: optional group filter
        :return: list of searchResEntry if paged=False, otherwise a generator is returned
        """

        search_filter = '&(objectCategory={})'.format(ADObjectTypes.Group.value)
        if usn_changed:
            search_filter += '(uSNChanged>={})'.format(str(usn_changed))
        if group_filter:
            search_filter += group_filter

        search_filter = '({})'.format(search_filter)
        if paged:
            return self.connection.extend.standard.paged_search(search_base=self.base_dn,
                                                                search_filter=search_filter,
                                                                search_scope=search_scope,
                                                                attributes=attributes,
                                                                paged_size=paged_size,
                                                                generator=True)

        if not self.connection.search(search_base=self.base_dn,
                                      search_filter=search_filter,
                                      search_scope=search_scope,
                                      attributes=attributes,
                                      size_limit=size_limit,
                                      time_limit=time_limit):
            return []

        return self.connection.response

    def get_deleted_objects(self, search_scope=ldap3.SUBTREE, attributes=None, size_limit=0, time_limit=0, paged=False,
                            paged_size=DEFAULT_PAGED_SIZE):
        """
        Lookup deleted LDAP objects in the search scope from the AD deleted objects container.
        NB: most of the object attribute disappear when it's moved to the deleted container so there's no point
        limiting the search filter e.g. to objectCategory=group since the lookup will yield no results
        Deleted objects remain in the container only for the amount of `tombstoneLifetime` attribute specified in
        https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-adts/1887de08-2a9e-4694-95e2-898cde411180
        :param search_scope: SUBTREE, LEVEL or BASE
        :param attributes: list of LDAP attributes
        :param size_limit: max amount of objects
        :param time_limit: maximum search time
        :param paged: set to True to use paged search (RFC2696)
        :param paged_size: amount of entries per page
        :return: list of searchResEntry if paged=False, otherwise a generator is returned
        """

        search_filter = '(&(isDeleted=TRUE))'
        if paged:
            return self.connection.extend.standard.paged_search(search_base=self.base_dn,
                                                                search_filter=search_filter,
                                                                search_scope=search_scope,
                                                                attributes=attributes,
                                                                paged_size=paged_size,
                                                                generator=True,
                                                                controls=[show_deleted_control(criticality=True)])

        if not self.connection.search(search_base=self.base_dn,
                                      search_filter=search_filter,
                                      search_scope=search_scope,
                                      attributes=attributes,
                                      size_limit=size_limit,
                                      time_limit=time_limit,
                                      controls=[show_deleted_control(criticality=True)]):
            return []

        return self.connection.response

    def get_domain_service_info(self, attributes=None):
        """
        Get the domain controller's service object from DSA service information
        :param attributes: list of LDAP attributes
        :return: First search result entry corresponding to ds_service_name
        """
        self.connection.server.get_info_from_server(self.connection)
        if not self.connection.server.info:
            LOGGER.warning("Failed to get DSA info from LDAP server")
            return None

        # read the dsServiceName attribute of the rootDSE
        ds_service_name = self.connection.server.info.other.get('dsServiceName')
        if not ds_service_name:
            LOGGER.warning("Failed to get dsServiceName from LDAP server")
            return None

        if isinstance(ds_service_name, list) and len(ds_service_name) > 0:
            ds_service_name = ds_service_name[0]

        if self.connection.search(search_base=ds_service_name,
                                  search_filter='(&(objectClass=*))',
                                  search_scope=ldap3.BASE,
                                  attributes=attributes):
            if isinstance(self.connection.response, list) and len(self.connection.response) > 0:
                return self.connection.response[0]

        return None

    def update_hosts(self, hosts):
        """
        Update server pool to contain only given hosts
        :param hosts: List of hostnames or IPs, with or without port (dc.contoso.microsoft.com:443)
        """
        # add missing hosts
        for host in hosts:
            if host not in self.hosts:
                server = self.server_from_host(host=host, use_ssl=self.use_ssl, connect_timeout=self._connect_timeout)
                self.server_pool.add(server)
                self.hosts.append(host)
        # remove irrelevant hosts
        for host in self.hosts:
            if host not in hosts:
                server = self.server_from_host(host=host, use_ssl=self.use_ssl, connect_timeout=self._connect_timeout)
                self.server_pool.remove(server)
        self.hosts = hosts
